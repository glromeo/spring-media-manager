import Highcharts, {HTMLDOMElement} from "highcharts/highstock";

import "./AtwChart.scss";
import {useLayoutEffect, useRef} from "react";

export function AtwChart({data}: { data: any[] }) {

    const container = useRef<HTMLDOMElement>(null);

    useLayoutEffect(() => {

        if (container.current) {
            let price = data.map(axe => axe.price).filter(p => p);
            let volume = data.map(axe => axe.actualSize).filter(v => v);
            Highcharts.stockChart(container.current, {
                        yAxis: [{
                            startOnTick: false,
                            labels: {
                                align: "left"
                            },
                            height: "60%",
                            resize: {
                                enabled: true
                            }
                        }, {
                            startOnTick: false,
                            labels: {
                                align: "left"
                            },
                            top: "66%",
                            height: "33%",
                            offset: 0
                        }],
                        xAxis: {
                            startOnTick: false,
                            type: 'category',
                            gridLineWidth: 1,
                            tickmarkPlacement: 'between'
                        },
                        series: [{
                            type: "line",
                            id: "price",
                            name: "Price",
                            data: price
                        }, {
                            type: "column",
                            id: "volume",
                            name: "Volume",
                            data: volume,
                            yAxis: 1
                        }]
                    });
        }

    }, [data, container]);

    return (
        <div className="atw-chart">
            <div ref={container} className="atw-chart-container"/>
        </div>
    );
}