export function AtwCheckbox(props: { label: string, checked: boolean, onChange: (checked: boolean) => void }) {
    const {label, checked, onChange} = props;
    return (
        <label className="atw-checkbox">
            <input type="checkbox" name="atw-checkbox" checked={checked} onChange={() => onChange(!checked)}/>
            {label}
        </label>
    );
}