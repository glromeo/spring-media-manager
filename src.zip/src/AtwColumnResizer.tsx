import "./AtwColumnResizer.scss";
import {useCallback} from "react";

type ColumnResizerProps = {
    width: number;
    minWidth?: number;
    inverse?: boolean;
    onResize: (deltaX: number) => void;
    onMouseUp: (deltaX: number) => void;
    container?: HTMLDivElement | null
};

export const columnResizer = {
    isResizing: false
};

export function AtwColumnResizer({width, minWidth = 32, inverse, onResize, onMouseUp, container}: ColumnResizerProps) {
    const onMouseDown = useCallback(
        function (trigger) {
            trigger.preventDefault();
            trigger.stopPropagation();

            document.body.addEventListener("mousemove", dragHandler);
            document.body.addEventListener("mouseup", dragHandler);

            const initialX = trigger.pageX;
            const initialLeft = container?.scrollLeft ?? 0;

            columnResizer.isResizing = true;

            let commit = 0, af: number;

            function dragHandler(mouseEvent: MouseEvent) {
                if (mouseEvent.buttons !== 1) {
                    document.body.removeEventListener("mousemove", dragHandler);
                    document.body.removeEventListener("mouseup", dragHandler);
                    requestAnimationFrame(function () {
                        columnResizer.isResizing = false;
                        onMouseUp(commit);
                    });
                } else {
                    let deltaX = inverse ? initialX - mouseEvent.pageX : mouseEvent.pageX - initialX;

                    cancelAnimationFrame(af);

                    af = requestAnimationFrame(function () {
                        const update = Math.round(Math.max(minWidth, width + deltaX) - width);
                        onResize(update);
                        if (container && inverse) {
                            container.scrollLeft = update + initialLeft;
                        }
                        commit = update;
                    });
                }
            }
        },
        [width, minWidth, onResize, onMouseUp]
    );
    let className = "resizer";
    if (inverse) {
        className += " inverse";
    }
    return <div className={className} onMouseDown={onMouseDown}/>;
}
