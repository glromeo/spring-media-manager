import React, {
    CSSProperties,
    MouseEvent,
    MouseEventHandler,
    useCallback,
    useEffect,
    useMemo,
    useRef,
    useState
} from "react";
import {columnResizer} from "./AtwColumnResizer";
import {useViewport} from "./useViewport";
import {Bucket, useBuckets} from "./useBuckets";

import "./AtwGrid.scss";
import {AtwGridGroupBy} from "./AtwGridGroupBy";
import {AtwGridHeader} from "./AtwGridHeader";
import {AtwGridBody, INITIAL_RANGE} from "./AtwGridBody";
import {AtwGridContainer} from "./AtwGridContainer";

export type AtwCellRenderer<T extends DataItem> = (data: T, column: AtwColumn<T>) => JSX.Element | null;
export type AtwCellRenderDecorator<T extends DataItem> = (render: AtwCellRenderer<T>) => AtwCellRenderer<T>;

export type DataItem = { id: any, $$bucket?: Bucket<any> };

export type AtwColumnDef<T extends DataItem> = {
    label: string;
    field: keyof T;
    type: "string" | "number" | "date" | "object"
    render?: AtwCellRenderer<T>;
    minWidth?: number;
    preferredWidth: number;
    width: number;
    className?: string;
    sort: ["asc" | "desc", number] | [];
    style?: CSSProperties;
    resizable: boolean;
    sortable: boolean;
    pinned?: boolean;
};

export type AtwColumn<T extends DataItem> = AtwColumnDef<T> & {
    index: number;
    render: AtwCellRenderer<T>;
    style: CSSProperties;
    onSort?: MouseEventHandler<HTMLDivElement>
}

// const TEXT_ALIGN: any = {
//     "0": "center",
//     "1": "left",
//     "2": "right",
// };

export type AtwGroupTotals<T extends DataItem> = Map<keyof T, null | { name: keyof T, fn: (items: T[], field: keyof T) => number }>;
export type AtwGroupBy<T extends DataItem> = Map<keyof T, AtwGroupTotals<T>>;

export type AtwGridProps<T extends DataItem> = {
    inverse?: boolean;
    columnDefs: AtwColumnDef<T>[];
    data: T[];
    rowHeight: number;
    onColumnResize?: (column: AtwColumnDef<T>, width: number) => void;
    onSort?: (columnDef: AtwColumnDef<T>, shiftKey: boolean) => void;
    onScroll?: (gridElement: HTMLDivElement) => void;
    groupBy?: AtwGroupBy<T>;
    onGroupBy?: (update: AtwGroupBy<T>) => void;
    dnd?: boolean;
    onDnD?: (sourceColumnIndex: number, destinationColumnIndex: number) => void;
};

export type VisibleRange = {
    topIndex: number
    bottomIndex: number
    leftIndex: number
    rightIndex: number
}

export type AtwGridContext<T extends DataItem> = {
    grid: HTMLDivElement;
    inverse: boolean;
    dnd: boolean;
    groupBy?: AtwGroupBy<T>;
    onGroupBy?: (update: AtwGroupBy<T>) => void;
    range: VisibleRange;
}

export const AtwGridContext = React.createContext<AtwGridContext<DataItem>>(null as any);

/**
 *           _             _____      _     _
 *      /\  | |           / ____|    (_)   | |
 *     /  \ | |___      _| |  __ _ __ _  __| |
 *    / /\ \| __\ \ /\ / / | |_ | '__| |/ _` |
 *   / ____ \ |_ \ V  V /| |__| | |  | | (_| |
 *  /_/    \_\__| \_/\_/  \_____|_|  |_|\__,_|
 *
 * @param inverse
 * @param columnDefs
 * @param data
 * @param onColumnResize
 * @param onSort
 * @param onScroll
 * @param onDnD
 * @param groupBy
 * @param onGroupBy
 * @param dnd
 * @constructor
 */
export function AtwGrid<T extends DataItem>(props: AtwGridProps<T>) {
    const {
        inverse = false,
        columnDefs,
        data,
        rowHeight,
        onColumnResize,
        onSort,
        onScroll,
        onDnD,
        groupBy,
        onGroupBy,
        dnd = true
    } = props;

    const [pinned, setPinned] = useState<AtwColumn<T>[]>([]);
    const [columns, setColumns] = useState<AtwColumn<T>[]>([]);

    const [rows, renderGroupBy] = useBuckets(data, groupBy, bucket => {
        setPinned([...pinned]);
        setColumns([...columns]);
    });

    useEffect(() => {

        const pinned:AtwColumn<T>[] = [];
        const columns:AtwColumn<T>[] = [];

        columnDefs.forEach((columnDef, index) => {

            let {field, type, render, className, style, width, pinned: isPinned} = columnDef;
            if (!render) {
                render = useCellRenderer(columnDef);
            }
            if (groupBy?.has(field)) {
                render = renderGroupBy(render);
                isPinned = true;
            }
            className = className ? `atw-grid-cell ${className}` : "atw-grid-cell";
            if (type === "number" || type === "date") {
                className += " justify-right";
            } else {
                className += " justify-left";
            }

            (isPinned ? pinned : columns).push({
                ...columnDef,
                index,
                className,
                pinned: isPinned,
                render,
                style: {
                    ...style,
                    width
                },
                onSort: columnDef.sortable && onSort ? ({shiftKey}: MouseEvent<HTMLDivElement>) => {
                    if (!columnResizer.isResizing) {
                        onSort(columnDef, shiftKey);
                    }
                } : undefined
            } as AtwColumn<T>);
        });

        const groupByFields = groupBy ? [...groupBy.keys()] : null;

        pinned.sort((left, right) => {
            if (groupByFields) {
                let l = groupByFields.indexOf(left.field);
                let r = groupByFields.indexOf(right.field);
                if (l < 0) {
                    l = groupByFields.length;
                }
                if (r < 0) {
                    r = groupByFields.length;
                }
                return l < r ? -1 : l > r ? 1 : 0;
            }
            return 0;
        });

        setPinned(pinned);
        setColumns(columns);

    }, [columnDefs, groupBy, renderGroupBy]);

    const groupByHeight = groupBy ? 38 : 0;
    const headerHeight = 2 * rowHeight;
    const scrollHeight = rows.length * rowHeight;
    const stickyTop = groupByHeight + headerHeight;

    const scrollWidth = useMemo(() => {
        let scrollWidth = 0;
        for (const column of columns) {
            column.style = {
                ...column.style,
                left: scrollWidth,
                width: column.width
            };
            scrollWidth += column.width;
        }
        return scrollWidth;
    }, [columns]);

    const stickyWidth = useMemo(() => {
        let stickyWidth = 0;
        for (const column of pinned) {
            column.style = {
                ...column.style,
                left: stickyWidth,
                width: column.width
            };
            stickyWidth += column.width;
        }
        return stickyWidth;
    }, [pinned]);

    const gridRef = useRef<HTMLDivElement>(null);

    const {scrollLeft, scrollTop, clientWidth, clientHeight} = useViewport(gridRef, inverse, onScroll);
    const {left, leftIndex, right, rightIndex} = sliceRow(columns, scrollLeft, clientWidth);

    const range = useRef<VisibleRange>(INITIAL_RANGE).current;
    range.topIndex = Math.floor(scrollTop / rowHeight);
    range.bottomIndex = Math.min(Math.ceil((scrollTop + clientHeight) / rowHeight), rows.length);
    range.leftIndex = leftIndex;
    range.rightIndex = rightIndex;

    return (
        <AtwGridContainer gridRef={gridRef}
                          range={range}
                          inverse={inverse}
                          dnd={dnd}
                          style={{
                              "--atw-grid-header-width": `${stickyWidth}px`,
                              "--atw-grid-header-height": `${stickyTop}px`
                          }}
                          onDragEnd={useCallback(({source, destination}) => {
                              console.log("DnD", source, destination);
                              if (source && destination) {
                                  let sourceId = source.droppableId;
                                  let destinationId = destination.droppableId;
                                  if (sourceId === "grid-header" && destinationId === "grid-header" && onDnD) {
                                      onDnD(columns[source.index].index, columns[destination.index].index);
                                      return;
                                  }
                                  if (sourceId === "grid-header" && destinationId === "group-by" && onGroupBy) {
                                      const {field} = columns[source.index];
                                      const update = [...groupBy!];
                                      update.splice(destination.index, 0, [field, new Map()]);
                                      onGroupBy(new Map(update));
                                      return;
                                  }
                                  if (sourceId === "group-by" && destinationId === "grid-header" && onGroupBy) {
                                      const update = [...groupBy!];
                                      const map = new Map(update);
                                      map.delete(update[source.index][0]);
                                      onGroupBy(map);
                                      return;
                                  }
                                  if (sourceId === "group-by" && destinationId === "group-by" && onGroupBy) {
                                      const update = [...groupBy!];
                                      const item = update[source.index];
                                      update.splice(destination.index, 0, item);
                                      onGroupBy(new Map(update));
                                      return;
                                  }
                              }
                          }, [columns, onDnD, onGroupBy])}>
            <div className={inverse ? "top-right-anchor" : "top-left-anchor"}>
                {groupBy ? (
                    <AtwGridGroupBy width={scrollWidth} columns={columns} groupBy={groupBy} onGroupBy={onGroupBy}/>
                ) : null}
                <AtwGridHeader droppableId="pinned-header" columns={pinned} onChange={({action, column, index}) => {
                    setPinned([...pinned].splice(index, 0, column))
                }} style={{
                    width: stickyWidth,
                    height: headerHeight
                }}/>
            </div>
            <div className="top-anchor" style={{top: groupByHeight}}>
                <AtwGridHeader droppableId="grid-header" columns={columns.slice(leftIndex, rightIndex)} onChange={({action, column, index}) => {
                    setColumns([...columns].splice(index, 0, column))
                }} style={{
                    marginLeft: stickyWidth,
                    minWidth: scrollWidth,
                    height: headerHeight
                }}/>
            </div>
            <div className={inverse ? "right-anchor" : "left-anchor"}>
                <AtwGridBody columns={pinned} rows={rows} rowHeight={rowHeight} style={{
                    marginTop: stickyTop,
                    width: stickyWidth,
                    minHeight: scrollHeight
                }}/>
            </div>
            <AtwGridBody columns={columns.slice(leftIndex, rightIndex)} rows={rows} rowHeight={rowHeight} style={{
                marginLeft: stickyWidth,
                minWidth: scrollWidth,
                minHeight: scrollHeight
            }}/>
        </AtwGridContainer>
    );
}

function useCellRenderer<T extends DataItem>({field, type}: AtwColumnDef<T>) {
    return (row: T) => <div className={`atw-grid-cell-content ${field}`}>{row[field]}</div>;
}

function sliceRow<T extends DataItem>(columns: AtwColumn<T>[], scrollLeft: number, clientWidth: number) {
    let left = 0;
    let leftIndex = 0;
    while (leftIndex < columns.length) {
        let next = left + columns[leftIndex].width;
        if (next < scrollLeft) {
            left = next;
            leftIndex++;
        } else {
            break;
        }
    }
    let width = 0;
    let rightIndex = leftIndex;
    while (rightIndex < columns.length) {
        width += columns[rightIndex++].width;
        if (width > clientWidth) {
            break;
        }
    }
    return {
        left,
        leftIndex,
        right: clientWidth - (left + width),
        rightIndex
    };
}
