import React, {CSSProperties, useContext, useMemo, useState} from "react";
import {AtwColumn, AtwGridContext, DataItem, VisibleRange} from "./AtwGrid";

export const INITIAL_RANGE: VisibleRange = {
    topIndex: 0,
    bottomIndex: Number.MAX_SAFE_INTEGER,
    leftIndex: 0,
    rightIndex: Number.MAX_SAFE_INTEGER
};
type RowCache = VisibleRange & { elements: JSX.Element[] }

export function AtwGridBody<T extends DataItem>(props: {
    columns: AtwColumn<T>[]
    rows: T[]
    rowHeight: number
    style: CSSProperties
}) {
    const {
        columns,
        rows,
        rowHeight,
        style
    } = props;

    const {
        topIndex,
        bottomIndex
    } = useContext(AtwGridContext).range;

    const [cache] = useState<RowCache>(() => ({
        ...INITIAL_RANGE,
        elements: []
    }));
    const elements: JSX.Element[] = [];

    useMemo(() => {
        cache.topIndex = Number.MAX_SAFE_INTEGER;
    }, [columns]);

    for (let rowIndex = topIndex; rowIndex < bottomIndex; rowIndex++) {
        if (rowIndex >= cache.topIndex && rowIndex < cache.bottomIndex) {
            elements.push(cache.elements[rowIndex - cache.topIndex]);
        } else {
            const row = rows[rowIndex];
            let className = "atw-grid-row";
            if (row.$$bucket) {
                className += " group-by";
            }
            const style = {
                transform: `translateY(${rowIndex * rowHeight}px)`,
                height: rowHeight,
                background: (row as any).shade ?? "var(--grid__background-color)"
            };
            elements.push(
                <div className={className} key={rowIndex} row-id={row.id} row-index={rowIndex} style={style}>
                    {columns.map((column, columnIndex) => {
                        const {className, style} = column;
                        return (
                            <div className={className} key={column.index} column-index={column.index} style={style}>
                                {column.render!(row, column)}
                            </div>
                        );
                    })}
                    <div className={"atw-grid-cell filler"} key="row-filler"/>
                </div>
            );
        }
    }

    cache.topIndex = topIndex;
    cache.bottomIndex = bottomIndex;
    cache.elements = elements;

    return (
        <div className="atw-grid-body" style={style}>
            {elements}
        </div>
    );
}