import React, {CSSProperties, ReactNode, RefObject} from "react";
import {DragDropContext, DropResult, ResponderProvided} from "react-beautiful-dnd";
import {AtwGridContext, DataItem, VisibleRange} from "./AtwGrid";

export function AtwGridContainer<T extends DataItem>(props: {
    gridRef: RefObject<HTMLDivElement>
    range: VisibleRange
    inverse: boolean
    dnd: boolean
    style: CSSProperties & { [key: `--${string}`]: string }
    onDragEnd(result: DropResult, provided: ResponderProvided): void
    children: ReactNode
}) {
    const {
        gridRef,
        range,
        inverse,
        dnd,
        style,
        children
    } = props;

    return (
        <div ref={gridRef} className={inverse ? "atw-grid rtl" : "atw-grid ltr"} style={style}>
            <DragDropContext onDragEnd={props.onDragEnd}>
                <AtwGridContext.Provider value={{
                    grid: gridRef.current!,
                    range,
                    inverse,
                    dnd
                }}>
                    {gridRef.current ? children : null}
                </AtwGridContext.Provider>
            </DragDropContext>
        </div>
    );
}