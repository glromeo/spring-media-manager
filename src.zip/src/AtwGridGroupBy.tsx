import {Draggable, Droppable} from "react-beautiful-dnd";
import React, {Fragment, useCallback} from "react";
import {AtwColumn, AtwGroupBy, DataItem} from "./AtwGrid";
import {AtwMenu} from "./AtwMenu";

type AtwGridGroupByProps<T extends DataItem> = {
    columns: AtwColumn<T>[],
    width: number;
    groupBy: AtwGroupBy<T>,
    onGroupBy: ((update: AtwGroupBy<T>) => void) | undefined
};

function stopPropagation(e:any) {
    e.stopPropagation();
}

export function AtwGridGroupBy<T extends DataItem>(props: AtwGridGroupByProps<T>) {
    const {columns, width, groupBy, onGroupBy} = props;

    const isAggregate = useCallback(({
                                         field,
                                         type
                                     }: AtwColumn<T>) => type === "number" && !groupBy?.has(field), [groupBy]);

    return (
        <Droppable droppableId="group-by" direction="horizontal">
            {({droppableProps, innerRef, placeholder}, {isDraggingOver}) => (
                <div ref={innerRef} className="atw-grid-group-by"
                     {...droppableProps}
                     style={{
                         width,
                         background: isDraggingOver ? "lightblue" : undefined
                     }}>
                    {[...groupBy.keys()].map((field: keyof T, index: number) => (
                        <Draggable key={index} draggableId={`group-${field}`} index={index}>
                            {({dragHandleProps, draggableProps, innerRef}, {isDragging}) => (
                                <div ref={innerRef} className="atw-grid-group-item"
                                     {...draggableProps}
                                     {...dragHandleProps}
                                     style={{
                                         background: isDragging ? "gold" : undefined,
                                         border: isDragging ? "2px solid goldenrod" : undefined,
                                         ...draggableProps.style
                                     }}>
                                    <span className="label">{String(field)}</span>
                                    {isDragging
                                        ? null
                                        : <AtwMenu options={columns.filter(isAggregate).map(column => {
                                            return {
                                                label: (
                                                    <AtwMenu label={column.label} onSelect={({label}) => {
                                                        switch (label) {
                                                            case "Sum":
                                                                groupBy.get(field)!.set(column.field, {
                                                                    name: label as keyof T,
                                                                    fn: (items, field) => items.reduce((total, axe) => total + (axe[field] as unknown as number || 0), 0)
                                                                });
                                                                break;
                                                            case "Avg":
                                                                groupBy.get(field)!.set(column.field, {
                                                                    name: label as keyof T,
                                                                    fn: (items, field) => items.reduce((total, axe) => total + (axe[field] as unknown as number || 0), 0) / items.length
                                                                });
                                                                break;
                                                            default:
                                                                groupBy.get(field)!.set(column.field, null);
                                                        }
                                                        if (onGroupBy) {
                                                            onGroupBy(new Map(groupBy));
                                                        }
                                                    }} options={[
                                                        {label: ""},
                                                        {label: "Sum"},
                                                        {label: "Avg"}
                                                    ]}/>
                                                ),
                                                value: column,
                                                checked: groupBy.get(field)!.has(column.field)
                                            };
                                        })}/>
                                    }
                                </div>
                            )}
                        </Draggable>
                    ))}
                    {placeholder}
                </div>
            )}
        </Droppable>
    );
}