import React, {CSSProperties, useContext} from "react";
import {Draggable, Droppable} from "react-beautiful-dnd";
import {useContextMenu} from "./useContextMenu";
import {AtwMenu} from "./AtwMenu";
import {AtwMenuItem} from "./AtwMenuItem";
import {AtwGridSort} from "./AtwGridSort";
import {AtwColumnResizer} from "./AtwColumnResizer";
import {AtwColumn, AtwGridContext, DataItem} from "./AtwGrid";
import {pipeline} from "stream";

export function AtwGridHeader<T extends DataItem>(props: {
    columns: AtwColumn<T>[]
    droppableId: string
    onChange: (event: { action: "sort" | "size" | "grouping" | "pinned", column: AtwColumn<T>, index: number }) => void
    style: CSSProperties
}) {
    const {
        grid,
        inverse,
        dnd,
        groupBy,
        onGroupBy
    } = useContext(AtwGridContext);
    const {
        columns,
        droppableId,
        onChange,
        style
    } = props;
    return (
        <Droppable droppableId={droppableId} direction="horizontal" mode="virtual">
            {({droppableProps, innerRef, placeholder}, {isDraggingOver}) => (
                <div ref={innerRef}
                     className={isDraggingOver ? "atw-grid-header drag-over" : "atw-grid-header"}
                     style={style}
                     {...droppableProps}>
                    <div className="atw-grid-row">
                        {columns.map((column, index) => {
                            const {style, sort} = column;
                            const field = column.field as any;
                            const key = String(column.index);
                            const canAggregate = groupBy && !groupBy.has(field);
                            return (
                                <Draggable key={key} draggableId={key} index={index}>
                                    {({dragHandleProps, draggableProps, innerRef}, {isDragging}) => (
                                        <div className={isDragging ? "atw-grid-cell dragging" : column.className}
                                             column-index={index}
                                             ref={innerRef}
                                             {...draggableProps}
                                             style={{
                                                 ...style,
                                                 ...draggableProps.style
                                             }}
                                             onClick={column.onSort}
                                             onContextMenu={useContextMenu(close => {
                                                 return (
                                                     <AtwMenu open={true} onClose={close}>
                                                         <AtwMenuItem><span
                                                             style={{fontWeight: "bold"}}>field:</span>{field}
                                                         </AtwMenuItem>
                                                         {canAggregate ? (
                                                             <AtwMenuItem label="Aggregate" onClick={() => {
                                                                 onGroupBy?.(new Map([[field, new Map()], ...groupBy!]));
                                                             }}/>
                                                         ) : (
                                                             <AtwMenuItem label="Aggregate" onClick={() => {
                                                                 onGroupBy?.(new Map([[field, new Map()], ...groupBy!]));
                                                             }}/>
                                                         )}
                                                         {canAggregate ? (
                                                             <AtwMenuItem>
                                                                 <AtwMenu label="Function">
                                                                     <AtwMenuItem label="Aggregate" onClick={() => {
                                                                         onGroupBy?.(new Map([[field, new Map()], ...groupBy!]));
                                                                     }}/>
                                                                     <AtwMenuItem label="Aggregate" onClick={() => {
                                                                         onGroupBy?.(new Map([[field, new Map()], ...groupBy!]));
                                                                     }}/>
                                                                 </AtwMenu>
                                                             </AtwMenuItem>
                                                         ) : null}
                                                     </AtwMenu>
                                                 );
                                             })}>
                                            <div className="atw-grid-cell-content" {...(dragHandleProps)}>
                                                {column.label}
                                                <AtwGridSort sort={sort}/>
                                            </div>
                                            {column.resizable ? (
                                                <AtwColumnResizer
                                                    container={grid}
                                                    inverse={inverse}
                                                    minWidth={column.minWidth}
                                                    width={column.width}
                                                    onResize={deltaX => {
                                                        const columnCells = grid.querySelectorAll<HTMLDivElement>(`.atw-grid-cell[column-index="${index}"]`);
                                                        const header = grid.querySelector<HTMLDivElement>(".atw-grid-header")!;
                                                        const body = grid.querySelector<HTMLDivElement>(".atw-grid-body")!;
                                                        const width = `${column.width + deltaX}px`;
                                                        for (const cell of columnCells) {
                                                            cell.style.width = width;
                                                        }
                                                        header.style.minWidth = `${style.width as number + deltaX}px`;
                                                        body.style.minWidth = `${style.width as number + deltaX}px`;
                                                    }}
                                                    onMouseUp={deltaX => onChange({
                                                        action: "size",
                                                        index,
                                                        column: {
                                                            ...column,
                                                            width: column.width + deltaX
                                                        }
                                                    })}
                                                />
                                            ) : null}
                                        </div>
                                    )}
                                </Draggable>
                            );
                        })}
                        {placeholder}
                        <div className={"atw-grid-cell filler"} key="header-filler"/>
                    </div>
                </div>
            )}
        </Droppable>
    );
}
