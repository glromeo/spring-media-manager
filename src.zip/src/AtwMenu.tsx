import React, {Dispatch, RefObject, SetStateAction, useEffect, useMemo, useRef, useState} from "react";
import {AtwMenuItemElement} from "./AtwMenuItem";

import "./AtwMenu.scss";

export const AtwMenuContext = React.createContext<[any, Dispatch<SetStateAction<any>>]>([null, ()=>{}]);

export type AtwMenuProps<V> = {
    label?: string,
    open?: boolean,
    parentRef?: RefObject<HTMLElement>,
    value?: V,
    children: (AtwMenuItemElement<V>|null)[],
    onClose?: () => void
};

export function AtwMenu<T>(props: AtwMenuProps<T>) {
    const {
        label,
        parentRef,
        children,
        onClose
    } = props;

    const menuRef = useRef<HTMLDivElement>(null);

    const [value, setValue] = useState(props.value);
    const [open, setOpen] = useState(props.open);

    useEffect(() => {
        setValue(props.value);
        setOpen(props.open);
    }, [props]);

    const dropdown = useRef<HTMLDivElement>(null);

    const handleClickOutside = (event: MouseEvent) => {
        if (dropdown.current && !dropdown.current.contains(event.target as HTMLDivElement)) {
            setOpen(false);
            onClose?.();
        }
    };

    const parent = parentRef?.current;

    useEffect(() => {
        if (parent) {
            const onMouseEnter = () => setOpen(true);
            const onMouseLeave = () => setOpen(false);
            parent.addEventListener("mouseenter", onMouseEnter);
            parent.addEventListener("mouseleave", onMouseLeave);
            return () => {
                parent.removeEventListener("mouseenter", onMouseEnter);
                parent.removeEventListener("mouseleave", onMouseLeave);
            };
        }
    }, [parent]);

    useEffect(() => {
        document.addEventListener("mousedown", handleClickOutside);
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, []);

    const onClick = (e: any) => {
        e.stopPropagation();
        setOpen(!open);
        onClose?.();
    };

    const toggle = !(parent || props.open) ? (
        <svg className="chevron" width="16" height="16" fill="currentColor" viewBox="0 0 16 16" onClick={onClick}>
            <path fillRule="evenodd"
                  d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z"/>
        </svg>
    ) : null;

    return (
        <AtwMenuContext.Provider value={[value, value=>{
            setValue(value);
            setOpen(!open);
            onClose?.();
        }]}>
            <div className="atw-menu" ref={menuRef}>
                <div className="label" onClick={onClick} style={{display: label ? "inline-block" : "none"}}>{label}</div>
                {toggle}
                {open && (
                    <div className="atw-menu-dropdown-placeholder">
                        <div className="atw-menu-dropdown" ref={dropdown}>
                            {children}
                        </div>
                    </div>
                )}
            </div>
        </AtwMenuContext.Provider>
    );
}