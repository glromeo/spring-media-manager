import React, {MouseEventHandler, ReactNode, useContext} from "react";
import {AtwMenuContext} from "./AtwMenu";

export type AtwMenuItemProps<V> = {
    label?: JSX.Element | string | null,
    value?: V,
    onClick?: MouseEventHandler<HTMLDivElement> | undefined
    children?: ReactNode
}
export type AtwMenuItemElement<V> = JSX.Element;

export function AtwMenuItem<V>(props: AtwMenuItemProps<V>): AtwMenuItemElement<V> | null {
    const [value, setValue] = useContext(AtwMenuContext);
    return (
        <div className={props.value === value ? "atw-menu-item active" : "atw-menu-item"}
             onClick={event => {
                 event.stopPropagation();
                 props.onClick?.(event);
                 setValue(props.value);
             }}>
            {props.label ?? props.children}
        </div>
    );
}