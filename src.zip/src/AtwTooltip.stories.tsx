import React from 'react';
import {ComponentMeta, ComponentStory} from '@storybook/react';

import {AtwTooltip} from "./AtwTooltip";

import "./index.scss";

export default {
    title: "AtwTooltip",
    component: AtwTooltip
} as ComponentMeta<typeof AtwTooltip>

const Template: ComponentStory<typeof AtwTooltip> = (args) => (
    <AtwTooltip {...args}>
        <div style={{backgroundColor: "darkblue", color: "white", fontSize: 20}}>Content</div>
    </AtwTooltip>
);

export const with_message = Template.bind({});
with_message.args = {
    message: "Tooltip message",
};

