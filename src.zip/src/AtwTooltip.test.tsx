import React from "react";
import {render, screen, fireEvent, waitFor } from "@testing-library/react";
import {AtwTooltip} from "./AtwTooltip";

describe("ATW Tooltip", function () {

    beforeAll(async function () {
        fireEvent(document, new Event("DOMContentLoaded"));
        await waitFor(() => {
            expect(document.getElementById("atw-tooltip")).toBeInTheDocument();
        })
    });

    it("renders children", function () {
        render(<AtwTooltip message={"Test message"}><div className="child-component">The child</div></AtwTooltip>);
        expect(screen.getByText("The child")).toBeInTheDocument();
    });

    it("shows message on pointer enter and hides it on pointer leave", async function () {

        render(<AtwTooltip message={"Test message"}><div className="child-component">The child</div></AtwTooltip>);

        fireEvent.pointerEnter(screen.getByText("The child"));
        await waitFor(() => {
            expect(document.getElementById("atw-tooltip")).toBeVisible();
        })
        expect(screen.getByText("Test message")).toBeInTheDocument();

        fireEvent.pointerLeave(screen.getByText("The child"));
        await new Promise(resolve => setTimeout(resolve, 300));
        expect(document.getElementById("atw-tooltip")!.className).toMatch(/hidden/);
    });
})