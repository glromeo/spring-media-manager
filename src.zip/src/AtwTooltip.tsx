import React, { ReactNode, useCallback } from "react";
import ReactDOM from "react-dom";

import "./AtwTooltip.scss";

export type AtwTooltipProps = React.AllHTMLAttributes<any> & {
    className?: string;
    message: string | null;
    children?: ReactNode;
};

const ATW_TOOLTIP_ID = "atw-tooltip";

let timeout: any = 0;

export function AtwTooltip({ className, message, children, ...rest }: AtwTooltipProps) {
    const onPointerEnter = useCallback(
        ({ target, pageX, pageY }) => {
            if (message) {
                const tooltipElement = document.getElementById(ATW_TOOLTIP_ID)!;
                let left = pageX < window.innerWidth * 0.75;
                let top = pageY < window.innerHeight * 0.75;
                ReactDOM.render(
                    <div className={`content ${left ? "left" : "right"} ${top ? "top" : "bottom"}`}>{message}</div>,
                    tooltipElement
                );
                tooltipElement.classList.remove("hidden");
                clearTimeout(timeout);
                timeout = setTimeout(() => {
                    tooltipElement.classList.add("visible");
                });
                tooltipElement.style.left = `${pageX}px`;
                tooltipElement.style.top = `${pageY}px`;
            }
        },
        [message]
    );

    const onPointerLeave = useCallback(
        e => {
            if (message) {
                const tooltipElement = document.getElementById(ATW_TOOLTIP_ID)!;
                tooltipElement.classList.remove("visible");
                clearTimeout(timeout);
                timeout = setTimeout(() => {
                    tooltipElement.classList.add("hidden");
                }, 300);
            }
        },
        [message]
    );

    return (
        <div
            className={className}
            data-message={message}
            onPointerEnter={onPointerEnter}
            onPointerLeave={onPointerLeave}
            {...rest}
        >
            {children}
        </div>
    );
}

document.addEventListener('DOMContentLoaded', () => {
    let tooltipElement = document.getElementById(ATW_TOOLTIP_ID);
    if (tooltipElement === null) {
        tooltipElement = document.createElement("div");
        tooltipElement.id = ATW_TOOLTIP_ID;
        document.body.append(tooltipElement);
    }
});