import { meta } from './bootstrap';
import { set_aux_accordion_expansion_panel } from './esm/aux-bundle.entry';
import info from './meta/aux-accordion_2.json';
//@ts-ignore
import {aux_accordion_expansion_panel} from '@blk/aladdin-web-components/dist/esm/aux-accordion_2.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_accordion_expansion_panel(aux_accordion_expansion_panel);

export const AuxAccordionExpansionPanel = /*@__PURE__*/createReactComponent<JSX.AuxAccordionExpansionPanel, HTMLAuxAccordionExpansionPanelElement>('aux-accordion-expansion-panel');
