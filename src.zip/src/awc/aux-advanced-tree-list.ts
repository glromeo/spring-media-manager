import { meta } from './bootstrap';
import { set_aux_advanced_tree_list } from './esm/aux-bundle.entry';
import info from './meta/aux-advanced-tree-list_2.json';
//@ts-ignore
import {aux_advanced_tree_list} from '@blk/aladdin-web-components/dist/esm/aux-advanced-tree-list_2.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_advanced_tree_list(aux_advanced_tree_list);

export const AuxAdvancedTreeList = /*@__PURE__*/createReactComponent<JSX.AuxAdvancedTreeList, HTMLAuxAdvancedTreeListElement>('aux-advanced-tree-list');
