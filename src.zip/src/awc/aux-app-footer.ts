import { meta } from './bootstrap';
import { set_aux_app_footer } from './esm/aux-bundle.entry';
import info from './meta/aux-app-footer.json';
//@ts-ignore
import {aux_app_footer} from '@blk/aladdin-web-components/dist/esm/aux-app-footer.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_app_footer(aux_app_footer);

export const AuxAppFooter = /*@__PURE__*/createReactComponent<JSX.AuxAppFooter, HTMLAuxAppFooterElement>('aux-app-footer');
