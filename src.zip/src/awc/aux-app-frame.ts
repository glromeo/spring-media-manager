import { meta } from './bootstrap';
import { set_aux_app_frame } from './esm/aux-bundle.entry';
import info from './meta/aux-app-frame.json';
//@ts-ignore
import {aux_app_frame} from '@blk/aladdin-web-components/dist/esm/aux-app-frame.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_app_frame(aux_app_frame);

export const AuxAppFrame = /*@__PURE__*/createReactComponent<JSX.AuxAppFrame, HTMLAuxAppFrameElement>('aux-app-frame');
