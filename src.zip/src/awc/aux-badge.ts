import { meta } from './bootstrap';
import { set_aux_badge } from './esm/aux-bundle.entry';
import info from './meta/aux-badge.json';
//@ts-ignore
import {aux_badge} from '@blk/aladdin-web-components/dist/esm/aux-badge.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_badge(aux_badge);

export const AuxBadge = /*@__PURE__*/createReactComponent<JSX.AuxBadge, HTMLAuxBadgeElement>('aux-badge');
