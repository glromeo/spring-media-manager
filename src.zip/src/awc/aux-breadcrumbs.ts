import { meta } from './bootstrap';
import { set_aux_breadcrumbs } from './esm/aux-bundle.entry';
import info from './meta/aux-breadcrumbs.json';
//@ts-ignore
import {aux_breadcrumbs} from '@blk/aladdin-web-components/dist/esm/aux-breadcrumbs.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_breadcrumbs(aux_breadcrumbs);

export const AuxBreadcrumbs = /*@__PURE__*/createReactComponent<JSX.AuxBreadcrumbs, HTMLAuxBreadcrumbsElement>('aux-breadcrumbs');
