import { meta } from './bootstrap';
import { set_aux_button } from './esm/aux-bundle.entry';
import info from './meta/aux-button.json';
//@ts-ignore
import {aux_button} from '@blk/aladdin-web-components/dist/esm/aux-button.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_button(aux_button);

export const AuxButton = /*@__PURE__*/createReactComponent<JSX.AuxButton, HTMLAuxButtonElement>('aux-button');
