import { meta } from './bootstrap';
import { set_aux_card } from './esm/aux-bundle.entry';
import info from './meta/aux-card.json';
//@ts-ignore
import {aux_card} from '@blk/aladdin-web-components/dist/esm/aux-card.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_card(aux_card);

export const AuxCard = /*@__PURE__*/createReactComponent<JSX.AuxCard, HTMLAuxCardElement>('aux-card');
