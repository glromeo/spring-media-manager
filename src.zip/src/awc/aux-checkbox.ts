import { meta } from './bootstrap';
import { set_aux_checkbox } from './esm/aux-bundle.entry';
import info from './meta/aux-checkbox.json';
//@ts-ignore
import {aux_checkbox} from '@blk/aladdin-web-components/dist/esm/aux-checkbox.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_checkbox(aux_checkbox);

export const AuxCheckbox = /*@__PURE__*/createReactComponent<JSX.AuxCheckbox, HTMLAuxCheckboxElement>('aux-checkbox');
