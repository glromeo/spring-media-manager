import { meta } from './bootstrap';
import { set_aux_data_viz } from './esm/aux-bundle.entry';
import info from './meta/aux-data-viz.json';
//@ts-ignore
import {aux_data_viz} from '@blk/aladdin-web-components/dist/esm/aux-data-viz.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_data_viz(aux_data_viz);

export const AuxDataViz = /*@__PURE__*/createReactComponent<JSX.AuxDataViz, HTMLAuxDataVizElement>('aux-data-viz');
