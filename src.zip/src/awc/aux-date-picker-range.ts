import { meta } from './bootstrap';
import { set_aux_date_picker_range } from './esm/aux-bundle.entry';
import info from './meta/aux-date-picker-range.json';
//@ts-ignore
import {aux_date_picker_range} from '@blk/aladdin-web-components/dist/esm/aux-date-picker-range.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_date_picker_range(aux_date_picker_range);

export const AuxDatePickerRange = /*@__PURE__*/createReactComponent<JSX.AuxDatePickerRange, HTMLAuxDatePickerRangeElement>('aux-date-picker-range');
