import { meta } from './bootstrap';
import { set_aux_date_picker } from './esm/aux-bundle.entry';
import info from './meta/aux-date-picker.json';
//@ts-ignore
import {aux_date_picker} from '@blk/aladdin-web-components/dist/esm/aux-date-picker.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_date_picker(aux_date_picker);

export const AuxDatePicker = /*@__PURE__*/createReactComponent<JSX.AuxDatePicker, HTMLAuxDatePickerElement>('aux-date-picker');
