import { meta } from './bootstrap';
import { set_aux_drag_and_drop } from './esm/aux-bundle.entry';
import info from './meta/aux-drag-and-drop.json';
//@ts-ignore
import {aux_drag_and_drop} from '@blk/aladdin-web-components/dist/esm/aux-drag-and-drop.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_drag_and_drop(aux_drag_and_drop);

export const AuxDragAndDrop = /*@__PURE__*/createReactComponent<JSX.AuxDragAndDrop, HTMLAuxDragAndDropElement>('aux-drag-and-drop');
