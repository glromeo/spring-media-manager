import { meta } from './bootstrap';
import { set_aux_drawer_content } from './esm/aux-bundle.entry';
import info from './meta/aux-drawer_2.json';
//@ts-ignore
import {aux_drawer_content} from '@blk/aladdin-web-components/dist/esm/aux-drawer_2.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_drawer_content(aux_drawer_content);

export const AuxDrawerContent = /*@__PURE__*/createReactComponent<JSX.AuxDrawerContent, HTMLAuxDrawerContentElement>('aux-drawer-content');
