import { meta } from './bootstrap';
import { set_aux_faceted_filter } from './esm/aux-bundle.entry';
import info from './meta/aux-faceted-filter_2.json';
//@ts-ignore
import {aux_faceted_filter} from '@blk/aladdin-web-components/dist/esm/aux-faceted-filter_2.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_faceted_filter(aux_faceted_filter);

export const AuxFacetedFilter = /*@__PURE__*/createReactComponent<JSX.AuxFacetedFilter, HTMLAuxFacetedFilterElement>('aux-faceted-filter');
