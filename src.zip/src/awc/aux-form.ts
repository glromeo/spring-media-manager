import { meta } from './bootstrap';
import { set_aux_form } from './esm/aux-bundle.entry';
import info from './meta/aux-form_3.json';
//@ts-ignore
import {aux_form} from '@blk/aladdin-web-components/dist/esm/aux-form_3.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_form(aux_form);

export const AuxForm = /*@__PURE__*/createReactComponent<JSX.AuxForm, HTMLAuxFormElement>('aux-form');
