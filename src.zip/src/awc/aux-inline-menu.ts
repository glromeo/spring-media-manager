import { meta } from './bootstrap';
import { set_aux_inline_menu } from './esm/aux-bundle.entry';
import info from './meta/aux-inline-menu.json';
//@ts-ignore
import {aux_inline_menu} from '@blk/aladdin-web-components/dist/esm/aux-inline-menu.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_inline_menu(aux_inline_menu);

export const AuxInlineMenu = /*@__PURE__*/createReactComponent<JSX.AuxInlineMenu, HTMLAuxInlineMenuElement>('aux-inline-menu');
