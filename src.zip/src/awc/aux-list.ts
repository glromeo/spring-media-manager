import { meta } from './bootstrap';
import { set_aux_list } from './esm/aux-bundle.entry';
import info from './meta/aux-list.json';
//@ts-ignore
import {aux_list} from '@blk/aladdin-web-components/dist/esm/aux-list.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_list(aux_list);

export const AuxList = /*@__PURE__*/createReactComponent<JSX.AuxList, HTMLAuxListElement>('aux-list');
