import { meta } from './bootstrap';
import { set_aux_mega_menu } from './esm/aux-bundle.entry';
import info from './meta/aux-mega-menu.json';
//@ts-ignore
import {aux_mega_menu} from '@blk/aladdin-web-components/dist/esm/aux-mega-menu.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_mega_menu(aux_mega_menu);

export const AuxMegaMenu = /*@__PURE__*/createReactComponent<JSX.AuxMegaMenu, HTMLAuxMegaMenuElement>('aux-mega-menu');
