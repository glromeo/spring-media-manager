import { meta } from './bootstrap';
import { set_aux_notification_group } from './esm/aux-bundle.entry';
import info from './meta/aux-notification_2.json';
//@ts-ignore
import {aux_notification_group} from '@blk/aladdin-web-components/dist/esm/aux-notification_2.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_notification_group(aux_notification_group);

export const AuxNotificationGroup = /*@__PURE__*/createReactComponent<JSX.AuxNotificationGroup, HTMLAuxNotificationGroupElement>('aux-notification-group');
