import { meta } from './bootstrap';
import { set_aux_notification } from './esm/aux-bundle.entry';
import info from './meta/aux-notification_2.json';
//@ts-ignore
import {aux_notification} from '@blk/aladdin-web-components/dist/esm/aux-notification_2.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_notification(aux_notification);

export const AuxNotification = /*@__PURE__*/createReactComponent<JSX.AuxNotification, HTMLAuxNotificationElement>('aux-notification');
