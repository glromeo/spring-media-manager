import { meta } from './bootstrap';
import { set_aux_pagination_advanced } from './esm/aux-bundle.entry';
import info from './meta/aux-pagination-advanced.json';
//@ts-ignore
import {aux_pagination_advanced} from '@blk/aladdin-web-components/dist/esm/aux-pagination-advanced.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_pagination_advanced(aux_pagination_advanced);

export const AuxPaginationAdvanced = /*@__PURE__*/createReactComponent<JSX.AuxPaginationAdvanced, HTMLAuxPaginationAdvancedElement>('aux-pagination-advanced');
