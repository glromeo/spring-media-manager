import { meta } from './bootstrap';
import { set_aux_picklist } from './esm/aux-bundle.entry';
import info from './meta/aux-picklist.json';
//@ts-ignore
import {aux_picklist} from '@blk/aladdin-web-components/dist/esm/aux-picklist.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_picklist(aux_picklist);

export const AuxPicklist = /*@__PURE__*/createReactComponent<JSX.AuxPicklist, HTMLAuxPicklistElement>('aux-picklist');
