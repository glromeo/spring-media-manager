import { meta } from './bootstrap';
import { set_aux_pill } from './esm/aux-bundle.entry';
import info from './meta/aux-pill.json';
//@ts-ignore
import {aux_pill} from '@blk/aladdin-web-components/dist/esm/aux-pill.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_pill(aux_pill);

export const AuxPill = /*@__PURE__*/createReactComponent<JSX.AuxPill, HTMLAuxPillElement>('aux-pill');
