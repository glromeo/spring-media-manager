import { meta } from './bootstrap';
import { set_aux_pillbox } from './esm/aux-bundle.entry';
import info from './meta/aux-pillbox.json';
//@ts-ignore
import {aux_pillbox} from '@blk/aladdin-web-components/dist/esm/aux-pillbox.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_pillbox(aux_pillbox);

export const AuxPillbox = /*@__PURE__*/createReactComponent<JSX.AuxPillbox, HTMLAuxPillboxElement>('aux-pillbox');
