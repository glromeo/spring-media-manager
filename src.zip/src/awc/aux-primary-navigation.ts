import { meta } from './bootstrap';
import { set_aux_primary_navigation } from './esm/aux-bundle.entry';
import info from './meta/aux-primary-navigation_2.json';
//@ts-ignore
import {aux_primary_navigation} from '@blk/aladdin-web-components/dist/esm/aux-primary-navigation_2.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_primary_navigation(aux_primary_navigation);

export const AuxPrimaryNavigation = /*@__PURE__*/createReactComponent<JSX.AuxPrimaryNavigation, HTMLAuxPrimaryNavigationElement>('aux-primary-navigation');
