import { meta } from './bootstrap';
import { set_aux_progress_indicator } from './esm/aux-bundle.entry';
import info from './meta/aux-progress-indicator.json';
//@ts-ignore
import {aux_progress_indicator} from '@blk/aladdin-web-components/dist/esm/aux-progress-indicator.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_progress_indicator(aux_progress_indicator);

export const AuxProgressIndicator = /*@__PURE__*/createReactComponent<JSX.AuxProgressIndicator, HTMLAuxProgressIndicatorElement>('aux-progress-indicator');
