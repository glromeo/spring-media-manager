import { meta } from './bootstrap';
import { set_aux_progress_stepper } from './esm/aux-bundle.entry';
import info from './meta/aux-progress-stepper.json';
//@ts-ignore
import {aux_progress_stepper} from '@blk/aladdin-web-components/dist/esm/aux-progress-stepper.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_progress_stepper(aux_progress_stepper);

export const AuxProgressStepper = /*@__PURE__*/createReactComponent<JSX.AuxProgressStepper, HTMLAuxProgressStepperElement>('aux-progress-stepper');
