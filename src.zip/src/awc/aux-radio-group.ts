import { meta } from './bootstrap';
import { set_aux_radio_group } from './esm/aux-bundle.entry';
import info from './meta/aux-radio-group.json';
//@ts-ignore
import {aux_radio_group} from '@blk/aladdin-web-components/dist/esm/aux-radio-group.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_radio_group(aux_radio_group);

export const AuxRadioGroup = /*@__PURE__*/createReactComponent<JSX.AuxRadioGroup, HTMLAuxRadioGroupElement>('aux-radio-group');
