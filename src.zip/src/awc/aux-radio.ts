import { meta } from './bootstrap';
import { set_aux_radio } from './esm/aux-bundle.entry';
import info from './meta/aux-radio.json';
//@ts-ignore
import {aux_radio} from '@blk/aladdin-web-components/dist/esm/aux-radio.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_radio(aux_radio);

export const AuxRadio = /*@__PURE__*/createReactComponent<JSX.AuxRadio, HTMLAuxRadioElement>('aux-radio');
