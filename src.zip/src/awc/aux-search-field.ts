import { meta } from './bootstrap';
import { set_aux_search_field } from './esm/aux-bundle.entry';
import info from './meta/aux-search-field.json';
//@ts-ignore
import {aux_search_field} from '@blk/aladdin-web-components/dist/esm/aux-search-field.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_search_field(aux_search_field);

export const AuxSearchField = /*@__PURE__*/createReactComponent<JSX.AuxSearchField, HTMLAuxSearchFieldElement>('aux-search-field');
