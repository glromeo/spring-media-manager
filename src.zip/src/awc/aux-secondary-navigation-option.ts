import { meta } from './bootstrap';
import { set_aux_secondary_navigation_option } from './esm/aux-bundle.entry';
import info from './meta/aux-secondary-navigation_3.json';
//@ts-ignore
import {aux_secondary_navigation_option} from '@blk/aladdin-web-components/dist/esm/aux-secondary-navigation_3.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_secondary_navigation_option(aux_secondary_navigation_option);

export const AuxSecondaryNavigationOption = /*@__PURE__*/createReactComponent<JSX.AuxSecondaryNavigationOption, HTMLAuxSecondaryNavigationOptionElement>('aux-secondary-navigation-option');
