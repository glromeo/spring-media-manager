import { meta } from './bootstrap';
import { set_aux_segmented_control } from './esm/aux-bundle.entry';
import info from './meta/aux-segmented-control.json';
//@ts-ignore
import {aux_segmented_control} from '@blk/aladdin-web-components/dist/esm/aux-segmented-control.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_segmented_control(aux_segmented_control);

export const AuxSegmentedControl = /*@__PURE__*/createReactComponent<JSX.AuxSegmentedControl, HTMLAuxSegmentedControlElement>('aux-segmented-control');
