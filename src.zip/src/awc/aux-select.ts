import { meta } from './bootstrap';
import { set_aux_select } from './esm/aux-bundle.entry';
import info from './meta/aux-select.json';
//@ts-ignore
import {aux_select} from '@blk/aladdin-web-components/dist/esm/aux-select.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_select(aux_select);

export const AuxSelect = /*@__PURE__*/createReactComponent<JSX.AuxSelect, HTMLAuxSelectElement>('aux-select');
