import { meta } from './bootstrap';
import { set_aux_slider } from './esm/aux-bundle.entry';
import info from './meta/aux-slider.json';
//@ts-ignore
import {aux_slider} from '@blk/aladdin-web-components/dist/esm/aux-slider.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_slider(aux_slider);

export const AuxSlider = /*@__PURE__*/createReactComponent<JSX.AuxSlider, HTMLAuxSliderElement>('aux-slider');
