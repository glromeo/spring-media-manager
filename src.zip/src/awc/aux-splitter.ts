import { meta } from './bootstrap';
import { set_aux_splitter } from './esm/aux-bundle.entry';
import info from './meta/aux-splitter.json';
//@ts-ignore
import {aux_splitter} from '@blk/aladdin-web-components/dist/esm/aux-splitter.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_splitter(aux_splitter);

export const AuxSplitter = /*@__PURE__*/createReactComponent<JSX.AuxSplitter, HTMLAuxSplitterElement>('aux-splitter');
