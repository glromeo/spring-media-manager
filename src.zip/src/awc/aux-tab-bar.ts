import { meta } from './bootstrap';
import { set_aux_tab_bar } from './esm/aux-bundle.entry';
import info from './meta/aux-tab-bar_2.json';
//@ts-ignore
import {aux_tab_bar} from '@blk/aladdin-web-components/dist/esm/aux-tab-bar_2.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_tab_bar(aux_tab_bar);

export const AuxTabBar = /*@__PURE__*/createReactComponent<JSX.AuxTabBar, HTMLAuxTabBarElement>('aux-tab-bar');
