import { meta } from './bootstrap';
import { set_aux_tab_group } from './esm/aux-bundle.entry';
import info from './meta/aux-tab-group.json';
//@ts-ignore
import {aux_tab_group} from '@blk/aladdin-web-components/dist/esm/aux-tab-group.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_tab_group(aux_tab_group);

export const AuxTabGroup = /*@__PURE__*/createReactComponent<JSX.AuxTabGroup, HTMLAuxTabGroupElement>('aux-tab-group');
