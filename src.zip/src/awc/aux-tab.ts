import { meta } from './bootstrap';
import { set_aux_tab } from './esm/aux-bundle.entry';
import info from './meta/aux-tab_2.json';
//@ts-ignore
import {aux_tab} from '@blk/aladdin-web-components/dist/esm/aux-tab_2.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_tab(aux_tab);

export const AuxTab = /*@__PURE__*/createReactComponent<JSX.AuxTab, HTMLAuxTabElement>('aux-tab');
