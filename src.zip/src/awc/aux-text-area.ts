import { meta } from './bootstrap';
import { set_aux_text_area } from './esm/aux-bundle.entry';
import info from './meta/aux-text-area.json';
//@ts-ignore
import {aux_text_area} from '@blk/aladdin-web-components/dist/esm/aux-text-area.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_text_area(aux_text_area);

export const AuxTextArea = /*@__PURE__*/createReactComponent<JSX.AuxTextArea, HTMLAuxTextAreaElement>('aux-text-area');
