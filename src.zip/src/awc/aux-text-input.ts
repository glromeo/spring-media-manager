import { meta } from './bootstrap';
import { set_aux_text_input } from './esm/aux-bundle.entry';
import info from './meta/aux-text-input.json';
//@ts-ignore
import {aux_text_input} from '@blk/aladdin-web-components/dist/esm/aux-text-input.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_text_input(aux_text_input);

export const AuxTextInput = /*@__PURE__*/createReactComponent<JSX.AuxTextInput, HTMLAuxTextInputElement>('aux-text-input');
