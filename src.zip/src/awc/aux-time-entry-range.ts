import { meta } from './bootstrap';
import { set_aux_time_entry_range } from './esm/aux-bundle.entry';
import info from './meta/aux-time-entry-range.json';
//@ts-ignore
import {aux_time_entry_range} from '@blk/aladdin-web-components/dist/esm/aux-time-entry-range.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_time_entry_range(aux_time_entry_range);

export const AuxTimeEntryRange = /*@__PURE__*/createReactComponent<JSX.AuxTimeEntryRange, HTMLAuxTimeEntryRangeElement>('aux-time-entry-range');
