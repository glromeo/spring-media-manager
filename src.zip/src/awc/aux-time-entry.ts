import { meta } from './bootstrap';
import { set_aux_time_entry } from './esm/aux-bundle.entry';
import info from './meta/aux-time-entry.json';
//@ts-ignore
import {aux_time_entry} from '@blk/aladdin-web-components/dist/esm/aux-time-entry.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_time_entry(aux_time_entry);

export const AuxTimeEntry = /*@__PURE__*/createReactComponent<JSX.AuxTimeEntry, HTMLAuxTimeEntryElement>('aux-time-entry');
