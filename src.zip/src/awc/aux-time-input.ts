import { meta } from './bootstrap';
import { set_aux_time_input } from './esm/aux-bundle.entry';
import info from './meta/aux-time-input.json';
//@ts-ignore
import {aux_time_input} from '@blk/aladdin-web-components/dist/esm/aux-time-input.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_time_input(aux_time_input);

export const AuxTimeInput = /*@__PURE__*/createReactComponent<JSX.AuxTimeInput, HTMLAuxTimeInputElement>('aux-time-input');
