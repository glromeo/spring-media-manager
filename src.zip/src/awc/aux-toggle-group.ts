import { meta } from './bootstrap';
import { set_aux_toggle_group } from './esm/aux-bundle.entry';
import info from './meta/aux-toggle-group.json';
//@ts-ignore
import {aux_toggle_group} from '@blk/aladdin-web-components/dist/esm/aux-toggle-group.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_toggle_group(aux_toggle_group);

export const AuxToggleGroup = /*@__PURE__*/createReactComponent<JSX.AuxToggleGroup, HTMLAuxToggleGroupElement>('aux-toggle-group');
