import { meta } from './bootstrap';
import { set_aux_tree_list } from './esm/aux-bundle.entry';
import info from './meta/aux-expansion-panel_2.json';
//@ts-ignore
import {aux_tree_list} from '@blk/aladdin-web-components/dist/esm/aux-expansion-panel_2.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_tree_list(aux_tree_list);

export const AuxTreeList = /*@__PURE__*/createReactComponent<JSX.AuxTreeList, HTMLAuxTreeListElement>('aux-tree-list');
