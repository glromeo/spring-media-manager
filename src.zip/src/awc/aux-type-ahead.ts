import { meta } from './bootstrap';
import { set_aux_type_ahead } from './esm/aux-bundle.entry';
import info from './meta/aux-type-ahead.json';
//@ts-ignore
import {aux_type_ahead} from '@blk/aladdin-web-components/dist/esm/aux-type-ahead.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_type_ahead(aux_type_ahead);

export const AuxTypeAhead = /*@__PURE__*/createReactComponent<JSX.AuxTypeAhead, HTMLAuxTypeAheadElement>('aux-type-ahead');
