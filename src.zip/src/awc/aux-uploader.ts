import { meta } from './bootstrap';
import { set_aux_uploader } from './esm/aux-bundle.entry';
import info from './meta/aux-uploader.json';
//@ts-ignore
import {aux_uploader} from '@blk/aladdin-web-components/dist/esm/aux-uploader.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_uploader(aux_uploader);

export const AuxUploader = /*@__PURE__*/createReactComponent<JSX.AuxUploader, HTMLAuxUploaderElement>('aux-uploader');
