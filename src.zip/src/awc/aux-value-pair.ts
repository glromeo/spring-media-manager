import { meta } from './bootstrap';
import { set_aux_value_pair } from './esm/aux-bundle.entry';
import info from './meta/aux-value-pair.json';
//@ts-ignore
import {aux_value_pair} from '@blk/aladdin-web-components/dist/esm/aux-value-pair.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_value_pair(aux_value_pair);

export const AuxValuePair = /*@__PURE__*/createReactComponent<JSX.AuxValuePair, HTMLAuxValuePairElement>('aux-value-pair');
