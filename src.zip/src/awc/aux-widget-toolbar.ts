import { meta } from './bootstrap';
import { set_aux_widget_toolbar } from './esm/aux-bundle.entry';
import info from './meta/aux-widget_2.json';
//@ts-ignore
import {aux_widget_toolbar} from '@blk/aladdin-web-components/dist/esm/aux-widget_2.entry.js';

import { JSX } from '@blk/aladdin-web-components';
//@ts-ignore
import { createReactComponent } from '../react-component-lib';

meta.push(info); 
set_aux_widget_toolbar(aux_widget_toolbar);

export const AuxWidgetToolbar = /*@__PURE__*/createReactComponent<JSX.AuxWidgetToolbar, HTMLAuxWidgetToolbarElement>('aux-widget-toolbar');
