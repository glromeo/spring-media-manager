export const meta:any[] = []

const bundleRelativeUrl = "./esm/aux-bundle.entry.js";

export function bootstrapComponents() {

    Object.defineProperty(window, "auxWebComponents", {
        enumerable: true,
        writable: true,
        value: {"name": "@blk/aladdin-web-components", "version": "9.3.1", "mode": "default"}
    });
    Object.defineProperty(window, "mode", {
        enumerable: true,
        writable: true,
        value: "default"
    });
    // @ts-ignore
    import(bundleRelativeUrl).then(({b: bootstrapLazy, s: setMode, p: plt, w: win})=>{
        setMode((elm:any) => {
            // @ts-ignore
            return (window['mode'] || elm['mode'] || elm.getAttribute('mode') || 'default');
        });
        bootstrapLazy(meta.map(data=>["aux-bundle", data]));
    })
}
