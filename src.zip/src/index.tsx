import './index.scss';

export * from "./AtwColumnResizer";
export * from "./AtwGrid";
export * from "./AtwTooltip";
export * from "./AtwChart";
//
// export {
//     AuxSegmentedControl,
//     AuxSelect,
//     AuxInputMask,
//     AuxCheckbox,
//     AuxIcon,
//     AuxPopover,
//     AuxRadioGroup,
//     AuxSearchField,
//     AuxNotificationGroup,
//     AuxWidget,
//     AuxWidgetToolbar,
//     AuxPicklist,
//     AuxButton,
//     AuxModal,
//     AuxTabBar,
// } from "./aladdin-react-components/index";
//
// export {
//     AuxNotificationGroupTypeEnum,
//     AuxNotificationStyleEnum,
//     AuxInputTypeEnum,
//     AuxDynamicPositionEnum
// } from "@blk/aladdin-web-components";
//
// export type {
//     AuxSelectApplyButtonClickedDetailInterface,
//     AuxSelectDropdownClosedDetailInterface,
//     AuxSelectDropdownOpenedDetailInterface,
//     AuxSelectOption,
//     AuxSelectOptionGroup,
//     AuxSelectSelectionChangedDetailInterface,
//     AuxCheckboxChangedDetailInterface,
//     AuxRadioGroupChangedDetailInterface,
//     AuxNotificationGroupConfig,
//     AuxSelectionTreeInterface,
// } from "@blk/aladdin-web-components";

// import awc from "./index.json";
//
// const bootstrapper = "./esm/aux-bundle.entry.js";

export function bootstrapComponents() {
    // Object.defineProperty(window, "auxWebComponents", {
    //     enumerable: true,
    //     writable: true,
    //     value: {"name": "@blk/aladdin-web-components", "version": "8.8.1", "mode": "default"}
    // });
    // Object.defineProperty(window, "mode", {
    //     enumerable: true,
    //     writable: true,
    //     value: "default"
    // });
    // // @ts-ignore
    // import(bootstrapper).then(({b: bootstrapLazy, s: setMode, p: plt, w: win})=>{
    //     setMode((elm:any) => {
    //         // @ts-ignore
    //         return (window['mode'] || elm['mode'] || elm.getAttribute('mode') || 'default');
    //     });
    //     bootstrapLazy(awc.map(([url, entry])=>["aux-bundle", entry]));
    // })
}
export {useContextMenu} from "./useContextMenu";
export {AtwGridHeader} from "./AtwGridHeader";
export {AtwGridBody} from "./AtwGridBody";
export {ROW_CACHE} from "./AtwGridBody";
export {RowCache} from "./AtwGridBody";
export {INITIAL_RANGE} from "./AtwGridBody";
export {AtwGridContainer} from "./AtwGridContainer";