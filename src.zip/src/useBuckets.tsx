import React, {Fragment, useMemo, useRef} from "react";
import {AtwCellRenderDecorator, AtwCellRenderer, AtwGroupBy, AtwGroupTotals, DataItem} from "./AtwGrid";

export type Bucket<T> = Map<string, Bucket<T>> & { item: T, items?: T[], collapsed?: boolean }

export type OnBucketChange<T> = (bucket: Bucket<T>) => void

const NO_DECORATOR: AtwCellRenderDecorator<any> = x => x;

export const useBuckets = <T extends DataItem>(data: T[], groupBy: AtwGroupBy<T> | undefined, onChange: OnBucketChange<T>): [T[], AtwCellRenderDecorator<T>] => {

    const buckets = useMemo<Bucket<T> | undefined>(() => {
        if (groupBy && groupBy.size && data.length) {
            const buckets: Bucket<T> = new Map() as Bucket<T>;
            for (const item of data) {
                let bucket: Bucket<T> = buckets;
                for (const [field] of groupBy) {
                    const key = String(item[field]);
                    let next = bucket.get(key);
                    if (!next) {
                        next = new Map() as Bucket<T>;
                        next.item = item; // note: this won't show up when we iterate!
                        bucket.set(key, next);
                    }
                    bucket = next;
                }
                const items = bucket.items;
                if (items) {
                    items.push(item);
                } else {
                    bucket.items = [item];
                    bucket.collapsed = false;
                }
            }
            return buckets;
        }
    }, [data, groupBy]);

    const changeCallback = useRef<OnBucketChange<T>>();
    changeCallback.current = onChange;

    const renderGroupBy = useMemo(() => {

        const Up = ({bucket}: { bucket: Bucket<T> }) => (
            <svg className="svg-icon" viewBox="0 0 16 16" onClick={() => {
                bucket.collapsed = false;
                changeCallback.current!(bucket);
            }}>
                <path fillRule="evenodd" d="M7.646 4.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1-.708.708L8 5.707l-5.646 5.647a.5.5 0 0 1-.708-.708l6-6z"/>
            </svg>
        );

        const Down = ({bucket}: { bucket: Bucket<T> }) => (
            <svg className="svg-icon" viewBox="0 0 16 16" onClick={() => {
                bucket.collapsed = true;
                changeCallback.current!(bucket);
            }}>
                <path fillRule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"/>
            </svg>
        );

        return (render: AtwCellRenderer<T>): AtwCellRenderer<T> => {
            return (row, column) => {
                const bucket = row.$$bucket;
                if (bucket) {
                    const delegated: any = render(row, column);
                    return delegated.props.children ? (
                        <Fragment>
                            {bucket.collapsed ? <Up bucket={bucket}/> : <Down bucket={bucket}/>}
                            {delegated}
                        </Fragment>
                    ) : delegated;
                } else {
                    return null;
                }
            };
        };

    }, []);

    if (!buckets) {
        return [data, NO_DECORATOR];
    } else {
        return [toArray(buckets, [...groupBy!.entries()]), renderGroupBy];
    }
};

function toArray<T extends DataItem>(bucket: Bucket<T>, entries: [keyof T, AtwGroupTotals<T>][]): T[] {
    const rows: T[] = [];
    const [entry] = entries;
    if (entry) {
        const [field, totals] = entry;
        const rest = entries.slice(1);
        for (const [key, next] of bucket) {
            const items = toArray(next, rest);
            const row = {id: `${field}-${key}`, $$bucket: next, [field]: next.item[field]} as T;
            for (const [on, t] of totals) if (t) {
                row[on] = t.fn(items, on) as any;
            } else {
                row[on] = null as any;
            }
            rows.push(row);
            if (!next.collapsed) {
                rows.push(...items);
            }
        }
        return rows;
    } else {
        return bucket.items!;
    }
}
