import {MouseEvent} from "react";
import ReactDOM from "react-dom";
import {DataItem} from "./AtwGrid";

export function useContextMenu<T extends DataItem>(createElement: (close: () => void) => JSX.Element) {
    return (event: MouseEvent) => {
        event.preventDefault();
        event.stopPropagation();

        const {pageX, pageY} = event;
        const anchorEl = document.createElement("div");
        document.body.append(anchorEl);
        anchorEl.style.cssText = `position: fixed; left:${pageX}px; top: ${pageY}px;`;

        ReactDOM.render(createElement(() => anchorEl.remove()), anchorEl);
    };
}