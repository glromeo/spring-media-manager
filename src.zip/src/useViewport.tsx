import {RefObject, useEffect, useState} from "react";

export type AtwGridViewPort = {
    scrollLeft: number
    scrollTop: number
    clientWidth: number
    clientHeight: number
}

type OnScroll<T> = ((gridElement: T) => void) | undefined

const DEFAULT_VIEWPORT = () => ({
    scrollLeft: 0,
    scrollTop: 0,
    clientWidth: 0,
    clientHeight: 0
});

export function useViewport<T extends HTMLDivElement>(gridRef: RefObject<T>, inverse: undefined | boolean, onScroll: OnScroll<T>): AtwGridViewPort {

    const gridElement = gridRef.current;
    let [viewPort, setViewPort] = useState(DEFAULT_VIEWPORT);

    useEffect(() => {
        if (gridElement) {
            viewPort.clientWidth = gridElement.clientWidth;
            viewPort.clientHeight = gridElement.clientHeight;

            let af: number;

            const mutationObserver = () => {
                cancelAnimationFrame(af);
                af = requestAnimationFrame(() => {
                    if (inverse) {
                        gridElement.scrollLeft = Number.MAX_SAFE_INTEGER;
                    }
                    setViewPort({
                        scrollLeft: gridElement.scrollLeft,
                        scrollTop: gridElement.scrollTop,
                        clientWidth: gridElement.clientWidth,
                        clientHeight: gridElement.clientHeight
                    });
                });
            };
            const scrollListener = () => {
                cancelAnimationFrame(af);
                af = requestAnimationFrame(() => {
                    setViewPort({
                        scrollLeft: gridElement.scrollLeft,
                        scrollTop: gridElement.scrollTop,
                        clientWidth: gridElement.clientWidth,
                        clientHeight: gridElement.clientHeight
                    });
                    if (onScroll) onScroll(gridElement);
                });
            };

            const observer = new ResizeObserver(mutationObserver);
            observer.observe(gridElement);
            gridElement.addEventListener("scroll", scrollListener);
            return () => {
                gridElement.removeEventListener("scroll", scrollListener);
                observer.disconnect();
            };
        }
    }, [gridElement, inverse, onScroll]);

    if (gridElement) {
        viewPort.clientWidth = gridElement.clientWidth;
        viewPort.clientHeight = gridElement.clientHeight;
    }

    return viewPort;
}