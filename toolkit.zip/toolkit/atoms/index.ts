import { atom } from "jotai";
import { searchParam } from "../utils";

export * from "./utils/atom-sink";
export * from "./utils/atom-with-effects";
export * from "./utils/globals";
export * from "./utils/matrix-atom";

export const statusOverlayAtom = ((pendingOperationsAtom = atom<string[]>([])) =>
    atom(
        (get) => get(pendingOperationsAtom)[0],
        (get, set, message: string, pending: Promise<any>) => {
            set(pendingOperationsAtom, [...get(pendingOperationsAtom), message]);
            pending.finally(() => {
                set(
                    pendingOperationsAtom,
                    get(pendingOperationsAtom).filter((msg) => msg !== message)
                );
            });
        }
    ))();

export const userAtom = atom<string>(searchParam("user") ?? "anonymous");
