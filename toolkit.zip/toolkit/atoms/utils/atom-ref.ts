import { atom } from "jotai";

export function atomRef<V extends object>(init: V) {
    const primitiveAtom = atom<[V]>([init]);
    return atom(
        (get) => {
            const [underlying] = get(primitiveAtom);
            return underlying;
        },
        (get, set, update: V | ((current: V) => V | void)) => {
            const [underlying] = get(primitiveAtom);
            if (typeof update === "function") {
                set(primitiveAtom, [update(underlying) ?? underlying]);
            } else {
                set(primitiveAtom, [update]);
            }
        }
    );
}
