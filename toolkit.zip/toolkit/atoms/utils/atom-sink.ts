import { atom, PrimitiveAtom } from "jotai";

/**
 * A sink is backed by an immutable array
 * writing to a sink pushes (copy on write) the element at the end of the array
 * reading from a sink drains it
 *
 * @param listAtom
 */
export function atomSink<T>(listAtom: PrimitiveAtom<T[]>) {
    return atom(
        (get, { setSelf }) => {
            const items = get(listAtom);
            setSelf([]);
            return items;
        },
        (get, set, value: T) => {
            set(listAtom, [...get(listAtom), value]);
        }
    );
}
