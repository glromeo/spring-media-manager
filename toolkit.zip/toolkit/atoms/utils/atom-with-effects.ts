import { atom, WritableAtom } from "jotai";

/**
 * It's a derivative atom backed by a primitive one that causes side effects BEFORE being written to
 *
 * @param initialValue
 * @param effect
 */
export function atomWithEffects<Value>(
    initialValue: Value,
    effect: WritableAtom<Value, [Value, Value], void>["write"]
) {
    const primitive = atom(initialValue);
    return atom(
        (get) => get(primitive),
        (get, set, value: Value) => {
            effect(get, set, value, get(primitive));
            set(primitive, value);
        }
    );
}
