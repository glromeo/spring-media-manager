import { atom, createStore } from "jotai";
import { useEffect } from "react";

import { Atom, WritableAtom } from "jotai";

export type AtomGetter = <Value>(atom: Atom<Value>) => Value;
export type AtomSetter = <Value, Args extends unknown[], Result>(
    atom: WritableAtom<Value, Args, Result>,
    ...args: Args
) => Result;

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Globally acessible jotaiStore ...I already know I am going to regret this!
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

export const jotaiStore = createStore();

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Legacy dispatch integration layer with Java Dashboard Components
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

export type AtxAction = { type: string; payload: any };
export type AtxDispatch = (action: AtxAction) => void;

const dispatchers = new Set<AtxDispatch>();

export function useDispatcher(dispatch: ((action: { type: string; payload: any }) => void) | undefined) {
    useEffect(() => {
        if (dispatch) {
            dispatchers.add(dispatch);
            return () => {
                dispatchers.delete(dispatch);
            };
        }
    }, []);
}

const atwRequestStateAtom = atom<any>({}); // TODO: remove this once we move away from redux in ATW

if (!window.hasOwnProperty("store")) {
    Object.defineProperty(window, "store", {
        configurable: true,
        enumerable: true,
        writable: true,
        value: {
            dispatch(action: AtxAction) {
                switch (action.type) {
                    case "ATW/SET_REQUEST_STATE":
                        jotaiStore.set(atwRequestStateAtom, action.payload);
                        return;
                    default:
                        if (dispatchers.size) {
                            for (const dispatch of dispatchers) {
                                dispatch(action);
                            }
                        } else {
                            console.error("no dispatchers available to dispatch action:", action);
                        }
                }
            }
        }
    });
}
