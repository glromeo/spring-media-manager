import { atom, WritableAtom } from "jotai";

type MapFn<V extends object, K extends keyof V> = (item: V, index?: number) => V[K];
type Mapper<V extends object, K extends keyof V> = Partial<Record<keyof V, MapFn<V, K> | V[K]>>;

type OnChange<V> = WritableAtom<V, [Set<V>, Set<keyof V>], void>["write"];
type OnDelete<V> = WritableAtom<V, [Set<V>], void>["write"];

/**
 * The purpose of this syntactic sugar is to simplify writing code that deals with arrays
 * of object because it deals with change detection and provides a simple onChange callback
 * in which one can apply further mutations to the changed entries knowing which ones
 * they are (X/rows) and which fields have been affected (Y/columns)
 *
 * In order to keed track of the changes there must be a 'key' field which must be passed in as option
 *
 * This utility provides various reducers to simplify apply changes in bulk:
 *
 * 1) To just set the values (in the onChange the fields will be all them):
 *
 * set(rfqsAtom, [rfq1, rfq2, ....])
 *
 * 2) Just map all the rows (in the onChange the fields will be all them)
 *
 * set(rfqsAtom, (rfq, index) => {...})
 *
 * 3) Map each field (like in this case just the benchmark), this notation is useful to provide onChange with
 *    the information of which columns have (likely) changed
 *
 * set(rfqsAtom, {
 *   priceType: "spread"
 * })
 *
 * set(rfqsAtom, {
 *   benchmark: rfq => benchmarks[rfq.order.asset.cusip] ?? null
 * })
 *
 * 4) Same as above but applies only to the item with the specified key
 *
 * set(rfqsAtom, order, {
 *   benchmark: rfq => benchmarks[rfq.order.asset.cusip] ?? null
 * })
 *
 * NOTE: 4 is kind of redundant given in 3 you can use a if condition on the item passed in the field mapper
 *       it is there as pure sugar (with a bit of optimization)
 *
 * 5) Delete a row from the matrix (the order here is the value of the key)
 */
export function matrixAtom<V extends object, K extends keyof V>(
    init: V[],
    { key, onChange, onDelete }: { key: K; onChange?: OnChange<V>; onDelete?: OnDelete<V> }
) {
    type T = V[K];
    const primitive = atom<V[]>(init ?? []);
    return atom<
        V[],
        /* (1) */
        | [V[]]
        /* (2) */
        | [(item: V, index?: number) => V]
        /* (3) */
        | [Mapper<V, keyof V>]
        /* (4) */
        | [T, Mapper<V, keyof V>]
        /* (5) */
        | [T, "delete"],
        void
    >(
        (get) => get(primitive),
        (get, set, ...args) => {
            const current = get(primitive);
            let [action, payload] = args;
            let update: V[];
            let changed: V[];
            let fields: (keyof V)[];
            if (Array.isArray(action)) {
                changed = update = action;
                fields = changed.length ? (Object.keys(changed[0]) as (keyof V)[]) : [];
            } else if (typeof action === "function") {
                const mapper = action as (item: V, index?: number) => V;
                update = current.map(mapper);
                changed = update.filter((item, index) => current[index] !== item);
                fields = changed.length ? (Object.keys(changed[0]) as (keyof V)[]) : [];
            } else if (payload === "delete") {
                fields = [];
                changed = [];
                update = current.filter((item) => {
                    if (item[key] !== action) {
                        return true;
                    } else {
                        changed.push(item);
                        return false;
                    }
                });
            } else {
                if (payload) {
                    const mapper = compileMapper(payload as Mapper<V, keyof V>);
                    fields = mapper.fields;
                    changed = [];
                    update = current.map((item, index) => {
                        if (item[key] === action) {
                            const mapped = mapper.map(item, index);
                            changed.push(mapped);
                            return mapped;
                        } else {
                            return item;
                        }
                    });
                } else {
                    const mapper = compileMapper(action as Mapper<V, keyof V>);
                    fields = mapper.fields;
                    changed = [];
                    update = current.map((item, index) => {
                        const mapped = mapper.map(item, index);
                        if (mapped !== item) {
                            changed.push(mapped);
                        }
                        return mapped;
                    });
                }
            }

            if (changed.length) {
                if (update.length < current.length) {
                    onDelete?.(get, set, new Set(changed));
                } else {
                    onChange?.(get, set, new Set(changed), new Set(fields));
                }
                set(primitive, update);
            }
        }
    );
}

function compileMapper<V extends object, K extends keyof V>(
    mapper: Mapper<V, K>
): { fields: (keyof V)[]; map: (item: V, index?: number) => V } {
    const fields = Object.keys(mapper) as (keyof V)[];
    return {
        fields,
        map(item: V) {
            let result = item;
            for (const field of fields) {
                const fn = mapper[field];
                const value = typeof fn === "function" ? fn(item) : fn;
                if (value !== item[field]) {
                    if (result === item) {
                        result = { ...item, [field]: value };
                    } else {
                        result[field] = value;
                    }
                }
            }
            return result;
        }
    };
}
