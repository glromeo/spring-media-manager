import type { Atom } from "jotai";

export interface WeakFamily<Param extends object, AtomType> {
    (param: Param): AtomType;
    remove(param: Param): void;
}

export function weakFamily<Param extends object, AtomType extends Atom<unknown>>(
    initializeAtom: (param: Param) => AtomType
): WeakFamily<Param, AtomType>;

export function weakFamily<Param extends object, AtomType extends Atom<unknown>>(
    initializeAtom: (param: Param) => AtomType,
    areEqual?: (a: Param, b: Param) => boolean
) {
    const atoms = new WeakMap<Param, AtomType>();
    const family = (param: Param) => {
        let atom = atoms.get(param);
        if (atom === undefined) {
            atoms.set(param, (atom = initializeAtom(param)));
        }
        return atom;
    };
    family.remove = (param: Param) => {
        atoms.delete(param);
    };
    return family;
}
