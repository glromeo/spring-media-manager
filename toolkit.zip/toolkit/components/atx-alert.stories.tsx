import { useParameter } from "@atx/stories";
import { AtxAlert } from "@atx/toolkit";

export default () => {
    const [disabled, setDisabled] = useParameter("disabled", "boolean", false);

    const [dismissible, setDismissible] = useParameter("dismissible", "boolean", true);

    const [dismissed, setDismissed] = useParameter("dismissed", "checkboxes", {
        "info": false,
        "warning": false,
        "danger": false,
        "success": false
    });

    return (
        <div className="flex-column">
            {!dismissed.info ? (
                <AtxAlert
                    testId="info"
                    style={{ marginBottom: "1rem" }}
                    title="MESSAGE"
                    disabled={disabled}
                    type="info"
                    onClose={
                        dismissible
                            ? () => {
                                  setDismissed({ ...dismissed, info: true });
                              }
                            : undefined
                    }
                >
                    This is a info level alert
                </AtxAlert>
            ) : null}
            {!dismissed.warning ? (
                <AtxAlert
                    testId="warning"
                    style={{ marginBottom: "1rem" }}
                    title="WARNING"
                    disabled={disabled}
                    type="warning"
                    onClose={
                        dismissible
                            ? () => {
                                  setDismissed({ ...dismissed, warning: true });
                              }
                            : undefined
                    }
                >
                    This is a warning level alert
                </AtxAlert>
            ) : null}
            {!dismissed.danger ? (
                <AtxAlert
                    testId="danger"
                    style={{ marginBottom: "1rem" }}
                    title="ERROR"
                    disabled={disabled}
                    type="danger"
                    onClose={
                        dismissible
                            ? () => {
                                  setDismissed({ ...dismissed, danger: true });
                              }
                            : undefined
                    }
                >
                    This is a danger alert
                </AtxAlert>
            ) : null}
            {!dismissed.success ? (
                <AtxAlert
                    testId="success"
                    style={{ marginBottom: "1rem" }}
                    title="SUCCESS"
                    disabled={disabled}
                    type="success"
                    onClose={
                        dismissible
                            ? () => {
                                  setDismissed({ ...dismissed, success: true });
                              }
                            : undefined
                    }
                >
                    This is a success alert
                </AtxAlert>
            ) : null}
        </div>
    );
};

export const info = () => (
    <AtxAlert testId="dismissible-info" type="info" onClose={() => console.log("delete info")}>
        This is a info message
    </AtxAlert>
);
export const warning = () => (
    <AtxAlert testId="dismissible-warning" type="warning" onClose={() => console.log("delete warning")}>
        This is a warning message
    </AtxAlert>
);
export const danger = () => (
    <AtxAlert testId="dismissible-danger" type="danger" onClose={() => console.log("delete danger")}>
        This is a error message
    </AtxAlert>
);
export const success = () => (
    <AtxAlert testId="dismissible-success" type="success" onClose={() => console.log("delete success")}>
        This is a success message
    </AtxAlert>
);
