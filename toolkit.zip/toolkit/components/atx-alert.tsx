import { classNames } from "../utils";
import { AtxIcon, AtxIconName } from "./atx-icon";
import { Level, Type, WidgetProps } from "./widgets";
import "./atx-alert.scss";

type AtxAlertProps = Omit<WidgetProps<HTMLDivElement>, "title" | "type"> & {
    title?: string;
    type?: Level;
    onClose?: (event: React.MouseEvent<HTMLDivElement>) => void;
};

const iconNames: Partial<Record<Type, AtxIconName>> = {
    info: "info-bold",
    danger: "error-bold",
    warning: "alert-bold",
    success: "success-bold"
};

export function AtxAlert(props: AtxAlertProps) {
    const {
        testId,
        className,
        style,
        title,
        onClick,
        disabled,
        children,
        size = "regular",
        type = "info",
        onClose
    } = props;
    return (
        <div
            data-test-id={testId}
            className={classNames(
                "atx-alert",
                className,
                !disabled && (onClick || onClose) && "actionable",
                disabled && "disabled",
                size,
                type
            )}
            style={style}
            onClick={disabled ? undefined : onClick}
        >
            <AtxIcon className="icon" name={iconNames[type]} />
            <div className="content">
                {title && <div className="title">{title}</div>}
                <div className="message">{children}</div>
            </div>
            {onClose && <AtxIcon className="close" name="delete" onClick={disabled ? undefined : onClose} />}
        </div>
    );
}
