import { ReactNode } from "react";
import { AtxStatusOverlay } from "./atx-status-overlay";
import { AtxNotifications } from "./atx-notifications";
import { AtxDispatch, useDispatcher } from "../atoms";
import { AtxAtoms } from "./atx-atoms";
import { AtxFloatingPortal } from "./atx-floating-portal";
import { Atom } from "jotai";

import "./atx-app.scss";

export type AtxAppProps = {
    atoms?: Record<string, Atom<any>>;
    children: ReactNode;
    dispatch?: AtxDispatch;
};

export function AtxApp({ atoms = {}, children, dispatch }: AtxAppProps) {
    useDispatcher(dispatch);
    return (
        <div className="atx-app">
            <AtxAtoms atoms={atoms}>
                <AtxStatusOverlay />
                <AtxNotifications />
                {children}
                <AtxFloatingPortal />
            </AtxAtoms>
        </div>
    );
}
