import React, { ReactNode } from "react";
import { Atom, Provider, useAtomValue } from "jotai";
import { AtxDevtools, useDebugTools } from "./atx-devtools";

import { jotaiStore } from "../atoms";

export const AtxAtomsContext = React.createContext<Record<string, Atom<any>>>({});

export function AtxAtoms({ atoms, children }: { atoms: Record<string, Atom<any>>; children: ReactNode }) {
    useDebugTools(atoms);

    if (atoms.settings) {
        useAtomValue(atoms.settings);
    }

    return (
        <AtxAtomsContext.Provider value={atoms}>
            <Provider store={jotaiStore}>
                <AtxDevtools>{children}</AtxDevtools>
            </Provider>
        </AtxAtomsContext.Provider>
    );
}
