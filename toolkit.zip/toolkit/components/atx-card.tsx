import "./atx-card.scss";
import React, { useEffect, useState } from "react";
import { classNames } from "../utils";
import { WidgetProps } from "./widgets";

export type AtxCardProps = Omit<WidgetProps<HTMLDivElement>, "children"> & {
    title: React.ReactNode;
    contents: (isOpen: boolean) => React.ReactNode;
    isOpen?: boolean;
    onToggle?: (isOpen: boolean) => {};
};

export function AtxCard(props: AtxCardProps) {
    const { testId, className, style, size, disabled, title, contents, onClick, onToggle } = props;
    const [isOpen, setOpen] = useState(false);
    if (props.hasOwnProperty("isOpen")) {
        useEffect(() => {
            setOpen(props.isOpen ?? false);
        }, [props.isOpen]);
    }
    const onChange = onToggle
        ? (isOpen: boolean) => {
              setOpen(isOpen);
              onToggle(isOpen);
          }
        : setOpen;
    return (
        <div
            data-test-id={testId}
            className={classNames(
                "atx-card",
                className,
                !disabled && (onClick || onToggle) && "actionable",
                disabled && "disabled",
                size
            )}
            style={style}
            onClick={disabled ? undefined : onClick}
        >
            <div className="heading">
                <div className="title">{title}</div>
                <ToggleIcon value={isOpen} onChange={onChange} />
            </div>
            <div className="content">{contents(isOpen)}</div>
        </div>
    );
}

const polyline = (downwards: boolean) => (downwards ? "4 10 8.04 6 12 9.92" : "4 6 8.04 10 12 6.08");

export function ToggleIcon({ value, onChange }: { value: boolean; onChange: (value: boolean) => void }) {
    return (
        <div className={`toggle-icon ${value ? "expanded" : "collapsed"}`} onClick={() => onChange(!value)}>
            <svg viewBox="0 0 16 16" fill="none" stroke="currentColor">
                <polyline strokeWidth="1.5" points={polyline(value)} />
            </svg>
        </div>
    );
}
