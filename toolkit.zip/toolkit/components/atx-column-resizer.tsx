import { MouseEventHandler, useMemo } from "react";
import { classNames } from "../utils";
import "./atx-column-resizer.scss";

export type AtxColumnResizerProps = {
    minWidth?: number;
    placement: "left" | "right";
    edge?: boolean;
    onResize?: (width: number, deltaX: number) => void;
    onMouseUp?: (width: number, deltaX: number) => void;
    container?: HTMLElement | null;
    onDoubleClick?: MouseEventHandler<HTMLDivElement> | undefined;
};

/**
 *
 * @param minWidth
 * @param placement
 * @param edge
 * @param onResize
 * @param onMouseUp
 * @param container
 * @param onDoubleClick
 * @constructor
 */
export function AtxColumnResizer({
    minWidth = 32,
    placement,
    edge = false,
    onResize,
    onMouseUp,
    container,
    onDoubleClick
}: AtxColumnResizerProps) {
    return useMemo(
        () => (
            <div
                ref={(instance) => {
                    if (!container) {
                        container = instance?.parentElement;
                    }
                    if (container) {
                        let computedStyle = getComputedStyle(container);
                        let computedMinWidth = parseInt(computedStyle.minWidth);
                        if (!isNaN(computedMinWidth)) {
                            minWidth = computedMinWidth;
                        }
                        if (computedStyle.position === "static") {
                            console.warn("column resizer parent is statically positioned");
                        }
                    }
                }}
                className={classNames("column-resizer", placement, edge && "edge")}
                onMouseDown={(trigger) => {
                    trigger.preventDefault();
                    trigger.stopPropagation();

                    const target = trigger.target as HTMLDivElement;
                    target.classList.toggle("active");

                    if (!container) {
                        container = target.parentElement;
                    }

                    if (!onResize) {
                        onResize = (width: number) => (container!.style.width = `${width}px`);
                    }

                    document.body.addEventListener("mousemove", dragHandler);
                    document.body.addEventListener("mouseup", dragHandler);

                    const initialCursor = document.body.style.cursor;
                    document.body.style.cursor = "ew-resize";
                    document.body.classList.add("resizing");

                    const initialX = trigger.pageX;
                    let width: number = container?.getBoundingClientRect().width ?? minWidth;
                    let update = 0;
                    let af: number = 0;

                    function dragHandler({ buttons, pageX }: MouseEvent) {
                        if (buttons !== 1) {
                            document.body.removeEventListener("mousemove", dragHandler);
                            document.body.removeEventListener("mouseup", dragHandler);
                            requestAnimationFrame(function () {
                                onResize!(width + update, update);
                                target.classList.toggle("active");
                                document.body.style.cursor = initialCursor;
                                document.body.classList.remove("resizing");
                                if (onMouseUp) {
                                    onMouseUp(width, update);
                                }
                            });
                        } else {
                            const deltaX = placement === "left" ? initialX - pageX : pageX - initialX;
                            update = Math.round(Math.max(minWidth, width + deltaX) - width);
                            clearTimeout(af);
                            af = requestAnimationFrame(function () {
                                onResize!(width + update, update);
                            });
                        }
                    }
                }}
                onDoubleClick={onDoubleClick}
            />
        ),
        [container, minWidth, placement]
    );
}
