import React, { ReactNode, useEffect } from "react";
import { DevTools } from "jotai-devtools";
import { Atom } from "jotai";
import { AtomFamily } from "jotai/vanilla/utils/atomFamily";
import { jotaiStore } from "../atoms";

export const useDebugTools = (atoms: { [name: string]: Atom<any> }) => {
    useEffect(() => {
        for (const [name, atom] of Object.entries(atoms)) {
            if (atom) {
                (atom as any).debugLabel = name;
            }
        }

        Object.defineProperty(window, "jotaiStore", {
            configurable: true,
            writable: true,
            value: jotaiStore
        });

        Object.defineProperty(window, "atoms", {
            configurable: true,
            writable: true,
            value: atoms
        });

        Object.defineProperty(window, "getAtom", {
            configurable: true,
            writable: true,
            value: (name: keyof typeof atoms) => jotaiStore.get(atoms[name] as any)
        });

        Object.defineProperty(window, "setAtom", {
            configurable: true,
            writable: true,
            value: (name: keyof typeof atoms, value: any) => jotaiStore.set(atoms[name] as any, value)
        });
    }, [atoms]);
};

export function AtxDevtools({ children }: { children: ReactNode }) {
    // useAtomsDevtools(location.href, { enabled: false, store: jotaiStore });
    // useAtomsDebugValue();

    return (
        <>
            <DevTools isInitialOpen={false} store={jotaiStore} />
            {children}
        </>
    );
}
