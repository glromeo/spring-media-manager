import { createPortal } from "react-dom";
import { AtxButton, WidgetProps } from "./widgets";
import { CSSProperties, ReactElement, useEffect, useMemo, useRef } from "react";
import { useChangeEffect } from "../hooks/use-changed";
import { classNames } from "../utils";

import "./atx-dialog.scss";

export type AtxDialogProps = Omit<WidgetProps<HTMLDialogElement>, "type"> & {
    className?: string;
    style?: CSSProperties;
    title?: string | ReactElement | null;
    type?: "alert" | "prompt";
    open?: boolean;
    modal?: boolean;
    onOpen?: () => void;
    onClose?: () => void;
    onOK?: () => void;
    onCancel?: () => void;
    onBack?: () => void;
    labels?: { OK?: string; Cancel?: string; Back?: string };
};

export function AtxDialog(props: AtxDialogProps) {
    const {
        className,
        style,
        testId,
        title,
        type = "prompt",
        open,
        disabled,
        modal,
        children,
        onOpen,
        onClose,
        onClick,
        onOK,
        onCancel,
        onBack,
        labels
    } = props;

    const footer = useMemo(
        () =>
            (onBack || onOK || onCancel) && (
                <div className="footer">
                    <div className="flex-fill">
                        {onBack && (
                            <AtxButton
                                testId="Back"
                                size="regular"
                                type="tertiary"
                                className={classNames("back")}
                                onClick={onBack}
                            >
                                {labels?.Back ?? "<< Back"}
                            </AtxButton>
                        )}
                    </div>
                    {onOK && (
                        <AtxButton testId="OK" size="regular" type="primary" onClick={onOK} disabled={disabled}>
                            {labels?.OK ?? "OK"}
                        </AtxButton>
                    )}
                    {onCancel && (
                        <AtxButton testId="Cancel" size="regular" type="secondary" onClick={onCancel}>
                            {labels?.Cancel ?? "Cancel"}
                        </AtxButton>
                    )}
                </div>
            ),
        [onOK, onCancel]
    );

    useChangeEffect(open, (isOpen) => (isOpen ? onOpen?.() : onClose?.()));

    /**
     * What's going on here? The shared portal doesn't work well with dialogs... I need to refactor it
     * to (1) use context and (2) use the js api of floating UI rather than their react bindings...
     */
    const dialogRef = useRef<HTMLDialogElement>(null);
    useEffect(() => {
        let dialog = dialogRef.current;
        let portal = document.querySelector("[data-floating-ui-portal]");
        if (dialog && portal) {
            const parentElement = portal.parentElement;
            dialog.appendChild(portal);
            return () => {
                parentElement!.appendChild(portal!);
            };
        }
    }, [open]);

    return open
        ? createPortal(
              <dialog
                  data-test-id={testId}
                  className={classNames("atx-dialog", className, modal && "modal")}
                  ref={(dialog) => {
                      if (dialog) {
                          dialog.removeAttribute("open"); // REACT-18 bug
                          if (open) {
                              if (modal) {
                                  dialog.showModal();
                              } else {
                                  dialog.show();
                              }
                          } else {
                              dialog.close();
                          }
                      }
                      (dialogRef as any).current = dialog;
                  }}
                  open={undefined}
                  data-type={type}
                  onClick={onClick}
                  style={style}
              >
                  {title && <div className="header">{title}</div>}
                  {children && <div className="body">{children}</div>}
                  {footer}
              </dialog>,
              document.body
          )
        : null;
}
