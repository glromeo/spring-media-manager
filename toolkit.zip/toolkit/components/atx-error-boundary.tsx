import { ErrorBoundary } from "react-error-boundary";
import { logError } from "@atw/toolkit/telemetry";
import { ReactNode } from "react";

export const AtxErrorBoundary = ({ children }: { children: ReactNode }) => {
    return (
        /* @ts-ignore */
        <ErrorBoundary
            fallbackRender={ErrorFallBack}
            onError={(error) => logError("ErrorBoundary caught an error", error)}
            onReset={() => window.location.replace(window.location.href)}
        >
            {children}
        </ErrorBoundary>
    );
};

const ErrorFallBack = ({ error, resetErrorBoundary }: { error: Error; resetErrorBoundary: () => void }) => {
    return (
        <div>
            <p>Something went wrong:</p>
            <pre>{error.message || JSON.stringify(error)}</pre>
            <button onClick={resetErrorBoundary}>Try again</button>
        </div>
    );
};
