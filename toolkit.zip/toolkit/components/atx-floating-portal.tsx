import React, {
    MutableRefObject,
    ReactNode,
    RefCallback,
    useCallback,
    useEffect,
    useLayoutEffect,
    useMemo,
    useState
} from "react";

import {
    autoUpdate,
    flip,
    FloatingPortal,
    offset,
    Placement as FloatingUIPlacement,
    shift,
    useDismiss,
    useFloating,
    useHover,
    useInteractions
} from "@floating-ui/react";

import { ReferenceType, UseFloatingReturn } from "@floating-ui/react/src/types";

import { Atom, atom, useAtomValue, useSetAtom } from "jotai";

export type Placement = FloatingUIPlacement;

let floatingWidgetSeq = 0;

export const floatingWidgetsAtom = atom([] as ReactNode[]);
floatingWidgetsAtom.debugLabel = "floatingWidgets";

export function AtxFloatingPortal() {
    const widgets = useAtomValue(floatingWidgetsAtom);
    return <FloatingPortal>{widgets}</FloatingPortal>;
}

export type AtxFloatingWidgetProps<RT extends ReferenceType> = Pick<
    UseFloatingReturn<RT>,
    "refs" | "floatingStyles" | "context"
> & {
    isOpen: boolean;
    setOpen: (isOpen: boolean) => void;
    getFloatingProps: (props?: any) => Record<string, unknown>;
};

function AtxFloatingWidget<RT extends ReferenceType>({
    Widget,
    propsAtom
}: {
    Widget: React.FC<AtxFloatingWidgetProps<RT>>;
    propsAtom: Atom<AtxFloatingWidgetProps<RT>>;
}) {
    const props = useAtomValue(propsAtom);
    if (props.isOpen) {
        return <Widget {...props} />;
    } else {
        return null;
    }
}

export type AtxFloatingProps<RT extends ReferenceType = ReferenceType> = {
    delay?: number;
    move?: boolean;
    placement?: Placement;
    restMs?: number;
    trigger?: "hover" | "click" | "none";
    Widget: React.FC<AtxFloatingWidgetProps<RT>>;
    onOpen?: () => void;
    onClose?: () => void;
};

function useMutable<T extends object>(init: T) {
    const state = useState(init);
    return Object.assign(state, init);
}

/**
 * WARN: This should be a generic hook, but it has been created based on the tooltip specialization
 * so it might require some further refactoring
 * @param props
 */
export function useAtxFloating(props: AtxFloatingProps) {
    const { trigger = "hover", Widget, placement, delay = 150, restMs = 600, move = true, onOpen, onClose } = props;

    const [isOpen, setOpen] = useState(false);

    useEffect(() => {
        if (isOpen) {
            onOpen?.();
        } else {
            onClose?.();
        }
    }, [isOpen]);

    const { refs, floatingStyles, context } = useFloating({
        placement,
        open: isOpen,
        onOpenChange: trigger === "hover" ? setOpen : undefined,
        whileElementsMounted: autoUpdate,
        middleware: [offset(4), flip(), shift({ padding: 8 })]
    });

    const { getReferenceProps, getFloatingProps } = useInteractions([
        useHover(context, { delay, restMs, move }),
        useDismiss(context, {
            escapeKey: true,
            outsidePress: true
        })
    ]);

    const floatingWidget = useSetAtom(
        useMemo(() => {
            const init = {
                isOpen,
                setOpen,
                refs,
                floatingStyles,
                context,
                getFloatingProps
            };
            const propsAtom = atom(init);
            return atom(null, (get, set, props?: typeof init) => {
                if (props) {
                    set(propsAtom, props);
                } else {
                    const widgets = get(floatingWidgetsAtom);
                    const widget = (
                        <AtxFloatingWidget key={++floatingWidgetSeq} Widget={Widget} propsAtom={propsAtom} />
                    );
                    set(floatingWidgetsAtom, [...widgets, widget]);

                    return () => {
                        set(
                            floatingWidgetsAtom,
                            get(floatingWidgetsAtom).filter((w) => w !== widget)
                        );
                    };
                }
            });
        }, [Widget])
    );

    useLayoutEffect(floatingWidget, [Widget]);
    useLayoutEffect(
        () =>
            floatingWidget({
                isOpen,
                setOpen,
                refs,
                floatingStyles,
                context,
                getFloatingProps
            }),
        [isOpen, floatingStyles, context, getFloatingProps]
    );

    const state = useMutable({ isOpen });
    return {
        isOpen,
        setOpen,
        /**
         * NOTE: Workaround for floatingUI using mouse events rather than pointer events
         */
        getReferenceProps: useCallback(
            <T extends HTMLElement>(
                props: React.HTMLAttributes<T> & {
                    disabled?: boolean;
                },
                ref?: RefCallback<T> | MutableRefObject<T> | null
            ) => {
                const referenceProps = { ...props } as React.HTMLAttributes<T> & React.RefAttributes<T>;

                const legacyRef = ref;
                referenceProps.ref = legacyRef
                    ? function (instance: any) {
                          if (typeof legacyRef === "function") {
                              legacyRef(instance);
                          } else {
                              legacyRef.current = instance;
                          }
                          refs.setReference(instance);
                      }
                    : refs.setReference;

                if (trigger === "hover" && props.disabled) {
                    const legacyPointerMove = props.onPointerMove;
                    let hoverTimeout: any;
                    referenceProps.onPointerMove = function (this: any) {
                        legacyPointerMove?.apply(this, arguments as any);
                        if (!state.isOpen) {
                            clearTimeout(hoverTimeout);
                            hoverTimeout = setTimeout(() => {
                                setOpen(true);
                            }, delay);
                        }
                    };
                }

                if (trigger === "click") {
                    const legacyClick = props.onClick;
                    let open = isOpen;
                    referenceProps.onClick = function (this: any) {
                        legacyClick?.apply(this, arguments as any);
                        setOpen((open = !open));
                    };
                }

                return getReferenceProps(referenceProps);
            },
            [getReferenceProps, trigger]
        )
    };
}
