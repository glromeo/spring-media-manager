import { useIconParameter, useSizeParameter, useTypeParameter } from "../stories/parameters";
import { AtxIcon } from "@atx/toolkit/components/atx-icon";

export default () => {
    const [type] = useTypeParameter();
    const [size] = useSizeParameter();
    const [icon] = useIconParameter("help");
    return <AtxIcon name={icon!} size={size!} type={type!} />;
};
