import { classNames } from "../utils";
import icons from "./atx-icons";
import { AtxTooltip, Type, WidgetProps } from "./widgets";

import "./atx-icon.scss";
import { cloneElement, ReactNode } from "react";

export type AtxIconName = keyof typeof icons;

export type AtxIconProps = Omit<WidgetProps<HTMLDivElement>, "children" | "type"> & {
    name?: AtxIconName | null;
    type?: Type;
};

function createOverlaySVG(name: AtxIconName) {
    return cloneElement(icons[name], { className: "overlay" });
}

const overlays: Partial<Record<AtxIconName, ReactNode>> = {
    "alert": createOverlaySVG("alert-subtle"),
    "alert-bold": createOverlaySVG("alert-subtle"),
    "help": createOverlaySVG("help-subtle"),
    "help-bold": createOverlaySVG("help-subtle")
};

export const AtxIcon = ({
    testId,
    className,
    style,
    label,
    disabled,
    size,
    title,
    name,
    type,
    onClick
}: AtxIconProps) => {
    const overlay = type === "warning" && name && overlays[name];
    return (
        <AtxTooltip title={title}>
            <div
                data-test-id={testId}
                className={classNames("atx-icon", className, name, type, size, disabled && "disabled")}
                style={style}
                onClick={disabled ? undefined : onClick}
            >
                {label}
                {name && icons[name]}
                {overlay}
            </div>
        </AtxTooltip>
    );
};
