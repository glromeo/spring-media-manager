import { AtxLookup } from "./index";
import { css, useParameter } from "@atx/stories";
import React, { ReactNode, useEffect, useState } from "react";

const [
    {
        output: { data }
    }
] = require("./atx-lookup.fixture.json");

type Option = {
    cusip: string;
    desc1: string;
    ticker: string;
    sedol: string;
    isin: string;
    secGroup: string;
    secType: string;
};

css`
`;

export default () => {
    const [text, setText] = useParameter("text", "string", "");
    const [messsage, setMessage] = useState<ReactNode>();
    const [options, setOptions] = useState<Option[]>([]);
    const [value, setValue] = useState<Option | null>(null);
    useEffect(() => {
        if (text != value?.desc1) {
            setOptions([]);
            if (text.length < 3) {
                setMessage(<div>Please provide at least 3 characters...</div>);
                return;
            } else {
                setMessage("searching...");
                setTimeout(() => {
                    setOptions(data);
                    setMessage("");
                }, 3000);
            }
        }
    }, [text, value]);
    return (
        <AtxLookup
            className="custom-lookup"
            placeholder="-"
            text={text}
            value={value}
            options={options}
            message={messsage}
            validate={(value) => {
                if (!value) {
                    return "You must pick a value!";
                }
            }}
            header="sticky"
            onSelect={(option) => {
                if (option) {
                    setText(option.desc1);
                    setValue(option);
                } else {
                    setText("");
                    setValue(null);
                }
            }}
            onSearch={(what) => {
                setText(what);
                if (text.startsWith(what) && what.length >= 3) {
                    return;
                }
            }}
            columns={[
                { label: "CUSIP", field: "cusip", width: 100 },
                { label: "Security Description", field: "desc1", width: 350 },
                { label: "Ticker", field: "ticker", width: 100 },
                { label: "SEDOL", field: "sedol", width: 100 },
                { label: "ISIN", field: "isin", width: 100 },
                { label: "Security Group", field: "secGroup", width: 110 },
                { label: "Security Type", field: "secType", width: 110 }
            ]}
        />
    );
};
