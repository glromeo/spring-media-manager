import {
    AtxButton,
    useErrorNotification,
    useMessageNotification,
    useSuccessNotification,
    useWaringNotification
} from "@atx/toolkit";
import { useParameter } from "@atx/stories";

let type = 0;

export default () => {
    const notifyError = useErrorNotification();
    const notifyMessage = useMessageNotification();
    const notifySuccess = useSuccessNotification();
    const notifyWaring = useWaringNotification();
    const [message] = useParameter("message", "string", "This is a sample message");
    return (
        <AtxButton
            label="Click Me!"
            style={{ width: 90 }}
            onClick={() => {
                switch (type++ % 4) {
                    case 0:
                        return notifyError("Error", message);
                    case 1:
                        return notifyMessage("Message", message);
                    case 2:
                        return notifySuccess("Success", message);
                    case 3:
                        return notifyWaring("Waring", message);
                }
            }}
        />
    );
};
