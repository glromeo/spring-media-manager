import React, { useCallback, useEffect, useState } from "react";

import { useAtom } from "jotai";
import { AtxAlert, Level, Notification, notificationsAtom } from "@atx/toolkit";
import "./atx-notifications.scss";

const LEVEL: Record<Notification["type"], Level> = {
    ALERT: "danger",
    MESSAGE: "info",
    ERROR: "danger",
    WARNING: "warning",
    SUCCESS: "success"
};

// This component can either be added standalone (and managed with notificationsAtom) or used automatically wit AtxApp

export function AtxNotifications() {
    const [notifications, setNotifications] = useAtom(notificationsAtom);

    const onNotificationClosed = useCallback(function (event: any) {
        // TODO: hook into telemetry here?
    }, []);

    return (
        <div className="atx-notifications">
            {notifications.map((notification) => (
                <AtxToast
                    key={notification.id}
                    notification={notification}
                    onDismiss={() => {
                        setNotifications(notifications.filter(({ id }) => notification.id !== id));
                    }}
                />
            ))}
        </div>
    );
}

function AtxToast({
    notification: { message, title, type, timeout },
    onDismiss
}: {
    notification: Notification;
    onDismiss: () => void;
}) {
    const [visible, setVisible] = useState(false);
    const onClose = () => {
        setVisible(false);
        setTimeout(onDismiss, 300);
    };
    useEffect(() => {
        setVisible(true);
        if (timeout) {
            setTimeout(onClose, timeout);
        }
    }, []);
    return (
        <div className={`atx-notification ${visible ? "visible" : "hidden"}`}>
            <AtxAlert type={LEVEL[type]} title={title} onClose={onClose}>
                {message}
            </AtxAlert>
        </div>
    );
}

function timeoutByType(type: Notification["type"]): number {
    switch (type) {
        case "ERROR":
            return 3600000; // Indefinite
        case "WARNING":
            return 300000; // 5 min
        case "MESSAGE":
        case "SUCCESS":
        default:
            return 60000; // 1 min
    }
}
