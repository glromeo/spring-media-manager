import { AtxRowResizer } from "./atx-row-resizer";
import { AtxColumnResizer } from "./atx-column-resizer";
import { classNames } from "../utils";
import { CSSProperties, ReactNode, useMemo, useState } from "react";

import "./atx-resizable-pane.scss";

export function AtxResizablePane(props: {
    testId?: string;
    className?: string;
    style?: CSSProperties;
    onResize?: (style: Pick<CSSProperties, "width" | "height">) => void;
    children?: ReactNode;
    resizer?: ("top" | "bottom" | "left" | "right") | ("top" | "bottom" | "left" | "right")[];
}) {
    const { testId, className, style, onResize, resizer, children } = props;
    const [width, setWidth] = useState(style?.width);
    const [height, setHeight] = useState(style?.height);
    const resizers = useMemo(() => {
        const directions = Array.isArray(resizer) ? resizer : [resizer];
        let state = { width, height };
        return directions.map((direction, index) => {
            switch (direction) {
                case "top":
                    return (
                        <AtxRowResizer
                            key={index}
                            placement="top"
                            onResize={(height) => {
                                setHeight(height);
                                state.height = height;
                                onResize?.({ ...state });
                            }}
                        />
                    );
                case "bottom":
                    return (
                        <AtxRowResizer
                            key={index}
                            placement="bottom"
                            onResize={(height) => {
                                setHeight(height);
                                state.height = height;
                                onResize?.({ ...state });
                            }}
                        />
                    );
                case "left":
                    return (
                        <AtxColumnResizer
                            key={index}
                            placement="left"
                            onResize={(width) => {
                                setWidth(width);
                                state.width = width;
                                onResize?.({ ...state });
                            }}
                        />
                    );
                case "right":
                    return (
                        <AtxColumnResizer
                            key={index}
                            placement="right"
                            onResize={(width) => {
                                setWidth(width);
                                state.width = width;
                                onResize?.({ ...state });
                            }}
                        />
                    );
                default:
                    return null;
            }
        });
    }, [resizer]);
    return (
        <div
            data-test-id={testId}
            className={classNames("atx-resizable-pane", className)}
            style={{
                ...style,
                width,
                height
            }}
        >
            {children}
            {resizers}
        </div>
    );
}
