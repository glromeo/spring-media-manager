import { MouseEventHandler, useMemo } from "react";

import "./atx-row-resizer.scss";
import { classNames } from "../utils";

export type AtxRowResizerProps = {
    minHeight?: number;
    placement: "top" | "bottom";
    edge?: boolean;
    onResize?: (height: number, deltaY: number) => void;
    onMouseUp?: (height: number, deltaY: number) => void;
    container?: HTMLElement | null;
    onDoubleClick?: MouseEventHandler<HTMLDivElement> | undefined;
};

/**
 *
 * @param minHeight
 * @param placement
 * @param edge
 * @param onResize
 * @param onMouseUp
 * @param container
 * @param onDoubleClick
 * @constructor
 */
export function AtxRowResizer({
    minHeight = 32,
    placement,
    edge = false,
    onResize,
    onMouseUp,
    container,
    onDoubleClick
}: AtxRowResizerProps) {
    return useMemo(
        () => (
            <div
                ref={(instance) => {
                    if (!container) {
                        container = instance?.parentElement;
                    }
                    if (container) {
                        let computedStyle = getComputedStyle(container);
                        let computedMinHeight = parseInt(computedStyle.minHeight);
                        if (!isNaN(computedMinHeight)) {
                            minHeight = computedMinHeight;
                        }
                        if (computedStyle.position === "static") {
                            console.warn("row resizer parent is statically positioned");
                        }
                    }
                }}
                className={classNames("row-resizer", placement, edge && "edge")}
                onMouseDown={(trigger) => {
                    trigger.preventDefault();
                    trigger.stopPropagation();

                    const target = trigger.target as HTMLDivElement;
                    target.classList.toggle("active");

                    if (!container) {
                        container = target.parentElement;
                    }

                    if (!onResize) {
                        onResize = (height: number) => (container!.style.height = `${height}px`);
                    }

                    document.body.addEventListener("mousemove", dragHandler);
                    document.body.addEventListener("mouseup", dragHandler);

                    const initialCursor = document.body.style.cursor;
                    document.body.style.cursor = "ns-resize";
                    document.body.classList.add("resizing");

                    const initialY = trigger.pageY;
                    let height: number = container?.getBoundingClientRect().height ?? minHeight;
                    let update = 0;
                    let af: number = 0;

                    function dragHandler({ buttons, pageY }: MouseEvent) {
                        if (buttons !== 1) {
                            document.body.removeEventListener("mousemove", dragHandler);
                            document.body.removeEventListener("mouseup", dragHandler);
                            requestAnimationFrame(function () {
                                onResize!(height + update, update);
                                target.classList.toggle("active");
                                document.body.style.cursor = initialCursor;
                                document.body.classList.remove("resizing");
                                if (onMouseUp) {
                                    onMouseUp(height, update);
                                }
                            });
                        } else {
                            const deltaY = placement === "top" ? initialY - pageY : pageY - initialY;
                            update = Math.round(Math.max(minHeight, height + deltaY) - height);
                            clearTimeout(af);
                            af = requestAnimationFrame(function () {
                                onResize!(height + update, update);
                            });
                        }
                    }
                }}
                onDoubleClick={onDoubleClick}
            />
        ),
        [container, minHeight, placement]
    );
}
