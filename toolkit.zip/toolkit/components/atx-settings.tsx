import React, { ReactElement, useCallback, useContext, useLayoutEffect, useState } from "react";
import { dispatchHost, Settings, SettingsAtom } from "../utils";
import { PrimitiveAtom, useAtom } from "jotai";
import { AtxIcon } from "./atx-icon";
import { logClick } from "@atw/toolkit/telemetry";
import { AtxAtomsContext } from "./atx-atoms";
import { AtxTabbedPane, AtxTabProps } from "./atx-tabbed-pane";
import { AtxDialog } from "./atx-dialog";
import { useChangeEffect } from "../hooks/use-changed";

import "./atx-settings.scss";

export function AtxSettingsIcon({ atom }: { atom: SettingsAtom<Settings> }) {
    let [settings, setSettings] = useAtom(atom);
    return (
        <AtxIcon
            name="settings-subtle"
            disabled={!settings}
            onClick={() => {
                console.log("toggle settings");
                return setSettings({
                    ...settings,
                    isOpen: !settings.isOpen
                });
            }}
        />
    );
}

export type SettingsTabProps = AtxTabProps & {};

export type AtxSettingsProps = {
    standalone?: boolean;
    title?: string;
    children: ReactElement<SettingsTabProps>[] | ReactElement<SettingsTabProps>;
};

const DEFAULT_TITLE = process.env.APP_TITLE + " Settings";

export function AtxSettings({ standalone = false, title = DEFAULT_TITLE, children }: AtxSettingsProps) {
    const [settings, setSettings] = useAtom(useContext(AtxAtomsContext).settings! as PrimitiveAtom<Settings>);
    const [changed, setChanged] = useState<Partial<Settings>>({});

    useLayoutEffect(() => {
        const extraBodyClass = `atx-modal--${standalone ? "standalone" : "standard"}`;
        document.body.classList.add(extraBodyClass);
        return () => {
            document.body.classList.remove(extraBodyClass);
        };
    }, [standalone]);

    const tabState = useState(0);
    const [selected, setSelected] = tabState;

    const tabs = (
        <AtxTabbedPane className="atx-settings" state={tabState}>
            {children}
        </AtxTabbedPane>
    );

    let onOK = useCallback(() => {
        // setSelected(0);
        // setChanged({});
        // const saved = setSettings({...settings, ...changed, isOpen: false});
        //
        // // TODO: remember to wire a settings atom update to the plugin dispatch action
        //
        // queryHost("APPLY_SETTINGS", JSON.stringify(changed)).catch(() => {
        //     console.error("unable to dispatch APPLY_SETTINGS to host");
        // });
        //
        // if (standalone) {
        //     saved.then(() => dispatchHost("close"));
        // }
    }, [settings, changed, standalone]);

    let onCancel = useCallback(async () => {
        setSelected(0);
        setChanged({});
        setSettings({ ...settings, isOpen: false });

        if (standalone) {
            dispatchHost("close");
        }
    }, [standalone]);

    const open = standalone || settings.isOpen;

    useChangeEffect(open, (isOpen) => {
        if (isOpen) {
            logClick(`User opened ${title} settings`);
        } else {
            logClick(`User closed ${title} settings`);
        }
    });

    return standalone ? (
        tabs
    ) : (
        <AtxDialog
            title={title}
            open={open}
            modal={true}
            onOK={onOK}
            onCancel={onCancel}
            labels={{ OK: "Submit", Cancel: "Cancel" }}
        >
            {tabs}
        </AtxDialog>
    );
}
