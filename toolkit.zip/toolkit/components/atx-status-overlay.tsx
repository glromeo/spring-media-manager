import {
    AuxProgressIndicator,
    AuxProgressIndicatorSizeEnum,
    AuxProgressIndicatorTypeEnum
} from "@blk/aladdin-react-components-es";
import { useAtomValue } from "jotai";
import { statusOverlayAtom } from "../atoms";
import { createPortal } from "react-dom";

import "./atx-status-overlay.scss";

export function AtxStatusOverlay() {
    const title = useAtomValue(statusOverlayAtom);
    return title
        ? createPortal(
              <div className="atx-status-overlay">
                  <div className="atx-app-progress-indicator">
                      <AuxProgressIndicator
                          hasCounter
                          hasLabel
                          isSpinner
                          loadingLabel={title}
                          progress={30}
                          size={AuxProgressIndicatorSizeEnum.LARGE}
                          type={AuxProgressIndicatorTypeEnum.LOADING}
                      />
                  </div>
              </div>,
              document.body
          )
        : null;
}
