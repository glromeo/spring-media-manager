import React, { ReactElement, ReactNode, useState } from "react";
import { classNames } from "../utils";
import { WidgetProps } from "./widgets";

import "./atx-tabbed-pane.scss";

export type AtxTabbedPaneProps = WidgetProps & {
    children: ReactElement<AtxTabProps>[] | ReactElement<AtxTabProps>;
    state?: [number, (update: number) => void];
    onChange?: (title:string) => void
};

export type AtxTabProps = {
    "tab-title": ReactNode; // This property is used by the AtxTabbedPane
};

export function AtxTabbedPane({ testId, className, style, children = [], state = useState(0), onChange }: AtxTabbedPaneProps) {
    const [selected, setActive] = state;
    if (!Array.isArray(children)) {
        children = [children];
    }
    return (
        <div data-test-id={testId} className={classNames("atx-tabbed-pane", className)} style={style}>
            <div className="atx-tab-bar">
                {children.map((child, index) => {
                    let title = child.props["tab-title"];
                    return (
                        <div
                            key={index}
                            tab-title={title}
                            className={classNames("atx-tab-tag", selected === index && "selected")}
                            onClick={() => {
                                if (typeof title === "string") {
                                    onChange?.(title);
                                    setActive(index);
                                }
                            }}
                        >
                            {title}
                        </div>
                    );
                })}
            </div>
            <div className="atx-tabbed-content">{children[selected]}</div>
        </div>
    );
}
