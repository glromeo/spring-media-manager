import React, { ReactNode, useContext } from "react";
import { hasSearchParam, searchParam } from "../utils/location";
import { SettingsAtom } from "../utils/settings";
import { AtxSettingsIcon } from "./atx-settings";
import { AtxAtomsContext } from "./atx-atoms";

import "./atx-title-bar.scss";

const embedded = hasSearchParam("embedded");
const fixture = searchParam("fixture");

export type AtxTitleBarProps = { title?: string; toolbar?: ReactNode };

export function AtxTitleBar({ title = process.env.APP_TITLE, toolbar }: AtxTitleBarProps) {
    if (!title) {
        throw new Error("missing title in package.json config section");
    }
    const atoms = useContext(AtxAtomsContext);
    return (
        <div className="atx-title-bar" data-embedded={embedded} data-fixture={fixture}>
            <div className="title-text">{title}</div>
            {fixture && (
                <div className="title-text">
                    Using fixture: <span className="fixture-text">{fixture}</span>
                </div>
            )}
            <div className="flex-fill" />
            {toolbar}
            <div className="settings">
                {atoms.settings ? <AtxSettingsIcon atom={atoms.settings as SettingsAtom<any>} /> : null}
            </div>
        </div>
    );
}
