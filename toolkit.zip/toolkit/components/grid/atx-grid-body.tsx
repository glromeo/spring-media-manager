import React, { memo } from "react";
import type { AtxGridColumn } from "./atx-grid";
import { AtxGridCell } from "./atx-grid-cell";
import { AtxGridRow, ScrollHeight } from "./state/rows";
import { VisibleColumns, VisibleRows } from "./state/ranges";
import { PinnedColumns, PinnedWidth, ScrollWidth } from "./state/columns";
import { atom, Atom } from "jotai";
import { RowSelection } from "./state/grid";
import { HeaderHeight, Inverse, RowDetails } from "./state/props";
import { ClientHeight, ClientWidth } from "./state/viewport";
import { useGridAtom, useGridAtoms, useMemoMapper } from "./state/hooks";
import { classNames } from "../../utils";
import { GridHover } from "./state/hover";

const AtxGridBodyCells = memo(
    ({
        row,
        Columns
    }: {
        row: AtxGridRow;
        Columns: Atom<AtxGridColumn[]>;
    }) => {
        return (
            <>
                {useGridAtom(Columns).map(
                    useMemoMapper(
                        (column: AtxGridColumn) => <AtxGridCell key={column.index} row={row} column={column} />,
                        [row.data]
                    )
                )}
            </>
        );
    }
);
AtxGridBodyCells.displayName = "AtxGridBodyCells";

const AtxGridBodyRow = memo(
    ({
        row,
        Columns
    }: {
        row: AtxGridRow;
        Columns: Atom<AtxGridColumn[]>;
    }) => {
        const { className, id, index } = row;
        const [selectedIndex, rowDetails] = useGridAtoms(RowSelection, RowDetails);
        const selected = selectedIndex === index;
        if (rowDetails) {
            const details = rowDetails.render!(row);
            if (details) {
                const cellsHeight = row.height - details.props.style.height;
                return (
                    <div className={className} row-id={id} row-index={index}>
                        <div style={{ height: cellsHeight, position: "absolute" }}>
                            <AtxGridBodyCells row={row} Columns={Columns} />
                        </div>
                        {details}
                    </div>
                );
            }
        }
        return (
            <div className={classNames(className, selected && "selected")} row-id={id} row-index={index}>
                <AtxGridBodyCells row={row} Columns={Columns} />
            </div>
        );
    }
);
AtxGridBodyRow.displayName = "AtxGridBodyRow";

const AtxGridBodyRows = memo(({ Columns }: { Columns: Atom<AtxGridColumn[]> }) => (
    <>
        {useGridAtom(VisibleRows).map((row: AtxGridRow) => (
            <AtxGridBodyRow key={row.id} row={row} Columns={Columns} />
        ))}
    </>
));
AtxGridBodyRows.displayName = "AtxGridBodyRows";

const PinnedStyle = atom((get) => [
    {
        left: get(Inverse) ? get(ClientWidth) - get(PinnedWidth) : 0
    },
    {
        width: get(PinnedWidth),
        minHeight: Math.max(get(ScrollHeight), get(ClientHeight) - get(HeaderHeight))
    }
]);

export function AtxGridPinnedBody() {
    const [pinnedColumns, [sectionStyle, bodyStyle], gridHover] = useGridAtoms(PinnedColumns, PinnedStyle, GridHover);
    return pinnedColumns.length ? (
        <div className="section pinned-section" style={sectionStyle}>
            <div className="atx-grid-body pinned" style={bodyStyle} {...gridHover}>
                <AtxGridBodyRows Columns={PinnedColumns} />
            </div>
        </div>
    ) : null;
}

const ScrollStyle = atom((get) => {
    return ({
        paddingLeft: get(Inverse) ? 0 : get(PinnedWidth),
        width: Math.max(get(ScrollWidth) + get(PinnedWidth), get(ClientWidth)),
        minHeight: Math.max(get(ScrollHeight), get(ClientHeight) - get(HeaderHeight))
    });
});

export function AtxGridScrollBody() {
    const [visibleColumns, scrollStyle, gridHover] = useGridAtoms(VisibleColumns, ScrollStyle, GridHover);
    return visibleColumns.length ? (
        <div className="atx-grid-body scroll" style={scrollStyle} {...gridHover}>
            <AtxGridBodyRows Columns={VisibleColumns} />
        </div>
    ) : null;
}
