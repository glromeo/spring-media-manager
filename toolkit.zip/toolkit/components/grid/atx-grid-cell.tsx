import React, { memo, MouseEventHandler, ReactElement, ReactNode, useMemo } from "react";
import { AtxColumnType, AtxGridColumn, DataItem } from "./atx-grid";
import {
    classNames,
    formatDate,
    formatDateTime,
    formatPercentage,
    formatPrice,
    formatQuantity,
    formatSpread,
    formatTime,
    formatYield
} from "../../utils";
import { AtxGridRow } from "./state/rows";
import { useColumnSelected } from "./state/hooks";

export type AtxCellRenderer<T extends DataItem = DataItem> = (row: AtxGridRow<T>, column: AtxGridColumn<T>) => ReactNode;

export function AtxGridCellContent({ children, field }: { children: ReactNode; field: string }): ReactElement {
    return (
        <div
            className="atx-grid-cell-content"
            data-field={field}
            data-value={typeof children === "string" ? children : undefined}
        >
            {children}
        </div>
    );
}

export const defaultCellRenderer:AtxCellRenderer = (
    row: AtxGridRow,
    { field, formatter }: AtxGridColumn
): ReactElement => <AtxGridCellContent field={field as string}>{formatter(row.data, field)}</AtxGridCellContent>;

export type AtxCellFormatter<T = DataItem> = (data: T, field: keyof T) => string;

export const defaultCellFormatters: Record<string, AtxCellFormatter> = {
    text: (data, field) => data[field] ?? "-",
    flag: (data, field) => (data[field] === true || data[field] === "true" ? "Y" : "N"),
    number: (data, field) => (isNaN(data[field]) ? "-" : data[field]),
    quantity: (data, field) => formatQuantity(data[field]),
    spread: (data, field) => formatSpread(data[field]),
    price: (data, field) => formatPrice(data[field]),
    yield: (data, field) => formatYield(data[field]),
    date: (data, field) => formatDate(data[field]),
    time: (data, field) => formatTime(data[field]),
    datetime: (data, field) => formatDateTime(data[field]),
    percentage: (data, field) => formatPercentage(data[field]),
    csv: (data, field) => data[field]?.map((text: any) => String(text) ?? "-").join(", "),
    unknown: (data, field) => data[field]
};

export const cellJustify: Record<string, string> = {
    text: "justify-left",
    flag: "justify-left",
    number: "justify-right",
    quantity: "justify-right",
    spread: "justify-right",
    price: "justify-right",
    yield: "justify-right",
    date: "justify-right",
    time: "justify-right",
    datetime: "justify-right",
    percentage: "justify-right",
    csv: "justify-left",
    unknown: "justify-center"
};

type SVGIconProps = { onClick: MouseEventHandler<any> };

export type AtxGridChevronProps = SVGIconProps & { isCollapsed: boolean | undefined };

export function Chevron({ isCollapsed, onClick }: AtxGridChevronProps) {
    if (isCollapsed) {
        return (
            <svg className="svg-icon chevron-collapsed" viewBox="0 0 16 16" onClick={onClick}>
                <path
                    fillRule="evenodd"
                    d="M7.646 4.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1-.708.708L8 5.707l-5.646 5.647a.5.5 0 0 1-.708-.708l6-6z"
                />
            </svg>
        );
    } else {
        return (
            <svg className="svg-icon chevron-expanded" viewBox="0 0 16 16" onClick={onClick}>
                <path
                    fillRule="evenodd"
                    d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"
                />
            </svg>
        );
    }
}

export type AtxCellDataType = "summary-group" | "summary-cell" | "aggregated-value" | "cell-value";
export type AtxCellFieldType = "date" | "cpty";

export type AtxCellAPI = {
    hasClass(token: string): boolean;
    hasRowClass(token: string): boolean;

    get type(): AtxCellDataType;
    get field(): string;
    get rowIndex(): number;
    get columnIndex(): number;
    get innerText(): string;
    get group(): AtxCellFieldType;
};

export const AtxGridCell = memo(
    ({
        row,
        column
    }: {
        row: AtxGridRow;
        column: AtxGridColumn;
    }) => {
        const className = classNames(column.className, useColumnSelected(column.index));
        const { data, bucket } = row;
        if (column.aggregate) {
            if (bucket) {
                if (bucket.field === column.field) {
                    return (
                        <div className={className} data-type="summary-group" column-index={column.index}>
                            <Chevron isCollapsed={bucket.collapsed} onClick={bucket.toggle} />
                            {column.render(row, column)}
                        </div>
                    );
                } else {
                    return <div className={className} data-type="summary-group" column-index={column.index} />;
                }
            } else {
                return <div className={className} data-type="summary-cell" column-index={column.index} />;
            }
        } else {
            if (bucket) {
                const { totals, field } = column;
                const value = useMemo(() => {
                    return data && column.totals ? column.totals(bucket.data, field) : null;
                }, [data, totals]);

                return (
                    <div
                        className={className}
                        data-type="aggregated-value"
                        data-field={field}
                        data-group={bucket.field}
                        column-index={column.index}
                    >
                        <div className={classNames("atx-grid-cell-content", field)}>{value}</div>
                    </div>
                );
            } else {
                return (
                    <div className={className} data-type="cell-value" column-index={column.index}>
                        {column.render(row, column)}
                    </div>
                );
            }
        }
    }
);
AtxGridCell.displayName = "AtxGridCell";
