import "./atx-grid-column-resizer.scss";
import { AtxGridColumn } from "./atx-grid";
import { memo, useCallback } from "react";
import { ColumnLayoutAtom } from "./state/columns";
import { GridElement, Resizing } from "./state/grid";
import { Inverse } from "./state/props";
import { WritableAtom } from "jotai";
import { useGridAtom, useGridStore } from "./state/hooks";

export type AtxGridColumnResizerProps = {
    column: AtxGridColumn;
    Layout: ColumnLayoutAtom;
    TotalWidth: WritableAtom<number, [number], void>;
};

export const AtxGridColumnResizer = memo(({column, Layout, TotalWidth}: AtxGridColumnResizerProps) => {
    const inverse = useGridAtom(Inverse)
    const {get, set} = useGridStore()
    return (
        <div
            className={inverse ? 'resizer inverse' : 'resizer'}
            onMouseDown={useCallback(
                (trigger: React.MouseEvent<HTMLDivElement>) => {
                    const grid = get(GridElement)!
                    const {minWidth = 24, maxWidth = window.innerWidth} =
                        typeof column.resizable === 'boolean' ? {} : column.resizable!

                    trigger.preventDefault()
                    trigger.stopPropagation()

                    document.body.addEventListener('mousemove', dragHandler)
                    document.body.addEventListener('mouseup', dragHandler)

                    const initialX = trigger.pageX

                    set(Resizing, true)

                    const initialLayout = [...get(Layout)]
                    const layoutIndex = column.index - initialLayout[0]!.index
                    const {width: initialWidth} = initialLayout[layoutIndex]
                    const initialTotalWidth = get(TotalWidth)
                    const initialScrollLeft = grid.scrollLeft

                    let commit = 0,
                        af: number

                    function dragHandler(mouseEvent: MouseEvent) {
                        if (mouseEvent.buttons !== 1) {
                            document.body.removeEventListener('mousemove', dragHandler)
                            document.body.removeEventListener('mouseup', dragHandler)
                            requestAnimationFrame(function () {
                                set(Resizing, false)
                            })
                        } else {
                            let deltaX = inverse ? initialX - mouseEvent.pageX : mouseEvent.pageX - initialX

                            cancelAnimationFrame(af)

                            af = requestAnimationFrame(function () {
                                let deltaWidth = Math.round(Math.max(minWidth, initialWidth + deltaX) - initialWidth)
                                const layout = [...initialLayout]
                                let i = layoutIndex
                                if (inverse) {
                                    grid.scrollLeft = initialScrollLeft + deltaWidth
                                }
                                layout[i] = {
                                    ...layout[i],
                                    width: layout[i].width + deltaWidth
                                }
                                while (++i < layout.length) {
                                    const {index, left, width} = layout[i]
                                    layout[i] = {
                                        index,
                                        left: left + deltaWidth,
                                        width
                                    }
                                }
                                set(Layout, layout)
                                set(TotalWidth, initialTotalWidth + deltaWidth)
                                commit = deltaWidth
                            })
                        }
                    }
                },
                [column, Layout, TotalWidth, inverse]
            )}
            onDoubleClick={undefined}
        />
    )
})
AtxGridColumnResizer.displayName = 'AtxGridColumnResizer'
