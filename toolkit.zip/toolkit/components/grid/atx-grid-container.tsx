import React, { CSSProperties, useCallback, useMemo } from "react";

import { ClientHeight, ClientWidth, useViewport } from "./state/viewport";
import { classNames } from "../../utils";
import { ColumnSelection, GridElement, MaxWidth, RowSelection } from "./state/grid";
import { AtxGridPinnedStyleX, AtxGridScrollStyleX, AtxGridStyleY, AtxGridStyleZ } from "./atx-grid-style";
import { Fill, HeaderHeight, Inverse, Stripes } from "./state/props";
import { atom } from "jotai";
import { PinnedWidth, ScrollWidth } from "./state/columns";
import { ScrollHeight } from "./state/rows";
import { useGridAtoms, useGridStore } from "./state/hooks";
import { AtxGridPinnedHeader, AtxGridScrollHeader } from "./atx-grid-header";
import { AtxGridPinnedBody, AtxGridScrollBody } from "./atx-grid-body";
import { DragColumn } from "./state/dnd";
import { useGridPointer } from "./state/hover";
import { AtxGridTooltip } from "./atx-grid-tooltip";

export type AtxGridContainerProps = {
    gId: string;
    className?: string;
    style?: CSSProperties;
};

const FillX = atom((get) => {
    const clientWidth = get(ClientWidth);
    const pinnedWidth = get(PinnedWidth);
    const scrollWidth = get(ScrollWidth);
    return scrollWidth <= clientWidth - pinnedWidth;
});

const FillY = atom((get) => {
    const clientHeight = get(ClientHeight);
    const headerHeight = get(HeaderHeight);
    const scrollHeight = get(ScrollHeight);
    return scrollHeight <= clientHeight - headerHeight;
});

const ClassName = atom((get) =>
    classNames(
        get(Inverse) ? "atx-grid rtl" : "atx-grid ltr",
        get(Fill) && "fill-width",
        get(Stripes) && "stripes",
        get(FillX) && "fill-x",
        get(FillY) && "fill-y",
        get(DragColumn) && "drag-n-drop"
    )
);

const Style = atom(
    (get) =>
        ({
            "--atx-grid-header-width": `${get(PinnedWidth) - 1}px`,
            "--atx-grid-header-height": `${get(HeaderHeight) - 1}px`,
            maxWidth: get(MaxWidth)
        }) as any
);

export const AtxGridContainer = ({ gId, className, style }: AtxGridContainerProps) => {
    const [grid, computedClassName, computedStyle] = useGridAtoms(GridElement, ClassName, Style);

    useViewport(grid);
    useGridPointer(grid);

    const { get, set } = useGridStore();
    return (
        <div
            id={gId}
            ref={(grid) => {
                if (grid) {
                    set(GridElement, grid);
                }
            }}
            className={classNames(computedClassName, className)}
            style={{ ...computedStyle, ...style }}
            onClick={useCallback(({ target }: React.MouseEvent<HTMLDivElement>) => {
                const targetElement = target as HTMLElement;
                const targetCell = targetElement.closest<HTMLElement>(".atx-grid-cell");
                if (!targetCell) {
                    return;
                }
                const targetRow = targetCell.closest<HTMLElement>(".atx-grid-row")!;

                const isContent =
                    targetElement.classList.contains("atx-grid-cell-content") || targetCell.classList.contains("text");

                if ((target === targetCell || isContent) && targetCell.parentElement === targetRow) {
                    const columnIndex = parseInt(targetCell.getAttribute("column-index")!);
                    const rowIndex = parseInt(targetRow.getAttribute("row-index")!);
                    if (get(RowSelection) !== false) {
                        set(RowSelection, rowIndex);
                    }
                    if (get(ColumnSelection) !== false) {
                        set(ColumnSelection, columnIndex);
                    }
                }
            }, [])}
        >
            {useMemo(
                () =>
                    grid && (
                        <>
                            <AtxGridPinnedStyleX gId={gId} />
                            <AtxGridScrollStyleX gId={gId} />
                            <AtxGridStyleY gId={gId} />
                            <AtxGridStyleZ gId={gId} />
                            <AtxGridPinnedHeader />
                            <AtxGridScrollHeader />
                            <AtxGridPinnedBody />
                            <AtxGridScrollBody />
                            <AtxGridTooltip />
                        </>
                    ),
                [grid]
            )}
        </div>
    );
};
