import React, { memo, ReactNode } from "react";
import { AtxGridColumn } from "./atx-grid";
import { AtxTextField, AtxTooltip } from "../widgets";
import { AtxGridColumnSortIcon } from "./atx-grid-sort";
import { AtxGridColumnResizer } from "./atx-grid-column-resizer";
import {
    ColumnLayoutAtom,
    PinnedColumnLayout,
    PinnedColumns,
    PinnedWidth,
    ScrollColumnLayout,
    ScrollColumns,
    ScrollWidth
} from "./state/columns";
import { Atom, atom, WritableAtom } from "jotai";
import { Fill, HeaderHeight, Inverse } from "./state/props";
import { VisibleColumns } from "./state/ranges";
import { ClientWidth } from "./state/viewport";
import { useGridAtom, useGridAtoms, useGridStore } from "./state/hooks";
import { ColumnDragEnter, ColumnDragStart, DragColumn } from "./state/dnd";
import { Filters } from "./state/transform";

const AtxGridHeaderCell = memo(
    ({
         column,
         children
     }: {
        column: AtxGridColumn<any>;
        children: ReactNode;
    }) => {
        const {get, set} = useGridStore();
        const filter = useGridAtom(Filters);
        return (
            <AtxTooltip title={column.tooltip}>
                <div
                    className={column.className}
                    column-index={column.index}
                    column-field={column.field}
                    onDragOver={(e) => {
                        e.preventDefault();
                        return false;
                    }}
                    onDragEnter={(e) => {
                        const {x, width} = e.currentTarget.getBoundingClientRect();
                        set(ColumnDragEnter, column, e.clientX < x + width / 2);
                        e.currentTarget.setAttribute("drag-over", "");
                    }}
                    onDragLeave={(e) => e.currentTarget.removeAttribute("drag-over")}
                    onClick={column.onSort}
                >
                    <div
                        className="atx-grid-cell-content"
                        style={filter && {maxHeight: "calc(50% - 3px"} || undefined}
                        draggable={true}
                        onDragStart={(e) => set(ColumnDragStart, e, column)}
                    >
                        {column.label}
                        {column.onSort && <AtxGridColumnSortIcon column={column}/>}
                    </div>
                    {children}
                    {filter && (
                        <AtxTextField size="small"
                                      value={filter[String(column.field)]}
                                      type="search"
                                      onClick={e => {
                                          e.preventDefault();
                                          e.stopPropagation();
                                      }}
                                      onChange={text => {
                                          const update = {...filter};
                                          update[String(column.field)] = text;
                                          set(Filters, update);
                                      }}/>
                    )}
                </div>
            </AtxTooltip>
        );
    }
);
AtxGridHeaderCell.displayName = "AtxGridHeaderCell";

const AtxGridHeaderCells = memo(
    ({
         Columns,
         Layout,
         TotalWidth
     }: {
        Columns: Atom<AtxGridColumn[]>;
        Layout: ColumnLayoutAtom;
        TotalWidth: WritableAtom<number, [number], void>;
    }) => (
        <>
            {Array.from(useGridAtom(Columns), (column) => (
                <AtxGridHeaderCell key={column.index} column={column}>
                    {column.resizable && (
                        <AtxGridColumnResizer column={column} Layout={Layout} TotalWidth={TotalWidth}/>
                    )}
                </AtxGridHeaderCell>
            ))}
        </>
    )
);
AtxGridHeaderCells.displayName = "AtxGridHeaderCells";

const AtxGridHeaderRow = memo(
    ({
         children
     }: {
        children: ReactNode;
    }) => (
        <div className="atx-grid-row">
            {children}
            {useGridAtom(Fill) ? <div className={"atx-grid-cell filler"} key="header-filler"/> : null}
        </div>
    )
);
AtxGridHeaderRow.displayName = "AtxGridHeaderRow";

const PinnedStyle = atom((get) => ({
    left: get(Inverse) ? get(ClientWidth) - get(PinnedWidth) : 0,
    width: get(PinnedWidth),
    height: get(HeaderHeight)
}));

const SectionStyle = atom((get) => ({
    width: Math.max(get(ScrollWidth) + get(PinnedWidth), get(ClientWidth)),
    height: get(HeaderHeight)
}));
const HeaderStyle = atom((get) => ({
    paddingLeft: get(Inverse) ? 0 : get(PinnedWidth),
    minWidth: get(Inverse) ? get(ScrollWidth) : get(ScrollWidth) + get(PinnedWidth),
    height: get(HeaderHeight),
    width: "100%"
}));

export function AtxGridPinnedHeader() {
    const [pinnedColumns, pinnedStyle] = useGridAtoms(PinnedColumns, PinnedStyle);
    const {get, set} = useGridStore();
    return pinnedColumns.length ? (
        <div className="section corner-section">
            <div
                className={"atx-grid-header pinned"}
                style={pinnedStyle}
                onDragEnter={(e) => {
                    const dragColumn = get(DragColumn)!;
                    const scrollColumns = get(ScrollColumns);
                    const dragIndex = scrollColumns.indexOf(dragColumn);
                    if (dragIndex >= 0) {
                        set(
                            ScrollColumns,
                            scrollColumns.filter((column) => column !== dragColumn)
                        );
                        set(PinnedColumns, [...get(PinnedColumns), dragColumn]);
                    }
                }}
            >
                <AtxGridHeaderRow>
                    <AtxGridHeaderCells Columns={PinnedColumns} Layout={PinnedColumnLayout} TotalWidth={PinnedWidth}/>
                </AtxGridHeaderRow>
            </div>
        </div>
    ) : null;
}

export function AtxGridScrollHeader() {
    const [visibleColumns, sectionStyle, headerStyle] = useGridAtoms(VisibleColumns, SectionStyle, HeaderStyle);
    const {get, set} = useGridStore();
    return visibleColumns.length ? (
        <div className="section top-section" style={sectionStyle}>
            <div
                className={"atx-grid-header scroll"}
                style={headerStyle}
                onDragEnter={(e) => {
                    const dragColumn = get(DragColumn)!;
                    const pinnedColumns = get(PinnedColumns);
                    const dragIndex = pinnedColumns.indexOf(dragColumn);
                    if (dragIndex >= 0) {
                        set(
                            PinnedColumns,
                            pinnedColumns.filter((column) => column !== dragColumn)
                        );
                        set(ScrollColumns, [dragColumn, ...get(ScrollColumns)]);
                    }
                }}
            >
                <AtxGridHeaderRow>
                    <AtxGridHeaderCells Columns={VisibleColumns} Layout={ScrollColumnLayout} TotalWidth={ScrollWidth}/>
                </AtxGridHeaderRow>
            </div>
        </div>
    ) : null;
}
