import { HeaderHeight, Inverse } from "./state/props";
import { atom } from "jotai";
import { PinnedColumnLayout, PinnedWidth, ScrollColumnLayout, ScrollWidth } from "./state/columns";
import { FinalRows } from "./state/transform";
import { Shader } from "./state/ranges";
import { ScrollHeight } from "./state/rows";
import { GridID } from "./state/grid";
import { BottomIndex, LeftIndex, RightIndex, TopIndex } from "./state/window";
import { useGridAtom, useGridAtoms } from "./state/hooks";

export function AtxGridPinnedStyleX({ gId }: { gId: string }) {
    const [inverse, layout] = useGridAtoms(Inverse, PinnedColumnLayout);
    let css = "";
    let pos = inverse ? "right" : "left";

    for (const { index, left, width } of layout) {
        css += `.${gId}-c${index}{${pos}:${left}px;width:${width}px;}\n`;
    }

    return <style id={gId + "-pinned-style-x"}>{css}</style>;
}

const CssX = atom((get) => {
    const gId = get(GridID);

    let css = "";
    let pos = get(Inverse) ? "right" : "left";

    const layout = get(ScrollColumnLayout);
    const leftIndex = get(LeftIndex);
    const rightIndex = get(RightIndex);

    for (let i = leftIndex; i < rightIndex; i++) {
        const { index, left, width } = layout[i];
        css += `.${gId}-c${index}{${pos}:${left}px;width:${width}px;}\n`;
    }

    const scrollWidth = get(ScrollWidth);
    const pinnedWidth = get(PinnedWidth);
    css += `#${gId} .atx-grid-header{width:${scrollWidth}px;}\n`;
    css += `#${gId} .atx-grid-body{width:${scrollWidth}px;}\n`;
    css += `#${gId} .scroll>.atx-grid-row{${pos}:${pinnedWidth}px;width:${scrollWidth}px;}`;

    return css;
});

export function AtxGridScrollStyleX({ gId }: { gId: string }) {
    return <style id={gId + "-scroll-style-x"}>{useGridAtom(CssX)}</style>;
}

const CssY = atom((get) => {
    const gId = get(GridID);

    let css = "";

    const rowDefs = get(FinalRows);
    const shader = get(Shader);

    const topIndex = get(TopIndex);
    const bottomIndex = get(BottomIndex);

    for (let i = topIndex; i < bottomIndex; i++) {
        const { index, data, top, height } = rowDefs[i];
        css += `.${gId}-r${index}{transform:translateY(${top}px);height:${height}px;background:${
            shader?.(data, index) ?? "none"
        };}\n`;
    }

    const scrollHeight = get(ScrollHeight);
    const headerHeight = get(HeaderHeight);
    css += `#${gId} .atx-grid-body{height:${scrollHeight - headerHeight}px;}`;

    return css;
});

export function AtxGridStyleY({ gId }: { gId: string }) {
    return <style id={gId + "-style-y"}>{useGridAtom(CssY)}</style>;
}

const CssZ = atom((get) => {
    const gId = get(GridID);

    let css = "";

    return css;
});

export function AtxGridStyleZ({ gId }: { gId: string }) {
    return <style id={gId + "-style-z"}>{useGridAtom(CssZ)}</style>;
}
