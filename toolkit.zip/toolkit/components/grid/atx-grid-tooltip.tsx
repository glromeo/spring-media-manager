import React from "react";
import { useGridAtom } from "./state/hooks";
import { GridTooltip } from "./state/tooltip";
import { classNames } from "../../utils";
import "./atx-grid-tooltip.scss";

export function AtxGridTooltip() {
    const tooltip = useGridAtom(GridTooltip);
    return tooltip ? (
        <div
            className={classNames("atx-grid-tooltip", tooltip.visible && "visible")}
            style={tooltip.style}
            data-message={undefined}
        >
            <div className="atx-grid-tooltip-content">{tooltip.content}</div>
        </div>
    ) : null;
}
