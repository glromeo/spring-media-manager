import React, {CSSProperties, MouseEventHandler, ReactElement, useEffect, useMemo} from "react";
import {Atom, useStore, WritableAtom} from "jotai";
import {AtxGridRow, AtxGridRowDef, GridRows} from "./state/rows";
import {AtxGridContainer} from "./atx-grid-container";
import {
    AtxCellAPI,
    AtxCellFormatter,
    AtxCellRenderer,
    defaultCellFormatters,
    defaultCellRenderer
} from "./atx-grid-cell";
import {AtxGridStore, ColumnSelection, createGridStore, GridID, RowSelection, Selection} from "./state/grid";

import {
    Fill,
    GroupBy,
    HeaderHeight,
    Highlight,
    Inverse,
    OnChange,
    OnScroll,
    RowData,
    RowDetails,
    RowHeight,
    RowMapper,
    Stripes,
    Tooltip
} from "./state/props";
import {ColumnDefs, Defaults} from "./state/columns";

import "./atx-grid.scss";
import "./atx-grid-dnd.scss";
import {defaultSort, GridSort, GridSortReducer, Sort} from "./state/transform";

export type AtxColumnTotals<T = DataItem> = (
    data: T[],
    field: keyof T,
    selected?: boolean
) => JSX.Element | string | number | null;

export type AtxColumnType =
    | "text"
    | "flag"
    | "number"
    | "quantity"
    | "spread"
    | "yield"
    | "price"
    | "date"
    | "time"
    | "datetime"
    | "percentage"
    | "csv"
    | "unknown";

export type DataItem = Record<string | number, any>;

export type AtxGridChangeEvent<T extends DataItem = DataItem> = {
    type: "sort" | "size" | "grouping" | "pinned";
    column?: AtxGridColumn<T>;
    row?: AtxGridRow<T>;
};

export type AtxGridSelectionFilter<T extends DataItem = DataItem> = (data: T, index: number) => boolean;

export type AtxGridSelection<T extends DataItem = DataItem> = WritableAtom<
    AtxGridSelectionFilter<T> | T | null,
    [T | null],
    any
>;

export type AtxGridProps<T extends DataItem = DataItem, K extends keyof T = any> = {
    cellFormatter?: AtxCellFormatter<T>;
    cellFormatters?: Partial<Record<AtxColumnType, AtxCellFormatter>>;
    cellRenderer?: AtxCellRenderer<T>;
    children?: ReactElement<AtxGridColumnDef<T>>[];
    className?: string;
    columnDefs?: AtxGridColumnDef<T>[];
    fill?: boolean;
    filters?: boolean;
    groupBy?: Set<keyof T> | undefined;
    headerHeight?: number;
    highlight?: [number, number, number] | undefined;
    inverse?: boolean;
    onChange?: (event: AtxGridChangeEvent<T>) => void;
    onScroll?: (gridElement: HTMLDivElement) => void;
    onSort?: (columnDef: AtxGridColumn, shiftKey: boolean) => void;
    resizable?: boolean;
    rowClassName?: (row: AtxGridRowDef<T>) => string | undefined;
    rowData: T[] | Atom<T[]>;
    rowDetails?: (row: AtxGridRow<T>) => ReactElement | null | undefined;
    rowHeight?: number | ((data: T, index: number) => number);
    rowId?: K | ((row: AtxGridRowDef<T>) => string | number);
    selection?: AtxGridSelection<T> | "rows" | "columns" | "both";
    sort?: [keyof T, "asc" | "desc"][] | "auto";
    stripes?: boolean;
    style?: CSSProperties;
    tooltip?: (cellApi: AtxCellAPI) => React.ReactNode;
};

export type AtxGridColumnStyle = Pick<CSSProperties, "width" | "minWidth" | "maxWidth">;

export type AtxGridColumnDef<T extends DataItem = DataItem> = {
    className?: string;
    field?: keyof T;
    formatter?: AtxCellFormatter<T>;
    key?: (item: T) => string; // for group by & shader... rename me possibly
    label: ReactElement | string;
    pinned?: boolean;
    render?: AtxCellRenderer<T>;
    resizable?: boolean | { minWidth?: number; maxWidth?: number };
    sortable?: boolean;
    style?: AtxGridColumnStyle;
    tooltip?: string;
    totals?: AtxColumnTotals<T>;
    type?: AtxColumnType | string;
    hidden?: boolean;
    width?: number;
    comparator?: (a: T, b: T) => -1 | 0 | 1;
};

export type AtxGridColumn<T extends DataItem = DataItem> = {
    aggregate?: boolean;
    className: string | undefined;
    field: keyof T;
    formatter: AtxCellFormatter<T>;
    index: number;
    key?: (item: T) => string;
    label: ReactElement | string;
    onSort?: MouseEventHandler<HTMLDivElement>;
    pinned?: boolean;
    render: AtxCellRenderer<T>;
    resizable: boolean | { minWidth?: number; maxWidth?: number };
    tooltip?: string;
    totals?: AtxColumnTotals<T>;
    width: number;
    comparator?: (a: T, b: T) => -1 | 0 | 1;
};

/**
 *           _         _____      _     _
 *      /\  | |       / ____|    (_)   | |
 *     /  \ | |_ _   |_|  __ _ __ _  __| |
 *    / /\ \| __\ \ / /| |_ | '__| |/ _` |
 *   / ____ \ |_ \ V / |__| | |  | | (_| |
 *  /_/    \_\__|_/\_\\_____|_|  |_|\__,_|
 *
 * @constructor
 * @param props
 */
export function AtxGrid<T extends DataItem>(props: AtxGridProps<T>) {
    let {
        cellFormatter,
        cellFormatters,
        cellRenderer,
        children,
        className,
        columnDefs,
        fill,
        filters,
        groupBy,
        headerHeight,
        highlight,
        inverse,
        onChange,
        onScroll,
        onSort,
        resizable,
        rowClassName,
        rowData,
        rowDetails,
        rowHeight,
        rowId,
        selection,
        sort,
        stripes,
        style,
        tooltip
    } = props as AtxGridProps;

    const store = useMemo(createGridStore, []);
    const gId = store.get(GridID);

    const external = useStore();
    const {get, set, sub} = external;

    useEffect(() => store.set(Fill, fill), [fill])
    useEffect(() => store.set(GroupBy, groupBy ?? new Set<keyof DataItem>()), [groupBy])
    useEffect(() => store.set(HeaderHeight, (headerHeight ?? 32) + (filters ? 28 : 0)), [headerHeight, filters])
    useEffect(() => store.set(Highlight, highlight), [highlight])
    useEffect(() => store.set(Inverse, inverse), [inverse])
    useEffect(() => store.set(OnChange, onChange), [onChange])
    useEffect(() => store.set(OnScroll, onScroll), [onScroll])
    useEffect(() => {
        if (rowId) {
            if (typeof rowId !== "function") {
                const field = rowId as keyof DataItem
                rowId = (row: AtxGridRowDef) => row.data[field];
            }
        } else {
            rowId = (row: AtxGridRowDef) => row.index;
        }
        store.set(RowMapper, {rowId, rowClassName});
    }, [rowId, rowClassName])
    useEffect(() => store.set(RowHeight, {rowHeight}), [rowHeight])
    useEffect(() => {
        if (rowDetails) {
            store.set(RowDetails, {render: rowDetails})
        } else {
            store.set(RowDetails, undefined)
        }
    }, [rowDetails])
    useEffect(() => store.set(Stripes, stripes), [stripes])
    useEffect(() => store.set(Tooltip, tooltip), [tooltip])

    const sortable = !!sort

    useEffect(() => {
        set(Defaults, {
            cellFormatters: cellFormatters ?? defaultCellFormatters,
            cellFormatter: cellFormatter ?? defaultCellFormatters.unknown,
            cellRenderer: cellRenderer ?? defaultCellRenderer,
            resizable: resizable ?? false,
            sortable: sortable
        });
    }, [cellFormatter, cellFormatters, cellRenderer, resizable, sortable])

    useEffect(() => {
        if (sort) {
            if (sort === 'auto') {
                store.set(Sort, [[], defaultSort]);
            } else {
                store.set(Sort, [sort as GridSort, (onSort ?? defaultSort) as GridSortReducer]);
            }
        }
    }, [sort]);

    useEffect(() => {
        store.set(ColumnDefs, gId, [
            ...(columnDefs ?? []),
            ...(children ?? []).map(({props}) => ({...props, field: props.field, type: props.type}))
        ] as AtxGridColumnDef[]);
    }, [columnDefs, children]);

    useEffect(() => {
        if (rowData && "read" in rowData) {
            store.set(RowData, get(rowData));
            return sub(rowData, () => store.set(RowData, get(rowData as Atom<DataItem[]>)));
        } else {
            store.set(RowData, rowData as T[]);
        }
    }, [rowData]);

    useEffect(() => {
        store.set(RowSelection, selection === "rows" || selection === "both");
        store.set(ColumnSelection, selection === "columns" || selection === "both");
        if (selection !== null && typeof selection === "object") {
            const atom = selection as AtxGridSelection
            store.set(Selection, get(atom));
            const unsubGridRows = store.sub(GridRows, () => store.set(Selection, get(atom)))
            const unsubInbound = sub(atom, () => store.set(Selection, get(atom)));
            const unsubOutbound = store.sub(Selection, () => set(atom, store.get(Selection) as T | null));
            return () => {
                unsubGridRows();
                unsubInbound();
                unsubOutbound();
            };
        }
    }, [selection]);

    return useMemo(
        () => (
            <AtxGridStore.Provider value={store}>
                <AtxGridContainer gId={gId} className={className} style={style}/>
            </AtxGridStore.Provider>
        ),
        [className, style]
    );
}

export type AtxGrid<T extends DataItem = DataItem> = typeof AtxGrid<T> & {
    Column: React.FC<AtxGridColumnDef<T>>;
};

AtxGrid.Column = <T extends DataItem>(props: AtxGridColumnDef<T>) => {
    return null;
};
