import { AtxGridColumn, AtxGridColumnDef, DataItem } from "../atx-grid";
import { cellJustify, defaultCellFormatters, defaultCellRenderer } from "../atx-grid-cell";
import { MouseEvent } from "react";
import { classNames } from "../../../utils";
import { atom, PrimitiveAtom } from "jotai";
import { GroupBy } from "./props";
import { Resizing } from "./grid";
import { ColumnSort } from "./transform";

export const PinnedColumns = atom([] as AtxGridColumn[]);
export const ScrollColumns = atom([] as AtxGridColumn[]);

export const PinnedColumnLayout = atom([] as ColumnLayout);
export const ScrollColumnLayout = atom([] as ColumnLayout);

export const PinnedWidth = atom(0 as number);
export const ScrollWidth = atom(0 as number);

export const Defaults = atom({
    cellFormatters: defaultCellFormatters,
    cellFormatter: defaultCellFormatters.unknown,
    cellRenderer: defaultCellRenderer,
    resizable: false,
    sortable: false
});

export const ColumnDefs = atom(null, (get, set, id: string, columnDefs: AtxGridColumnDef[]) => {
    const defaults = get(Defaults);
    const groupBy = get(GroupBy);

    const pinnedColumns: AtxGridColumn[] = [];
    const scrollColumns: AtxGridColumn[] = [];
    const columnsMap = {} as Record<string, AtxGridColumn>;

    columnDefs.forEach((columnDef, index) => {
        if (!columnDef.hidden) {
            let {
                className,
                field = index as string | number,
                formatter,
                key,
                label,
                pinned,
                render,
                resizable = defaults.resizable,
                sortable = defaults.sortable,
                tooltip,
                totals,
                type,
                width = 100, // here is where I should calculate it...
                comparator,
            } = columnDef;
            const aggregate = groupBy?.has(field);
            const column: Omit<AtxGridColumn, "onPack"> = {
                aggregate,
                className: classNames(`atx-grid-cell ${id}-c${index}`, type, type && cellJustify[type], className),
                field,
                formatter: formatter || (type && defaults.cellFormatters[type]) || defaults.cellFormatter,
                key,
                index,
                label,
                pinned: pinned || aggregate,
                render: render || defaults.cellRenderer,
                resizable,
                tooltip,
                totals,
                width,
                comparator
            };
            console.log(column, groupBy, field, groupBy?.has(field))
            if (sortable) {
                column.onSort = ({shiftKey}: MouseEvent<HTMLDivElement>) => {
                    if (!get(Resizing)) {
                        set(ColumnSort, column as AtxGridColumn, shiftKey);
                    }
                };
            }
            if (column.pinned) {
                pinnedColumns.push(column);
            } else {
                scrollColumns.push(column);
            }
            columnsMap[column.field] = column;
        }
    });

    const groupByFields = groupBy ? [...groupBy.keys()] : null;

    pinnedColumns.sort((left, right) => {
        if (groupByFields) {
            let l = groupByFields.indexOf(left.field);
            let r = groupByFields.indexOf(right.field);
            if (l < 0) {
                l = groupByFields.length;
            }
            if (r < 0) {
                r = groupByFields.length;
            }
            return l < r ? -1 : l > r ? 1 : 0;
        }
        return 0;
    });

    set(PinnedColumns, pinnedColumns);
    set(ScrollColumns, scrollColumns);
    set(ColumnsMap, columnsMap);

    set(ColumnSink, pinnedColumns, scrollColumns);
});

export const ColumnSink = atom(null, (get, set, pinnedColumns: AtxGridColumn[], scrollColumns: AtxGridColumn[]) => {
    const { layout: pinnedLayout, width: pinnedWidth } = toLayout(pinnedColumns);
    const { layout: scrollLayout, width: scrollWidth } = toLayout(scrollColumns);

    set(PinnedColumnLayout, pinnedLayout);
    set(PinnedWidth, pinnedWidth);

    set(ScrollColumnLayout, scrollLayout);
    set(ScrollWidth, scrollWidth);
});

export const ColumnsMap = atom({} as Record<string, AtxGridColumn>);

export type ColumnLayout = { index: number; left: number; width: number }[];

export type ColumnLayoutAtom = PrimitiveAtom<ColumnLayout>;

function toLayout<T = DataItem>(columns: AtxGridColumn<T>[]) {
    let left = 0;
    const layout = [] as ColumnLayout;
    for (let i = 0; i < columns.length; i++) {
        let { index, width } = columns[i];
        ++width; // We do like html table and cater for the border size here...kind of...
        layout.push({
            index,
            left,
            width
        });
        left += width;
    }
    return { layout, width: left };
}
