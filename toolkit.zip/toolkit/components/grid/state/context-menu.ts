import { MouseEvent } from "react";
import ReactDOM from "react-dom";

// HOWTO:
//
// onContextMenu={useContextMenu(close => {
//     return (
//         <AtxMenu open={true} onClose={close}>
//     <AtxMenuItem><span
//         style={{fontWeight: "bold"}}>field:</span>{field}
//     </AtxMenuItem>
//     {canAggregate ? (
//         <AtxMenuItem label="Aggregate" onClick={() => {
//     }}/>
//     ) : (
//         <AtxMenuItem label="Aggregate" onClick={() => {
//     }}/>
//     )}
//     {canAggregate ? (
//         <AtxMenuItem>
//             <AtxMenu label="Function">
//         <AtxMenuItem label="Aggregate" onClick={() => {
//     }}/>
//     <AtxMenuItem label="Aggregate" onClick={() => {
//     }}/>
//     </AtxMenu>
//     </AtxMenuItem>
//     ) : null}
//     </AtxMenu>
// );
// })}>

export function useContextMenu<T>(createElement: (close: () => void) => JSX.Element) {
    return (event: MouseEvent) => {
        event.preventDefault()
        event.stopPropagation()

        const {pageX, pageY} = event
        const anchorEl = document.createElement('div')
        document.body.append(anchorEl)
        anchorEl.style.cssText = `position: fixed; left:${pageX}px; top: ${pageY}px;`

        ReactDOM.render(
            createElement(() => anchorEl.remove()),
            anchorEl
        )
    }
}
