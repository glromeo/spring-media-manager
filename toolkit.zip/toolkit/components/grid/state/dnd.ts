import React from "react";
import { atom } from "jotai";
import { GridElement } from "./grid";
import { ClientHeight, ClientWidth } from "./viewport";
import { ColumnSink, PinnedColumns, PinnedWidth, ScrollColumns } from "./columns";
import { AtxGridColumn } from "../atx-grid";
import { Inverse } from "./props";

const DragScroll = atom((get) => {
    let af: number;
    let x0: number, x1: number, dX: number;
    let y0: number, y1: number, dY: number;

    const grid = get(GridElement)!;
    const isInverse = get(Inverse);

    function dragOver(e: { pageX: number; pageY: number }) {
        dX = Math.round(e.pageX < x0 ? e.pageX - x0 : e.pageX > x1 ? e.pageX - x1 : 0);
        if (dX < -32 || dX > 32) {
            dX = 0;
        }
        dY = Math.round(e.pageY < y0 ? e.pageY - y0 : e.pageY > y1 ? e.pageY - y1 : 0);
    }

    /**
     * document.getElementById('debug-info')!.innerText = `x: ${dX}, y: ${dY}    ${new Date().toLocaleTimeString()}`
     */
    function eachFrame() {
        const dragColumn = get(DragColumn)!;
        grid!.scrollLeft += dX;
        grid!.scrollTop += dY;
        af = requestAnimationFrame(eachFrame);
    }

    let cleanUp: Function;

    /**
     * document.body.insertAdjacentHTML('beforeend', `<div id="debug-info" style="pointer-events: none; position:fixed; left:${x0}px; top:${y0}px; border: 1px solid black; width: ${x1 - x0}px; height: ${y1 - y0}px; padding: 8px; background:white; color: black; font-size: 2rem;"></div>`)
     *
     * @param currentTarget
     * @param pageX
     * @param pageY
     */
    function startDragScroll({ currentTarget, pageX, pageY }: React.DragEvent<HTMLDivElement>) {
        const scrollBody = grid!.querySelector(".atx-grid-body.scroll") as HTMLDivElement;
        const { left, top } = scrollBody.getBoundingClientRect();
        const { scrollLeft, scrollTop } = grid!;
        if (isInverse) {
            x1 = scrollLeft + left + get(ClientWidth) - get(PinnedWidth) - 32;
            x0 = scrollLeft + left + 32;
        } else {
            x0 = scrollLeft + left + get(PinnedWidth) + 32;
            x1 = scrollLeft + left + get(ClientWidth) - 32;
        }
        y0 = scrollTop + top + 16;
        y1 = scrollTop + top + get(ClientHeight) - 40;

        dragOver({ pageX, pageY });

        af = requestAnimationFrame(eachFrame);

        window.addEventListener("dragover", dragOver);
        window.addEventListener("mouseleave", stopDragScroll);
        currentTarget.addEventListener("dragend", stopDragScroll);

        cleanUp = () => {
            window.removeEventListener("dragover", dragOver);
            window.removeEventListener("mouseleave", stopDragScroll);
            currentTarget.removeEventListener("dragend", stopDragScroll);
        };
    }

    /**
     * document.getElementById('debug-info')?.remove()
     */
    function stopDragScroll() {
        cleanUp();
        cancelAnimationFrame(af);
    }

    return { startDragScroll, stopDragScroll };
});

export const DragColumn = atom<AtxGridColumn | null>(null);
const DragState = atom<{
    pinnedColumns: AtxGridColumn[];
    scrollColumns: AtxGridColumn[];
} | null>(null);

const dragIcon = `<svg style="height:1rem;width:1rem;margin:0.25rem;" viewBox="0 0 512 512"><path d="M352.2 425.8l-79.2 79.2c-9.4 9.4-24.6 9.4-33.9 0l-79.2-79.2c-15.1-15.1-4.4-41 17-41h51.2L228 284H127.2v51.2c0 21.4-25.9 32.1-41 17L7 272.9c-9.4-9.4-9.4-24.6 0-33.9L86.2 159.8c15.1-15.1 41-4.4 41 17V228H228V127.2h-51.2c-21.4 0-32.1-25.9-17-41l79.2-79.2c9.4-9.4 24.6-9.4 33.9 0l79.2 79.2c15.1 15.1 4.4 41-17 41h-51.2V228h100.8v-51.2c0-21.4 25.9-32.1 41-17l79.2 79.2c9.4 9.4 9.4 24.6 0 33.9L425.8 352.2c-15.1 15.1-41 4.4-41-17V284H284v100.8h51.2c21.4 0 32.1 25.9 17 41z"/></svg>`;

export const ColumnDragStart = atom(null, (get, set, event: React.DragEvent<HTMLDivElement>, column: AtxGridColumn) => {
    const { startDragScroll, stopDragScroll } = get(DragScroll);
    const { currentTarget } = event;

    currentTarget.insertAdjacentHTML("afterbegin", dragIcon);
    currentTarget.style.padding = ".25rem";
    currentTarget.style.margin = "-.25rem";

    currentTarget.setAttribute("drag-start", "true");
    requestAnimationFrame(() => {
        currentTarget.style.padding = "";
        currentTarget.style.margin = "";
        currentTarget.firstElementChild!.remove();
        currentTarget.removeAttribute("drag-start");
        currentTarget.style.opacity = "0.4";
        set(DragColumn, column);
        set(DragState, {
            pinnedColumns: get(PinnedColumns),
            scrollColumns: get(ScrollColumns)
        });
    });

    startDragScroll(event);

    function onDragEnd(event: DragEvent) {
        stopDragScroll();
        for (const el of get(GridElement)!.querySelectorAll("[drag-over]")) {
            el.removeAttribute("drag-over");
        }
        currentTarget.removeEventListener("dragend", onDragEnd);
        currentTarget.style.opacity = "1";
        set(DragColumn, null);
        const { pinnedColumns, scrollColumns } = get(DragState)!;
        set(PinnedColumns, pinnedColumns);
        set(ScrollColumns, scrollColumns);
    }

    currentTarget.addEventListener("dragend", onDragEnd);
});

export const ColumnDragEnter = atom(null, (get, set, dropColumn: AtxGridColumn, insert: boolean) => {
    const dragColumn = get(DragColumn)!;
    const isInverse = get(Inverse)!;
    if (dropColumn && dragColumn !== dropColumn) {
        let pinnedColumns = get(PinnedColumns);
        let scrollColumns = get(ScrollColumns);
        let dragIndex = pinnedColumns.indexOf(dragColumn);
        let dragFrom;
        if (dragIndex >= 0) {
            dragFrom = pinnedColumns = [...pinnedColumns];
        } else {
            dragIndex = scrollColumns.indexOf(dragColumn);
            dragFrom = scrollColumns = [...scrollColumns];
        }
        dragFrom.splice(dragIndex, 1);

        let dropIndex = pinnedColumns.indexOf(dropColumn!);
        let dropTo;
        if (dropIndex >= 0) {
            if (dragFrom === pinnedColumns) {
                dropTo = pinnedColumns;
            } else {
                dropTo = pinnedColumns = [...pinnedColumns];
            }
        } else {
            dropIndex = scrollColumns.indexOf(dropColumn!);
            if (dragFrom === scrollColumns) {
                dropTo = scrollColumns;
            } else {
                dropTo = scrollColumns = [...scrollColumns];
            }
        }

        const spliceIndex = isInverse ? (insert ? dropIndex : dropIndex + 1) : insert ? dropIndex + 1 : dropIndex;
        dropTo.splice(spliceIndex, 0, dragColumn);

        set(ColumnSink, pinnedColumns, scrollColumns);
        set(DragState, {
            pinnedColumns,
            scrollColumns
        });
    }
});
