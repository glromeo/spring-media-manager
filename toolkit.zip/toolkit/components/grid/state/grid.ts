import { createContext } from "react";
import { atom, createStore } from "jotai";
import { GridRows } from "./rows";
import { AtxGridSelectionFilter, DataItem } from "../atx-grid";

export const GridID = atom("atx-grid");
export const GridElement = atom(null as HTMLDivElement | null);
export const Resizing = atom(false);
export const MaxWidth = atom(undefined as number | undefined);
export const MaxHeight = atom(undefined as number | undefined); // atom(get => get(HeaderHeight) + get(ScrollHeight) + 2);

export const RowSelection = atom(false as number | null | boolean);
export const ColumnSelection = atom(false as number | null | boolean);

export const Selection = atom(
    (get) => {
        const selectedRowIndex = get(RowSelection);
        return get(GridRows).find(({ index }) => index === selectedRowIndex)?.data ?? (null as DataItem | null);
    },
    (get, set, item: DataItem | null | AtxGridSelectionFilter) => {
        if (typeof item === "function") {
            set(RowSelection, get(GridRows).find(({ data, index }) => item(data, index))?.index ?? null);
        } else if (item) {
            set(RowSelection, get(GridRows).find(({ data }) => data === item)?.index ?? null);
        } else {
            set(RowSelection, null);
        }
    }
);

let sequence = 0;

export function createGridStore() {
    const store = createStore();
    store.set(GridID, `atx-g${sequence++}`);
    return store;
}

export const AtxGridStore = createContext({} as ReturnType<typeof createGridStore>);
