import { Atom } from "jotai";
import { ReactElement, useContext, useMemo, useSyncExternalStore } from "react";
import { AtxGridStore, ColumnSelection } from "./grid";

export function useMemoMapper<I extends object>(
    mapper: (input: I, index: number) => ReactElement,
    dependencies: any[]
) {
    return useMemo(() => {
        const cache = new WeakMap<I, ReactElement>()
        return (input: I, index: number) => {
            let cached = cache.get(input)
            if (!cached) {
                cache.set(input, (cached = mapper(input, index)))
            }
            return cached
        }
    }, dependencies)
}

export function useColumnSelected(columnIndex: number) {
    if (columnIndex === useGridAtom(ColumnSelection)) {
        return 'selected'
    }
}

export function useGridStore() {
    return useContext(AtxGridStore)
}

export function useGridAtoms<A, B, C, D, E, G, H, I>(
    ...atoms: [Atom<A>, Atom<B>?, Atom<C>?, Atom<D>?, Atom<E>?, Atom<G>?, Atom<H>?, Atom<H>?]
): [A, B, C, D, E, G, H, I] {
    const store = useContext(AtxGridStore)
    const {subscribe, getSnapshot} = useMemo(() => {
        const {get, sub} = store
        let cache = atoms.map((a) => get(a as any)) as any
        return {
            subscribe: function (callback: () => void) {
                const subs = atoms.map((a) => sub(a as any, callback))
                return () => subs.forEach((unsub) => unsub())
            },
            getSnapshot: function () {
                let update = [...cache]
                let same = true
                for (let i = 0; i < update.length; i++) {
                    if (same) {
                        same = Object.is(cache[i], (update[i] = get(atoms[i] as any)))
                    } else {
                        update[i] = get(atoms[i] as any)
                    }
                }
                return same ? cache : (cache = update)
            }
        }
    }, atoms)
    return useSyncExternalStore(subscribe, getSnapshot) as any
}

export function useGridAtom<Value>(atom: Atom<Value>): Value {
    const store = useContext(AtxGridStore)
    const {subscribe, getSnapshot} = useMemo(() => {
        const {get, sub} = store
        return {
            subscribe: (callback: () => void) => sub(atom, callback),
            getSnapshot: () => get(atom)
        }
    }, [atom])
    return useSyncExternalStore(subscribe, getSnapshot)
}
