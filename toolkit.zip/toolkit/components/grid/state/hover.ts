import { MouseEventHandler, useEffect } from "react";
import { atom } from "jotai";
import { GridTooltip } from "./tooltip";
import { GridElement } from "./grid";
import { useGridStore } from "./hooks";

export const HoverCell = atom<HTMLDivElement | null>(null);

const HoverTimeout = atom<any>(0);

export const GridPointer = atom({ mouseX: 0, mouseY: 0 });

export function useGridPointer(grid: HTMLDivElement | null) {
    const { set } = useGridStore();
    let af: any = null;
    useEffect(() => {
        if (grid) {
            const listener = (event: MouseEvent) => {
                af =
                    af ||
                    requestAnimationFrame(() => {
                        const { pageX, pageY } = event;
                        const { left, top } = grid.getBoundingClientRect();
                        set(GridPointer, {
                            mouseX: grid.scrollLeft + pageX! - left,
                            mouseY: grid.scrollTop + pageY! - top
                        });
                        af = null;
                    });
            };
            grid.addEventListener("mousemove", listener);
            return () => {
                grid.removeEventListener("mousemove", listener);
            };
        }
    }, [grid]);
}

export const GridHover = atom<
    {
        onMouseOver: MouseEventHandler<HTMLDivElement>;
        onMouseOut: MouseEventHandler<HTMLDivElement>;
    },
    [HTMLDivElement | null, number?, number?],
    void
>(
    (get, { setSelf }) => {
        const grid = get(GridElement)!;
        let pinnedHover: HTMLDivElement | null = null;
        let scrollHover: HTMLDivElement | null = null;
        return {
            onMouseOver({ target, currentTarget, pageX, pageY }) {
                const hoverCell = ((target as HTMLDivElement).closest(".atx-grid-cell") as HTMLDivElement) ?? null;
                if (hoverCell !== get(HoverCell)) {
                    if (hoverCell) {
                        pinnedHover?.removeAttribute("hover");
                        scrollHover?.removeAttribute("hover");

                        const targetRow = hoverCell.closest(".atx-grid-row") as HTMLDivElement;
                        const rowIndex = targetRow.getAttribute("row-index");
                        if (currentTarget.classList.contains("pinned")) {
                            pinnedHover = targetRow;
                            scrollHover = grid.querySelector(`.atx-grid-body.scroll [row-index="${rowIndex}"]`);
                        } else {
                            pinnedHover = grid.querySelector(`.atx-grid-body.pinned [row-index="${rowIndex}"]`);
                            scrollHover = targetRow;
                        }
                        pinnedHover?.setAttribute("hover", "");
                        scrollHover?.setAttribute("hover", "");

                        setSelf(hoverCell);
                    } else {
                        setSelf(null);
                    }
                }
            },
            onMouseOut({ target, currentTarget }) {
                if (target === get(HoverCell)) {
                    pinnedHover?.removeAttribute("hover");
                    scrollHover?.removeAttribute("hover");

                    setSelf(null);
                }
            }
        };
    },
    (get, set, hoverCell, x, y) => {
        set(HoverCell, hoverCell);
        clearTimeout(get(HoverTimeout));
        set(
            HoverTimeout,
            setTimeout(() => set(GridTooltip, hoverCell), 250)
        );
    }
);
