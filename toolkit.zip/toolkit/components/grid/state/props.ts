import {atom} from "jotai";
import {AtxGridProps, DataItem} from "../atx-grid";

export const RowData = atom([] as DataItem[]);

export const Fill = atom<boolean | undefined>(undefined);
export const GroupBy = atom(new Set<keyof DataItem>());
export const HeaderHeight = atom<number>(32);
export const Highlight = atom<AtxGridProps["highlight"]>(undefined);
export const Inverse = atom<AtxGridProps["inverse"] | undefined>(undefined);
export const OnChange = atom<AtxGridProps["onChange"] | undefined>(undefined);
export const OnScroll = atom<AtxGridProps["onScroll"] | undefined>(undefined);
export const RowMapper = atom<Partial<{
    rowId: AtxGridProps["rowId"],
    rowClassName: AtxGridProps["rowClassName"]
}>>({});
export const RowHeight = atom<{rowHeight:AtxGridProps["rowHeight"]}>({rowHeight:28});
export const RowDetails = atom<{render:AtxGridProps["rowDetails"]} | undefined>(undefined);
export const Stripes = atom<AtxGridProps["stripes"] | undefined>(undefined);
export const Tooltip = atom<AtxGridProps["tooltip"] | undefined>(undefined);
