import {AtxGridColumn, DataItem} from "../atx-grid";
import {classNames} from "../../../utils";
import {AtxGridRow, AtxGridRowDef, Bucket} from "./rows";
import {ColumnSort, FinalRows} from "./transform";
import {Highlight, RowData, RowMapper} from "./props";
import {atom} from "jotai";
import {PinnedColumns, ScrollColumns} from "./columns";
import {GridID} from "./grid";
import {BottomIndex, LeftIndex, RightIndex, TopIndex} from "./window";
import {DragColumn} from "./dnd";

export type AtxGridShader<T extends DataItem = DataItem> = (item: T | Bucket<T>, index: number) => string;

export const Shader = atom((get): AtxGridShader | undefined => {
    const highlight = get(Highlight);
    const sort = get(ColumnSort);
    if (sort) {
        const hasSort = (column: AtxGridColumn) => {
            const columnSort = sort.get(column.field as any);
            if (columnSort) {
                const [mode, order] = columnSort;
                return highlight && mode && (!order || order === 1);
            }
        };
        const sortedColumn = get(PinnedColumns).find(hasSort) ?? get(ScrollColumns).find(hasSort);
        if (sortedColumn) {
            const data = get(RowData);
            const {field} = sortedColumn;
            const getKey = sortedColumn.key ?? ((item) => String(item[field]));
            const buckets = new Set(data.map(getKey));
            const RGB = highlight!.join(",");
            const range = buckets.size;
            let shade = range;
            const shades: any = {};
            for (const key of buckets) {
                shades[key] = `rgba(${RGB}, ${shade / range})`;
                shade -= 1;
            }
            return (item: any) => shades[getKey(item)];
        }
    }
});

const VisibleRowMapper = atom((get) => {
    const cache = new Map<number, AtxGridRow>();
    get(FinalRows); // This dependency makes so that the cache is flushed
    const gId = get(GridID);
    const {rowId, rowClassName} = get(RowMapper);
    return (row: AtxGridRowDef, sortIndex: number) => {
        let cached = cache.get(row.index);
        if (!cached) {
            cache.set(
                row.index,
                (cached = {
                    ...row,
                    id: rowId(row),
                    className: classNames(
                        `atx-grid-row ${gId}-r${row.index}`,
                        sortIndex % 2 ? "odd" : "even",
                        row.bucket && `group-by depth-${row.bucket.depth}`,
                        rowClassName?.(row)
                    )
                } as AtxGridRow)
            );
        }
        return cached;
    };
});

export const VisibleRows = atom((get) => {
    const rows = get(FinalRows);
    const topIndex = get(TopIndex);
    const bottomIndex = get(BottomIndex);
    const visibleRowMapper = get(VisibleRowMapper);
    return rows.slice(topIndex, bottomIndex).map((row, index) => visibleRowMapper(row, topIndex + index));
});

export const VisibleColumns = atom((get) => {
    const leftIndex = get(LeftIndex);
    const rightIndex = get(RightIndex);
    const scrollColumns = get(ScrollColumns);
    const dragColumn = get(DragColumn);
    const slice = scrollColumns.slice(leftIndex, rightIndex);
    if (dragColumn) {
        const columnIndex = scrollColumns.indexOf(dragColumn);
        if (columnIndex >= 0 && (columnIndex < leftIndex || columnIndex >= rightIndex)) {
            slice.push(dragColumn);
        }
    }
    return slice;
});
