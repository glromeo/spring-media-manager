import { MouseEvent } from "react";
import { DataItem } from "../atx-grid";
import { GroupBy, RowData, RowHeight } from "./props";
import { atom } from "jotai";

export type AtxGridRowDef<T extends DataItem = DataItem> = {
    data: T;
    bucket?: Bucket<T>;
    index: number;
    top: number;
    height: number;
};

export type AtxGridRow<T extends DataItem = DataItem> = AtxGridRowDef<T> & {
    id: string | number;
    className: string | undefined;
};

export type Bucket<T extends DataItem = DataItem> = Map<string, Bucket<T>> & {
    totals: T;
    field: keyof T;
    collapsed?: boolean;
    depth: number;
    items?: T[];
    data: T[];
    toggle: ({ shiftKey }: MouseEvent<HTMLDivElement>) => void;
};

function* iterateRecursively<T extends DataItem = DataItem>(root: Bucket<T>): Generator<Bucket<T>> {
    for (const bucket of root.values()) {
        yield* iterateRecursively(bucket);
        yield bucket;
    }
}

export const ComputedRowHeight = atom((get) => {
    const {rowHeight = 28} = get(RowHeight);
    return typeof rowHeight === "function" ? rowHeight : () => rowHeight;
});

const Snapshot = atom<Bucket | undefined>(undefined);

export const GridRows = atom<AtxGridRowDef[], [Bucket | undefined], void>(
    (get, { setSelf }) => {
        const rowData = get(RowData);
        const groupBy = get(GroupBy);

        const rowHeight = get(ComputedRowHeight);
        let rows: AtxGridRowDef[];
        let top = 0;

        /**
         * NOTE: Both these functions assume to be called in order!!!
         */

        const mapItemToRow = (data: DataItem, index: number): AtxGridRowDef => {
            let height = rowHeight(data, index) + 1; // We do like html table and cater for the border size here...kind of...
            let row = {
                index,
                top,
                data,
                height
            };
            top += height;
            return row;
        };

        if (groupBy && groupBy.size && rowData.length) {
            const snapshot = get(Snapshot);
            const buckets: Bucket = new Map() as Bucket;

            const createBucket = (
                totals: DataItem,
                field: string | number | symbol,
                collapsed: boolean | undefined
            ) => {
                const bucket = new Map() as Bucket;
                return Object.assign(bucket, {
                    totals: totals,
                    field: field,
                    collapsed,
                    depth: 0,
                    data: [],
                    toggle(event: MouseEvent<HTMLDivElement>) {
                        event.preventDefault();
                        event.stopPropagation();
                        collapsed = !collapsed;
                        if (event.shiftKey) {
                            for (const child of iterateRecursively(bucket)) {
                                child.collapsed = collapsed;
                            }
                        }
                        setSelf(new Map(buckets) as Bucket);
                    }
                });
            };

            for (const item of rowData) {
                let current = snapshot;
                let bucket = buckets;
                for (const field of groupBy) {
                    const key = String(item[field]);
                    let b = bucket.get(key);
                    let s = current?.get(key);
                    if (!b) {
                        b = createBucket(
                            Object.create(item, { id: { value: `${field as any}-${key}` } }),
                            field,
                            s && s.collapsed
                        );
                        bucket.set(key, b);
                    }
                    bucket = b;
                    current = s;
                }
                const items = bucket.items;
                if (items) {
                    items.push(item);
                } else {
                    bucket.items = [item];
                }
            }

            const mapBucketToRow = (bucket: Bucket, index: number): AtxGridRowDef => {
                let height = rowHeight(rowData, index) + 1; // We do like html table and cater for the border size here...kind of...
                let row = {
                    index,
                    top,
                    data: bucket.totals,
                    bucket,
                    height
                };
                top += height;
                return row;
            };

            function flatten(buckets: IterableIterator<Bucket>, collapsed: boolean | undefined, depth: number) {
                let data = [] as DataItem[];
                for (const bucket of buckets) {
                    bucket.depth = depth;
                    if (!collapsed) {
                        rows.push(mapBucketToRow(bucket, rows.length));
                    }
                    if (bucket.items) {
                        if (!(collapsed || bucket.collapsed)) {
                            for (const item of bucket.items) {
                                rows.push(mapItemToRow(item, rows.length));
                            }
                        }
                        bucket.data = bucket.items;
                        data = [...data, ...bucket.data];
                    } else {
                        bucket.data = flatten(bucket.values(), collapsed || bucket.collapsed, depth + 1);
                        data = [...data, ...bucket.data];
                    }
                }
                return data;
            }

            rows = [];
            flatten(buckets.values(), false, 0);
        } else {
            rows = rowData.map(mapItemToRow);
        }

        console.log(rows)

        return rows;
    },
    (get, set, snapshot) => {
        set(Snapshot, snapshot);
    }
);

export const ScrollHeight = atom((get) => {
    const rows = get(GridRows);
    // Math.max(clientHeight - headerHeight, useTotalHeight(rows, rowHeight));
    const lastRowIndex = rows.length - 1;
    if (lastRowIndex >= 0) {
        let lastRow = rows[lastRowIndex];
        return lastRow.top + lastRow.height;
    } else {
        return 0;
    }
});
