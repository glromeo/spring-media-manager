import { ReactNode } from "react";
import { atom } from "jotai";
import { AtxCellDataType, AtxCellFieldType } from "../atx-grid-cell";
import { Tooltip } from "./props";
import { GridPointer } from "./hover";

const GridTooltipInfo = atom<{
    visible: boolean;
    style: {
        left: number;
        top: number;
    };
    content: ReactNode | null;
} | null>(null);

export const GridTooltip = atom(
    (get) => get(GridTooltipInfo),
    (get, set, targetCell: HTMLDivElement | null) => {
        const tooltip = get(Tooltip);
        if (tooltip) {
            if (targetCell) {
                const { mouseX, mouseY } = get(GridPointer);
                set(GridTooltipInfo, {
                    style: {
                        left: mouseX + 8,
                        top: mouseY + 12
                    },
                    visible: false,
                    content: tooltip({
                        hasClass(token: string): boolean {
                            return targetCell.classList.contains(token);
                        },
                        hasRowClass(token: string): boolean {
                            return targetCell.parentElement!.classList.contains(token);
                        },
                        get type() {
                            return targetCell.getAttribute("data-type") as AtxCellDataType;
                        },
                        get field() {
                            return targetCell.getAttribute("data-field") as string;
                        },
                        get group() {
                            return targetCell.getAttribute("data-group") as AtxCellFieldType;
                        },
                        get rowIndex(): number {
                            return Number(targetCell.parentElement!.getAttribute("row-index"));
                        },
                        get columnIndex(): number {
                            return Number(targetCell.getAttribute("column-index"));
                        },
                        get innerText() {
                            return targetCell.querySelector<HTMLDivElement>(".atx-grid-cell-content")!.innerText;
                        }
                    })
                });
                requestAnimationFrame(() => {
                    set(GridTooltipInfo, { ...get(GridTooltipInfo)!, visible: true });
                });
            } else {
                const info = get(GridTooltipInfo);
                if (info) {
                    set(GridTooltipInfo, { ...info, visible: false });
                    set(GridTooltipInfo, null);
                }
            }
        }
    }
);
