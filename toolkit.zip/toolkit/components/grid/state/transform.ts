import {AtxGridColumn, DataItem} from "../atx-grid";
import {atom} from "jotai";
import {AtxGridRowDef, GridRows} from "./rows";
import {ColumnsMap} from "./columns";

export type GridSort<T extends DataItem = DataItem> = [keyof T, "asc" | "desc"][];

export type GridSortReducer<T extends DataItem = DataItem> = (
    sort: GridSort<T>,
    column: AtxGridColumn<T>,
    shiftKey: boolean
) => GridSort<T>;

export const defaultSort: GridSortReducer = (sort, { field }, shiftKey): GridSort => {
    if (!sort) {
        return [[field, "asc"]];
    } else {
        const index = sort.findIndex((s) => field === s[0]);
        if (index >= 0) {
            if (sort[index][1] === "asc" && !shiftKey) {
                return sort.map((entry) => {
                    if (entry[0] === field) {
                        return [field, "desc"] as [string | number, "desc"];
                    } else {
                        return entry;
                    }
                });
            } else {
                return sort.filter(((_: any, i: number) => index !== i) as any);
            }
        } else {
            if (shiftKey) {
                return [...sort.slice(0, 2), [field, "asc"]];
            } else {
                return [[field, "asc"]];
            }
        }
    }
};

export const Filters = atom<Record<string, string | null> | null>(null);

export const RowFilter = atom(get => {
    const filters = get(Filters);
    if (!filters) {
        return
    }

    const columnsMap = get(ColumnsMap);
    const filterMap = {} as Record<string, (data: any) => boolean>
    const keys = Object.keys(filters).filter(k => filters[k]);

    keys.forEach(key => {
        const formatter = columnsMap[key].formatter;
        const regExp = new RegExp(filters[key]!, "i")
        filterMap[key] = (data: any) => {
            const string = formatter(data, key);
            return regExp.test(string);
        }
    })

    return (({data}: AtxGridRowDef) => {
        return keys.every(key => filterMap[key](data))
    });
});

export const Sort = atom<[GridSort, GridSortReducer]>([[], defaultSort]);

export const ColumnSort = atom(
    (get) => {
        const [sort] = get(Sort);
        return new Map<string | number, ["asc" | "desc", number]>(
            sort
                ? sort.length === 1
                    ? [[sort[0][0], [sort[0][1], 0]]]
                    : sort.map(([field, dir], index) => [field, [dir, index + 1]])
                : []
        );
    },
    (get, set, column: AtxGridColumn, shiftKey: boolean) => {
        const [sort, reducer] = get(Sort);
        set(Sort, [reducer(sort, column, shiftKey), reducer]);
    }
);

export const FinalRows = atom((get) => {
    const [sort] = get(Sort);
    const columnsMap = get(ColumnsMap);
    const filter = get(RowFilter);
    const gridRows = get(GridRows);
    if (sort) {
        const filteredRows = filter ? gridRows.filter(filter) : [...gridRows];
        const sortedRows = filteredRows.sort((a, b) => {
            for (const [field, dir] of sort) {
                const formatter = columnsMap[field].formatter;
                const left = formatter(a.data, field);
                const right = formatter(b.data, field);
                if (left !== right) {
                    if (dir === "asc") {
                        return left < right ? -1 : 1;
                    } else {
                        return left < right ? 1 : -1;
                    }
                }
            }
            return 0;
        });
        let top = 0;
        for (const rowDef of sortedRows) {
            rowDef.top = top;
            top += rowDef.height;
        }
        return sortedRows;
    } else {
        return filter ? gridRows.filter(filter) : gridRows;
    }
});
