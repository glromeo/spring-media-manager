import { useLayoutEffect } from "react";
import { atom } from "jotai";
import { Inverse, OnScroll } from "./props";
import { useGridStore } from "./hooks";

export const ViewPort = atom({
    scrollLeft: 0,
    scrollTop: 0,
    clientWidth: 0,
    clientHeight: 0
});

export const ScrollLeft = atom((get) => get(ViewPort).scrollLeft);
export const ScrollTop = atom((get) => get(ViewPort).scrollTop);
export const ClientWidth = atom((get) => get(ViewPort).clientWidth);
export const ClientHeight = atom((get) => get(ViewPort).clientHeight);

export function useViewport(grid: HTMLDivElement | null) {
    const { get, set } = useGridStore();
    useLayoutEffect(() => {
        if (!grid) return;

        let pending: number;

        function deferToNextFrame(deferred: FrameRequestCallback) {
            return () => {
                cancelAnimationFrame(pending);
                pending = requestAnimationFrame(deferred);
            };
        }

        if (get(Inverse)) {
            grid.scrollLeft = Number.MAX_SAFE_INTEGER;
        }

        const refreshViewPort = () =>
            set(ViewPort, {
                scrollLeft: grid.scrollLeft,
                scrollTop: grid.scrollTop,
                clientWidth: grid.clientWidth,
                clientHeight: grid.clientHeight
            });

        refreshViewPort();

        let clientWidth = grid.clientWidth;

        const mutationObserver = deferToNextFrame(() => {
            if (get(Inverse) && clientWidth !== grid.clientWidth) {
                grid.scrollLeft += clientWidth - grid.clientWidth;
                clientWidth = grid.clientWidth;
            }
            refreshViewPort();
        });

        const scrollListener = deferToNextFrame(() => {
            refreshViewPort();
            get(OnScroll)?.(grid);
        });

        const observer = new ResizeObserver(mutationObserver);
        observer.observe(grid);
        grid.addEventListener("scroll", scrollListener);

        return () => {
            grid.removeEventListener("scroll", scrollListener);
            observer.disconnect();
        };
    }, [grid]);
}
