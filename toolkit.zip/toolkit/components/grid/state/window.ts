import { ScrollColumnLayout, ScrollWidth } from "./columns";
import { Inverse } from "./props";
import { atom } from "jotai";
import { FinalRows } from "./transform";
import { ClientHeight, ClientWidth, ScrollLeft, ScrollTop } from "./viewport";

const WindowX =
    location.search.indexOf("NO_VRT") >= 0
        ? atom((get) => {
              const columns = get(ScrollColumnLayout);
              return {
                  leftIndex: 0,
                  rightIndex: columns.length
              };
          })
        : atom((get) => {
              const scrollLeft = get(ScrollLeft);
              const clientWidth = get(ClientWidth);
              const min = get(Inverse) ? get(ScrollWidth) - clientWidth - scrollLeft : scrollLeft;
              const max = min + clientWidth;
              const columns = get(ScrollColumnLayout);
              let leftIndex = 0;
              while (leftIndex < columns.length) {
                  let { left, width } = columns[leftIndex];
                  if (left + width < min) {
                      leftIndex++;
                  } else {
                      break;
                  }
              }
              let rightIndex = leftIndex;
              while (rightIndex < columns.length) {
                  const { left } = columns[rightIndex++];
                  if (left > max) {
                      break;
                  }
              }
              return {
                  leftIndex,
                  rightIndex
              };
          });

export const LeftIndex = atom((get) => get(WindowX).leftIndex);
export const RightIndex = atom((get) => get(WindowX).rightIndex);

const WindowY =
    location.search.indexOf("NO_VRT") >= 0
        ? atom((get) => {
              const rows = get(FinalRows);
              return {
                  topIndex: 0,
                  bottomIndex: rows.length
              };
          })
        : atom((get) => {
              const rows = get(FinalRows);
              const scrollTop = get(ScrollTop);
              const clientHeight = get(ClientHeight);
              let topIndex = 0;
              while (topIndex < rows.length) {
                  let { top, height } = rows[topIndex];
                  if (top + height < scrollTop) {
                      topIndex++;
                  } else {
                      break;
                  }
              }
              const max = scrollTop + clientHeight;
              let bottomIndex = topIndex;
              while (bottomIndex < rows.length) {
                  const { top } = rows[bottomIndex++];
                  if (top > max) {
                      break;
                  }
              }
              return {
                  topIndex,
                  bottomIndex
              };
          });

export const TopIndex = atom((get) => get(WindowY).topIndex);
export const BottomIndex = atom((get) => get(WindowY).bottomIndex);
