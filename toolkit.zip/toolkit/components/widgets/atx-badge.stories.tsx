import { useParameter } from "@atx/stories";
import { useIconParameter, useLabelParameter, useTypeParameter } from "@atx/toolkit/stories/parameters";
import { AtxBadge } from "@atx/toolkit/components/widgets/atx-badge";

export default () => {
    const [type] = useTypeParameter();
    const [size] = useParameter<"regular" | "large">("size", ["regular", "large"]);
    const [outline] = useParameter("outline", "boolean", false);
    const [label] = useLabelParameter("badge");
    const [icon] = useIconParameter();
    return <AtxBadge size={size} type={type} outline={outline} icon={icon} label={label} />;
};
