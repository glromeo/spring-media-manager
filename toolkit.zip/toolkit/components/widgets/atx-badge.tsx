import { ReactNode } from "react";
import { classNames } from "@atx/toolkit/utils";
import { Type } from "./index";
import { AtxIcon, AtxIconName } from "../atx-icon";

import "./atx-badge.scss";

export type AtxBadgeProps = {
    type?: Type;
    size?: "regular" | "large";
    outline?: boolean;
    icon?: AtxIconName | null;
    label?: string;
    children?: ReactNode;
};

export function AtxBadge(props: AtxBadgeProps) {
    const { type, size, outline, icon, label, children } = props;
    return (
        <div className={classNames("atx-badge", type, size, outline && "outline")}>
            {icon && <AtxIcon name={icon} />}
            {label}
            {children}
        </div>
    );
}
