import { AtxButton, AtxButtonGroup } from "@atx/toolkit/components/widgets/atx-button";
import { AtxIcon } from "@atx/toolkit/components/atx-icon";
import {
    useIconParameter,
    useLabelParameter,
    useTitleParameter,
    useTypeParameter
} from "@atx/toolkit/stories/parameters";

export default () => {
    const [label] = useLabelParameter("Button");
    const [title] = useTitleParameter("This the button tooltip");
    const [type] = useTypeParameter();
    return <AtxButton title={title} type={type} label={label} />;
};

export const types = () => (
    <div className="flex-row row-spaced">
        <AtxButton type="primary">Primary</AtxButton>
        <AtxButton type="secondary">Secondary</AtxButton>
        <AtxButton type="tertiary">Tertiary</AtxButton>
    </div>
);

export const button_group = () => {
    const [type] = useTypeParameter();
    return (
        <AtxButtonGroup>
            <AtxButton type={type} label="left" />
            <AtxButton type={type} label="center" />
            <AtxButton type={type} label="right" />
        </AtxButtonGroup>
    );
};

export const rich_label = () => {
    const [type] = useTypeParameter();
    const [icon] = useIconParameter("help");
    return (
        <div className="flex-row row-spaced">
            <AtxButton style={{ marginRight: 10 }} type={type} title={() => <h1>Group Tooltip</h1>}>
                {icon && <AtxIcon name={icon} />}
                Look mom, I have an icon!
            </AtxButton>
            <AtxButton type={type} title={() => <h1>Group Tooltip</h1>}>
                Me too!
                {icon && <AtxIcon name={icon} />}
            </AtxButton>
        </div>
    );
};

const PADDING = { padding: "1rem" };

export const various_sizes = () => (
    <div style={{ display: "flex", flexDirection: "column" }}>
        <h1>auto</h1>
        <div style={PADDING}>
            <div style={{ display: "flex", flexDirection: "row" }}>
                <div style={PADDING}>
                    <AtxButton type="primary" label="primary" />
                </div>
                <div style={PADDING}>
                    <AtxButton type="secondary" label="secondary" />
                </div>
                <div style={PADDING}>
                    <AtxButton type="tertiary" label="tertiary" />
                </div>
            </div>
        </div>
        <h1>xs</h1>
        <div style={PADDING}>
            <div style={{ display: "flex", flexDirection: "row" }}>
                <div style={PADDING}>
                    <AtxButton type="primary" label="primary" size="xs" />
                </div>
                <div style={PADDING}>
                    <AtxButton type="secondary" label="secondary" size="xs" />
                </div>
                <div style={PADDING}>
                    <AtxButton type="tertiary" label="tertiary" size="xs" />
                </div>
            </div>
        </div>
        <h1>small</h1>
        <div style={PADDING}>
            <div style={{ display: "flex", flexDirection: "row" }}>
                <div style={PADDING}>
                    <AtxButton type="primary" label="primary" size="small" />
                </div>
                <div style={PADDING}>
                    <AtxButton type="secondary" label="secondary" size="small" />
                </div>
                <div style={PADDING}>
                    <AtxButton type="tertiary" label="tertiary" size="small" />
                </div>
            </div>
        </div>
        <h1>regular</h1>
        <div style={PADDING}>
            <div style={{ display: "flex", flexDirection: "row" }}>
                <div style={PADDING}>
                    <AtxButton type="primary" label="primary" size="regular" />
                </div>
                <div style={PADDING}>
                    <AtxButton type="secondary" label="secondary" size="regular" />
                </div>
                <div style={PADDING}>
                    <AtxButton type="tertiary" label="tertiary" size="regular" />
                </div>
            </div>
        </div>
        <h1>large</h1>
        <div style={PADDING}>
            <div style={{ display: "flex", flexDirection: "row" }}>
                <div style={PADDING}>
                    <AtxButton type="primary" label="primary" size="large" />
                </div>
                <div style={PADDING}>
                    <AtxButton type="secondary" label="secondary" size="large" />
                </div>
                <div style={PADDING}>
                    <AtxButton type="tertiary" label="tertiary" size="large" />
                </div>
            </div>
        </div>
        <h1>xl</h1>
        <div style={PADDING}>
            <div style={{ display: "flex", flexDirection: "row" }}>
                <div style={PADDING}>
                    <AtxButton type="primary" label="primary" size="xl" />
                </div>
                <div style={PADDING}>
                    <AtxButton type="secondary" label="secondary" size="xl" />
                </div>
                <div style={PADDING}>
                    <AtxButton type="tertiary" label="tertiary" size="xl" />
                </div>
            </div>
        </div>
    </div>
);
