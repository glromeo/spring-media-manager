import React, { ReactElement, useMemo } from "react";
import { AtxTooltip, WidgetProps } from "./index";
import { AtxWidget } from "./atx-widget";
import { classNames } from "@atx/toolkit/utils";

import "./atx-button.scss";

export type AtxButtonProps = WidgetProps<HTMLButtonElement>;

export function AtxButton(props: AtxButtonProps) {
    const {
        testId,
        className,
        style,
        label,
        type = "primary",
        size = "regular",
        disabled,
        children,
        title,
        onClick
    } = props;

    const contents = useMemo(() => {
        if (children) {
            const contents =
                React.Children.count(children) === 1
                    ? children
                    : React.Children.map(children, (child) => {
                          return typeof child === "string" ? <span>{child}</span> : child;
                      });
            if (label) {
                return (
                    <>
                        {contents}
                        <span>{label}</span>
                    </>
                );
            }
            return contents;
        }
        return label;
    }, [label, children]);

    return (
        <AtxTooltip title={title}>
            <button
                data-test-id={testId}
                className={classNames("atx-button", className, size, type, disabled && "disabled")}
                onClick={disabled ? undefined : onClick}
                {...{ label, disabled, style }}
            >
                {contents}
            </button>
        </AtxTooltip>
    );
}

export type AtxButtonGroupProps = WidgetProps<HTMLDivElement> & {
    children: ReactElement<AtxButtonProps>[] | ReactElement<AtxButtonProps>;
};

export function AtxButtonGroup(props: AtxButtonGroupProps) {
    return (
        <AtxWidget {...props} className={classNames("atx-button-group", props.size, props.disabled && "disabled")}>
            {props.children}
        </AtxWidget>
    );
}
