import React, { useState } from "react";
import { AtxCheckbox, AtxCheckboxGroup, AtxCheckboxGroupProps } from "@atx/toolkit/components";
import { useParameter } from "@atx/stories";

export const checkbox = () => {
    const [state, setState] = useState<boolean | null>(false);
    return <AtxCheckbox checked={state} onChange={setState} />;
};

export const checkbox_with_label = () => {
    const [state, setState] = useState<boolean | null>(false);
    return <AtxCheckbox label="label" checked={state} onChange={setState} />;
};

export const disabled_checkbox_with_label = () => {
    const [state, setState] = useState<boolean | null>(false);
    return <AtxCheckbox label="label" checked={state} onChange={setState} disabled={true} title={"Hey you!"} />;
};

export const checkbox_with_tooltip = () => {
    const [state, setState] = useState<boolean | null>(false);
    return <AtxCheckbox checked={state} onChange={setState} title={<h1>{state ? "Checked" : "Not Checked"}</h1>} />;
};

export const checkbox_with_both = () => {
    const [state, setState] = useState<boolean | null>(false);
    return (
        <AtxCheckbox checked={state} onChange={setState} title={() => <h1>{state ? "Checked" : "Not Checked"}</h1>}>
            Checkbox
        </AtxCheckbox>
    );
};

export const group = () => {
    const [disabled] = useParameter("disabled", "boolean", false);
    const [layout] = useParameter<AtxCheckboxGroupProps<any>["layout"]>("layout", ["stacked", "inline"], "stacked");
    return (
        <AtxCheckboxGroup
            checked={{
                "One": false,
                "Two": false,
                "Three": false
            }}
            layout={layout}
            disabled={disabled}
            onChange={console.log}
        />
    );
};
