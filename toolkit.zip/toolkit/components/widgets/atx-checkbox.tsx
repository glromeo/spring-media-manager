import { useLayoutEffect, useRef } from "react";
import { AtxTooltip, Layout, WidgetProps } from "./index";
import { classNames } from "@atx/toolkit/utils";

import "./atx-checkbox.scss";

export type AtxCheckboxProps = WidgetProps<HTMLLabelElement> & {
    checked?: boolean | null;
    onChange: (checked: boolean | null) => void;
};

export function AtxCheckbox(props: AtxCheckboxProps) {
    const {
        testId,
        className,
        style,
        label,
        type = "primary",
        size = "regular",
        disabled,
        children,
        title,
        onClick,
        checked,
        onChange
    } = props;

    const checkboxRef = useRef<HTMLInputElement>(null);

    useLayoutEffect(() => {
        const current = checkboxRef?.current;
        if (current) {
            if (checked === true) {
                current.checked = true;
                current.indeterminate = false;
            } else if (checked === false) {
                current.checked = false;
                current.indeterminate = false;
            } else {
                current.checked = false;
                current.indeterminate = true;
            }
        }
    }, [checked]);

    return (
        <AtxTooltip title={title}>
            <label
                data-test-id={testId}
                className={classNames("atx-checkbox", className, size, type, disabled && "disabled")}
                style={style}
                onClick={disabled ? undefined : onClick}
            >
                {
                    <input
                        type="checkbox"
                        ref={checkboxRef}
                        disabled={disabled}
                        onChange={disabled ? undefined : (e) => onChange(!checked)}
                    />
                }
                <span>{label}</span>
                {children}
            </label>
        </AtxTooltip>
    );
}

export type AtxCheckboxGroupProps<C extends Record<string, boolean>> = Omit<
    WidgetProps<HTMLDivElement>,
    "label" | "children"
> & {
    layout?: Layout;
    checked: C;
    onChange: (checked: C) => void;
};

export function AtxCheckboxGroup<C extends Record<string, boolean>>(props: AtxCheckboxGroupProps<C>) {
    const {
        testId,
        className,
        layout = "inline",
        style,
        type = "primary",
        disabled,
        title,
        onClick,
        checked,
        onChange
    } = props;
    return (
        <AtxTooltip title={title}>
            <div
                data-test-id={testId}
                className={classNames("atx-checkbox-group", className, layout, type, disabled && "disabled")}
                style={style}
                onClick={onClick}
            >
                {Object.keys(checked).map((label) => (
                    <AtxCheckbox
                        key={label}
                        label={label}
                        checked={checked[label]}
                        disabled={disabled}
                        onChange={(value) => onChange({ ...checked, [label]: value })}
                    />
                ))}
            </div>
        </AtxTooltip>
    );
}
