import { AuxDatePicker } from "@blk/aladdin-react-components-es";
import { AtxDatePicker } from "@atx/toolkit/components/widgets/atx-date-picker";

export default function () {
    return (
        <div className="flex-row">
            <div>
                <label>ATX</label>
                <span>
                    <AtxDatePicker />
                </span>
            </div>
            <div className="flex-fill" />
            <div>
                <label>AUX</label>
                <span>
                    <AuxDatePicker />
                </span>
            </div>
        </div>
    );
}
