import data from "./atx-dropdown.data.json";
import { useMemo, useState } from "react";
import { AtxDropdown } from "@atx/toolkit";
import { useParameter } from "@atx/stories/src";

export default function () {
    const [value, setValue] = useParameter("value", "number", 3 as number | null);

    useState<number | null>(3);

    const options = useMemo(
        () =>
            data.map((item) => {
                if (item) {
                    const { id, first_name, last_name } = item;
                    return {
                        value: id,
                        label: first_name,
                        tooltip: `${first_name} ${last_name}`
                    };
                } else {
                    return null;
                }
            }),
        [data]
    );

    return (
        <div>
            <div style={{ width: "33%" }}>
                <AtxDropdown options={options} value={value} onChange={setValue} />
            </div>
        </div>
    );
}
