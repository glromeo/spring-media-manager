import React, { CSSProperties, ReactNode, useCallback, useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import { AtxIcon } from "../atx-icon";
import { WidgetProps } from "./index";
import { classNames, hasSearchParam } from "../../utils";

import "./atx-dropdown.scss";

export type AtxDropdownOption<T> = {
    label: string | ReactNode;
    value: T;
};

export type AtxDropdownProps<T> = WidgetProps<HTMLButtonElement> & {
    value?: T | null;
    required?: boolean;
    placeholder?: string;
    options?: (AtxDropdownOption<T> | T | null)[];
    isOpen?: boolean;
    onSelect?: (option: AtxDropdownOption<T>, index: number) => void;
    onChange?: (value: T | null) => void;
};

export function AtxDropdown<T>(props: AtxDropdownProps<T>) {
    const { testId, value = null, placeholder = "Select", children, disabled, onClick, onSelect, onChange } = props;

    const options = useMemo<(AtxDropdownOption<T> | null)[]>(() => {
        return (
            props.options?.map((opt) => {
                switch (typeof opt) {
                    case "undefined":
                        return null;
                    case "object":
                        return opt as AtxDropdownOption<T> | null;
                    default:
                        return { value: opt as T, label: opt } as AtxDropdownOption<T>;
                }
            }) ?? []
        );
    }, [props.options]);

    const [isOpen = props.isOpen, setOpen] = useState<boolean>();

    const [trigger, setTrigger] = useState<HTMLElement | null>(null);

    const label = value !== null ? options.find((opt) => opt?.value === value)?.label ?? "" : children ?? placeholder;

    return (
        <button
            data-test-id={testId}
            data-label={label}
            data-value={String(value)}
            ref={setTrigger}
            className={classNames("atx-dropdown", props.className, props.size, props.required && !value && "error")}
            data-opened={isOpen || undefined}
            disabled={disabled || undefined}
            onClick={
                disabled
                    ? undefined
                    : (e) => {
                          onClick?.(e);
                          setOpen(!isOpen);
                      }
            }
            onKeyDown={useCallback(() => {
                if (!disabled && !isOpen) {
                    setOpen(true);
                }
            }, [])}
        >
            {typeof label === "string" ? <div className="dropdown-label">{label}</div> : label}

            <AtxIcon className="dropdown-toggle" name="data-select-caret-down" />
            {isOpen &&
                trigger &&
                createPortal(
                    <AtxDropdownMenu
                        className={props.className}
                        value={value}
                        trigger={trigger}
                        options={options}
                        onSelect={onSelect}
                        onChange={onChange}
                        onClose={() => {
                            setOpen(false);
                            trigger?.focus();
                        }}
                    />,
                    trigger.closest("dialog") ?? document.body
                )}
        </button>
    );
}

type AtxDropdownMenuProps<T> = {
    className?: string;
    value?: T | null;
    trigger: HTMLElement;
    options: (AtxDropdownOption<T> | null)[];
    onSelect?: (option: AtxDropdownOption<T>, index: number) => void;
    onChange?: (value: T | null) => void;
    onOpen?: (menuEl: HTMLDivElement) => void;
    onClose?: () => void;
};

function eachAnimationFrame(callback: () => void) {
    let af: number = 0;
    const listener = () => {
        callback();
        af = requestAnimationFrame(listener);
    };
    af = requestAnimationFrame(listener);
    return () => {
        cancelAnimationFrame(af);
    };
}

export type DropdownMenuProps = {
    trigger: HTMLElement;
    onOpen?: (menuEl: HTMLDivElement) => void;
    onClose?: () => void;
};

export function useDropdownMenu({ trigger, onOpen, onClose }: DropdownMenuProps) {
    const [menuEl, setMenuEl] = useState<HTMLDivElement | null>(null);

    let [menuStyle, setMenuStyle] = useState<CSSProperties>(() => {
        const { left, top, width, height } = trigger.getBoundingClientRect();
        return { left, top: top + height, width };
    });

    useEffect(() => {
        if (menuEl) {
            requestAnimationFrame(() => onOpen?.(menuEl));

            function onWindowBlur() {
                if (hasSearchParam("embedded")) onClose?.();
            }

            function onDocumentMouseDown({ target }: Event) {
                if (menuEl && target && !trigger.contains(target as Node) && !menuEl.contains(target as Node)) {
                    onClose?.();
                }
            }

            function checkTargetBoundingClientRect() {
                let { left, top, width, height } = trigger.getBoundingClientRect();
                top += height;
                if (menuStyle.left !== left || menuStyle.top !== top || menuStyle.width !== width) {
                    setMenuStyle((menuStyle = { left, top, width }));
                }
            }

            window.addEventListener("blur", onWindowBlur);
            document.addEventListener("mousedown", onDocumentMouseDown);
            const cancelEachAnimationFrame = eachAnimationFrame(checkTargetBoundingClientRect);
            return () => {
                window.removeEventListener("blur", onWindowBlur);
                document.removeEventListener("mousedown", onDocumentMouseDown);
                cancelEachAnimationFrame();
            };
        }
    }, [trigger, menuEl]);

    return {
        menuEl,
        setMenuEl,
        menuStyle
    };
}

export function AtxDropdownMenu<T>({
    className,
    value,
    trigger,
    options,
    onSelect,
    onChange,
    onClose
}: AtxDropdownMenuProps<T>) {
    const { menuStyle, menuEl, setMenuEl } = useDropdownMenu({
        trigger,
        onOpen(menuEl) {
            menuEl.focus();
        },
        onClose
    });

    let [focusIndex, setFocusIndex] = useState(() => options?.findIndex((option) => option?.value === value) ?? -1);

    const onKeyDown = useCallback(
        (event: React.KeyboardEvent<HTMLDivElement>) => {
            event.preventDefault();
            event.stopPropagation();

            if (menuEl) {
                switch (event.code) {
                    case "ArrowDown":
                        focusIndex = Math.min(options.length - 1, focusIndex + 1);
                        break;
                    case "ArrowUp":
                        focusIndex = Math.max(0, focusIndex - 1);
                        break;
                    case "Tab":
                        const start = Math.max(focusIndex, 0);
                        const slice = options.slice(start);
                        const nextSepIndex = slice.findIndex((o, i) => o === null && i > focusIndex);
                        if (nextSepIndex >= 0) {
                            focusIndex = start + nextSepIndex + slice.slice(nextSepIndex).findIndex((o) => o !== null);
                        } else {
                            focusIndex = start + slice.findIndex((o) => o !== null);
                        }
                        break;
                    case "Enter":
                        const option = options[focusIndex];
                        if (option) {
                            onSelect?.(option, focusIndex);
                            onChange?.(option.value);
                        }
                    case "Escape":
                        onClose?.();
                    default:
                        return;
                }

                if (focusIndex >= 0) {
                    menuEl.querySelector(`:nth-child(${focusIndex})`)?.scrollIntoView({ block: "center" });
                }
                setFocusIndex(focusIndex);
            }
        },
        [options, menuEl]
    );

    return (
        <div
            ref={setMenuEl}
            className={classNames("atx-dropdown-portal", className)}
            style={menuStyle}
            onKeyDown={onKeyDown}
        >
            {options.map((option, index) => {
                if (!option) {
                    return <div key={index} className="dropdown-separator" />;
                } else {
                    return (
                        <div
                            key={index}
                            className="dropdown-option"
                            data-selected={option.value === value || undefined}
                            data-focused={index === focusIndex || undefined}
                            data-label={option.label}
                            data-value={option.value}
                            onClick={() => {
                                onSelect?.(option, index);
                                onChange?.(option.value);
                                onClose?.();
                            }}
                        >
                            {option.label}
                        </div>
                    );
                }
            })}
        </div>
    );
}
