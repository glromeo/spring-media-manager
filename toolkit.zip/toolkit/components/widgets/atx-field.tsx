import { FieldProps, WidgetProps } from "@atx/toolkit/components";
import { AtxWidget } from "./atx-widget";

export function AtxField<V>(props: WidgetProps<HTMLDivElement> & Pick<FieldProps<V>, "value" | "format">) {
    const { value = null, format = String } = props;
    return <AtxWidget {...props}>{format!(value)}</AtxWidget>;
}
