import React, { CSSProperties, ReactNode, useCallback, useEffect, useRef, useState } from "react";
import { AtxTextField, AtxTextFieldProps, useDropdownMenu } from "./index";
import { createPortal } from "react-dom";
import { classNames } from "../../utils";

import "./atx-lookup.scss";

export type AtxLookupColumn<T extends object> = {
    label?: string;
    width: CSSProperties["width"];
    field: keyof T;
    render?: (value: T[any]) => string;
};

export type AtxLookupProps<T extends object> = Omit<AtxTextFieldProps<string>, "value"> & {
    text: string;
    value: T | null;
    disabled?: boolean;
    message?: ReactNode;
    options: T[];
    rowHeight?: number;
    header?: "sticky" | true | null | undefined;
    columns: AtxLookupColumn<T>[];
    onSelect?: (option: T, index: number) => void;
    onSearch?: (text: string) => void;
};

export function AtxLookup<T extends object>(props: AtxLookupProps<T>) {
    const {
        testId,
        className,
        value,
        text,
        message,
        disabled,
        options = [],
        rowHeight,
        header,
        columns,
        onSelect,
        onSearch
    } = props;
    const [trigger, setTrigger] = useState<HTMLElement | null>(null);
    const [focused, setFocused] = useState<boolean>(false);
    const [selected, setSelected] = useState<T | null>(null);
    useEffect(() => {
        setSelected(value);
    }, [value]);
    const shouldOpen = !disabled && focused && (options.length > 0 || message);
    const debounce = useRef<any>(0);
    const onChange = (search: string | null) => {
        if (!search) {
            onSearch?.("");
        } else {
            if (!text.startsWith(search)) {
                clearTimeout(debounce.current);
                debounce.current = setTimeout(() => onSearch?.(search), 250);
            }
        }
    };
    return (
        <AtxTextField
            testId={testId}
            className={classNames("atx-lookup", className)}
            disabled={disabled}
            type="search"
            value={text}
            placeholder={props.placeholder}
            textAlign={props.textAlign}
            validate={props.validate}
            onReady={setTrigger}
            onInput={onChange}
            onChange={onChange}
            onFocus={(evt) => {
                evt.currentTarget.select();
                setFocused(true);
            }}
            onBlur={() => {
                setTimeout(() => setFocused(false), 250);
            }}
        >
            {trigger &&
                shouldOpen &&
                createPortal(
                    <AtxLookupMenu
                        testId={`${testId}-portal`}
                        selected={selected}
                        message={message}
                        search={text}
                        trigger={trigger}
                        options={options}
                        rowHeight={rowHeight}
                        header={header}
                        columns={columns}
                        onSelect={(option, index) => {
                            setSelected(option);
                            onSelect?.(option, index);
                        }}
                        onClose={() => setFocused(false)}
                    />,
                    trigger.closest("dialog") ?? document.body
                )}
        </AtxTextField>
    );
}

type AtxLookupMenuProps<T extends object> = {
    testId?: string;
    selected?: T | null;
    message?: ReactNode;
    search: string;
    trigger: HTMLElement;
    options: T[];
    columns: AtxLookupColumn<T>[];
    rowHeight?: number;
    header?: "sticky" | true | null | undefined;
    onSelect?: (option: T, index: number) => void;
    onOpen?: (menuEl: HTMLDivElement) => void;
    onClose?: () => void;
};

export function AtxLookupMenu<T extends object>({
    testId,
    selected,
    message,
    search,
    trigger,
    options,
    columns,
    rowHeight = 35,
    header,
    onSelect,
    onClose
}: AtxLookupMenuProps<T>) {
    const { menuStyle, menuEl, setMenuEl } = useDropdownMenu({ trigger, onClose });

    let [focusIndex, setFocusIndex] = useState(() => -1);

    const onKeyDown = useCallback(
        (event: React.KeyboardEvent<HTMLDivElement>) => {
            event.preventDefault();
            event.stopPropagation();

            if (menuEl) {
                switch (event.code) {
                    case "ArrowDown":
                        focusIndex = Math.min(options.length - 1, focusIndex + 1);
                        break;
                    case "ArrowUp":
                        focusIndex = Math.max(0, focusIndex - 1);
                        break;
                    case "Tab":
                        const start = Math.max(focusIndex, 0);
                        const slice = options.slice(start);
                        const nextSepIndex = slice.findIndex((o, i) => o === null && i > focusIndex);
                        if (nextSepIndex >= 0) {
                            focusIndex = start + nextSepIndex + slice.slice(nextSepIndex).findIndex((o) => o !== null);
                        } else {
                            focusIndex = start + slice.findIndex((o) => o !== null);
                        }
                        break;
                    case "Enter":
                        const option = options[focusIndex];
                        if (option) {
                            onSelect?.(option, focusIndex);
                        }
                    case "Escape":
                        onClose?.();
                    default:
                        return;
                }

                if (focusIndex >= 0) {
                    menuEl.querySelector(`:nth-child(${focusIndex})`)?.scrollIntoView({ block: "center" });
                }
                setFocusIndex(focusIndex);
            }
        },
        [options, menuEl]
    );

    const [range, setRange] = useState<{ option: T; style: CSSProperties }[]>([]);

    const headerHeight = rowHeight + 4;
    let [menuHeight, setMenuHeight] = useState(() => window.innerHeight / 3);

    useEffect(() => {
        if (menuEl) {
            let af: number = 0;
            let innerHeight = window.innerHeight;
            const updateRange = () => {
                if (innerHeight !== window.innerHeight) {
                    innerHeight = window.innerHeight;
                    setMenuHeight((menuHeight = innerHeight / 3));
                }
                const { scrollTop } = menuEl;
                const minIndex = Math.floor(scrollTop / rowHeight);
                const maxIndex = minIndex + Math.ceil(menuHeight / rowHeight);
                const minTop = minIndex * rowHeight + (header ? headerHeight : 0);
                setRange(
                    options.slice(minIndex, maxIndex).map((option, index) => ({
                        option,
                        style: {
                            top: minTop + index * rowHeight,
                            height: rowHeight
                        }
                    }))
                );
            };
            updateRange();
            const scheduleUpdate = () => {
                cancelAnimationFrame(af);
                af = requestAnimationFrame(updateRange);
            };
            window.addEventListener("resize", scheduleUpdate);
            menuEl.addEventListener("scroll", scheduleUpdate);
            return () => {
                window.removeEventListener("resize", scheduleUpdate);
                menuEl.removeEventListener("scroll", scheduleUpdate);
            };
        }
    }, [rowHeight, header, options, menuEl]);

    return (
        <div
            ref={setMenuEl}
            data-test-id={testId}
            className="atx-lookup-portal"
            style={{
                ...menuStyle,
                width: "fit-content",
                height: message ? "fit-content" : menuHeight
            }}
            onKeyDown={onKeyDown}
        >
            {message ? (
                <div className="atx-lookup-message">{message}</div>
            ) : (
                <div
                    className="atx-lookup-scroll"
                    style={{
                        height: options.length * rowHeight
                    }}
                >
                    {header && (
                        <div
                            className="atx-lookup-header"
                            style={{
                                height: headerHeight,
                                position: header === "sticky" ? "sticky" : "absolute"
                            }}
                        >
                            {columns.map(({ width, label }, index) => (
                                <div key={index} className="atx-lookup-cell" style={{ width }}>
                                    {label}
                                </div>
                            ))}
                        </div>
                    )}
                    {range.map(({ option, style }, index) => {
                        return (
                            <div
                                key={index}
                                className="atx-lookup-option"
                                data-selected={option === selected || undefined}
                                data-focused={index === focusIndex || undefined}
                                style={style}
                                onClick={() => {
                                    onSelect?.(option, index);
                                    onClose?.();
                                }}
                            >
                                {columns.map(({ width, field, render = String }, index) => {
                                    let text = render(option[field]);
                                    return (
                                        <div
                                            key={index}
                                            className="atx-lookup-cell"
                                            style={{ width }}
                                            title={text}
                                            ref={(div) => {
                                                if (div) {
                                                    div.innerHTML = highlightSearch(text, search);
                                                }
                                            }}
                                        />
                                    );
                                })}
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    );
}

function highlightSearch(text: string, search: string) {
    const joint = `<b>${search}</b>`;
    return text.split(search).join(joint);
}
