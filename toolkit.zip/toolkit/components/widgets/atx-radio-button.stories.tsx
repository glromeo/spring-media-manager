import { AtxRadioButton, AtxRadioGroup } from "@atx/toolkit/components/widgets/atx-radio-button";
import { useParameter } from "@atx/stories";
import { Layout } from "@atx/toolkit/components/widgets";

export default () => {
    const [disabled] = useParameter("disabled", "boolean", false);
    const [value, setValue] = useParameter("checked", "boolean", false);
    return <AtxRadioButton checked={value} disabled={disabled} onChange={setValue} label={"Label"} />;
};

export const two_options = () => {
    const [disabled] = useParameter("disabled", "boolean", false);
    const [value, setValue] = useParameter("option", "number", 1);
    return (
        <div className="flex-row">
            <AtxRadioButton
                checked={value === 1}
                disabled={disabled}
                onChange={(checked) => {
                    if (checked) setValue(1);
                }}
                label={"One"}
            />
            <div style={{ width: "0.75rem" }} />
            <AtxRadioButton
                checked={value === 2}
                disabled={disabled}
                onChange={(checked) => {
                    if (checked) setValue(2);
                }}
                label={"Two"}
            />
        </div>
    );
};

export const group = () => {
    const [disabled] = useParameter("disabled", "boolean", false);
    const [layout] = useParameter<Layout>("layout", ["stacked", "inline"], "inline");
    const [value, setValue] = useParameter<string | null>("value", "string");
    return (
        <AtxRadioGroup value={value} options={["One", "Two"]} layout={layout} disabled={disabled} onChange={setValue} />
    );
};
