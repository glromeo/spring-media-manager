import { AtxTooltip, Layout, WidgetProps } from "./index";
import { classNames } from "@atx/toolkit/utils";
import { useEffect, useState } from "react";

import "./atx-radio-button.scss";

export type AtxRadioButtonProps = WidgetProps<HTMLLabelElement> & {
    checked?: boolean;
    onChange?: (checked: boolean) => void;
};

export function AtxRadioButton(props: AtxRadioButtonProps) {
    const { testId, className, style, label, children, disabled, size, title, type, onClick, checked, onChange } =
        props;
    return (
        <AtxTooltip title={title}>
            <label
                data-test-id={testId}
                className={classNames("atx-radio-button", className, type, size, disabled && "disabled")}
                style={style}
                onClick={disabled ? undefined : onClick}
            >
                <input
                    type="radio"
                    role="radio"
                    disabled={disabled}
                    value={label ?? "on"}
                    checked={checked}
                    onChange={() => {
                        onChange?.(!checked);
                    }}
                />
                <div className="atx-radio-button-switch" />
                {label && <span className="atx-radio-button-label">{label}</span>}
                {children}
            </label>
        </AtxTooltip>
    );
}

export type AtxRadioGroupProps<T extends string | null> = Omit<WidgetProps<HTMLFormElement>, "label" | "children"> & {
    layout?: Layout;
    value?: T | null;
    options: T[];
    onChange?: (value: T | null) => void;
};

export function AtxRadioGroup<T extends string>(props: AtxRadioGroupProps<T>) {
    const {
        testId,
        className,
        layout = "inline",
        style,
        disabled,
        size,
        title,
        type,
        onClick,
        value,
        options,
        onChange
    } = props;
    const [checked, setChecked] = useState(value);
    useEffect(() => {
        if (value !== checked) setChecked(value);
    }, [value]);
    return (
        <AtxTooltip title={title}>
            <form
                data-test-id={testId}
                data-checked={checked}
                className={classNames("atx-radio-group", className, layout, type, size, disabled && "disabled")}
                style={style}
                onClick={onClick}
            >
                {options.map((option) => (
                    <label key={option} className={classNames("atx-radio-button", type, size, disabled && "disabled")}>
                        <input
                            type="radio"
                            role="radio"
                            value={option}
                            checked={option === value}
                            disabled={disabled}
                            onChange={({ currentTarget }) => {
                                const checked = currentTarget.value as T;
                                setChecked(checked);
                                onChange?.(checked);
                            }}
                        />
                        <div className="atx-radio-button-switch" />
                        {option && <span className="atx-radio-button-label">{option}</span>}
                    </label>
                ))}
            </form>
        </AtxTooltip>
    );
}
