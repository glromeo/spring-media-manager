import { AuxTextInput } from "@blk/aladdin-react-components-es";
import { AtxTextField } from "@atx/toolkit/components/widgets/atx-text-field";

export default () => <AtxTextField onChange={console.log} />;

export const reference = () => <AuxTextInput />;
