import React, { FormEvent, useEffect, useMemo, useState } from "react";
import { classNames } from "@atx/toolkit/utils";
import { AtxTooltip, FieldProps } from "./index";

import "./atx-text-field.scss";
import { AtxIcon } from "../atx-icon";

export type AtxTextFieldProps<T> = FieldProps<T, HTMLDivElement> &
    Pick<
        React.DetailedHTMLProps<React.InputHTMLAttributes<HTMLInputElement>, HTMLInputElement>,
        "onClick" | "onBlur" | "onFocus" | "onKeyDown" | "onKeyUp" | "onMouseDown" | "onMouseUp"
    > & {
        placeholder?: string;
        textAlign?: "left" | "center" | "right";
        validate?: (value: T | null) => string | undefined;
        onInput?: (text: string, event: FormEvent<HTMLInputElement>) => void;
        onReady?: (el: HTMLDivElement | null) => void;
    };

function defaultFormat<T>(value: T | null): string | undefined {
    return value ? String(value) : undefined;
}

function defaultParse<T>(text: string): T | null {
    return text as T;
}

export function AtxTextField<T>(props: AtxTextFieldProps<T>) {
    const {
        testId,
        defaultValue = null,
        disabled,
        format = defaultFormat,
        parse = defaultParse,
        placeholder = "",
        style,
        textAlign,
        title,
        type,
        validate,
        value = null,
        onClick,
        onReady,
        onInput,
        onChange,
        children
    } = props;

    const [text, setText] = useState<string>("");
    useEffect(() => {
        setText(format(value) ?? "");
    }, [value, format]);

    const undo =
        (defaultValue !== null && value !== defaultValue) || (type === "search" && text && text !== placeholder);
    const icon = undo ? "clear" : type === "search" ? "search" : null;

    const error = useMemo(() => validate?.(value), [value, validate]);

    return (
        <AtxTooltip title={error || title}>
            <div
                className="atx-text-field"
                style={style}
                ref={onReady}
                data-test-id={testId}
                data-value={String(value)}
                onClick={onClick}
            >
                <input
                    className={classNames(props.className, props.size, error && "error", icon && "has-icon")}
                    type="text"
                    style={{ textAlign }}
                    placeholder={placeholder}
                    value={text}
                    disabled={disabled}
                    onInput={onInput ? (event) => onInput(event.currentTarget.value, event) : undefined}
                    onChange={(event) => {
                        const text = event.target.value;
                        setText(text);
                    }}
                    onFocus={props.onFocus}
                    onKeyDown={props.onKeyDown}
                    onKeyUp={props.onKeyUp}
                    onMouseDown={props.onMouseDown}
                    onMouseUp={props.onMouseUp}
                    onBlur={(event) => {
                        props.onBlur?.(event);
                        let parsed: T | null = value;
                        let error: string | undefined;
                        try {
                            parsed = parse(event.target.value) ?? null;
                            error = validate ? validate(parsed) : undefined;
                            if (!error) {
                                if (typeof parsed === "string") {
                                    setText(parsed);
                                } else {
                                    setText(format(parsed) ?? "");
                                }
                            }
                        } catch (e: any) {
                            error = e.message ?? String(e);
                        }
                        onChange?.(parsed, error);
                    }}
                />
                {icon && (
                    <AtxIcon
                        className={classNames(props.size, error && "error")}
                        testId="clear"
                        name={icon}
                        disabled={disabled}
                        onClick={
                            icon === "clear"
                                ? () => {
                                      if (type === "search") {
                                          setText("");
                                          onChange?.(defaultValue);
                                      } else {
                                          setText(format(defaultValue ?? null) ?? "");
                                          onChange?.(defaultValue ?? null);
                                      }
                                  }
                                : undefined
                        }
                    />
                )}
                {children}
            </div>
        </AtxTooltip>
    );
}
