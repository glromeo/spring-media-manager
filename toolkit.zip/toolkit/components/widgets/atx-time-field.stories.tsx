import { useState } from "react";
import { AtxTimeField } from "@atx/toolkit/components/widgets/atx-time-field";
import { useParameter } from "@atx/stories/src";

export function STATEFUL() {
    const [time, setTime] = useParameter<Date | null>("time", "date", () => new Date());
    const [error, setError] = useState<string | null>();
    return (
        <div className="field-column" style={{ padding: 25, border: "2px solid rgba(0,0,0,0.25)" }}>
            <AtxTimeField
                value={time}
                onChange={(value, error) => {
                    setTime(value ?? null);
                    setError(error);
                }}
            />
            <div className="error-field">{error}</div>
        </div>
    );
}

export default () => <AtxTimeField onChange={console.log} />;

export const INITIALIZED = () => <AtxTimeField value={new Date()} onChange={console.log} />;

export const WITH_TIMEZONE = () => <AtxTimeField timeZone="America/New_York" onChange={console.log} />;

export const INITIALIZED_WITH_TIMEZONE = () => (
    <AtxTimeField value={new Date()} timeZone="America/New_York" onChange={console.log} />
);
