import { AtxTextField, AtxTextFieldProps } from "./atx-text-field";
import { AtxDropdown } from "./index";
import { useMemo, useState } from "react";

import "./atx-time-field.scss";
import { DateTime } from "luxon";

export type AtxTimeFieldProps = Omit<AtxTextFieldProps<Date>, "onChange"> & {
    timeZone?: string | null;
    disableTZ?: boolean;
    onChange: (value: Date | null, timeZone?: string | null) => void;
};

const DEFAULT_TIMEZONE = "America/New_York";

const TZ_OPTIONS = [
    "America/New_York",
    "Europe/London",
    "Europe/Rome",
    "Asia/Tokyo",
    "Asia/Hong_Kong",
    "Australia/Melbourne"
].map((timeZone) => ({
    value: timeZone,
    label: Intl.DateTimeFormat("ia", { timeZone, timeZoneName: "long" }).formatToParts()[6].value.replace(/[a-z ]/g, "")
}));

export function useAtxTimeFieldUtils(
    timeZone: string | null = DEFAULT_TIMEZONE
): [(date?: Date | null) => string, (text?: string | null) => Date | null] {
    return useMemo(() => {
        const zone = timeZone ?? undefined;
        return [
            (date?: Date | null) => {
                if (date) {
                    console.debug("formatting:", date);
                    return DateTime.fromJSDate(date).setZone(zone).toFormat("h:mm  a");
                } else {
                    return "HH:MM  AM";
                }
            },
            (text?: string | null) => {
                if (text) {
                    try {
                        const date = DateTime.fromFormat(text, "h:mm  a", { zone }).toJSDate();
                        console.debug("parsed:", date.toUTCString());
                        return isNaN(date as any) ? null : date;
                    } catch (e) {
                        throw new Error("Time must be a valid HH:MM AM/PM time");
                    }
                } else {
                    return null;
                }
            }
        ];
    }, [timeZone]);
}

export function AtxTimeField(props: AtxTimeFieldProps) {
    const {
        className,
        style,
        testId,
        size,
        value,
        validate,
        timeZone: defaultTimeZone = null,
        disabled,
        disableTZ,
        onChange
    } = props;
    const [timeZone, setTimeZone] = useState<string | null>(defaultTimeZone);
    const [format, parse] = useAtxTimeFieldUtils(timeZone);

    return (
        <div className={`atx-time-field ${className}`} style={style} data-test-id={testId}>
            <AtxTextField
                textAlign="center"
                size={size}
                disabled={disabled}
                format={format}
                parse={parse}
                validate={(value) => {
                    if (value === null) {
                        return "Time must be a valid HH:MM AM/PM time";
                    }
                    return validate?.(value);
                }}
                onFocus={(evt) => {
                    evt.currentTarget.select();
                }}
                onInput={(text, { currentTarget }) => {
                    let start = currentTarget.selectionStart ?? 0;

                    if (start === 3 && text[2] !== ":") {
                        text = text.slice(0, 2) + ":" + text.slice(2);
                        ++start;
                    }
                    if (start === 6 && text[5] !== " ") {
                        text = text.slice(0, 5) + " " + text.slice(5);
                        start++;
                    }
                    if (start === 7 && text[6] !== " ") {
                        text = text.slice(0, 6) + " " + text.slice(6).toUpperCase();
                        start++;
                    }

                    const rules = [
                        /^[0-1]/,
                        /^(0[0-9]|1[0-2])/,
                        /^..:/,
                        /^..:[0-5]/,
                        /^..:.[0-9]/,
                        /^..:.. /,
                        /^..:..  /,
                        /^..:..  [AP]/,
                        /^..:..  .M/
                    ];

                    let end = 0,
                        limit = Math.min(rules.length, start);
                    while (end < limit) {
                        if (rules[end].test(text)) {
                            end++;
                            continue;
                        }
                        break;
                    }

                    currentTarget.value = fixNoon(text.slice(0, end) + "HH:MM  AM".slice(end));
                    currentTarget.selectionStart = end;
                    currentTarget.selectionEnd = end;
                }}
                value={value}
                onChange={onChange}
            />
            {defaultTimeZone !== undefined && (
                <AtxDropdown
                    className="tz-dropdown"
                    size={size}
                    options={TZ_OPTIONS}
                    value={timeZone}
                    disabled={disableTZ}
                    onChange={(timeZone) => {
                        setTimeZone(timeZone);
                        onChange?.(value ?? null, timeZone);
                    }}
                />
            )}
        </div>
    );
}

/**
 * Later versions of Chrome are more lenient in parsing the time... eg they map 12:30 AM to 12:30 PM
 * @param text
 */
function fixNoon(text: string) {
    if (text.startsWith("12") && text.endsWith("AM")) {
        text = text.slice(0, -2) + "PM";
    }
    return text;
}
