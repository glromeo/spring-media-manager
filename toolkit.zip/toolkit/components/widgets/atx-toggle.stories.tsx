import { AtxToggle } from "@atx/toolkit/components/widgets/atx-toggle";
import { useParameter } from "@atx/stories";

export default () => {
    const [disabled] = useParameter("disabled", "boolean", false);
    const [value, setValue] = useParameter("checked", "boolean", false);
    return (
        <div style={{ margin: 25 }}>
            <AtxToggle value={value} disabled={disabled} onChange={setValue} label={"Label"} />
        </div>
    );
};
