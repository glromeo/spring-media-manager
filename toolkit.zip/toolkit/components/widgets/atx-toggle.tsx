import { AtxTooltip, WidgetProps } from "./index";
import { classNames } from "@atx/toolkit/utils";
import { AtxIcon, AtxIconName } from "../atx-icon";
import React, { ReactNode, useEffect, useState } from "react";

import "./atx-toggle.scss";

export type AtxToggleProps = WidgetProps<HTMLLabelElement> & {
    icon?: AtxIconName | null;
    value?: boolean;
    onChange?: (value: boolean) => void;
};

export function AtxToggle(props: AtxToggleProps) {
    const {
        testId,
        className,
        style,
        icon,
        label,
        children,
        disabled,
        size,
        title,
        type = "primary",
        onClick,
        value = false,
        onChange
    } = props;
    const [checked, setChecked] = useState(value);
    useEffect(() => {
        if (checked !== checked) setChecked(checked);
    }, [checked]);
    return (
        <AtxTooltip title={title}>
            <label
                data-test-id={testId}
                className={classNames("atx-toggle", className, size, type, disabled && "disabled")}
                style={style}
                onClick={disabled ? undefined : onClick}
            >
                {icon && <AtxIcon className="icon" disabled={disabled} name={icon} />}
                {label && <span className="atx-toggle-label">{label}</span>}
                <input
                    type="checkbox"
                    role="switch"
                    checked={checked}
                    disabled={disabled}
                    onChange={({ currentTarget }) => {
                        const checked = currentTarget.checked;
                        setChecked(checked);
                        onChange?.(checked);
                    }}
                />
                <div className="atx-toggle-slider">
                    <AtxIcon className="checkmark" name={checked ? "checkmark" : null} />
                </div>
                {children}
            </label>
        </AtxTooltip>
    );
}
