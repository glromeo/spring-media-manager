import React from "react";

import { AtxTooltip } from "@atx/toolkit";

export const auto_top = () => {
    return (
        <div
            style={{
                height: "calc(100% - 2rem)",
                display: "flex",
                alignItems: "flex-end",
                justifyContent: "center"
            }}
        >
            <AtxTooltip trigger="hover" placement="top" title={<div>This is popover content</div>}>
                <a href="">This is a popover trigger</a>
            </AtxTooltip>
        </div>
    );
};

export const auto_bottom = () => {
    return (
        <div
            style={{
                height: "calc(100% - 2rem)",
                display: "flex",
                alignItems: "flex-start",
                justifyContent: "center"
            }}
        >
            <AtxTooltip trigger="hover" placement="bottom" title={<div>This is popover content</div>}>
                <a href="">This is a popover trigger</a>
            </AtxTooltip>
        </div>
    );
};

export const auto_right = () => {
    return (
        <div
            style={{
                height: "calc(100% - 2rem)",
                display: "flex",
                alignItems: "center"
            }}
        >
            <AtxTooltip trigger="hover" placement="right" title={<div>This is popover content</div>}>
                <a href="">This is a popover trigger</a>
            </AtxTooltip>
        </div>
    );
};

export const auto_left = () => {
    return (
        <div
            style={{
                height: "calc(100% - 2rem)",
                display: "flex",
                alignItems: "center",
                justifyContent: "flex-end"
            }}
        >
            <AtxTooltip trigger="hover" placement="left" title={<div>This is popover content</div>}>
                <a href="">This is a popover trigger</a>
            </AtxTooltip>
        </div>
    );
};

export const top = () => {
    return (
        <div
            style={{
                height: "calc(100% - 2rem)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center"
            }}
        >
            <AtxTooltip trigger="hover" placement="right" title={<div>This is popover content</div>}>
                <a href="">This is a popover trigger</a>
            </AtxTooltip>
        </div>
    );
};

export const bottom = () => {
    return (
        <div
            style={{
                height: "calc(100% - 2rem)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center"
            }}
        >
            <AtxTooltip trigger="hover" placement="bottom" title={<div>This is popover content</div>}>
                <a href="">This is a popover trigger</a>
            </AtxTooltip>
        </div>
    );
};

export const left = () => {
    return (
        <div
            style={{
                height: "calc(100% - 2rem)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center"
            }}
        >
            <AtxTooltip trigger="hover" placement="left" title={<div>This is popover content</div>}>
                <a href="">This is a popover trigger</a>
            </AtxTooltip>
        </div>
    );
};

export const right = () => {
    return (
        <div
            style={{
                height: "calc(100% - 2rem)",
                display: "flex",
                alignItems: "center",
                justifyContent: "center"
            }}
        >
            <AtxTooltip trigger="hover" placement="right" title={<div>This is popover content</div>}>
                <a href="">This is a popover trigger</a>
            </AtxTooltip>
        </div>
    );
};
