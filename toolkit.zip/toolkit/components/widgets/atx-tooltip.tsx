import React, { cloneElement, ReactElement, ReactNode, useCallback } from "react";

import { Size, Title, Type } from "./index";
import { classNames, LazyNode } from "@atx/toolkit/utils";
import { AtxFloatingProps, useAtxFloating } from "../atx-floating-portal";

import "./atx-tooltip.scss";

export type TooltipOptions = Omit<AtxFloatingProps, "Widget"> & {
    title: LazyNode;
    size?: Size;
    type?: Type;
};

export function AtxTooltipWrapper(props: AtxTooltipProps) {
    const { title, children, type, size } = props;

    const { getReferenceProps } = useAtxFloating({
        ...props,
        Widget: useCallback(
            ({ refs, floatingStyles, context, getFloatingProps }) => {
                const { x = 0, y = 0 } = context.middlewareData.shift ?? {};
                const style: any = { "--shift-x": `${-x}px`, "--shift-y": `${-y}px` };
                return (
                    <div
                        ref={refs.setFloating}
                        className={classNames("atx-tooltip", type, size)}
                        style={floatingStyles}
                        {...getFloatingProps()}
                    >
                        <div className="atx-tooltip-content">
                            {typeof title === "function" ? title() : (title as ReactNode)}
                        </div>
                        <div className={`atx-tooltip-arrow ${context.placement}`} style={style} />
                    </div>
                );
            },
            [title, type, size]
        )
    });

    return cloneElement(children, getReferenceProps(children.props, (children as any).ref));
}

export type AtxTooltipProps = Omit<TooltipOptions, "title"> & {
    title?: Title;
    children: ReactElement;
};

export function AtxTooltip({ title, children }: AtxTooltipProps) {
    if (title) {
        if ((title as TooltipOptions).title) {
            let options = {} as TooltipOptions;
            options = title as TooltipOptions;
            title = options.title;
            return (
                <AtxTooltipWrapper {...options} title={title}>
                    {children}
                </AtxTooltipWrapper>
            );
        } else {
            return <AtxTooltipWrapper title={title}>{children}</AtxTooltipWrapper>;
        }
    } else {
        return children;
    }
}
