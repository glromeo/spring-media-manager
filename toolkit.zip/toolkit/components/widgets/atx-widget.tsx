import { AtxTooltip, WidgetProps } from "./index";
import { classNames } from "@atx/toolkit/utils";

/**
 * This is just a template!!!
 *
 * @param testId
 * @param className
 * @param style
 * @param size
 * @param disabled
 * @param label
 * @param title
 * @param onClick
 * @param children
 * @constructor
 */

export function AtxWidget({
    testId,
    className,
    style,
    size,
    disabled,
    label,
    title,
    onClick,
    children
}: WidgetProps<HTMLDivElement>) {
    return (
        <AtxTooltip title={title}>
            <div
                data-test-id={testId}
                className={classNames("atx-widget", className, size, disabled && "disabled")}
                onClick={onClick}
                {...{ style }}
            >
                {label && <label>{label}</label>}
                {children}
            </div>
        </AtxTooltip>
    );
}
