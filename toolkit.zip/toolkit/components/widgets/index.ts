import { CSSProperties, MouseEventHandler, ReactNode } from "react";
import { TooltipOptions } from "./atx-tooltip";

export * from "./atx-badge";
export * from "./atx-button";
export * from "./atx-checkbox";
export * from "./atx-dropdown";
export * from "./atx-field";
export * from "./atx-lookup";
export * from "./atx-radio-button";
export * from "./atx-text-field";
export * from "./atx-time-field";
export * from "./atx-toggle";
export * from "./atx-tooltip";

export type Size = "xs" | "small" | "regular" | "large" | "xl";

export type Level = "danger" | "warning" | "info" | "success";
export type Type = "primary" | "secondary" | "tertiary" | Level;

export type Title = ReactNode | (() => ReactNode) | TooltipOptions;

export type Layout = "stacked" | "inline";

export type WidgetProps<E = Element, S = Size, T = Type> = {
    testId?: string;
    className?: string;
    style?: CSSProperties;
    label?: string | null;
    children?: ReactNode;
    disabled?: boolean;
    size?: S;
    title?: Title;
    type?: T;
    onClick?: MouseEventHandler<E> | undefined;
};

export type FieldType = "search";

export type FieldProps<V, E = Element, S = Size, T = FieldType> = WidgetProps<E, S, T> & {
    placeholder?: string;
    value?: V | null;
    defaultValue?: V | null;
    format?: (value: V | null) => string | null;
    parse?: (text: string | null) => V | null;
    onChange?: (value: V | null, error?: string | null) => void;
};
