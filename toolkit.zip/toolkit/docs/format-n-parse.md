# Formatting and Parsing
![Format & Parse Diagram](./format-n-parse.svg)

## External Representation
This is the world of number precisions and placeholders for missing data
It's also the world where time goes from being a number to being days and hours
minutes etc

## Internal Model
This is a world of `undefined`, `null`, Js types and NaN (don't you love it?)
This is where Js is sweet and nasty at the same time and one has to 
be extremely weary of the most common assumptions about logic `+0 === -0` ? `NaN === NaN` ? 
double, triple... and I didn't even start on Ts!!!

### `undefined` vs `null`
After coding Js for a while one can begin to see patterns and one I tend to leverage on
is that `undefined` means optionality while `null` is more suited for a well defined absence
of data.
That comes from the fact that if you do a property access and the property is not even defined
you get indeed...`undefined`.
That's why I tend to avoid using undefined for things like pricingType and use `null` instead

## Backend
When writing step definitions that mock the backend in any way don't forget to
remember that the data is supposed to be in a format that's what would be
expected to be parsed as if it is coming from the backend, and this involves
making sure that dates and timestamps take into accound a different offset
but also that numbers and strings are either a value or null
This is why we should talk about conversion rather than parsing of backend data
since parsing should be limited to a string that's either null/empty or containing
some textual representation of data while the responses are implicitly parsed
by JSON and we deal with an intermediate format in which some stuff which
numbers, booleans objects or strings that need further parsing (e.g. ISO dates)

### DON'T


### DO ...BUT DON'T TRY TOO HARD
* Sanitize backend data 

### DO IT, SERIOUSLY
* Take into account Time Zones and Offsets

## User

## App

