import { Atom, useStore } from "jotai";
import { useEffect } from "react";

export function useLogAtom(name: string, atom: Atom<any>) {
    const { sub, get } = useStore();
    useEffect(() => {
        return sub(atom, () => console.log("name", get(atom)));
    }, []);
}
