import { useEffect, useRef } from "react";

export function useChangeEffect<T>(value: T, callback: (current: T, previous: T) => void): void {
    const ref = useRef(value);
    useEffect(() => {
        if (ref.current !== value) {
            callback(value, ref.current);
        }
        ref.current = value;
    }, [value]);
}
