import { useEffect, useState } from "react";

export function useClickOutside(callback: () => void) {
    const [container, setContainer] = useState<HTMLDivElement | null>(null);
    useEffect(() => {
        if (container) {
            const listener = ({ target }: any) => {
                if (target === window || !container.contains(target as Node | null)) callback();
            };
            document.addEventListener("click", listener);
            window.addEventListener("blur", listener);
            return () => {
                document.removeEventListener("click", listener);
                window.removeEventListener("blur", listener);
            };
        }
    }, [container]);
    return setContainer;
}
