import { AtwGrid } from "@atw/toolkit/components/grid";
import { css } from "@atx/stories";

let csv = require("./simple.csv");
let i = 0;
let data = csv.slice(1).map((row: string[]) => ({
    "id": row[(i = 0)],
    "first_name": row[++i],
    "last_name": row[++i],
    "email": row[++i],
    "gender": row[++i],
    "ip_address": row[++i],
    "trade_id": row[++i],
    "stock_symbol": row[++i],
    "trade_date": row[++i],
    "trade_time": row[++i],
    "trade_price": row[++i],
    "trade_quantity": row[++i],
    "buyer_id": row[++i],
    "seller_id": row[++i],
    "trade_type": row[++i],
    "commission_fee": row[++i]
}));

// language=css
css`
    .fixture {
        height: 100%;
    }
`;

export default (i = 0) => (
    <AtwGrid
        data={data}
        rowHeight={28}
        columnDefs={[
            { type: "string", field: "id", label: "Id" },
            { type: "string", field: "first_name", label: "First Name" },
            { type: "string", field: "last_name", label: "Last Name" },
            { type: "string", field: "email", label: "Email" },
            { type: "string", field: "gender", label: "Gender" },
            { type: "string", field: "ip_address", label: "Ip Address" },
            { type: "string", field: "trade_id", label: "Trade Id" },
            { type: "string", field: "stock_symbol", label: "Stock Symbol" },
            { type: "string", field: "trade_date", label: "Trade Date" },
            { type: "string", field: "trade_time", label: "Trade Time" },
            { type: "string", field: "trade_price", label: "Trade Price" },
            { type: "string", field: "trade_quantity", label: "Trade Quantity" },
            { type: "string", field: "buyer_id", label: "Buyer Id" },
            { type: "string", field: "seller_id", label: "Seller Id" },
            { type: "string", field: "trade_type", label: "Trade Type" },
            { type: "string", field: "commission_fee", label: "Commission Fee" }
        ]}
    />
);

export const features = (i = 0) => (
    <AtwGrid
        data={data}
        rowHeight={28}
        inverse={true}
        columnDefs={[
            { type: "string", pinned: true, resizable: true, sortable: true, field: "id", label: "Id" },
            { type: "string", pinned: true, resizable: true, sortable: true, field: "first_name", label: "First Name" },
            { type: "string", pinned: true, resizable: true, sortable: true, field: "last_name", label: "Last Name" },
            { type: "string", resizable: true, sortable: true, field: "email", label: "Email" },
            { type: "string", resizable: true, sortable: true, field: "gender", label: "Gender" },
            { type: "string", resizable: true, sortable: true, field: "ip_address", label: "Ip Address" },
            { type: "string", resizable: true, sortable: true, field: "trade_id", label: "Trade Id" },
            { type: "string", resizable: true, sortable: true, field: "stock_symbol", label: "Stock Symbol" },
            { type: "string", resizable: true, sortable: true, field: "trade_date", label: "Trade Date" },
            { type: "string", resizable: true, sortable: true, field: "trade_time", label: "Trade Time" },
            { type: "string", resizable: true, sortable: true, field: "trade_price", label: "Trade Price" },
            { type: "string", resizable: true, sortable: true, field: "trade_quantity", label: "Trade Quantity" },
            { type: "string", resizable: true, sortable: true, field: "buyer_id", label: "Buyer Id" },
            { type: "string", resizable: true, sortable: true, field: "seller_id", label: "Seller Id" },
            { type: "string", resizable: true, sortable: true, field: "trade_type", label: "Trade Type" },
            { type: "string", resizable: true, sortable: true, field: "commission_fee", label: "Commission Fee" }
        ]}
    />
);
