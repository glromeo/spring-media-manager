import { css, useParameter } from "@atx/stories";
import { AtxGrid } from "@atx/toolkit/components/grid";
import { ReactElement, useState } from "react";
import { AtxIcon } from "../../components";

let data = require("./simple.csv").slice(1);

let innerData = data;

// language=css
css`
    .fixture {
        height: 100%;
        width: 100%;
        overflow: hidden;
    }
`;

export default () => {
    const [resizable] = useParameter("resizable", "boolean", true);
    const [stripes] = useParameter("stripes", "boolean", true);
    const [inverse] = useParameter("inverse", "boolean", false);

    return (
        <AtxGrid
            rowData={data}
            selection="rows"
            sort="auto"
            stripes={stripes}
            inverse={inverse}
            columnDefs={[
                { type: "text", resizable: resizable, sortable: true, pinned: true, label: "Id" },
                { type: "text", resizable: resizable, sortable: true, pinned: true, label: "First Name" },
                { type: "text", resizable: resizable, sortable: true, pinned: true, label: "Last Name" },
                { type: "text", resizable: resizable, sortable: true, label: "Email" },
                { type: "text", resizable: resizable, sortable: true, label: "Gender" },
                { type: "text", resizable: resizable, label: "Ip Address" },
                { type: "text", resizable: resizable, label: "Trade Id" },
                { type: "text", resizable: resizable, label: "Stock Symbol" },
                { type: "text", resizable: resizable, label: "Trade Date" },
                { type: "text", resizable: resizable, label: "Trade Time" },
                { type: "text", resizable: resizable, label: "Trade Price" },
                { type: "text", resizable: resizable, label: "Trade Quantity" },
                { type: "text", resizable: resizable, label: "Buyer Id" },
                { type: "text", resizable: resizable, label: "Seller Id" },
                { type: "text", resizable: resizable, label: "Trade Type" },
                { type: "text", resizable: resizable, label: "Commission Fee" }
            ]}
        />
    );
};
