import { css, useParameter } from "@atx/stories";
import { AtxGrid, AtxGridColumnDef } from "@atx/toolkit/components/grid";
import { atom } from "jotai";
import { formatPrice, formatQuantity, formatSpread, formatYield } from "../../utils";
import {AtwColumnDef, AtwGrid, DataItem} from '@atw/toolkit'

type Liquidity = DataItem & {
    id: string;
    assetId: string;
    type: "AXE" | "TRACE" | "Trade";
    subType: string;
    side: "BID" | "ASK" | "D";
    cpty: string;
    bidQty?: number | null;
    askQty?: number | null;
    bidPx?: number | null;
    askPx?: number | null;
    bidSprd?: number | null;
    askSprd?: number | null;
    bidYld?: number | null;
    askYld?: number | null;
    date: Date;
    time: Date;
    tradeSz: number | null;
    tradePx: number | null;
    tradeSprd: number | null;
    traceSz: number | null;
    tracePx: number | null;
    tracePartyType: "C2D" | "D2D" | null;
    traceTranType: "BUY" | "SELL" | "D" | null;
    traceSprd: number | null;
    gSpread?: number | null;
    className?: string;
};

let liquidity:Liquidity[] = require("./liquidity.json").map((l:any) => ({
    ...l,
    date: new Date(l.date),
    time: new Date(l.time),
}) as Liquidity);

// language=css
css`
    .fixture {
        height: 100%;
        width: 100%;
        overflow: hidden;
    }

    .axe .bidPx,
    .axe .bidSprd,
    .axe .bidYld,
    .axe .bidQty {
        color: var(--buy-primary__background-color);
    }

    .axe .askPx,
    .axe .askSprd,
    .axe .askYld,
    .axe .askQty {
        color: var(--sell-primary__background-color);
    }

    .trace.bid .trace .atx-grid-cell-content,
    .trade.bid .trade .atx-grid-cell-content {
        color: var(--buy-primary__background-color);
    }

    .trace.ask .trace .atx-grid-cell-content,
    .trade.ask .trade .atx-grid-cell-content {
        color: var(--sell-primary__background-color);
    }

`;

const base: AtxGridColumnDef<Liquidity> = {
    field: "id",
    type: "string",
    label: "Auto",
    width: 150,
    sortable: true,
    resizable: true,
};

const columnDefs:AtxGridColumnDef<Liquidity>[] = [
    { ...base, width: 92, type: "date", field: "date", label: "Date" },
    { ...base, width: 84, type: "string", field: "cpty", label: "Counterparty", formatter: ({cpty})=>String(cpty??"-") },
    { ...base, width: 70, type: "time", field: "time", label: "Time" },
    { ...base, width: 60, type: "string", field: "subType", label: "Type" },
    { ...base, width: 96, type: "price", field: "bidPx", label: "Bid Px" },
    { ...base, width: 96, type: "price", field: "askPx", label: "Ask Px" },
    { ...base, width: 96, type: "spread", field: "bidSprd", label: "Bid Sprd" },
    { ...base, width: 96, type: "spread", field: "askSprd", label: "Ask Sprd" },
    { ...base, width: 96, type: "yield", field: "bidYld", label: "Bid Yld" },
    { ...base, width: 96, type: "yield", field: "askYld", label: "Ask Yld" },
    { ...base, width: 96, type: "quantity", field: "bidQty", label: "Bid Qty" },
    { ...base, width: 96, type: "quantity", field: "askQty", label: "Ask Qty" },
    { ...base, width: 96, type: "quantity", field: "tradeSz", label: "Trade Sz", className: "trade" },
    { ...base, width: 96, type: "price", field: "tradePx", label: "Trade Px", className: "trade" },
    { ...base, width: 96, type: "spread", field: "tradeSprd", label: "Trade Sprd", className: "trade" },
    { ...base, width: 96, type: "quantity", field: "traceSz", label: "TRACE Sz", className: "trace" },
    { ...base, width: 96, type: "price", field: "tracePx", label: "TRACE Px", className: "trace" },
    { ...base, width: 96, type: "spread", field: "traceSprd", label: "TRACE Sprd", className: "trace" },
    { ...base, width: 96, type: "string", field: "tracePartyType", label: "TRACE Party Type", className: "trace" },
    { ...base, width: 96, type: "string", field: "traceTranType", label: "TRACE Tran Type", className: "trace" },
    { ...base, width: 96, type: "spread", field: "gSpread", label: "G-Spread" },
];

const classNames: Record<string, string> = {
    AXE: "axe",
    BID: "bid",
    ASK: "ask",
    TRACE: "trace",
    Trade: "trade",
};

export default () => {
    const [resizable] = useParameter("resizable", "boolean", true);
    const [stripes] = useParameter("stripes", "boolean", true);
    const [inverse] = useParameter("inverse", "boolean", false);

    return (
        <AtxGrid
            rowData={liquidity}
            rowClassName={({ data, bucket }) => bucket ? undefined : `${classNames[data.type]} ${classNames[data.side]}`}
            groupBy={new Set<keyof Liquidity>(["date", "cpty", "time"])}
            selection="rows"
            sort="auto"
            stripes={stripes}
            inverse={inverse}
            resizable={resizable}
            columnDefs={columnDefs}
        />
    );
};

export const legacy =  () => {
    const [resizable] = useParameter("resizable", "boolean", true);
    const [stripes] = useParameter("stripes", "boolean", true);
    const [inverse] = useParameter("inverse", "boolean", false);

    return (
        <AtwGrid
            data={liquidity}
            rowClassName={({ data, bucket }) => bucket ? undefined : `${classNames[data.type]} ${classNames[data.side]}`}
            groupBy={new Set<keyof Liquidity>(["date", "cpty", "time"])}
            sort="auto"
            stripes={stripes}
            inverse={inverse}
            resizable={resizable}
            columnDefs={columnDefs.map(columnDef=>({...columnDef}) as AtwColumnDef<Liquidity>)}
        />
    );
};


const aggregations = atom(get => Object.fromEntries([
    [
        "bidPx",
        (data: Liquidity[]) => {
            return formatPrice(
                data.reduce((acc, { bidPx }) => (bidPx! < acc ? bidPx! : acc), Number.MAX_VALUE)
            );
        },
    ],
    [
        "askPx",
        (data: Liquidity[]) => {
            return formatPrice(data.reduce((acc, { askPx }) => (askPx! > acc ? askPx! : acc), 0));
        },
    ],
    [
        "bidSprd",
        (data: Liquidity[]) => {
            return formatSpread(
                data.reduce((acc, { bidSprd }) => (bidSprd! < acc ? bidSprd! : acc), Number.MAX_VALUE)
            );
        },
    ],
    [
        "askSprd",
        (data: Liquidity[]) => {
            return formatSpread(data.reduce((acc, { askSprd }) => (askSprd! > acc ? askSprd! : acc), 0));
        },
    ],
    [
        "bidQty",
        (data: Liquidity[]) => {
            return formatQuantity(
                data.reduce((acc, { bidQty }) => (bidQty! > acc ? bidQty! : acc), 0) || null
            );
        },
    ],
    [
        "askQty",
        (data: Liquidity[]) => {
            return formatQuantity(
                data.reduce((acc, { askQty }) => (askQty! > acc ? askQty! : acc), 0) || null
            );
        },
    ],
    [
        "bidYld",
        (data: Liquidity[]) => {
            return formatYield(
                data.reduce((acc, { bidYld }) => (bidYld! < acc ? bidYld! : acc), Number.MAX_VALUE)
            );
        },
    ],
    [
        "askYld",
        (data: Liquidity[]) => {
            return formatYield(data.reduce((acc, { askYld }) => (askYld! > acc ? askYld! : acc), 0));
        },
    ],
    [
        "tradePx",
        (data: Liquidity[], field: keyof Liquidity) => {
            const axes = data.filter(axe => axe.tradePx);
            return formatPrice(axes.reduce((total, axe) => total + axe.tradePx!, 0) / axes.length);
        },
    ],
    [
        "tradeSprd",
        (data: Liquidity[], field: keyof Liquidity) => {
            const axes = data.filter(axe => axe.tradeSprd);
            return formatSpread(axes.reduce((total, axe) => total + axe.tradeSprd!, 0) / axes.length);
        },
    ],
    [
        "tradeSz",
        (data: Liquidity[], field: keyof Liquidity) => {
            const axes = data.filter(axe => axe.tradeSz);
            return formatQuantity(axes.reduce((total, axe) => total + axe.tradeSz!, 0) || null);
        },
    ],
    [
        "tracePx",
        (data: Liquidity[], field: keyof Liquidity) => {
            const axes = data.filter(axe => axe.tracePx);
            return formatPrice(axes.reduce((total, axe) => total + axe.tracePx!, 0) / axes.length);
        },
    ],
    [
        "traceSprd",
        (data: Liquidity[], field: keyof Liquidity) => {
            const axes = data.filter(axe => axe.traceSprd);
            return formatSpread(axes.reduce((total, axe) => total + axe.traceSprd!, 0) / axes.length);
        },
    ],
    [
        "traceSz",
        (data: Liquidity[], field: keyof Liquidity) => {
            const axes = data.filter(axe => axe.traceSz);
            return formatQuantity(axes.reduce((total, axe) => total + axe.traceSz!, 0) || null);
        },
    ],
]))