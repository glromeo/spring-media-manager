import { css, useParameter } from "@atx/stories";
import { AtxGrid } from "@atx/toolkit/components/grid";
import { ReactElement, useState } from "react";
import { AtxIcon } from "../../components";

let data = require("./simple.csv").slice(1);

let innerData = data;

// language=css
css`
    .fixture {
        height: 100%;
        width: 100%;
        overflow: hidden;
    }

    .two {
        height: 100%;
        width: 100%;
        overflow: hidden;
        position: relative;
        align-items: stretch;
    }
`;

const { Column } = AtxGrid;

export default () => (
    <AtxGrid rowData={data}>
        <Column label="Id" />
        <Column label="First Name" />
        <Column label="Last Name" />
        <Column label="Email" />
        <Column label="Gender" />
        <Column label="Ip Address" />
        <Column label="Trade Id" />
        <Column label="Stock Symbol" />
        <Column label="Trade Date" />
        <Column label="Trade Time" />
        <Column label="Trade Price" />
        <Column label="Trade Quantity" />
        <Column label="Buyer Id" />
        <Column label="Seller Id" />
        <Column label="Trade Type" />
        <Column label="Commission Fee" />
    </AtxGrid>
);

export const features = () => {
    const [rows] = useParameter("rows", "number", data.length);
    const [columns] = useParameter("columns", "number", 10); // data[0]?.length ?? 0);
    const slice: any[] = data.slice(0, rows).map((row: any[]) => row);

    const [resizable] = useParameter("resizable", "boolean", true);
    const [stripes] = useParameter("stripes", "boolean", true);
    const [inverse] = useParameter("inverse", "boolean", true);

    return (
        <AtxGrid
            rowData={slice}
            rowId={({data: [_, id]}: any) => id}
            rowClassName={({data}) => {
                if (data[0] === "2" || data[0] === "11") {
                    return "info";
                }
                if (data[0] === "4" || data[0] === "12") {
                    return "warning";
                }
                if (data[0] === "6" || data[0] === "13") {
                    return "danger";
                }
                if (data[0] === "8" || data[0] === "14") {
                    return "success";
                }
            }}
            selection="rows"
            sort="auto"
            stripes={stripes}
            inverse={inverse}
            columnDefs={[
                { type: "text", resizable: resizable, sortable: true, pinned: true, label: "Id" },
                { type: "text", resizable: resizable, sortable: true, pinned: true, label: "First Name" },
                { type: "text", resizable: resizable, sortable: true, pinned: true, label: "Last Name" },
                { type: "text", resizable: resizable, sortable: true, label: "Email" },
                { type: "text", resizable: resizable, sortable: true, label: "Gender" },
                { type: "text", resizable: resizable, label: "Ip Address" },
                { type: "text", resizable: resizable, label: "Trade Id" },
                { type: "text", resizable: resizable, label: "Stock Symbol" },
                { type: "text", resizable: resizable, label: "Trade Date" },
                { type: "text", resizable: resizable, label: "Trade Time" },
                { type: "text", resizable: resizable, label: "Trade Price" },
                { type: "text", resizable: resizable, label: "Trade Quantity" },
                { type: "text", resizable: resizable, label: "Buyer Id" },
                { type: "text", resizable: resizable, label: "Seller Id" },
                { type: "text", resizable: resizable, label: "Trade Type" },
                { type: "text", resizable: resizable, label: "Commission Fee" }
            ].slice(0, columns)}
        />
    );
};

export const two = () => (
    <div className="two flex-row">
        <AtxGrid className="relative flex-fill" rowData={data}>
            <Column resizable={true} label="Id" />
            <Column resizable={true} label="First Name" />
            <Column resizable={true} label="Last Name" />
            <Column resizable={true} label="Email" />
            <Column resizable={true} label="Gender" />
            <Column resizable={true} label="Ip Address" />
            <Column resizable={true} label="Trade Id" />
            <Column resizable={true} label="Stock Symbol" />
            <Column resizable={true} label="Trade Date" />
            <Column resizable={true} label="Trade Time" />
            <Column resizable={true} label="Trade Price" />
            <Column resizable={true} label="Trade Quantity" />
            <Column resizable={true} label="Buyer Id" />
            <Column resizable={true} label="Seller Id" />
            <Column resizable={true} label="Trade Type" />
            <Column resizable={true} label="Commission Fee" />
        </AtxGrid>
        <AtxGrid className="relative flex-fill" rowData={data}>
            <Column resizable={true} label="Id" />
            <Column resizable={true} label="First Name" />
            <Column resizable={true} label="Last Name" />
            <Column resizable={true} label="Email" />
            <Column resizable={true} label="Gender" />
            <Column resizable={true} label="Ip Address" />
            <Column resizable={true} label="Trade Id" />
            <Column resizable={true} label="Stock Symbol" />
            <Column resizable={true} label="Trade Date" />
            <Column resizable={true} label="Trade Time" />
            <Column resizable={true} label="Trade Price" />
            <Column resizable={true} label="Trade Quantity" />
            <Column resizable={true} label="Buyer Id" />
            <Column resizable={true} label="Seller Id" />
            <Column resizable={true} label="Trade Type" />
            <Column resizable={true} label="Commission Fee" />
        </AtxGrid>
    </div>
);

export const nested = () => {
    const [details, setDetails] = useState<Record<number, ReactElement | null>>({});
    return (
        <AtxGrid
            rowData={data}
            rowHeight={(data, index) => {
                let style = details[index]?.props.style;
                if (style) {
                    return style.height + 28;
                } else {
                    return 28;
                }
            }}
            rowDetails={({ data, index }) => {
                return details[index];
            }}
            selection="rows"
            sort="auto"
            tooltip={({ columnIndex, rowIndex }) => {
                return (
                    <div>
                        Tooltip for cell at row: {rowIndex} column: {columnIndex}
                    </div>
                );
            }}
            columnDefs={[
                {
                    type: "text",
                    resizable: true,
                    sortable: true,
                    pinned: true,
                    label: "Id",
                    render: ({ data, index }) => {
                        return (
                            <div className="atx-grid-cell-content flex-row">
                                <AtxIcon
                                    className="caret"
                                    name={details[index] ? "arrow-dropdown-up" : "arrow-dropdown"}
                                    onClick={(evt) => {
                                        evt.preventDefault();
                                        evt.stopPropagation();
                                        setDetails({
                                            ...details,
                                            [index]: details[index] ? null : (
                                                <div
                                                    className="atx-grid-row-details"
                                                    style={{ height: 350, marginTop: 28 }}
                                                >
                                                    <AtxGrid rowData={innerData}>
                                                        <Column label="Id" />
                                                        <Column label="First Name" />
                                                        <Column label="Last Name" />
                                                        <Column label="Email" />
                                                        <Column label="Gender" />
                                                        <Column label="Ip Address" />
                                                        <Column label="Trade Id" />
                                                        <Column label="Stock Symbol" />
                                                        <Column label="Trade Date" />
                                                        <Column label="Trade Time" />
                                                        <Column label="Trade Price" />
                                                        <Column label="Trade Quantity" />
                                                        <Column label="Buyer Id" />
                                                        <Column label="Seller Id" />
                                                        <Column label="Trade Type" />
                                                        <Column label="Commission Fee" />
                                                    </AtxGrid>
                                                </div>
                                            )
                                        });
                                    }}
                                />
                                <div>{data[0]}</div>
                            </div>
                        );
                    }
                },
                { type: "text", resizable: true, sortable: true, pinned: true, label: "First Name" },
                { type: "text", resizable: true, sortable: true, pinned: true, label: "Last Name" },
                { type: "text", resizable: true, sortable: true, label: "Email" },
                { type: "text", resizable: true, sortable: true, label: "Gender" },
                { type: "text", resizable: true, label: "Ip Address" },
                { type: "text", resizable: true, label: "Trade Id" },
                { type: "text", resizable: true, label: "Stock Symbol" },
                { type: "text", resizable: true, label: "Trade Date" },
                { type: "text", resizable: true, label: "Trade Time" },
                { type: "text", resizable: true, label: "Trade Price" },
                { type: "text", resizable: true, label: "Trade Quantity" },
                { type: "text", resizable: true, label: "Buyer Id" },
                { type: "text", resizable: true, label: "Seller Id" },
                { type: "text", resizable: true, label: "Trade Type" },
                { type: "text", resizable: true, label: "Commission Fee" }
            ]}
        />
    );
};
