import { atom, useAtom } from "jotai";
import { useEffect } from "react";

import "./styles.scss";

const primitive = atom(0);

const changing = atom(1);

const derived = atom(
    (get) => get(primitive),
    (get, set, value: number) => {
        let otherValue = get(changing);
        console.log("setting derived", otherValue, value);
        set(primitive, otherValue + value);
    }
);

export const dependents_in_set_dont_cause_update = () => {
    const [derivedValue, setDerivedValue] = useAtom(derived);
    const [changingValue, setChangingValue] = useAtom(changing);

    useEffect(() => {
        const i = setInterval(() => {
            let n = Math.floor(Math.random() * 10);
            setChangingValue(n);
        }, 1000);
        return () => {
            clearInterval(i);
        };
    }, []);

    return <div>look at console.log {derivedValue}</div>;
};
