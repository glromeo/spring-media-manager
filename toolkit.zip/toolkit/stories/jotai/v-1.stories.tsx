import { atom, useAtom } from "jotai";
import { useEffect } from "react";

import "./styles.scss";

type Structure = {
    alpha: string;
    beta: number;
    gamma: Date;
    delta: boolean;
};

const listAtom = atom<Structure[]>([]);

export const V_1 = () => {
    const [list, setList] = useAtom(listAtom);

    useEffect(() => {
        let N = 1000;
        const list: Structure[] = new Array(N);
        for (let i = 0; i < N; i++) {
            list[i] = {
                alpha: "alpha_" + i,
                beta: i,
                gamma: new Date(Date.now() + i),
                delta: i % 2 === 0
            };
        }

        setList(list);

        const i = setInterval(() => {
            let update = [...list];
            update[3] = { ...update[3], gamma: new Date() };
            setList(update);
        }, 1000);

        return () => {
            clearInterval(i);
        };
    }, []);

    return (
        <div className="jotai-table-story">
            <table>
                <thead>
                    <tr>
                        <th>alpha</th>
                        <th>beta</th>
                        <th>gamma</th>
                        <th>delta</th>
                    </tr>
                </thead>
                <tbody>
                    {list.map((item, index) => (
                        <TR key={index} item={item} />
                    ))}
                </tbody>
            </table>
        </div>
    );
};

function TR({ item }: { item: Structure }) {
    return (
        <tr>
            <th>{item.alpha}</th>
            <th>{item.beta?.toLocaleString()}</th>
            <th>{item.gamma?.toLocaleString()}</th>
            <th>{item.delta ? "True" : "False"}</th>
        </tr>
    );
}
