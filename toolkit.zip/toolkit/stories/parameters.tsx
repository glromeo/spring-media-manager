import { useParameter } from "@atx/stories";
import React from "react";
import { AtxDropdownOption, AtxIcon, AtxIconName, Size, Title, Type } from "@atx/toolkit/components";
import atxIcons from "@atx/toolkit/components/atx-icons";

export function useTypeParameter(initial: Type = "primary") {
    return useParameter<Type>(
        "type",
        ["primary", "secondary", "tertiary", "info", "warning", "danger", "success"],
        initial
    );
}

export function useSizeParameter(initial: Size = "regular") {
    return useParameter<Size>("size", ["regular", "small", "large", "xs", "xl"], initial);
}

export function useLabelParameter(initial: string = "Label") {
    return useParameter("label", "string", initial);
}

export function useTitleParameter(initial: Title = "This is a sample tooltip") {
    return useParameter("title", "string", initial);
}

const ICON_PARAMETER_OPTIONS = [
    "" as AtxIconName,
    ...Object.keys(atxIcons).map(
        (name) =>
            ({
                value: name,
                label: (
                    <div className="flex-row flex-fill">
                        <AtxIcon name={name as AtxIconName} style={{ margin: "-0.25rem .5rem -0.25rem -0.25rem" }} />
                        <div className="dropdown-label">{name}</div>
                    </div>
                )
            }) as AtxDropdownOption<AtxIconName>
    )
];

export function useIconParameter(initial: AtxIconName | null = null) {
    return useParameter("icon", ICON_PARAMETER_OPTIONS, initial);
}
