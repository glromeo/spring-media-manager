import { logPerformance } from "@atw/toolkit/telemetry";
import { recording } from "./rec";
import { hasSearchParam, searchParam, searchParams } from "./location";
import { jotaiStore, userAtom } from "../atoms";
import pako from "pako";

const API_KEY =
    process.env.API_KEY ||
    "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIqIiwiYXBwSWQiOiJtYXJrZXRkZXB0aCIsInNlcnZpY2VHcm91cHMiOltdLCJkZXRhaWxzIjoiW10iLCJpZCI6IjdhOTEwMDFjLTg2ZDAtNDNiNi1iMTNkLTk5Y2VkYjc1ZTc3MiIsImV4cCI6MTcwMzk4MDgwMH0.dfp1VrvVoX7opFHXbqaCpIlEtTG6j2EB0nXF94nZ6a0";

function getDelay(time: number) {
    return Date.now() - time;
}

const EMBEDDED_AUTH_HEADERS =
    searchParams.has("embedded") && searchParams.has("user")
        ? { "X-Remote-User": searchParams.get("user")! }
        : ({} as HeadersInit);

export type ApiFetchOptions = RequestInit & {
    fixture?: string;
    timeout?: number;
    ready?: (controller: AbortController, clearTimeout: () => void) => void;
    intercept?: (response: Response) => void;
    trace?: (options: ApiFetchOptions, text: string) => void;
    telemetry?: [string, string];
};

const DEFAULT_FETCH_TIMEOUT = 2 * 60 * 1000;

export function isAbortError(error: any) {
    return error.code === 20 && error.name === "AbortError" && !error.timeout;
}

export function isServerError(error: any) {
    return (
        error.type === "ServerError" ||
        error.type === "FetchError" ||
        error.type === "AbortError" ||
        error.type === "Timeout"
    );
}

const ERROR_NAMES: Record<number, string> = {
    500: "ServerError",
    400: "ClientError"
};

export type FetchError = {
    type: "FetchError" | "ServerError" | "ClientError" | "AbortError" | "Timeout";
    name: string;
    code?: number;
    message: string;
    stack?: string;
    headers?: Headers;
    status?: number;
};

const GZIP_ENABLED = process.env.NODE_ENV === "production" && !hasSearchParam("NO_GZIP");

/**
 * When things go bad apiFetch throws an Error, what are the fields of that error?
 *
 * case: network issues of other things preventing a server response altogether
 * {
 *   message: "Failed to fetch",
 *   code: undefined,
 *   name: undefined
 * }
 *
 * case: controller aborted
 * {
 *   message: "The user aborted a request.",
 *   code: 20,
 *   name: "AbortError"
 * }
 *
 * case: there's a response but it's not OK
 * {
 *   headers: response headers,
 *   status: response status,
 *   message: message field of the response or the response as whole text,
 *   name: response status text
 *   ...any other fields of the reponse body
 * }
 *
 * note that typically the Aladdin studio APIs return a { code: string, message: string } when there's an error
 *
 * @param path
 * @param options
 */
export async function apiFetch<R>(path: string, options: ApiFetchOptions = {}): Promise<R> {
    const time = Date.now();
    const controller = new AbortController();
    let hasTimeout = false;
    const timeout = setTimeout(() => {
        hasTimeout = true;
        controller.abort();
    }, options.timeout ?? DEFAULT_FETCH_TIMEOUT);

    let response: Response;
    try {
        if (typeof options.ready === "function") {
            options.ready(controller, () => clearTimeout(timeout));
        }

        const fetched = fetch(path, {
            body: options.body,
            cache: options.cache,
            credentials: options.credentials ?? "include",
            headers: {
                "X-Fixture": options.fixture?.replace("/null", "/?") ?? "",
                "VND.com.blackrock.API-Key": API_KEY,
                "VND.com.blackrock.Request-ID": uuid(),
                "VND.com.blackrock.Origin-Timestamp": new Date().toISOString(),
                ...EMBEDDED_AUTH_HEADERS,
                ...options.headers
            },
            integrity: options.integrity,
            keepalive: options.keepalive,
            method: options.method,
            mode: options.mode,
            redirect: options.redirect,
            referrer: options.referrer,
            referrerPolicy: options.referrerPolicy,
            signal: controller.signal,
            window: options.window
        });

        if (options.telemetry) {
            const [key, message] = options.telemetry;
            logPerformance(key, message, fetched);
        }

        response = await fetched;
    } catch (error: any) {
        if (recording) {
            recording.exchange(path, options, {
                delay: getDelay(time),
                error
            });
        }
        throw {
            type: hasTimeout ? "TimeoutError" : error.name === "AbortError" ? "AbortError" : "FetchError",
            name: error.name,
            code: error.code,
            message: error.message
        };
    }

    if (response instanceof DOMException && response.name === "AbortError") {
        throw {
            ...response,
            type: hasTimeout ? "TimeoutError" : "AbortError"
        };
    }

    let body: any = options.intercept?.(response);
    if (!body) {
        let text;
        try {
            text = await response.text();
        } catch (error: any) {
            if (recording) {
                recording.exchange(path, options, {
                    delay: getDelay(time),
                    headers: response.headers,
                    status: response.status,
                    error
                });
            }
            throw {
                ...error,
                type: hasTimeout ? "TimeoutError" : error.name === "AbortError" ? "AbortError" : "StreamError"
            };
        }
        if (options.trace) {
            options.trace(options, text);
        }
        try {
            body = JSON.parse(text);
        } catch (ignored) {
            body = text;
        }
    } else {
        console.warn("intercepted fetch to:", path);
    }

    if (recording) {
        recording.exchange(path, options, {
            delay: getDelay(time),
            headers: response.headers,
            status: response.status,
            body: body
        });
    }

    if (response.ok) {
        return body as R;
    } else {
        if (typeof body === "string") {
            body = {
                name: ERROR_NAMES[Math.floor(response.status / 100) * 100],
                message: body || response.statusText
            };
        }
        throw {
            headers: response.headers,
            status: response.status,
            ...body,
            message: body.message ?? body.error
        };
    }
}

export type ApiGetOptions = ApiFetchOptions & {
    method?: "GET";
};

export async function apiGet<R>(path: string, options: ApiGetOptions = {}): Promise<R> {
    return apiFetch(path, {
        ...options,
        method: "GET"
    });
}

export type ApiPostOptions<P> = ApiFetchOptions & {
    method?: "POST";
    body?: P;
    headers?: ApiFetchOptions["headers"] & {
        "Content-Type"?: "application/json";
    };
    gzip?: boolean;
};

export async function apiPost<P, R>(path: string, payload: P, options: ApiPostOptions<P> = {}): Promise<R> {
    let body: any = JSON.stringify(payload);

    // NOTE: we cannot use gzip in dev because the fixtures rely on express.json() which cannot handle it...
    if (GZIP_ENABLED && options.gzip) {
        body = pako.gzip(body);
        options.headers = {
            ...options.headers,
            "Content-Encoding": "gzip",
            "Content-Length": String(body.byteLength)
        };
    }

    return apiFetch(path, {
        ...options,
        method: "POST",
        body: body,
        headers: {
            "Content-Type": "application/json",
            ...options.headers
        }
    });
}

export type ApiPatchOptions<P> = ApiFetchOptions & {
    method?: "PATCH";
    body?: P;
    headers?: ApiFetchOptions["headers"] & {
        "Content-Type"?: "application/json";
    };
};

export async function apiPatch<P, R>(path: string, body: P, options: ApiPatchOptions<P> = {}): Promise<R> {
    return apiFetch(path, {
        ...options,
        method: "PATCH",
        body: JSON.stringify(body),
        headers: {
            "Content-Type": "application/json",
            ...options.headers
        }
    });
}

export type ApiDeleteOptions = ApiFetchOptions & {
    method?: "DELETE";
};

export async function apiDelete<R>(path: string, options: ApiDeleteOptions = {}): Promise<R> {
    return apiFetch(path, {
        ...options,
        method: "DELETE"
    });
}

type QueryParams<V> = {
    query: string;
    variables: V;
};

interface ErrorLocation {
    line: number;
    column: number;
    sourceName: string;
}

interface QueryError {
    locations: ErrorLocation[];
    message: string;
    errorType: string;
    extensions: any;
    path: any;
}

export interface QueryResult<R> {
    errors?: QueryError[];
    data?: R;
}

const queryEndpoint = location.pathname.indexOf("beta") > 0 ? "/oemsgqlserver_beta/graphql" : "/oemsgqlserver/graphql";

export async function apiQuery<V, R>(
    query: string,
    variables: V,
    options: ApiPostOptions<QueryParams<V>> = {}
): Promise<QueryResult<R>> {
    return apiPost<QueryParams<V>, QueryResult<R>>(
        queryEndpoint,
        {
            query: query.replace(/\s+/g, " "),
            variables
        },
        {
            ...options,
            mode: "cors",
            credentials: "include",
            headers: {
                "X-OEMS-User": jotaiStore.get(userAtom), // TODO: remove this when we move on to the new GraphQL server
                ...options.headers
            }
        }
    );
}

/**
 * What a nonsense... just waste of CPU!
 * Extinction rebellion should stop gluing themselves and start doing code reviews
 */
function uuid() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (c) {
        let r = (Math.random() * 16) | 0;
        if (c == "x") {
            return r.toString(16);
        } else {
            return ((r & 0x3) | 0x8).toString(16);
        }
    });
}
