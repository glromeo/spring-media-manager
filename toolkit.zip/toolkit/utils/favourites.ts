import { apiDelete, apiGet, apiPatch, apiPost } from "./api";
import { searchParam } from "./location";

import pako from "pako";

const API_PATH = `/api/platform/identity/favorite/v1/favorites`;

/**
 * These sort of access "process.env.APP_ID" are replaced literally by esbuild. Be careful not to try
 * to access them in any other way (e.g. const { APP_ID } = process.env won't work).
 */
const APP_ID = process.env.APP_ID;
if (!(process.env.APP_ID && process.env.API_KEY)) {
    throw new Error(
        'This application is missing either the "appId" or the "apiKey",\n' +
            'please make sure that they are provided in package.json "config" section'
    );
}

function deserializeContent<T>(encodedContent: string): T {
    const inflated = pako.inflate(Uint8Array.from(window.atob(encodedContent), (v) => v.charCodeAt(0)));
    const decoded = new TextDecoder().decode(inflated);
    const parsed = JSON.parse(decoded);
    // This is a workaround for what I think is a stupid bug/feature of the API
    if (parsed.title && parsed.content) {
        return parsed.content;
    }
    return parsed;
}

function serializeContent(payload: any): string {
    const text = JSON.stringify(payload);
    const decoded = new TextEncoder().encode(text);
    return window.btoa(new TextDecoder().decode(pako.deflate(decoded)));
}

export type Favorite<T> = {
    activeFlag?: string;
    applicationName?: string;
    content: T;
    description?: string;
    favoriteType?: string;
    listOrder?: number;
    title?: string;
    url?: string;
    id?: string;
    owner?: string;
};

export type FavoriteQuery = {
    applicationNames?: string[];
    favoriteDescription?: string;
    favoriteTitles?: string[];
    favoriteTypes?: string[];
    favoriteUrls?: string[];
    ids?: string[];
    owners?: string[];
};

export type FavoriteQueryResponse<T> = {
    nextPageToken?: string;
    favorites: Favorite<T>[];
};
export type FavoritePager = {
    pageSize?: number;
    pageToken?: string;
};

export function createFavorite<T>(payload: Favorite<T>): Promise<{ id: string }> {
    return apiPost(API_PATH, {
        applicationName: APP_ID,
        ...payload,
        content: serializeContent(payload.content),
        owner: searchParam("user")
    });
}

export function updateFavorite<T>(id: string, payload: Favorite<T>) {
    return apiPatch(`${API_PATH}/${id}`, {
        applicationName: APP_ID,
        ...payload,
        content: serializeContent(payload.content),
        owner: searchParam("user")
    });
}

export async function loadFavorite<T>(id: string): Promise<T> {
    const { content } = await apiGet<Favorite<string>>(`${API_PATH}/${id}`);
    return deserializeContent(content);
}

export function deleteFavorite(id: string): Promise<void> {
    return apiDelete(`${API_PATH}/${id}`);
}

export async function queryFavorites<T>(
    payload?: FavoriteQuery,
    mode: "slim" | "full" = "slim",
    pager?: FavoritePager
): Promise<FavoriteQueryResponse<T>> {
    const body: any = {
        query: {
            applicationNames: [APP_ID],
            ...payload
        },
        viewOption: {
            favoriteView: mode === "slim" ? "FAVORITE_VIEW_SLIM" : "FAVORITE_VIEW_FULL"
        }
    };
    if (pager) {
        body.pageSize = pager.pageSize;
        body.pageToken = pager.pageToken;
    }
    const { nextPageToken, favorites } = await apiPost<any, any>(`${API_PATH}:filter`, body);
    const response: FavoriteQueryResponse<T> = {
        nextPageToken: nextPageToken,
        favorites: favorites
    };
    if (mode === "slim") {
        return response;
    } else {
        response.favorites = favorites.map((favorite: Favorite<string>) => {
            return { ...favorite, content: deserializeContent(favorite.content) };
        });
        return response;
    }
}

if ((window as any).createFavorite === undefined) {
    Object.defineProperties(window, {
        createFavorite: { enumerable: true, value: createFavorite },
        updateFavorite: { enumerable: true, value: updateFavorite },
        loadFavorite: { enumerable: true, value: loadFavorite },
        queryFavorites: { enumerable: true, value: queryFavorites },
        flushFavorites: {
            enumerable: true,
            async value() {
                const { favorites } = await queryFavorites();
                for (const { id } of favorites) {
                    await deleteFavorite(id!);
                }
            }
        }
    });
}
