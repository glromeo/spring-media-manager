import { apiGet } from "./api";
import { hasSearchParam, searchParam } from "../utils";

type BfmCefQuery = (args: {
    request: string;
    persistent?: boolean;
    onSuccess?: (message: string) => void;
    onFailure?: (id: string, message: string) => void;
}) => void;

export const HOST_NOT_AVAILABLE = "bfmCefQuery not available";

const bfmCefReady = new Promise<BfmCefQuery>((resolve, reject) => {
    const host = window as any;
    const listener = () => {
        if (document.readyState === "complete") {
            if (typeof host.bfmCefQuery === "function") {
                console.log("found bfmCefQuery");
                resolve(host.bfmCefQuery);
            } else if (hasSearchParam("fixture")) {
                console.warn("using /api/bfm-cef instead of bfmCefQuery");
                resolve(({ request, onFailure, onSuccess }) => {
                    let sliceIndex = request.indexOf(":");
                    if (sliceIndex > 0) {
                        request = request.slice(0, sliceIndex);
                    }
                    apiGet<any>("/api/bfm-cef", {
                        fixture: `bfm-cef/${searchParam("fixture")}`,
                        headers: {
                            "x-bfm-cef-request": request
                        }
                    })
                        .then((data) => {
                            let datum = data[request];
                            if (datum !== undefined) {
                                onSuccess!(datum);
                            } else {
                                onFailure!("0", `'${request}' not found in fixture`);
                            }
                        })
                        .catch((error) => {
                            onFailure!("0", error?.message);
                        });
                });
            } else {
                console.log("not found bfmCefQuery");
                reject(HOST_NOT_AVAILABLE);
            }
        }
    };
    if (document.readyState === "complete") {
        listener();
    } else {
        document.addEventListener("readystatechange", listener);
    }
});

bfmCefReady.catch((rej) => console.error(rej));

export function dispatchHost(request: string): Promise<string> {
    return bfmCefReady.then(
        (bfmCefQuery) =>
            new Promise<string>((resolve, reject) =>
                bfmCefQuery!({
                    request,
                    onSuccess: resolve,
                    onFailure: (id, message) => reject(message)
                })
            )
    );
}

function isLikelyJSON(message: string) {
    return message[0] === "{" || message[0] === "[";
}

export function queryHost<Q, R>(request: string, payload?: Q | string): Promise<R> {
    if (payload) {
        payload = typeof payload === "string" ? payload : JSON.stringify(payload);
        request += ":" + payload;
    }
    return bfmCefReady.then(
        (bfmCefQuery) =>
            new Promise<R>((resolve, reject) =>
                bfmCefQuery!({
                    request,
                    onSuccess: (message) =>
                        resolve(message ? (isLikelyJSON(message) ? JSON.parse(message) : message) : null),
                    onFailure: (id, message) => reject(message)
                })
            )
    );
}

/**
 * @deprecated this is a workaround for the settings html dialog constraints in swing
 */
export function maximizeFrame() {
    dispatchHost(`MAXIMIZE`).catch((error) => {});
}

/**
 * @deprecated this is a workaround for the settings html dialog constraints in swing
 */
export function restoreFrame() {
    dispatchHost(`RESTORE`).catch((error) => {});
}

if (!("dispatchHost" in window && "queryHost" in window)) {
    Object.defineProperties(window, {
        dispatchHost: { value: dispatchHost },
        queryHost: { value: queryHost }
    });
}

if (hasSearchParam("fixture") && !("timeline" in window)) {
    Object.defineProperty(window, "timeline", {
        enumerable: true,
        configurable: true,
        set(timeline: Record<string, Function>) {
            for (const [time, event] of Object.entries(timeline)) {
                let [hh, mm, ss] = time.split(":");
                let timeout = parseInt(hh) * 1000;
                if (mm) {
                    timeout = 60 * timeout + (parseInt(mm) % 60) * 1000;
                }
                if (ss) {
                    timeout = 60 * timeout + (parseInt(ss) % 60) * 1000;
                }
                setTimeout(event, timeout);
            }
        }
    });
    apiGet<any>("/api/timeline", {
        fixture: `timeline/${searchParam("fixture")}.js`
    }).then(eval).catch(() => {
        console.warn("no timeline for fixture:", searchParam("fixture"))
    });
}
