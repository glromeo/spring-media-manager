export const searchParams = new URLSearchParams(location.search);

(globalThis as any)["searchParams"] = searchParams;

export function hasSearchParam(name: string): boolean {
    const value = searchParams.get(name);
    return value !== null && (value === "" || value.toLowerCase() !== "false");
}

export function searchParam(name: string) {
    return searchParams.get(name);
}

(globalThis as any)["searchParam"] = searchParam;
