import { storeKey } from "./storage";

function uniqueId(): string {
    const counter = String((parseInt(localStorage.getItem(storeKey("app-counter")) ?? "0") || 0) + 1);
    localStorage.setItem(storeKey("app-counter"), counter);
    return counter;
}

export const logPrefix = `[${process.env.APP_ID}:${uniqueId()}]`;

export function injectLogPrefix(): () => void {
    const levels: (keyof typeof console)[] = ["debug", "info", "log", "warn", "error"];
    const backup = {} as Partial<Record<keyof typeof console, any>>;
    for (const level of levels) {
        if (level in console) {
            backup[level] = console[level];
            const value = (console[level] as (...args: any[]) => void).bind(console, level, logPrefix);
            Object.defineProperty(console, level, {
                ...Object.getOwnPropertyDescriptor(console, level),
                value
            });
        }
    }
    return () => {
        for (const level of levels) {
            if (level in console) {
                Object.defineProperty(console, level, {
                    ...Object.getOwnPropertyDescriptor(console, level),
                    value: backup[level]
                });
            }
        }
    };
}
