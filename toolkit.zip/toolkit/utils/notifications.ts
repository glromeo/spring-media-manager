import { atom, useAtom, useSetAtom } from "jotai";
import { atomSink } from "../atoms/utils/atom-sink";
import { useCallback } from "react";

export type Notification = {
    id: number;
    title: string;
    message: string;
    type: "ALERT" | "ERROR" | "MESSAGE" | "SUCCESS" | "WARNING";
    timeout?: number;
};

export const notificationsAtom = atom<Notification[]>([]);

export const notificationSink = atomSink(notificationsAtom);

let id = 0;

export const alertNotification = (title: string, message: string, timeout?: number): Notification => {
    return { id: id++, title, message, type: "ALERT", timeout };
};
export const errorNotification = (title: string, message: string, timeout?: number): Notification => {
    return { id: id++, title, message, type: "ERROR", timeout };
};
export const messageNotification = (title: string, message: string, timeout?: number): Notification => {
    return { id: id++, title, message, type: "MESSAGE", timeout };
};
export const successNotification = (title: string, message: string, timeout?: number): Notification => {
    return { id: id++, title, message, type: "SUCCESS", timeout };
};
export const warningNotification = (title: string, message: string, timeout?: number): Notification => {
    return { id: id++, title, message, type: "WARNING", timeout };
};

export function useNotification() {
    const [notifications, setNotifications] = useAtom(notificationsAtom);
    return useCallback(
        (notification?: Notification | null | undefined) => {
            if (notification) {
                setNotifications([...notifications, notification]);
                return () => setNotifications(notifications.filter((notification) => notification === notification));
            }
        },
        [notifications]
    );
}

export function useErrorNotification() {
    const appendNotification = useSetAtom(notificationSink);
    return (title: string, error?: Error | string | null | undefined, timeout?: number) => {
        if (error) {
            appendNotification(errorNotification(title, (error as Error).message ?? error, timeout));
            console.error(error);
        }
    };
}

export function useMessageNotification() {
    const appendNotification = useSetAtom(notificationSink);
    return (title: string, message?: string | null | undefined, timeout?: number) => {
        if (message) {
            appendNotification(messageNotification(title, message, timeout));
        }
    };
}

export function useSuccessNotification() {
    const appendNotification = useSetAtom(notificationSink);
    return (title: string, message?: string | null | undefined, timeout?: number) => {
        if (message) {
            appendNotification(successNotification(title, message, timeout));
        }
    };
}

export function useWaringNotification() {
    const appendNotification = useSetAtom(notificationSink);
    return (title: string, message?: string | null | undefined, timeout?: number) => {
        if (message) {
            appendNotification(warningNotification(title, message, timeout));
        }
    };
}
