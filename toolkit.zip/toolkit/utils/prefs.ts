import { apiFetch, apiGet } from "./api";
import pako from "pako";

/**
 * These sort of access "process.env.APP_ID" are replaced literally by esbuild. Be careful not to try
 * to access them in any other way (e.g. const { APP_ID } = process.env won't work).
 */
const APP_ID = process.env.APP_ID;
if (!(process.env.APP_ID && process.env.API_KEY)) {
    throw new Error(
        'This application is missing either the "appId" or the "apiKey",\n' +
            'please make sure that they are provided in package.json "config" section'
    );
}

function deserializeContent<T>(encodedContent: string): T | null {
    const content = decodeURIComponent(encodedContent);
    const data = Uint8Array.from(window.atob(content), (v) => v.charCodeAt(0));
    const inflated = pako.inflate(data);
    const decoded = new TextDecoder().decode(inflated);
    try {
        return JSON.parse(decoded);
    } catch (e) {
        return null;
    }
}

function serializeContent(payload: any): string {
    const text = JSON.stringify(payload);
    const encoded = new TextEncoder().encode(text);
    const deflated = pako.deflate(encoded);
    const data = window.btoa(String.fromCharCode.apply(null, deflated as any));
    return encodeURIComponent(data);
}

export async function getPrefs<T>(): Promise<T> {
    const response = await apiGet<any>(`/weblications/etc/getPrefs.epl?appID=${APP_ID}`, {
        fixture: "prefs.txt"
    });
    const preferences: any = {};
    for (let line of response.split("\n")) {
        if (line.startsWith(APP_ID)) {
            line = line.substring(APP_ID!.length + 1);
            const [key, value] = line.split("\t");
            try {
                preferences[key] = deserializeContent(value);
            } catch (e) {
                console.warn("unable to deserialize settings key:", key);
            }
        }
    }
    return preferences as T;
}

export function removePrefs(keys: string[]): Promise<void> {
    return apiFetch(`/weblications/etc/removePrefs.epl`, {
        method: "POST",
        body: keys.map((key) => `${APP_ID}.${key}=remove`).join("&"),
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        }
    });
}

export async function setPrefs(preferences: any): Promise<void> {
    return apiFetch(`/weblications/etc/setPrefs.epl`, {
        method: "POST",
        body: Object.keys(preferences)
            .map((key) => `${APP_ID}.${key}=${serializeContent(preferences[key])}`)
            .join("&"),
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        }
    });
}

if (!("setPrefs" in window && "removePrefs" in window && "getPrefs" in window)) {
    Object.defineProperties(window, {
        setPrefs: { enumerable: true, value: setPrefs },
        removePrefs: { enumerable: true, value: removePrefs },
        getPrefs: { enumerable: true, value: getPrefs }
    });
}
