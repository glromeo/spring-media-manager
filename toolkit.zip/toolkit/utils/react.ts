import React, { ReactNode } from "react";
import { createRoot } from "react-dom/client";
import { bootstrapComponents } from "@atw/toolkit/awc";
import { bootstrapTelemetry } from "@atw/toolkit/telemetry";
import { searchParam } from "./location";
import { SyntheticEvent } from "react/index";
import { injectLogPrefix } from "./logging";
import memoize from "micro-memoize";

export type RenderAppOptions = {
    strictMode?: boolean;
    telemetry?: boolean;
    logPrefix?: boolean;
};

/**
 *
 * @param main
 * @param strictMode
 * @param telemetry
 * @param logPrefix
 */
export function renderApp(
    main: ReactNode,
    { strictMode = false, telemetry = false, logPrefix = false }: RenderAppOptions = {}
) {
    const appid = process.env.APP_ID;
    if (!appid) {
        throw new Error("missing appId in package.json config section");
    }

    if (logPrefix) {
        injectLogPrefix();
    }

    bootstrapComponents();

    if (telemetry) {
        bootstrapTelemetry(appid, searchParam("user"), 5);
    }

    if (strictMode) {
        main = React.createElement(React.StrictMode, null, main);
    }

    if (process.env.NODE_ENV === "development") {
        Object.defineProperty(window, "$", { value: require("jquery") });
        Object.defineProperty(window, "luxon", { value: require("luxon") });
    }

    createRoot(document.getElementById("root")!).render(main);
}

export const classNames = memoize((...parts: (symbol | string | number | boolean | null | undefined)[]) => {
    const filtered = parts.filter((part) => part);
    return filtered.length ? filtered.join(" ") : undefined;
});

export function discardSyntheticEvent<T>(e: SyntheticEvent<T>) {
    e.preventDefault();
    e.stopPropagation();
}

export type LazyNode = ReactNode | (() => ReactNode);
