import JSZip from "jszip";
import FileSaver from "file-saver";
import { storedFlag } from "./storage";

export type HttpExchange = { request: string; response: string };

export class Rec {
    url: string = window.location.href.substring(window.location.origin.length);
    http: Record<string, HttpExchange[]> = {};
    ws: { start?: number; out: string[]; in: string[]; time: number[] } = {
        out: [],
        in: [],
        time: []
    };

    start = Date.now();

    exchange(url: string, request: any, response: any) {
        let key = request.fixture;
        if (!key) {
            console.warn("no fixture specified for ", request.method, url, "url path will be used instead");
            key = url;
        }
        if (!this.http[key]) {
            this.http[key] = [];
        }
        this.http[key].push({ request, response });
    }

    onopen() {
        this.ws.start = Date.now();
    }

    sent(message: any) {
        this.ws.out.push(message);
    }

    received(message: any) {
        this.ws.in.push(message);
        this.ws.time.push(Date.now());
    }

    async download(suffix?: string) {
        const zip = new JSZip(),
            fileName = suffix ? `recording-${suffix}` : `recording`;
        zip.file(`${fileName}.json`, JSON.stringify(recording, null, 4));
        const blob = await zip.generateAsync({ type: "blob" });
        FileSaver.saveAs(blob, `${fileName}.zip`);
    }
}

export const recording = storedFlag("recording") ? new Rec() : null;
