import { compareVersions } from "compare-versions";
import { retrieveObject, storeObject } from "../utils";
import { getPrefs, setPrefs } from "./prefs";
import { atom, WritableAtom } from "jotai";
import { errorNotification, notificationSink } from "./notifications";

export type Version = `${number}.${number}.${number}`;

export type Settings = { [key: string]: SettingValue } & {
    version: Version;
    isOpen?: boolean;
};

export type SettingValue = string | number | boolean | Date | null | SettingValue[] | { [key: string]: SettingValue };

export type SettingsAtom<S extends Settings> = WritableAtom<S, [S, boolean?], S>;

/**
 *
 * @param defaultSettings
 * @param upgrades
 */
export function settingsAtom<S extends Settings>(defaultSettings: S, upgrades: Upgrades) {
    let localSettings = atom(defaultSettings);
    localSettings.debugLabel = "settings (local)";

    const settingsAtom = atom<S, [S, boolean?], S>(
        (get) => get(localSettings),
        (get, set, settings, persist) => {
            const [major, minor, version] = (settings.version ?? "0.0.0").split(".");
            const storedSettings = {
                ...settings,
                version: `${major}.${minor}.${Date.now()}`
            };
            if (persist) {
                setPrefs({ settings: storedSettings }).catch((error) => {
                    set(notificationSink, errorNotification("Error Saving Settings", error.message));
                });
            }
            storeSettings(storedSettings);
            set(localSettings, storedSettings);
            return storedSettings;
        }
    );

    settingsAtom.onMount = (setAtom) => {
        const storedSettings = retrieveSettings(defaultSettings);

        setAtom(storedSettings, false);

        getPrefs<{ settings?: S }>()
            .then(({ settings: hostSettings }) => {
                if (!hostSettings) {
                    console.log("no settings retrieved from host");
                    hostSettings = defaultSettings;
                }

                const { version = "0.0.0" } = hostSettings;
                const diff = compareVersions(version, storedSettings.version);
                if (diff > 0) {
                    console.log(`updating local settings from: ${storedSettings.version} to: ${version}`);
                    setAtom(hostSettings);
                } else if (diff === 0) {
                    console.log(`keeping local settings: ${storedSettings.version} same as host settings: ${version}`);
                } else {
                    const mergedSettings = applyUpgrade(upgrades, hostSettings, storedSettings) ?? storedSettings;
                    if (mergedSettings !== storedSettings) {
                        console.log(`merging host settings: ${version}`);
                        setAtom(mergedSettings);
                    }
                }
            })
            .catch((error) => {
                throw new Error(`Error loading User Settings: ${error.message}`);
            });
    };

    return settingsAtom;
}

function retrieveSettings<S extends Settings>(defaultSettings: S) {
    let storedSettings = retrieveObject<S>("settings");
    if (storedSettings !== null) {
        if (compareVersions(storedSettings.version, defaultSettings.version) < 0) {
            console.warn(
                `outdated settings version: ${storedSettings.version} in local storage, replacing with default settings version: ${defaultSettings.version}`
            );
            return defaultSettings;
        } else {
            return storedSettings;
        }
    } else {
        console.log(`no settings in local storage, using default settings version: ${defaultSettings.version}`);
        return defaultSettings;
    }
}

export function storeSettings<S extends Settings>(settings: S | null): void {
    storeObject("settings", settings);
}

export type Upgrades = Record<Version, <H1 extends Settings, S1 extends Settings>(stale: H1) => S1>;

function applyUpgrade<H extends Settings, S extends Settings>(
    upgrade: Upgrades,
    hostSettings: H,
    storedSettings: S
): S {
    // effects: [
    //     effect => {
    //         effect.onSet((newValue, oldValue) => {
    //             if (newValue.version.startsWith("1.0")) {
    //                 effect.setSelf({
    //                     ...newValue,
    //                     version: "2.0"
    //                 });
    //             } else {
    //                 console.log("no 1.0 upgrade necessary");
    //             }
    //         });
    //     },
    //     effect => effect.onSet(storeSettings)
    // ]

    return storedSettings;
}
