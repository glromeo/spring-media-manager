const APP_ID = process.env.APP_ID;

export function storeKey(key: string) {
    return `${APP_ID}.${key}`;
}

export function storeObject(key: string, item: any) {
    key = storeKey(key);
    if (item)
        try {
            localStorage.setItem(key, JSON.stringify(item));
        } catch (e) {
            console.warn(`unable to persist '${key}' in local storage`, item, e);
        }
    else {
        localStorage.removeItem(key);
    }
}

export function retrieveObject<T>(key: string): T | null {
    key = storeKey(key);
    try {
        const item = localStorage.getItem(key);
        return item && JSON.parse(item);
    } catch (e) {
        console.warn(`unable to retrieve '${key}' from local storage`, e);
        return null;
    }
}

export function storeText(key: string, item: string) {
    localStorage.setItem(storeKey(key), item);
}

export function storedText(key: string): string | null {
    return localStorage.getItem(storeKey(key));
}

export function storeFlag(key: string, value: boolean) {
    localStorage.setItem(storeKey(key), value ? "true" : "false");
}

export function storedFlag(key: string): boolean {
    return localStorage.getItem(storeKey(key)) === "true";
}
