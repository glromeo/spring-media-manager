export function appendCall<O extends object, K extends keyof O>(object: O, property: K, method: O[K]) {
    const original = object[property] as Function;
    (object[property] as Function) = function (this: O) {
        let result = original.apply(this, arguments);
        return (method as Function).apply(this, arguments) ?? result;
    };
}

export function groupBy<T extends object, P extends keyof T>(array: T[], property: P): Map<T[P], T[]> {
    const grouped = new Map<T[P], T[]>();
    for (const item of array) {
        let items = grouped.get(item[property]);
        if (!items) {
            items = [] as T[];
            grouped.set(item[property], items);
        }
        items.push(item);
    }
    return grouped;
}