/**
 * Never ever have I ever ...lowercase! Seriously! A case mismatch has to be spotted by a failing test
 *
 * @param strings
 * @param params
 */
export function testId(strings: TemplateStringsArray, ...params: string[]) {
    let testid = strings[0];
    let i = 0;
    while (i < params.length) {
        testid += String(params[i]).replace(/\s/g, "_") + strings[++i];
    }
    return testid;
}
