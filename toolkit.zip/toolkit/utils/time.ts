const TZ_CACHE = new Map<string, { label: string; value: number }>();

export function tzOffset(timeZone: string) {
    let cached = TZ_CACHE.get(timeZone);
    if (!cached) {
        const parts = Intl.DateTimeFormat("ia", { timeZone, timeZoneName: "longOffset" }).formatToParts();
        const label = parts.find((part) => part.type === "timeZoneName")!.value.slice(3);
        const [HH, MM] = label.split(":");
        const gmtOffset = parseInt(HH) * 60 + parseInt(MM);
        const localOffset = new Date().getTimezoneOffset();
        cached = { label: label, value: (gmtOffset + localOffset) * 60000 };
        TZ_CACHE.set(timeZone, cached);
    }
    return cached;
}

export function parseDateTime(text: string, timeZone: string) {
    try {
        let { date, time } = text.match(/^(?<date>\d\d\d\d-\d\d-\d\d)?\s?(?<time>\d\d:\d\d:\d\d)$/)!.groups!;
        if (!date) {
            return parseTime(text, timeZone);
        }
        if (!time) {
            return parseDate(date, timeZone);
        }
        return new Date(`${date}T${time}${tzOffset(timeZone).label}`);
    } catch (error: any) {
        throw new Error(`unable to parse: '${text}' in '${timeZone}'`);
    }
}

export function parseDate(date: string, timeZone: string) {
    return new Date(`${date}T${"00:00:00"}${tzOffset(timeZone).label}`);
}

export function parseTime(time: string, timeZone: string) {
    const [DD, MM, YYYY] = new Date().toLocaleString("en-GB", { timeZone }).slice(0, 10).split("/");
    return new Date(`${YYYY}-${MM}-${DD}T${time}${tzOffset(timeZone).label}`);
}

export function parseTimestamp(timestamp: number, timeZone?: string) {
    return timeZone ? new Date(timestamp - tzOffset(timeZone).value) : new Date(timestamp);
}
