### link

This command is useful for linking a locally checked out copy of @atw with the current project.

First run:

```shell
cd atw
yarn run link
```

then run

```
cd execution-ui
yarn run link
```

and all the necessary projects will be linked for you.

When you want to revert to the real packages you can just run:

```shell
cd execution-ui
rm -rf node_modules/\@atw
yarn
```

**NOTE:** keep atw version consistent, differences might lead to hoisting and this linkage won't work properly
