const cypressPlugins = require("@atw/scripts").cypressPlugins;
module.exports = (on, config) => {
    cypressPlugins(on, config);
    // IMPORTANT to return the config object with the any changed environment variables
    return config;
};
