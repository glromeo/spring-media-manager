import { CounterParty, Desk } from "../features/order/order";
import { PartialPick, Side } from "../models/common";

export const requestPlacementQuoteMutation = `mutation requestPlacementQuote($request: PlacementQuoteRequest!, $user: String) {
  requestPlacementQuote(request: $request, user: $user) {
      order {
        ordNum
      },
      placements {
        placementNum,
        type,
        axeID,
        modifiedBy
      }
    }
  }`;

export const executePlacementQuoteMutation = `mutation executePlacementQuote($request: PlacementQuoteExecute!, $user: String) {
  executePlacementQuote(request: $request, user: $user) {
    order {
      ordNum
    },
    placements {
      placementNum,
      status
      quotes {
          quoteID,
          price,
          quantity
          counterparty {
              ticker
          }
      }
    }
  }
}`;

export const counterPlacementQuoteMutation = `mutation counterPlacementQuote($request: PlacementQuoteExecute!, $user: String) {
  counterPlacementQuote(request: $request, user: $user) {
    order {
      ordNum
    },
    placements {
      placementNum
    }
  }
}`;

export const validatePlacementsCounteringMutation = `mutation validatePlacementsCountering($request: PlacementQuoteRequest!, $warnings: String, $user: String) {
  validatePlacementsCountering(request: $request, warnings: $warnings, user: $user) {
    placementNum,
    placementValidations {
      validationID {
        id
        validationKey
        validationType
        touchCount
      }
      fillNums
      type
      violation
      severityType
      validationState
      validationDate
    }
    executionValidations {
      validationID {
        id
        validationKey
        validationType
        touchCount
      }
      fillNums
      type
      violation
      severityType
      validationState
      validationDate
    }
  }
}`;

export const cancelErrorPlacementsMutation = `mutation cancelErrorPlacements($placementNumList: [Int!], $user: String!) {
  cancelErrorPlacements(placementNumList: $placementNumList, user: $user) {
    placementNum
    status
    modifyReason
  }
}`;

export const validatePlacementsMutation = `mutation validatePlacements($request: MultiQuickPlaceRequest, $user: String) {
  validatePlacements(request: $request, user: $user) {
      placementNum,
      placementValidations {
        validationID {
          id
          validationKey
          validationType
          touchCount
        }
        fillNums
        type
        violation
        severityType
        validationState
        validationDate
      }
      executionValidations {
        validationID {
          id
          validationKey
          validationType
          touchCount
        }
        fillNums
        type
        violation
        severityType
        validationState
        validationDate
      }
    }
  }`;

export const validatePlacementsExecutionMutation = `mutation validatePlacementsExecution($request: PlacementQuoteExecute!, $user: String) {
    validatePlacementsExecution(request: $request, user: $user) {
      placementNum,
    }
  }`;

export const passPlacementQuoteMutation = `mutation passPlacementQuotes($placementNumList: [Int!], $user: String!) {
    passPlacementQuotes(placementNumList: $placementNumList, user: $user) {
      placementNum
      status
    }
  }`;

export const orderMutation = `mutation multiQuickPlace($request: MultiQuickPlaceRequest, $user: String) {
    multiQuickPlace(request: $request, user: $user) {
      placementNum,
    }
  }`;

export const brokerQuery = `query fiOrderSummary($ordNum: Int!) {
    fiOrderSummary(ordNum: $ordNum) {
      brokerEntity {
        key
        value
      }
    }
  }
  `;

export const orderLeavesQuery = `query fiOrderSummary($ordNum: Int!) {
    fiOrderSummary(ordNum: $ordNum) {
      order {
        orderLeaves
      }
    }
  }
  `;

const orderSchema = `
  order {
    price
    effectiveTranType
    updateInstr
    face
    fillAmt
    limitValue
    limitType
    orderLeaves
    settleDate
    tradingBenchmark
    priceCurrency
  }
  orderDetails {
    quantity
    quantityBooked
    portfolio {
      portfolioCode
      portfolioName
    }
  }
  delayedSpotEnabled
  mifidTagEnabled
  spreadFlowEnabled
  brokerAllocations {
    broker {
      defaultDesk
      shortName
      code
      desks {
        brokerType
        salesman
        subBrokerID
      }
    }
    availablePlacementQuantity
    eligiblePlacementQuantity
    eligiblePlacementQuantityAsPct
    portfolioAllocations {
      portfolioCode
      quantityAvailable
    }
  }
  fiAsset {
    bAsset {
      ticker
      maturity
      cusip
      secGroup
      secType
      minTrdSize
    }
    bondQuality
    couponValue
    isin
    defaultSettleDate
    isMiFID2Eligible
  }
  placements {
    placementNum,
    limitValue,
    limitType,
    quantity,
    status,
    modifyReason,
    externRefID,
    settleDate,
    type,
    axeID,    
    modifiedBy
    broker {
      ticker,
      type,
      shortName,
      code
    },
    desk {
      salesman,
      brokerType,
      subBrokerID
    },
    quotes {
      requestID,
      spread,
      price,
      type,
      quoteID,
      expTime,
      quantity,
      side,
      counterparty {
        ticker,
        code,
        shortName
      }
    }
    placementGenFields {
      key,
      value
    },
  }
  userMifidEligibility,
  counteringEnabled,
  actionableCounteringEnabled,
  spotTimes {
    venue,
    spotTime {
      code,
      displayName
    }
  }
}
`;

export const orderQuery = `query fiOrderSummary($ordNum: Int!, $user: String!, $brokerList: [Int!]) {
   fiOrderSummary(ordNum: $ordNum, user: $user, brokerList: $brokerList) {
     ${orderSchema}
  }
  `;

export const orderCaresQuery = `query fiOrderSummary($ordNum: Int!, $user: String!, $care: Boolean!) {
  fiOrderSummary(ordNum: $ordNum, user: $user, care: $care) {
    ${orderSchema}
 }
 `;

export const orderA2AQuery = `query fiOrderSummary($ordNum: Int!, $user: String!, $brokerList: [Int!], $a2a: Boolean!) {
  fiOrderSummary(ordNum: $ordNum, user: $user, brokerList: $brokerList, a2a: $a2a) {
    ${orderSchema}
 }
 `;

 export const orderLTXQuery = `query fiOrderSummary($ordNum: Int!, $user: String!, $brokerList: [Int!], $ltx: Boolean!) {
  fiOrderSummary(ordNum: $ordNum, user: $user, brokerList: $brokerList, ltx: $ltx) {
    ${orderSchema}
 }
 `;

export const pricesQuery = `query prices($cusips: [String!], $startInclusive: BFMTimestamp) {
  prices(cusips: $cusips, startInclusive: $startInclusive) {
    indexName
    price
  }
}
`;

export type GraphQLOrderDetails = {
    quantity: number;
    quantityBooked: number;
    portfolio: {
        portfolioCode: number;
        portfolioName: string;
    };
};
export type GraphQLQuote = {
    requestID: string;
    spread: number;
    price: number;
    quoteID: string;
    expTime: number;
    quantity: number;
    counterparty: CounterParty;
    type: "PRICE" | "SPREAD";
    side: "ASK" | "BID";
    broker?: string;
};
export type GraphQLPartialQuote = PartialPick<GraphQLQuote, "broker" | "price" | "quantity" | "quoteID">;
export type GraphQLPlacement = {
    axeID: string;
    placementNum: number;
    limitValue: number;
    limitType: "Price" | "Spread";
    quantity: number;
    status: string;
    modifyReason: string;
    modifiedTime?: number;
    externRefID: string;
    quotes: GraphQLQuote[];
    placementGenFields: { key: string, value: string}[]
    desk: Desk;
    broker: CounterParty;
    settleDate: string;
    ordNum?: number;
    dueInTime?: number;
    spreadIndex?: string;
    modifiedBy?: string;
};
export type GraphQLPlacements = GraphQLPlacement[] | [] | undefined;
export type GraphQLOrder = {
    effectiveTranType: Side;
    updateInstr: string;
    face: number;
    fillAmt: number;
    limitValue: number;
    limitType: string;
    orderLeaves: number;
    settleDate: string;
    tradingBenchmark: string;
    priceCurrency: string;
    price: number;
};
export type GraphQLAsset = {
    bAsset: {
        ticker: string;
        maturity: string;
        cusip: string;
        secGroup: string;
        secType: string;
        minTrdSize: number;
    };
    bondQuality: string;
    couponValue: string;
    isin: string;
    defaultSettleDate: string;
    isMiFID2Eligible: boolean;
};
export type GraphQLDelayedSpot = number;
export type GraphQLMifidEnabled = number;
export type GraphQLSpreadEnabled = number;
export type GraphQLCounteringEnabled = number;
export type GraphQLActionableCounteringEnabled = number;
export type GraphQLBrokerEntity = {
    key: string;
    value: string[];
};
export type GraphQLPorfolioAllocation = {
    portfolioCode: number;
    quantityAvailable: number;
};
export type GraphQLBrokerAllocationDesk = {
    brokerType: string;
    salesman: string;
    subBrokerID: number;
};
export type GraphQLBrokerAllocation = {
    broker: {
        defaultDesk?: string;
        shortName: string;
        code: number;
        desks: GraphQLBrokerAllocationDesk[];
    };
    availablePlacementQuantity: number;
    eligiblePlacementQuantity: number;
    eligiblePlacementQuantityAsPct: number;
    portfolioAllocations: GraphQLPorfolioAllocation[];
};
export type GraphQLSpotTimes = {
    venue: string;
    spotTime: {
        code: string;
        displayName: string;
    }[];
};
export type GraphQLOrderSummary = {
    order?: GraphQLOrder;
    orderDetails?: GraphQLOrderDetails[];
    fiAsset?: GraphQLAsset;
    brokerAllocations?: GraphQLBrokerAllocation[];
    brokerEntity?: GraphQLBrokerEntity[];
    delayedSpotEnabled?: GraphQLDelayedSpot[];
    mifidTagEnabled?: GraphQLMifidEnabled[];
    spreadFlowEnabled?: GraphQLSpreadEnabled[];
    placements: GraphQLPlacement[];
    userMifidEligibility: "true" | "false";
    counteringEnabled: GraphQLCounteringEnabled[];
    actionableCounteringEnabled: GraphQLActionableCounteringEnabled[];
    spotTimes?: GraphQLSpotTimes[];
};
export type GraphQLOrderSummaryResponse = {
    fiOrderSummary: GraphQLOrderSummary;
    errors: GraphQLValidation[];
};
export type GraphQLBrokerVariables = {
    ordNum: number;
};
export type GraphQLOrderSummaryVariables = {
    ordNum: number;
    brokerList?: number[];
    care?: boolean;
    a2a?: boolean;
    ltx?:boolean;
    user: string;
};
export type GraphQLMultiQuickPlaceRequest = {
    orderData: {
        orderNumber: number;
        quantity: number;
        limitValue?: number;
        lastPrice?: number;
        ordType?: string;
        timeInForce?: string;
    };
    broker: string;
    subBrokerID: number;
    percentToPlace: number;
    externRefID?: string;
    user: string;
    allocationStrategy: string;
    strategy: string;
    settleDate?: string;
    limitType?: string;
    spotType?: string;
    spreadIndex?: string;
    benchPrice?: number;
};
export type GraphQLOrderCreationVariables = {
    request: GraphQLMultiQuickPlaceRequest;
    user: string;
};
export type GraphQLValidation = {
    validationID: {
        id: number;
        validationKey: string;
        validationType: string;
        touchCount: number;
    };
    fillNums: number;
    type: number;
    violation: string;
    severityType: string;
    validationState: string;
    validationDate: string;
};
export type GraphQLValidationError = {
    message: string;
};
export type GraphQLValidationResponse = {
    placementNum: number;
    placementValidations: GraphQLValidation[];
    executionValidations: GraphQLValidation[];
};
export type GraphQLOrderCreationResponse = {
    multiQuickPlace: GraphQLPlacement[];
};
export type GraphQLErrorLocation = {
    line: number;
    column: number;
    sourceName: string;
};
export type GraphQLError = {
    locations: GraphQLErrorLocation[];
    message: string;
    errorType: string;
    extensions: any;
    path: any;
};
export type GraphQLResult<R> = {
    errors?: GraphQLError[];
    data: R;
};
export type GraphQLCounteringValidationResponse = {};
export type GraphQLOrderValidationResponse = {};
export type GraphQLBenchmarkVariables = {
    secId: string;
};
export type GraphQLBenchmarkResponse = {
    fiAsset: {
        bAsset: {
            secDesc1?: string;
            maturity: string;
            ticker: string;
        };
        couponValue: number;
    };
};
export type GraphQLPricesVariables = {
    cusips: string[];
    startInclusive: number;
};
export type GraphQLPricesResponse = {
    prices: [
        {
            indexName: string;
            price: number;
        }
    ];
};
export type GraphQLBrokerDeskPairing = {
    broker: string;
    subBrokerId: number;
};
export type GraphQLPlacementQuoteRequest = {
    ordNum: number;
    brokers: GraphQLBrokerDeskPairing[];
    placementAllocationStrategy: {
        strategy: string;
        value: number;
    };
    limitType: string;
    dueInTime: string;
    limitValue?: number;
    externRefID?: string;
    axeLevel?: number;
    axeQty: number;
    spreadIndex?: string;
    spotTime?: string;
    spotType?: string;
    settleDate?: string;
    axeID?: string;
    isBin?: boolean;
    benchPrice?: number;
};
export type GraphQLPlacementCreationVariables = {
    request: GraphQLPlacementQuoteRequest;
    user: string;
};
export type GraphQLPlacementCreationResponse = {
    requestPlacementQuote: GraphQLPlacementQuote[];
};
export type GraphQLPlacementQuote = {
    order: {
        ordNum: number;
    };
    placements: [{ placementNum: number; axeID: string; type: string; modifiedBy: string }];
};
export type GraphQlExecutePlacementQuoteRequest = {
    placementNum: number;
    externId: string;
    quantity: number;
    askPrice: number;
    bidPrice: number;
    counterparty: string;
    lastPrice?: string;
    dueInTime?: string;
};
export type GraphQlExecutePlacementQuoteResponse = {
    executePlacementQuote: GraphQLPlacementQuote[];
    errors: GraphQLValidation[];
};
export type GraphQlExecutePlacementQuoteVariables = {
    request: GraphQlExecutePlacementQuoteRequest;
    quotes?: GraphQLPartialQuote[];
    user: string;
};
export type GraphQlCounterPlacementQuoteResponse = {
    counterPlacementQuote: GraphQLPlacementQuote[];
};
export type GraphQlCounterPlacementQuoteVariables = {
    request: GraphQlExecutePlacementQuoteRequest;
    user: string;
};
export type GraphQlPassPlacementQuotesResponse = {
    passPlacementQuotes: GraphQLPlacementQuote[];
    errors: GraphQLValidation[];
};
export type GraphQlPassPlacementQuotesVariables = {
    placementNumList: number[];
    user: string;
};

export type GraphQlCancelErrorPlacementsResponse = {
    cancelErrorPlacements: GraphQlCancelErrorPlacements[];
};

export type GraphQlCancelErrorPlacementsVariables = {
    placementNumList: number[];
    user: string;
};

export type GraphQlCancelErrorPlacements = {
    placementNum: number;
    status: string;
    modifyReason: string;
};
