import { Provider } from "react-redux";
import { BrowserRouter as Router } from "react-router-dom";
import "./app.css";
import { store } from "./store";

type Props = {
    basename?: string;
    children: JSX.Element;
};

const App = ({ basename, children }: Props) => {
    return (
        <div className="App">
            <Router basename={basename}>
                <Provider store={store}>{children}</Provider>
            </Router>
        </div>
    );
};

export default App;
