import { alerts } from "../features/alerts/alertsReducer";
import { axeInfo } from "../features/axe/axeReducer";
import { config } from "../features/config/configReducer";
import { counteringInfo } from "../features/countering/counteringReducer";
import { decodes } from "../features/decodes/decodesReducer";
import { mktxBenchmark } from "../features/mktxBenchmark/mktxBenchmarkReducer";
import { orderInfo } from "../features/order/orderReducer";
import { prices } from "../features/prices/pricesReducer";
import { settings } from "../features/settings/settingsReducer";
import { stepper } from "../features/stepper/stepperReducer";
import { tokens } from "../features/tokens/tokensReducer";
import { tradeFormInfo } from "../features/tradeForm/tradeFormReducer";

// cannot use combineReducer here, ATW needs an object literal to combineReducer in ATW side
const appReducer = {
    alerts,
    stepper,
    axeInfo,
    tradeFormInfo,
    orderInfo,
    counteringInfo,
    config,
    mktxBenchmark,
    decodes,
    settings,
    tokens,
    prices
};

export const rootReducer = () => {
    return appReducer;
};
