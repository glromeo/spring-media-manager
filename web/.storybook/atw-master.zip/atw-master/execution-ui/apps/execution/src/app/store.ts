import { configureAtwStore } from "@atw/toolkit";
import { rootReducer } from "./rootReducer";

// When we are running in Cypress or JCEF/Dashboard we have initialState, otherwise it will be undefined -> empty
export const store = configureAtwStore({
    reducer: rootReducer(),
    preloadedState: (window as any).initialState || {}
});

// Expose the store so that it can be accessed by Cypress or JCEF/Dashboard
(window as any).store = store;
