export const TEXT = {
    // ERROR CONSTANTS
    NO_BROKERS_CERTIFIED: "No brokers have been certified for this workflow.",
    // POPUP/REVIEW CONSTANTS
    BROKER_ACCEPTED_TITLE: "Click Accept to Request Fill",
    CONFIRM_PROCEED_TEXT: "Would you still like to proceed?",
    ACK_SEND_BUTTON_LABEL: "Acknowledge & Send",
    CONFIRM_SEND: "Confirm Send",
    CONFIRM_CANCEL: "Confirm Cancel",
    CONFIRM_HIT: "Confirm Hit",
    CONFIRM_LIFT: "Confirm Lift",
    COUNTERING: "Countering",
    SEND: "Send",
    PASS: "Pass",
    NEXT: "Next",
    SPLIT_AND_NEXT: "Split & Next",
    SPLIT_AND_SEND: "Split & Send"   
};

export const CODE = {
    SPOT_NOW: "A"
}

export const STYLE = {
    SIDE_COLUMN_WIDTH: 50,
    SECURITY_COLUMN_WIDTH: 140,
    SIZE_COLUMN_WIDTH: 80,
    SOURCE_COLUMN_WIDTH: 80
};

export const CONFIG = {
    COUNTER_REQUEST_AUTO_CLOSE_SECS: 3,
    TSGOPS: "TSGOPS"
};

export const TIMEZONES = [
    {
        displayValue: "ET",
        isSelected: true,
        value: "America/New_York"
    }
];

export const BROWSER_TITLES = {
    VOICE_STP: "Send Direct to Broker - Voice STP",
    IND_AXE: "Indicative Axe",
    A2A: "Actionable A2A Axe",
    ACTIONABLE: "Actionable Axe"
};
