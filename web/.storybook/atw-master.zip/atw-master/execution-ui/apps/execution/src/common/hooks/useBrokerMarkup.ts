import { useEffect, useState } from "react";
import { useAppSelector } from "../../app";
import { NUM_PLACE_HOLDER, PRICING_TYPE_MAP } from "../../models/common";
import { pricingTypeUtils } from "../utils/pricingTypeUtils";

export const useBrokerMarkup = () => {
    const axeInfo = useAppSelector((state) => state.axeInfo);
    const orderInfo = useAppSelector((state) => state.orderInfo);
    const config = useAppSelector((store) => store.config);
    const countering = useAppSelector((store) => store.counteringInfo?.countering);
    const tradeFormInfo = useAppSelector((state) => state.tradeFormInfo);

    const [brokerFeeValue, setBrokerFeeValue] = useState("");
    useEffect(() => {
        const pricingType = pricingTypeUtils.getCurrentPricingType({ axeInfo, orderInfo, config, countering });
        const bondQuality = PRICING_TYPE_MAP[pricingType];

        const priceOrSpreadValue =
            (bondQuality === PRICING_TYPE_MAP.PRICE ? tradeFormInfo.tradeForm.price : tradeFormInfo.tradeForm.spread) ??
            0;

        let value = "";
        if (priceOrSpreadValue !== NUM_PLACE_HOLDER) {
            let brokerFee = axeInfo.axe.brokerFee;

            const isSpread = bondQuality === PRICING_TYPE_MAP.SPREAD
            if (isSpread) {
                brokerFee = (brokerFee * 1000) / 10;
            }
            
            // TWEB send a signed broker fee so we can always sum, would need
            // to confirm logic if supporting other platforms in the future
            const allInLevel = priceOrSpreadValue + brokerFee;

            value = `${allInLevel} (${brokerFee}${isSpread ? ' bps' : ''} mark-up fee)`;
        }

        setBrokerFeeValue(value);
    }, [axeInfo, orderInfo, config, countering, tradeFormInfo]);

    return brokerFeeValue;
};
