import { Config } from "../../features/config/config";
import { ModeType, WorkflowType } from "../../features/stepper/stepper";
import { BondQuality, NUM_PLACE_HOLDER, Side, STRING_PLACE_HOLDER } from "../../models/common";

export type RefreshActionType = "NOT_SET" | "RELOAD" | "BACK";

// NORMAL - https://tst.blackrock.com/apps/execution/477209185?side=Buy&cusip=02005NBM1&aid=A106709_1474274511_SELL_0_150600_CSus&asize=100000&aprice=101.03&acode=66402&abroker=NYFIXIOI&atime=1624619927000&aquality=ig&aspread=25&ayield=20&abmk=12&user=kburgess
// CARES - http://localhost:3001/517163882?side=Buy&cusip=382550BL4&user=kburgess&workflow=care
export function useSettings(search?: string): Config {
    const getBrokerCode = () => {
        const codes = query.get("acode")!.split(",");
        // for now just return first code
        return parseInt(codes[0]);
    };
    if (search === undefined) search = window.location.search;
    const query = new URLSearchParams(search);
    const isLtx = query.get("ltx") === "true"? true: false 
    return {
        orderNumber: Number(query.get("orderNumber") ?? "0"),
        side: query.get("side") ? (query.get("side")!.toUpperCase() as Side) : "BUY",
        cusip: parseQueryToString(query, "cusip", STRING_PLACE_HOLDER),
        axeId: parseQueryToString(query, "aid", STRING_PLACE_HOLDER),
        axeOrigId: parseQueryToString(query, "aoid", STRING_PLACE_HOLDER),
        axePrice: parseQueryToNumber(query, "aprice", NUM_PLACE_HOLDER),
        axeSpread:
            parseQueryToNumber(query, "aspread", NUM_PLACE_HOLDER) === NUM_PLACE_HOLDER
                ? undefined
                : parseQueryToNumber(query, "aspread", NUM_PLACE_HOLDER),
        axeYield: parseQueryToNumber(query, "ayield", NUM_PLACE_HOLDER),
        axeYieldType: parseQueryToString(query, "aytype", STRING_PLACE_HOLDER),
        axeQuality: query.get("aquality") ? (query.get("aquality")!.toUpperCase() as BondQuality) : STRING_PLACE_HOLDER,
        axePriceType: query.get("apricetype") ?? null,
        axeSize: parseQueryToNumber(query, "asize", NUM_PLACE_HOLDER, true),
        axeMinSize: parseQueryToNumber(query, "aminsize", NUM_PLACE_HOLDER),
        axeCode: query.get("acode") ? getBrokerCode() : NUM_PLACE_HOLDER,
        axeBroker: parseQueryToString(query, "abroker", STRING_PLACE_HOLDER),
        axeBmkId: parseQueryToString(query, "abmk", STRING_PLACE_HOLDER),
        axeExpiryTime: parseQueryToNumber(query, "aexpirytime", NUM_PLACE_HOLDER),
        axeTime: parseQueryToDate(query, "atime", NUM_PLACE_HOLDER),
        axeCounterPartyRating: parseQueryToNumber(query, "acounterpartyrating", NUM_PLACE_HOLDER),
        axeCounterPartyType: parseQueryToString(query, "acounterpartytype", STRING_PLACE_HOLDER),
        axeBrokerFee: parseQueryToNumber(query, "abrokerfee", 0),
        user: parseQueryToString(query, "user", STRING_PLACE_HOLDER),
        workflow: query.get("workflow") ? (query.get("workflow")!.toUpperCase() as WorkflowType) : "NOTSET",
        mode: query.get("mode") ? (query.get("mode")!.toUpperCase() as ModeType) : "NOTSET",
        embedded: !!query.get("embedded"),
        theme: query.get("theme") === "dark" ? "dark" : "light",
        env: query.get("env"),
        placementNumber: parseQueryToNumber(query, "placement", NUM_PLACE_HOLDER),
        ltx:query.get("ltx")? isLtx : false,
        action: "NOT_SET",
        scale: Number(query.get("scale") ?? "1"),
        fetch: NUM_PLACE_HOLDER,
        cancelAutoClose: false,
        debugInfo: false
    };
}

export function parseQueryToString(query: URLSearchParams, param: string, placeholder: string): string {
    return query.get(param) ? query.get(param)! : placeholder;
}

export function parseQueryToNumber(
    query: URLSearchParams,
    param: string,
    placeholder: number,
    isAbsValue?: boolean
): number {
    if (isAbsValue) {
        return query.get(param) && query.get(param) !== "null" ? Math.abs(parseFloat(query.get(param)!)) : placeholder;
    } else {
        return query.get(param) && query.get(param) !== "null" ? parseFloat(query.get(param)!) : placeholder;
    }
}

export function parseQueryToDate(query: URLSearchParams, param: string, placeholder: number): number {
    return query.get(param) ? new Date(query.get(param)!).getTime() : placeholder;
}
