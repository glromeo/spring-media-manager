import { Alert, AlertType } from "../../features/alerts/alert";

export const alertUtils = {
    hasAlertType: (alerts: Alert[], type: AlertType) => {
        return alerts.filter((alert: Alert) => alert.type === type).length > 0;
    },
    hasFatalError: (alerts: Alert[]) => {
        return alertUtils.hasAlertType(alerts, "ALERT");
    },
    hasHardNotification: (alerts: Alert[]) => {
        return alertUtils.hasAlertType(alerts, "ERROR");
    },
    hasSoftNotification: (alerts: Alert[]) => {
        return alertUtils.hasAlertType(alerts, "WARNING");
    },
    hasFatalErrorOrHardNotification: (alerts: Alert[]) => {
        return alertUtils.hasFatalError(alerts) || alertUtils.hasHardNotification(alerts);
    }
};
