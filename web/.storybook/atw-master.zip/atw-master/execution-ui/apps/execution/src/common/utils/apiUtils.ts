import { logClick, logError } from "@atw/toolkit/telemetry";
import { apiFetch, apiGet, apiPost, apiQuery } from "@atw/toolkit/utility/apiUtils";
import { SerializedError } from "@reduxjs/toolkit";
import _ from "lodash";
import {
    GraphQLError,
    GraphQlExecutePlacementQuoteRequest,
    GraphQlExecutePlacementQuoteVariables,
    GraphQLOrderCreationVariables
} from "../../api/types";
import { Alert, AlertType } from "../../features/alerts/alert";
import { Axe } from "../../features/axe/axe";
import { Config } from "../../features/config/config";
import { Countering } from "../../features/countering/countering";
import { Order, Placement, Quote } from "../../features/order/order";
import { TradeForm } from "../../features/tradeForm/tradeForm";
import { NUM_PLACE_HOLDER } from "../../models/common";
import { configUtils } from "./configUtils";
import { genericUtils } from "./genericUtils";
import { pricingTypeUtils } from "./pricingTypeUtils";
import { tradeFormUtils } from "./tradeFormUtils";

export type ApiError = {
    name: string;
    message: string;
};
const UNKNOWN_ERROR: ApiError = {
    name: "Error",
    message: "Failure accessing Aladdin API"
};
const reduceAlertTo = (alerts: Alert[], type: AlertType, name: string, message: string, timeout?: number): Alert[] => {
    return [
        ...alerts,
        {
            id: genericUtils.nextNumber(),
            name,
            message,
            type,
            timeout: timeout ?? 3600000
        }
    ];
};
const toApiError = (error: SerializedError): ApiError => {
    if ("{" === error.message?.charAt(0)) {
        return error.message ? (JSON.parse(error.message) as ApiError) : UNKNOWN_ERROR;
    } else {
        return {
            name: error.name ?? "Aladdin API Error",
            message: error.message ?? "Sorry, no message provided :("
        };
    }
};
export function apiError(name: string, message: string) {
    return { name, message };
}
const EXCLUDED_FIXTURES = ["filesDat"];
const trace = (options: any, text: any) => {
    const fixturePrefix = options?.fixture?.split("/")[0];
    if (EXCLUDED_FIXTURES.includes(fixturePrefix)) return;
    console.log(`fixture: ${options.fixture}, msg: ${text}`);
};

export const apiUtils = {
    apiFetch: async (url: string, options: any = {}) => {
        return apiFetch(url, { trace, ...options });
    },

    apiGet: async <R>(url: string, options: any = {}): Promise<R> => {
        return apiGet(url, { trace, ...options });
    },

    apiPost: async <P, R>(url: string, body: P, options: any = {}): Promise<R> => {
        return apiPost(url, body, { trace, ...options });
    },
    apiQuery: async <V, R>(query: string, variables: V, options: any = {}): Promise<R> => {
        return apiQuery(query, variables, {
            trace,
            ...options
        });
    },

    // Tries to return response as JSON, then as text
    parseFetchResponse: async (response: Response) => {
        const text = await response.text();
        try {
            return JSON.parse(text);
        } catch (err) {
            return text;
        }
    },

    getUnableToFetchMessage: (targetObject: string, identifier?: string | number, identifierName?: string) => {
        let str = "Unable to fetch " + targetObject;
        if (identifierName && identifier) {
            str += " for " + identifierName + ": " + identifier;
        } else if (identifier) {
            str += ": " + identifier;
        }
        return str;
    },

    createOrder: (
        order: Order,
        tradeForm: TradeForm,
        axe: Axe,
        config: Config,
        countering: Countering
    ): GraphQLOrderCreationVariables => {
        const isCares = configUtils.isCares();
        const isSpread = pricingTypeUtils.isSpread(order, axe, config, countering);
        const user = configUtils.getUser();
        const broker = tradeFormUtils.getSelectedBrokerEntity(order, tradeForm)!;
        const desk = tradeFormUtils.getSelectedDesk(broker, tradeForm)!;

        //if axe benchmark exsits ... pass to placement ...else use security benchmark ... (order)
        const orderCreationVariables: GraphQLOrderCreationVariables = {
            request: {
                orderData: {
                    orderNumber: order.id,
                    quantity: tradeForm.size!,
                    lastPrice: order.price === NUM_PLACE_HOLDER ? undefined : order.price,
                    ordType: "L",
                    timeInForce: "0",
                    limitValue: isSpread ? tradeForm.spread! : tradeForm.price!
                },
                broker: broker.name,
                subBrokerID: desk.subBrokerID,
                user: user,
                allocationStrategy: "E",
                strategy: "E",
                percentToPlace: tradeForm.size!,
                limitType: isSpread ? "S" : "P",
                settleDate: tradeForm.settleDate!
            },
            user: user
        };
        if (!isCares) {
            orderCreationVariables.request.externRefID = axe.id;
        }
        if (isSpread) {
            // if spread - don't send lastprice
            delete orderCreationVariables.request.orderData.lastPrice;
            orderCreationVariables.request.spreadIndex = isCares ? order.orderBmkId : axe.axeBmkId;
            orderCreationVariables.request.spotType = tradeForm.spotTimeSelected;     
        }
        return orderCreationVariables;
    },

    createUpdatePlacementQuoteVars: (
        placement: Placement,
        vars: { quantity: number; tradeValue: number; dueInTime?: string }
    ): GraphQlExecutePlacementQuoteVariables => {
        let req: GraphQlExecutePlacementQuoteVariables = {
            request: {
                placementNum: placement.placementNum,
                externId: _.get(_.last(placement.quotes) as Quote, "quoteID"),
                quantity: vars.quantity,
                askPrice: vars.tradeValue,
                bidPrice: vars.tradeValue,
                counterparty: _.get(_.last(placement.quotes), "counterparty.ticker")!
            },
            user: configUtils.getUser()
        };
        if (vars.dueInTime) {
            req.request.dueInTime = vars.dueInTime;
        }
        return req;
    },

    apiError: (name: string, message: string) => {
        return { name, message };
    },

    apiErrors: (alerts: Alert[]) => {
        const thrownAlerts = alerts.map((alert) => {
            return { ...alert, id: genericUtils.nextNumber(), timeout: alert.timeout ?? 3600000 };
        });
        return JSON.stringify(thrownAlerts);
    },

    reduceApiErrorTo:
        (type: AlertType, timeout?: number) => (alerts: Alert[], { error }: { error: SerializedError }): Alert[] => {
            const { name, message } = toApiError(error);
            console.error(`${name}: ${message}`);
            return reduceAlertTo(alerts, type, name, message, timeout);
        },

    reduceApiErrorsToNotification: (alerts: Alert[], { error }: { error: SerializedError }): Alert[] => {
        let thrownAlerts;
        try {
            thrownAlerts = JSON.parse(error.message!);
        } catch {
            thrownAlerts = [{ type: "ERROR", message: error.message! }];
        }
        console.error(error.message!);
        return [...alerts, ...thrownAlerts];
    },

    handleGQLErrorRes: (errors: GraphQLError[], message: string) => {
        let errorMessage = errors.map((m) => {
            return m.message + "\n";
        });
        logError(message, {
            message: errorMessage.toString().trim()
        });
        throw apiUtils.apiError(message, errorMessage.toString().trim());
    },

    HandleInvalidGQLRes: (order: any, req: GraphQlExecutePlacementQuoteRequest, message: string) => {
        logError(message, {
            "order id": order.id,
            "placement no": req.placementNum,
            "quote no": req.externId
        });
        throw new Error(`${message} for order: ${order.id}`);
    },

    logSoftWarningBypass: (alerts: Alert[]) => {
        logClick("User about to Acknowledge & Send");
        console.log("User bypassing soft warnings: [" + alerts.map((a) => a.type + ": " + a.message).join(", ") + "]");
    }
};
