import { useSettings } from "../hooks/useSettings";
import { configUtils } from "./configUtils";

export const axeUtils = {
    isIndAxe: function isIndAxe(): boolean {
        return this.isCounteringModeIndicative();
    },
    isCounteringModeIndicative(): boolean {
        return configUtils.isCounteringModeOnly(useSettings());
    }
};
