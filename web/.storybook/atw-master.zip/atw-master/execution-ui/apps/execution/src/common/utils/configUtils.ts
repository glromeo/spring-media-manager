import { Config } from "../../features/config/config";
import { useSettings } from "../hooks/useSettings";

export const configUtils = {
    getUser: () => {
        return useSettings().user;
    },

    getPlacementNumber: (): number => {
        return useSettings().placementNumber;
    },

    isCares: () => {
        return useSettings().workflow === "CARE";
    },

    isCounteringMode: (config: Config) => config.mode === "COUNTERING" || configUtils.isCounteringModeOnly(config),

    isCounteringModeOnly: (config: Config) => config.mode === "COUNTERING_ONLY",

    isAxeA2AMode: () => useSettings().mode === "AXE_A2A",

    isLtxMode: () => useSettings().ltx
};
