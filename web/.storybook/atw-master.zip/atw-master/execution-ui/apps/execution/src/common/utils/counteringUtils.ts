import { GraphQLPlacementQuote } from "../../api/types";
import { Alert } from "../../features/alerts/alert";
import {
    Countering,
    CounteringHistory,
    CounteringState,
    DEAD_NEGOTIATION_STATES,
    LIVE_NEGOTIATION_STATES,
    PASSING_STATES
} from "../../features/countering/countering";
import { Order, Placement, Quote } from "../../features/order/order";
import { BondQuality, HIGH_YIELD, INVESTMENT_GRADE, STRING_PLACE_HOLDER } from "../../models/common";
import { configUtils } from "./configUtils";
import { genericUtils } from "./genericUtils";
import { orderUtils } from "./orderUtils";
import { pricingTypeUtils } from "./pricingTypeUtils";

const { formatSize } = genericUtils;

export const counteringUtils = {
    getLastHistoryFromPlacement: (placement: Placement, usePlacementQuality?: boolean): CounteringHistory | null => {
        if (placement?.quotes && placement.quotes.length > 0) {
            const lastQuote = placement.quotes[placement.quotes.length - 1];
            if (lastQuote) {
                const negotiationQuality = usePlacementQuality
                    ? pricingTypeUtils.getQualityFromPlacement(placement)
                    : pricingTypeUtils.getQualityFromPlacementQuote(lastQuote);
                const priceVal = negotiationQuality == INVESTMENT_GRADE ? lastQuote.spread : lastQuote.price;
                return {
                    value: priceVal,
                    size: lastQuote.quantity,
                    quality: negotiationQuality || HIGH_YIELD,
                    status: ""
                };
            }
        }
        return null;
    },

    formatHistoryPriceBasedOnQuality: (history: CounteringHistory, quality: BondQuality): string => {
        if (!history?.value) return STRING_PLACE_HOLDER;
        return quality == INVESTMENT_GRADE
            ? genericUtils.formatSpread(history.value)
            : `$${genericUtils.formatPrice(history.value)}`;
    },

    isLiveNegotiationState: (state: CounteringState) => {
        return LIVE_NEGOTIATION_STATES.includes(state);
    },

    isPassingState: (state: CounteringState) => {
        return PASSING_STATES.includes(state);
    },

    isDeadNegotiationState: (state: CounteringState) => {
        return DEAD_NEGOTIATION_STATES.includes(state);
    },

    getValidQuote: (placement: Placement, orderSide: Order["side"]): Quote | undefined => {
        return placement.quotes.find((quote) => {
            const brokerMatch =
                quote.counterparty.code && placement.broker.code && quote.counterparty.code === placement.broker.code;
            const sideMatch =
                (orderSide == "BUY" && quote.side === "ASK") || (orderSide === "SELL" && quote.side === "BID");

            return brokerMatch && sideMatch;
        });
    },
    getMostRecentPlacementNumber: (placementQuotes: GraphQLPlacementQuote[]): { placementNum: number } => {
        const eligiblePlacements = placementQuotes[0].placements.filter((p) => {
            const validAxe = p.axeID !== null; //
            const validPlacementType = p.type?.toUpperCase() === "RFQ" || p.type?.toUpperCase() === "RFQW"; // type = RFQ or RFQW
            const validModifiedBy = p.modifiedBy?.toLowerCase() === configUtils.getUser().toLowerCase(); // modifiedBy = user
            return validAxe && validPlacementType && validModifiedBy;
        });
        return eligiblePlacements.sort((a, b) => b.placementNum - a.placementNum)[0];
    },
    getCounteringNotifications: (order: Order, countering: Countering): Alert[] => {
        // if we want type warning notifications, will have to handle it with more logic below
        let alerts: Alert[] = [];
        const errorAlert: Alert = {
            id: 1,
            name: "Errors - Please Reach out to Aladdin Support",
            message: [],
            type: "ERROR"
        };
        errorAlert.message = [];
        const { message } = errorAlert;

        const placement = orderUtils.getPlacement(order, countering.placementNum);
    const quote = counteringUtils.getValidQuote(placement!, order.side);

        if (quote) {
            if (quote.quantity > order.orderLeaves) {
                message.push(
                    `Broker ${quote.counterparty?.ticker} countered with size greater than order leaves: ${formatSize(
                        quote.quantity
                    )} > ${formatSize(order.orderLeaves)}`
                );
            }
        }

        if (message.length === 1) {
            errorAlert.message = message[0];
            alerts.push(errorAlert);
        } else if (errorAlert.message.length > 1) {
            alerts.push(errorAlert);
        }

        return alerts;
    },
    checkQuoteValidity: (order: Order, placementNum: number): void => {
        const placement = orderUtils.getPlacement(order, placementNum);
        let error = {};

        if (!placement) throw { message: `No Placement Found` };
        if (!placement.quotes) throw { message: "No Quote Found" };

        const validQuote = placement.quotes.find((quote) => {
            // as long as one quote is valid we are good, if all have issues then throw error
            const brokerMatch =
                quote.counterparty.code && placement.broker.code && quote.counterparty.code === placement.broker.code;
            const sideMatch =
                (order.side == "BUY" && quote.side === "ASK") || (order.side === "SELL" && quote.side === "BID");
            
            if (!quote.counterparty.code || !placement.broker.code) {
                error = {
                    title: "No Valid Broker Found",
                    message: "Broker code mapping not configured. Please contact Aladdin Support."
                };
                return;
            }
            if (!brokerMatch) {
                error = {
                    title: "No Valid Quote Found",
                    message: "There is a broker mismatch. Please contact Aladdin Support."
                };
                return;
            }
            if (!sideMatch) {
                error = {
                    title: "No Valid Quote Found",
                    message: "There are no matching quotes for the order side. Please contact Aladdin Support."
                };
                return;
            }

            return brokerMatch && sideMatch;
        });

        if (!validQuote) {
            throw error;
        }
    }
};
