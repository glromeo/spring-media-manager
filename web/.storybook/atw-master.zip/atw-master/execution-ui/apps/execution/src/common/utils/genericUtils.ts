/****************************
 ***** GENERIC UTILS ********
 ****************************/

import { NUM_PLACE_HOLDER, Side, STRING_PLACE_HOLDER } from "../../models/common";
import { logClick, logView } from "@atw/toolkit/telemetry/index";
import { ModeType } from "../../features/stepper/stepper";
import { OrderInfo } from "../../features/order/order";

let _nextNumber = 1;
type FormatDateConfig = { fullYear: boolean; month?: "short" | "number"; separator?: "slash" | "dash" };

export const genericUtils = {
    updateBrowserTitle: (newTitle: string) => (document.title = newTitle),
    nextNumber: () => {
        return _nextNumber++;
    },

    formatSize: (size: number, decimals?: number): string => {
        let num = Math.abs(size).toString();
        if (decimals) num = size.toFixed(decimals);
        return num.replace(/\B(?=(\d{3}){1,25}(?!\d))/g, ",");
    },
    isValidNumber: (num: any): boolean => {
        return !Number.isNaN(Number.parseFloat(num)) && num !== NUM_PLACE_HOLDER;
    },
    isValidString: (string: any): boolean => {
        return string !== STRING_PLACE_HOLDER;
    },
    removeCommas: (val: string): string => {
        // eslint-disable-next-line
        return val.replace(/[^0-9\.-]/g, "");
    },

    removeSpace: (val: string, lowerCase: boolean = true): string => {
        // eslint-disable-next-line
        const newVal = val.replace(/\s/g, "");
        return lowerCase ? newVal.toLowerCase() : newVal;
    },

    titleCase: (val: string): string => {
        if (val === null || val === undefined || val === "") return "";
        else val = val.toString();

        return val.replace(/\w\S*/g, function (txt) {
            return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
        });
    },

    formatDate: (
        val: string | undefined,
        dateConfig: FormatDateConfig = { fullYear: true, month: "number", separator: "slash" }
    ): string | undefined => {
        const { fullYear, month, separator } = dateConfig;
        let dateString: string = STRING_PLACE_HOLDER;
        let formattedMonth: string = STRING_PLACE_HOLDER;
        let date: Date = val ? new Date(val) : new Date();
        let formattedDay = ("0" + date.getDate()).slice(-2);
        if (month === "short") formattedMonth = date.toLocaleString("en-US", { month: "short" });
        if (month === "number" || month === undefined) formattedMonth = ("0" + (date.getMonth() + 1)).slice(-2);
        let formattedYear = fullYear ? date.getFullYear() : date.getFullYear().toString().substr(2, 2);
        if (separator === "dash") {
            dateString =
                formattedDay + STRING_PLACE_HOLDER + formattedMonth.toUpperCase() + STRING_PLACE_HOLDER + formattedYear;
        }
        if (separator === "slash" || separator === undefined) {
            dateString = formattedMonth + "/" + formattedDay + "/" + formattedYear;
        }
        return dateString;
    },

    getTodaysDate: (isFullYear: boolean) => {
        return genericUtils.formatDate(undefined, { fullYear: isFullYear });
    },

    getCurrentTime: (timeZone: string = "") => {
        return new Date().toLocaleTimeString("en-US", {
            hour12: true,
            hour: "2-digit",
            minute: "2-digit",
            timeZone
        });
    },

    getYesterdaysDateAsEpoch: () => {
        const today = new Date();
        const yesterday = new Date(new Date(today).setDate(new Date(today).getDate() - 1));
        const fullYear = yesterday.getFullYear();
        const month = yesterday.getMonth();
        const day = yesterday.getDate();
        const epoch = new Date(fullYear, month, day).getTime();
        return epoch;
    },

    convertHHmmToDate: (hourMins: string | null, baseDate?: Date | null): Date | null => {
        // sets current computer location's date with inputted time
        if (!hourMins || hourMins === STRING_PLACE_HOLDER) {
            return null;
        }

        if (!baseDate) {
            baseDate = new Date();
        }

        const [time, am] = hourMins.trim().split(/\ +/);
        let [h, minutes] = time.split(":");
        let hours = +h;
        if (hours === 12) {
            if (am.toLowerCase() === "am") {
                hours = 0;
            }
        }
        if (am.toLowerCase() === "pm" && hours !== 12) {
            hours += 12;
        }
        baseDate.setHours(+hours);
        baseDate.setMinutes(+minutes);
        baseDate.setSeconds(0);
        return baseDate;
    },

    formatPrice: (price: number): string => {
        return price !== null ? genericUtils.convertToMinPrecision(price, 3) : STRING_PLACE_HOLDER;
    },

    formatSpread: (spread: number): string => {
        if (genericUtils.isValidNumber(spread)) {
            const prefix = spread > 0 ? `+` : ``;
            return `${prefix}${genericUtils.convertToMinPrecision(spread, 3)}`;
        }
        return STRING_PLACE_HOLDER;
    },

    convertToMinPrecision: (num: number, minPrecision: number, maxPrecision?: number): string => {
        return Intl.NumberFormat("en-US", {
            minimumFractionDigits: minPrecision,
            maximumFractionDigits: maxPrecision || 20 // max allowed is 20
        }).format(num);
    },

    getSideTitle: (side: Side) => {
        return side === "BUY" ? "Lift" : "Hit";
    },

    getTimeDiff: (t1: Date, t2: Date): number => {
        let dif = t1.getTime() - t2.getTime();
        return dif / 1000;
    },

    getConvertedDueTime: (offsetMins?: number) => {
        // get current time
        let currentTime = "";
        if (offsetMins) {
            currentTime = new Date(new Date().getTime() + offsetMins * 60_000).toLocaleTimeString("en-US", {
                hourCycle: "h23",
                timeZone: "America/New_York"
            });
        } else {
            currentTime = new Date().toLocaleTimeString("en-US", { hourCycle: "h23", timeZone: "America/New_York" });
        }
        return currentTime + "|America/New_York";
    },

    getCurrentDateInTZ: (tz: string) => {
        return new Date(new Date().toLocaleString("en-US", { hourCycle: "h23", timeZone: tz }));
    },

    convertTZ(date: string | Date | null, tzString: any) {
        if (date) {
            return new Date(
                (typeof date === "string" ? new Date(date) : date).toLocaleString("en-US", { timeZone: tzString })
            );
        }
        return null;
    },

    sortSpotTimes: (times: string[]) => {
        times = times.filter((itm) => itm !== "Spot Now");
        let formData = times.map((itm) => {
            let tm = itm.replace("ET", "");
            if (tm.includes("am")) {
                if (!tm.includes(":")) tm = parseInt(tm) + ":00 am";
                else tm = tm.replace("am", " am");
            } else {
                if (!tm.includes(":")) tm = parseInt(tm) + ":00 pm";
                else tm = tm.replace("pm", " pm");
            }
            return tm.trim();
        });
        let sortedTimes = formData.sort(
            (a: string, b: string) => new Date("1970/01/01 " + a).getTime() - new Date("1970/01/01 " + b).getTime()
        );
        sortedTimes = sortedTimes.map((itm) => {
            return itm.replace(":00 ", "").replace(" am", "am").replace(" pm", "pm") + " ET";
        });
        sortedTimes.unshift("Spot Now");
        return sortedTimes;
    },

    convertTimeToDate: (time: number | null | undefined, timezone: string): Date | null => {
        if (time === null || time === undefined) return null;
        return new Date(
            new Date(time).toLocaleString("en-us", {
                hourCycle: "h23",
                timeZone: timezone
            })
        );
    },

    wait: async (ms: number) => {
        return new Promise<boolean>((resolve) => {
            setTimeout(() => resolve(true), ms);
        });
    },

    getAppname: () => {
        return "execution";
    },

    dumpStore: () => {
        console.log(`redux: ${JSON.stringify((window as any).store.getState())}`);
    },

    isNumPlaceHolder: (num?: number) => {
        return num === NUM_PLACE_HOLDER;
    },

    isFloat: (value: number | string) => {
        return Number(value) === value && value % 1 !== 0;
    },
    logTelemetryView(workflow: string, mode: ModeType) {
        let init: string = "";
        if (workflow === "CARE" && mode === "NOTSET") init = "Voice STP";
        if (workflow === "EXECUTION") {
            if (mode === "NORMAL") init = "HIT/LIFT";
            if (mode === "COUNTERING_ONLY" || mode === "COUNTERING") init = "Countering";
            if (mode === "AXE_A2A") init = "A2A";
        }
        logView(`User Initialized Execution in ${init}`);
    },
    logTelemetryClick(label: string, field: string, newValue: string | object) {
        logClick(`User changed ${label}`, { [field]: newValue });
    },
    isRestrictedBrokerSelected: (orderInfo: OrderInfo) => {
        return orderInfo.order.broker.selectedRestrictedBroker !== undefined;
    }
};
