import { Broker, BrokerEntity, BrokerRestrictionAllocation, Desk, Order, Placement } from "../../features/order/order";
import { genericUtils } from "./genericUtils";
import { SecurityOption } from "@atw/toolkit";

export const orderUtils = {
    isFullyRestricted: (entity: BrokerEntity) => entity?.restriction?.quantity === 0,

    isFullyAvailable: (entity: BrokerEntity) =>
        entity?.restriction?.allocation.filter((allocation) => allocation.isRestricted).length === 0,

    getRestrictedBrokerEntities: (order: Order) => {
        const entities = order.broker.entity.filter((e) => orderUtils.isRestrictedBrokerEntity(e));
        return entities.length;
    },

    isRestrictedBrokerEntity: (entity: BrokerEntity): boolean => {
        if (!entity.restriction) return false;
        return entity.restriction.percent !== 100;
    },

    getSelectedBrokerEntity: (broker: Broker, selectedBroker: string) =>
        broker.entity.find((entity) => entity.name === selectedBroker),

    isAllocated: (allocations: BrokerRestrictionAllocation[], code: number) =>
        allocations.find((allocation) => allocation.code === code) !== undefined,

    isBrokerCounterEnabled: (entities: BrokerEntity[], brokerName: string) => {
        return entities.find((entity: BrokerEntity) => entity.name === brokerName)?.isCounteringEnabled;
    },

    hasBrokerRestrictions: (order: Order) => {
        const entities = order.broker.entity.filter((entity: BrokerEntity) => {
            if (!entity.restriction) return false;
            const restricted = entity.restriction.allocation.filter((allocation) => allocation.isRestricted);
            return restricted.length > 0;
        });
        return entities.length > 0;
    },

    getDeskBySubBrokerId: (order: Order, subBrokerId: number): Desk | undefined => {
        const findDesk = (desks: Desk[]) => {
            return desks.find((desk) => desk.subBrokerID === subBrokerId);
        };
        for (let entity of order.broker.entity) {
            const desk = findDesk(entity.desk);
            if (desk !== undefined) return desk;
        }
        return undefined;
    },

    getPlacement: (order: Order, placementNumber: number): Placement | undefined => {
        if (order.placements === undefined || order.placements.length === 0) return undefined;
        return order.placements?.find((placement) => {
            if (placement.placementNum === placementNumber) return placement;
            return undefined;
        });
    },

    // formats text from TREASURY NOTE 1.625 15-MAY-2031 to TNOTE 1.625 05/15/31
    formatSecLookupDesc: (security: SecurityOption) => {
        const dateRegex = /\d{2}-[A-Z]{3}-\d{4}/g;
        const couponValueRegex = /\d{1,10}\.\d{1,10}/g;
        const { ticker } = security;
        const date = security.desc1.match(dateRegex)?.[0];
        const couponValue = security.desc1.match(couponValueRegex)?.[0] || "0.0";

        if (ticker && date && couponValue) {
            const formattedDate = genericUtils.formatDate(date, { fullYear: false });
            return `${security.ticker} ${couponValue} ${formattedDate}`
        }

        return security.desc1;
    }
};
