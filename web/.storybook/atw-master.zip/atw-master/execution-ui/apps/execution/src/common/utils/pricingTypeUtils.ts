import { Axe, AxeInfo } from "../../features/axe/axe";
import { Config } from "../../features/config/config";
import { Countering } from "../../features/countering/countering";
import { Order, OrderInfo, Placement, Quote } from "../../features/order/order";
import { BondQuality, HIGH_YIELD, INVESTMENT_GRADE, PRICE, SPREAD } from "../../models/common";
import { configUtils } from "./configUtils";
import { counteringUtils } from "./counteringUtils";
import { orderUtils } from "./orderUtils";

type Slice = {
    orderInfo: OrderInfo;
    countering?: Countering;
    axeInfo: AxeInfo;
    config: Config;
};

export const pricingTypeUtils = {
    getCurrentPricingType: (slice: Slice): typeof PRICE | typeof SPREAD => {
        let { orderInfo, countering, axeInfo, config } = slice;
        let quality: BondQuality | null = "-";
        if (configUtils.isAxeA2AMode()) {
            quality = pricingTypeUtils.getQualityFromAxePriceType(slice);
        } else if (countering) {
            const placement: Placement | undefined = orderUtils.getPlacement(orderInfo.order, countering.placementNum);
            quality = counteringUtils.isLiveNegotiationState(countering.prevState)
                ? pricingTypeUtils.getQualityFromPlacement(placement!)
                : pricingTypeUtils.getQualityFromAxeOrUser(axeInfo, orderInfo, config);
        }

        return quality === HIGH_YIELD ? PRICE : SPREAD;
    },

    getQualityFromAxePriceType: (slice: Slice): BondQuality => {
        const { orderInfo, axeInfo, config } = slice;
        if (config.axePriceType !== null) {
            const axePriceType: string = config.axePriceType;
            if (axePriceType === "AXE_PRICE_TYPE_PRICE") {
                return HIGH_YIELD;
            }

            if (axePriceType === "AXE_PRICE_TYPE_SPREAD") {
                return INVESTMENT_GRADE;
            }
        }

        return pricingTypeUtils.getQualityFromAxeOrUser(axeInfo, orderInfo, config);
    },

    isSpread: (order: Order, axe: Axe, config: Config, countering?: Countering, placement?: Placement) => {
        if (placement) {
            return placement.limitType === SPREAD;
        }

        return (
            pricingTypeUtils.getCurrentPricingType({
                axeInfo: { axe: axe, schema: [] },
                orderInfo: { order: order, schema: [] },
                countering,
                config
            }) === SPREAD
        );
    },

    getQualityFromAxeOrUser: (axeInfo: AxeInfo, orderInfo: OrderInfo, config: Config) => {
        if (config.axeQuality) {
            return config.axeQuality;
        }

        if (configUtils.isCares()) {
            return orderInfo.order.quality;
        }

        return axeInfo.axe.quality;
    },

    getQualityFromPlacementQuote: (quote: Quote): BondQuality | null => {
        if (!quote?.type) return null;
        return quote.type.toUpperCase() === "PRICE" ? HIGH_YIELD : INVESTMENT_GRADE;
    },

    getQualityFromPlacement: (placement: Placement): BondQuality | null => {
        if (!placement?.limitType) return null;
        return placement.limitType.toUpperCase() === "PRICE" ? HIGH_YIELD : INVESTMENT_GRADE;
    }
};
