import { Settings } from "../../features/settings/settings";
import { KeyValueNumber } from "../../models/common";

export const settingsUtils = {
    getDeskSettings: (settings: Settings) => {
        if (settings.desks === "") return {};
        const desks: KeyValueNumber = JSON.parse(settings.desks);
        return desks;
    }
};
