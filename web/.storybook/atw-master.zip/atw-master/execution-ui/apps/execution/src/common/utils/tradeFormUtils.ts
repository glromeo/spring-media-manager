import { BrokerEntity, Desk, Order } from "../../features/order/order";
import { TradeForm } from "../../features/tradeForm/tradeForm";
import { STRING_PLACE_HOLDER } from "../../models/common";
import { configUtils } from "./configUtils";
import { orderUtils } from "./orderUtils";

export const tradeFormUtils = {
    getSelectedBrokerEntity: (order: Order, tradeForm: TradeForm) =>
        order.broker.entity.find((entity: BrokerEntity) => entity.name === tradeForm.brokerSelected!),

    getSelectedDesk: (broker: BrokerEntity, tradeForm: TradeForm) =>
        broker.desk.find((desk: Desk) => tradeFormUtils.getDeskKey(desk) === tradeForm.deskSelected),

    getDeskKey: (desk: Desk) => `${desk.brokerType} - ${desk.salesman}`.trim(),

    getBrokerNames: (order: Order): string[] => {
        return order.broker.entity.filter((entity) => entity.name !== STRING_PLACE_HOLDER).map((entity) => entity.name);
    },
    getDesks: (order: Order, broker: string): string[] => {
        const entity = order.broker.entity.find((ent) => ent.name === broker);
        if (entity === undefined) return [];
        return entity.desk.map((desk) => tradeFormUtils.getDeskKey(desk));
    },
    getDefaultDesk: (order: Order, broker: string): string => {
        const entity = order.broker.entity.find((entity) => entity.name === broker);
        if (entity === undefined) return "";
        let desk = entity.desk[0];
        if (entity.defaultDesk === undefined) return tradeFormUtils.getDeskKey(desk);
        desk = entity.desk[entity.defaultDesk];
        return tradeFormUtils.getDeskKey(desk);
    },
    getDefaultSelectedBroker: (order: Order) => {
        const brokers = tradeFormUtils.getBrokerNames(order);
        if (orderUtils.hasBrokerRestrictions(order)) {
            if (order.broker.selectedRestrictedBroker === undefined && configUtils.isCares())
                return STRING_PLACE_HOLDER;
            const idx = order.broker.selectedRestrictedBroker!;
            return brokers[idx];
        } else {
            if (configUtils.isCares()) return STRING_PLACE_HOLDER;
            return brokers[0];
        }
    },
    getDefaultTradeForm: (order: Order): TradeForm => {
        const brokers = tradeFormUtils.getBrokerNames(order);
        const brokerSelected = tradeFormUtils.getDefaultSelectedBroker(order);
        const desks = tradeFormUtils.getDesks(order, brokerSelected);
        const deskSelected = tradeFormUtils.getDefaultDesk(order, brokerSelected);
        return {
            broker: brokers,
            desk: desks,
            settleDate: order.settleDate,
            brokerSelected: brokerSelected,
            deskSelected: deskSelected,
            hasValidData: true
        };
    }
};
