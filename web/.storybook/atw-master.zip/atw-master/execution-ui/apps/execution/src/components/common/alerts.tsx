import {
    AuxButton,
    AuxButtonTypeEnum,
    AuxDialog,
    AuxModal,
    AuxNotificationClosedDetailInterface,
    AuxNotificationGroup,
    AuxNotificationGroupConfig,
    AuxNotificationGroupTypeEnum,
    AuxNotificationStyleEnum
} from "@blk/aladdin-react-components-es";
import React, { useMemo } from "react";
import ReactDOM from "react-dom";
import { useAppDispatch, useAppSelector } from "../../app";
import { windowUtils } from "../../common/utils/index";
import { Alert } from "../../features/alerts/alert";
import { clearAlert } from "../../features/alerts/alertsActions";

export function Alerts() {
    const dispatch = useAppDispatch();
    const alerts = useAppSelector((state) => state.alerts);
    const getType = (alert: Alert): AuxNotificationStyleEnum => {
        // why can't I do a pick here?
        switch (alert.type) {
            case "ERROR":
                return "error" as AuxNotificationStyleEnum;
            case "WARNING":
                return "warning" as AuxNotificationStyleEnum;
            case "SUCCESS":
                return "success" as AuxNotificationStyleEnum;
            default:
                return "message" as AuxNotificationStyleEnum;
        }
    };
    const notificationConfig: AuxNotificationGroupConfig[] = useMemo(() => {
        return alerts
            .filter((alert) => alert.type !== "ALERT" && alert.type !== "PROMPT")
            .map((alert) => ({
                id: String(alert.id),
                header: alert.name,
                message: alert.message,
                toastTimeout: alert.timeout,
                notificationStyle: getType(alert),
                eventData: alert.id,
                showCloseIcon: true
            }));
    }, [alerts]);
    const RenderMessage = (message: string) => {
        const lines = message.split("\n");
        return (
            <React.Fragment>
                {lines.map((line, i) => {
                    return line.length === 0 ? <br key={i}></br> : <div key={i}>{line}</div>;
                })}
            </React.Fragment>
        );
    };

    const RenderNotifications = () => {
        if (notificationConfig.length === 0) {
            return null;
        }

        const onClose = (event: CustomEvent<AuxNotificationClosedDetailInterface>) => {
            dispatch(clearAlert(event.detail.eventData));
        };

        return (
            <div className="notifications-container">
                <div className="notifications__group-container">
                    <AuxNotificationGroup
                        key="alert-notifications"
                        data-test-id="alerts-notification-group"
                        config={notificationConfig}
                        openOnLoad
                        onNotificationClosed={onClose}
                        type={AuxNotificationGroupTypeEnum.WIDGET_INLINE}
                    />
                </div>
            </div>
        );
    };

    const RenderPrompts = () => {
        const onNo = () => {
            windowUtils.closeWindow("user clicked no on an alert");
        };
        const onYes = () => {
            dispatch(clearAlert(_prompts[0].id!));
        };
        const getPrompts = () => alerts.filter((alert) => alert.type === "PROMPT");
        const _prompts = getPrompts();
        if (_prompts.length === 0) return null;
        // render only 1 at a time
        return ReactDOM.createPortal(
            <AuxModal closeAllModalsOnEscape={false} header={_prompts[0].name} type="action" isOpen={true}>
                <div data-test-id="prompt" slot="content" className="trade-confirmation-modal">
                    {RenderMessage(_prompts[0].message as string)}
                </div>
                <AuxButton
                    data-test-id="promptpopupyesbutton"
                    label="Yes"
                    onClick={onYes}
                    slot="primary-button"
                    isDisabled={false}
                />
                <AuxButton
                    data-test-id="promptpopupnobutton"
                    label="No"
                    onClick={onNo}
                    slot="secondary-button"
                    type={AuxButtonTypeEnum.SECONDARY}
                    isDisabled={false}
                />
            </AuxModal>,
            document.body
        );
    };
    const RenderAlerts = () => {
        // these are fatal alerts
        const onOk = () => {
            windowUtils.closeWindow("user clicked OK on an alert");
        };
        const getAlerts = () => alerts.filter((alert) => alert.type === "ALERT");
        const _alerts = getAlerts();
        if (_alerts.length === 0) return null;

        // render only 1 at a time
        return ReactDOM.createPortal(
            <AuxDialog
                data-test-id="alert-dialog"
                header={_alerts[0].name}
                isOpen={true}
                onDialogClosed={onOk}
                primaryButtonLabel="OK"
                type="alert"
            >
                <div className="trade-confirmation-modal" data-test-id="confirmation-popup">
                    <div className="dialogmessage" data-test-id="alert-dialog-message">
                        {RenderMessage(_alerts[0].message as string)}
                    </div>
                </div>
            </AuxDialog>,
            document.body
        );
    };
    return (
        <React.Fragment>
            {RenderNotifications()}
            {RenderPrompts()}
            {RenderAlerts()}
        </React.Fragment>
    );
}
