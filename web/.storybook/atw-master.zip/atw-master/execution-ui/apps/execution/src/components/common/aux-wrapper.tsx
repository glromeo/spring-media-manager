import { querySelectorAllDeep } from "query-selector-shadow-dom";
import React, { useEffect } from "react";
import { useIntersectionObserver } from "react-intersection-observer-hook";

export type AuxWrapperType = {
    size: number;
    children: JSX.Element;
    selector?: string;
};

/**
 * DEPRECATED: We cannot pay the price of javascripting into the shadow dom of the aux components this way...
 * this is the stuff that makes out UIs clunky
 *
 * AUX components will be replaced by ad hoc Atx components...this wrapper is left here just to avoid
 * messing up with execution/single RFQ right now
 *
 * There are two copies of it in execution and rfq-single because I don't want this stuff to pollute @atx/commons
 *
 * @param size
 * @param selector
 * @param children
 * @constructor
 */
export const AuxWrapper: React.FC<AuxWrapperType> = ({ size, selector, children }) => {
    const [ref, { entry }] = useIntersectionObserver();
    const isVisible = entry && entry.isIntersecting;
    const shadowSelector = selector ?? "button";

    const hasShadow = (node: HTMLElement) => {
        const shadow = node.shadowRoot;
        return shadow && shadow.childNodes.length > 0;
    };
    const setSize = (node: HTMLElement) => {
        const nodes = querySelectorAllDeep(shadowSelector, node);
        nodes.forEach((element) => {
            element.style.width = size + "px";
            element.style.display = "inline-block";
        });
    };
    useEffect(() => {
        if (isVisible) {
            // we now need to dip into shadow - and look for the controling element ...and set size
            const child = entry.target.firstChild as HTMLElement;
            if (child) {
                if (!hasShadow(child)) {
                    // may take a sec for aux to build out shadow dom - unfortunately we can only seem to poll for it ...
                    const handle = setInterval(() => {
                        if (hasShadow(child)) {
                            setSize(child);
                            clearInterval(handle);
                        }
                    }, 50);
                } else {
                    setSize(child);
                }
            }
        }
    }, [isVisible, entry]);

    return (
        <div style={{ display: "inline" }} ref={ref}>
            {children}
        </div>
    );
};
