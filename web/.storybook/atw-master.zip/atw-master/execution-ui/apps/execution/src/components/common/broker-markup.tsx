import { AuxTextInput } from "@blk/aladdin-react-components-es";
import { useBrokerMarkup } from "../../common/hooks/useBrokerMarkup";
import { StepperState } from "../../features/stepper/stepper";

type BrokerMarkupProps = {
    state?: StepperState.Order | StepperState.Review;
    dataTestID?: string;
};

export const BrokerMarkup = ({ state = StepperState.Order, dataTestID }: BrokerMarkupProps) => {
    const brokerMarkupValue = useBrokerMarkup();

    if (state === StepperState.Order) {
        return <AuxTextInput data-test-id={dataTestID} isDisabled textAlign="right" value={brokerMarkupValue} />;
    } else {
        return <>{brokerMarkupValue}</>;
    }
};
