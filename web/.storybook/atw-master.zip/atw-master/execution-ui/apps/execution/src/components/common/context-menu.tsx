import { useCallback } from "react";

import {
    AtwContextMenu,
    AtwContextMenuCopy,
    AtwContextMenuCopyEvent,
    AtwContextMenuGroup,
    AtwContextMenuItem,
    copyToClipboard,
    hasSearchParam
} from "@atw/toolkit";
import { useAppDispatch } from "../../app";
import { setDebugInfo } from "../../features/config/configActions";

export const ContextMenu = () => {
    const dispatch = useAppDispatch();
    const isEmbedded = hasSearchParam("embedded");

    const onCopy = useCallback((evt: AtwContextMenuCopyEvent) => {
        copyToClipboard({ text: evt.detail.selection });
    }, []);

    const onClickDebug = () => {
        dispatch(setDebugInfo(true));
    };

    return isEmbedded ? (
        <div data-test-id="context-menu">
            <AtwContextMenu>
                <AtwContextMenuGroup>
                    <AtwContextMenuCopy onClick={onCopy} />
                </AtwContextMenuGroup>
                <AtwContextMenuItem onClick={onClickDebug} label={"Debug Info"} />
            </AtwContextMenu>
        </div>
    ) : null;
};
