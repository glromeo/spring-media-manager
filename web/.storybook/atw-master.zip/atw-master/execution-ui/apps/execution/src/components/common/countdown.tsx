import { useEffect, useRef, useState } from "react";
import { genericUtils } from "../../common/utils";

export function CountDown({
    timer,
    title = "Good For ",
    type = "basic",
    onCountDownEnd
}: {
    timer: number;
    title?: string;
    type?: string;
    onCountDownEnd?: Function;
}) {
    const [countDownTriggered, setCountDownTriggered] = useState(false);
    const getSecondsLeft = () => {
        if (!genericUtils.isValidNumber(timer)) return undefined;
        let gmtTime = new Date(timer);
        let seconds = genericUtils.getTimeDiff(gmtTime, new Date());
        if (seconds > 0) {
            return Math.round(seconds);
        } else {
            return 0;
        }
    };
    const stopCountdown = () => {
        clearInterval(nodeTimer.current);
        nodeTimer.current = undefined;
    };
    const [countDown, setCountDown] = useState(() => getSecondsLeft());
    const nodeTimer = useRef<NodeJS.Timer>();
    useEffect(() => {
        const secondsLeft = getSecondsLeft();
        setCountDown(secondsLeft);
        if (genericUtils.isValidNumber(secondsLeft)) {
            if (secondsLeft! > 0) {
                nodeTimer.current = setInterval(() => {
                    setCountDown(getSecondsLeft());
                }, 1 * 1000);
            }
            return () => {
                if (genericUtils.isValidNumber(nodeTimer.current)) clearInterval(nodeTimer.current);
            };
        }
    }, [timer]);
    useEffect(() => {
        if (genericUtils.isValidNumber(countDown)) {
            if (countDown! > 0 && !countDownTriggered) {
                setCountDownTriggered(true);
            }
            if (countDown === 0) {
                if (typeof onCountDownEnd === "function") {
                    onCountDownEnd(countDownTriggered);
                }
                stopCountdown();
            }
        }
    }, [countDown]);
    const secondsToTime = (secs?: number) => {
        if (!genericUtils.isValidNumber(secs) || secs! <= 0) {
            return "00:00";
        }
        let str = new Date(secs! * 1000).toISOString();
        if (secs! < 3600) return str.substring(14, 19); // MM:SS
        return str.substring(11, 19); // HH:MM:SS
    };
    return (
        <div>
            {type === "basic" ? (
                <span>{`${secondsToTime(countDown)}`}</span>
            ) : (
                <div
                    data-test-id={genericUtils.removeSpace("Countdown")}
                    className={`countdownBox countdownBox--${type}`}
                >
                    <span className={`${type}PopupLabel`} data-test-id={`${type}-popup-label`}>
                        {title}
                    </span>
                    <span className={`${type}PopupValue`} data-test-id={`${type}-popup-value`}>{`${secondsToTime(
                        countDown
                    )}`}</span>
                </div>
            )}
        </div>
    );
}
