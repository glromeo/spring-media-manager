import FileSaver from "file-saver";
import JSZip from "jszip";
import { useCallback, useEffect } from "react";
import { useAppDispatch, useAppSelector } from "../../app";
import packageJson from "../../../package.json";
import { setDebugInfo } from "../../features/config/configActions";
import {copyToClipboard} from "@atw/toolkit";

/**
 * The purpose of this component is to add a hidden row to the summary section that expands to debug information
 * when a secret key sequence is pressed. This is fundamental to troubleshoot in production and allows us to
 * avoid depending on console.log.
 *
 * @constructor
 */
export default function DebugInfo() {
    const dispatch = useAppDispatch();
    const debugInfo = useAppSelector((state) => state.config.debugInfo);

    const keydownCallback = useCallback((event: KeyboardEvent) => {
        if ((event.key === "X" && event.ctrlKey) || (event.key === "M" && event.ctrlKey)) {
            event.preventDefault();
            event.stopPropagation();
            dispatch(setDebugInfo(true));
        } else {
            if (event.keyCode === 27) dispatch(setDebugInfo(false));
        }
    }, []);

    useEffect(() => {
        window.addEventListener("keydown", keydownCallback);
        return () => {
            window.removeEventListener("keydown", keydownCallback);
        };
    }, [keydownCallback]);

    const copy = () => {
        const element: any = document.getElementById("url");
        copyToClipboard({ text: element.textContent });
    };

    const downloadState = useCallback(() => {
        const zip = new JSZip();
        zip.file("state.json", JSON.stringify((window as any).store.getState(), null, 4));
        zip.generateAsync({ type: "blob" })
            .then((blob) => {
                FileSaver.saveAs(blob, "store-snapshot.zip");
            })
            .catch(console.error);
    }, []);

    return debugInfo ? (
        <div data-test-id="debuginfo" className="debug-info">
            <div className="item">
                <label style={{ marginRight: 25 }}>Url</label>
                <button onClick={copy}>copy </button>
                <span id="url">{String(window.location)}</span>
            </div>
            <div className="item">
                <label style={{ marginRight: 5 }}>Redux</label>
                <div>
                    <button onClick={downloadState}>download</button>
                </div>
            </div>
            <div className="item">
                <label style={{ marginRight: 5 }}>Version</label>
                <div>
                    <span>{packageJson.version}</span>
                </div>
            </div>
        </div>
    ) : null;
}
