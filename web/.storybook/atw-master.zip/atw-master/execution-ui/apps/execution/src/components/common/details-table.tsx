import { logClick, SecurityLookupProps, SecurityOption } from "@atw/toolkit";
import { useMemo } from "react";
import { useAppSelector } from "../../app";
import { configUtils, genericUtils, orderUtils } from "../../common/utils";
import { StepperState, WORKFLOWS } from "../../features/stepper/stepper";

import {
    FieldType,
    NUM_PLACE_HOLDER,
    SideColor,
    STRING_PLACE_HOLDER
} from "../../models/common";

import { BrokerMarkup } from "./broker-markup";
import { Rating } from "./rating";
import { SecurityLookup } from "./security-lookup";

export type DetailsTableRowType = {
    label: string;
    value: number | string | boolean | JSX.Element;
    type: FieldType | SecurityLookupProps["type"];
    renderType?: FieldType;
    renderValue?: number | string | boolean;
    color?: SideColor;
    className?: string;
    editable?: boolean;
    onSelectionChange?: Function;
    onValidate?: Function;
    ref?: Function;
    separator?: boolean;
    dropdownOffsetWidth?: number;
};

export function DetailsTable({ name, data }: { name: string; data: DetailsTableRowType[] }) {
    return (
        <table className="aux-simple-table executeTable">
            <tbody>
                {data.map((info: DetailsTableRowType) => (
                    <TableRow key={info.label} name={name} info={info} />
                ))}
            </tbody>
        </table>
    );
}

export function PriceRenderer({ info, formattedValue }: { info: DetailsTableRowType; formattedValue: string }) {
    const query = useAppSelector((state) => state.config);
    const stepper = useAppSelector((state) => state.stepper);

    const currentWorkflow = WORKFLOWS[query.workflow];
    const currentStep = currentWorkflow[stepper.stepIdx];

    const showTargetForField =
        configUtils.isAxeA2AMode() && currentStep === StepperState.Order && ["Spread", "Price"].includes(info.label);

    return (
        <>
            {formattedValue}
            {showTargetForField && (
                <span className="price-target-icon" title={`Target ${info.label}`}>
                    T
                </span>
            )}
        </>
    );
}

function TableRow({ info, name }: { info: DetailsTableRowType; name: string }) {
    const renderValue = useMemo(
        () => () => {
            if (info.type !== "security" && info.value === STRING_PLACE_HOLDER) {
                return info.value;
            }

            switch (info.type) {
                case "boolean":
                    return info.value ? "Yes" : "No";
                case "size":
                    return info.value === NUM_PLACE_HOLDER || info.value === null
                        ? STRING_PLACE_HOLDER
                        : genericUtils.formatSize(info.value as number);
                case "price":
                    const formattedPriceValue =
                        info.value === NUM_PLACE_HOLDER || info.value === null
                            ? STRING_PLACE_HOLDER
                            : genericUtils.formatPrice(info.value as number);
                    return <PriceRenderer info={info} formattedValue={formattedPriceValue} />;
                case "allInLevel":
                    return <BrokerMarkup state={StepperState.Review} />;
                case "spread":
                    const formattedSpreadValue =
                        info.value === NUM_PLACE_HOLDER || info.value === null
                            ? STRING_PLACE_HOLDER
                            : genericUtils.formatSpread(info.value as number);
                    return <PriceRenderer info={info} formattedValue={formattedSpreadValue} />;
                case "time":
                    return new Date(info.value as number)
                        .toLocaleTimeString("en-US", { timeZone: "America/New_York" })
                        .toLowerCase();
                case "rating":
                    return <Rating rating={info.value as number} />;
                case "security":
                    return (
                        <SecurityLookup
                            value={info.value.toString()}
                            editable={info.editable ?? false}
                            onSelectionChange={(security: SecurityOption) => {
                                security.desc1 = orderUtils.formatSecLookupDesc(security);
                                const benchmark = {
                                    label: security?.desc1 || STRING_PLACE_HOLDER,
                                    value: security?.cusip || STRING_PLACE_HOLDER
                                };
                                logClick("User changed security benchmark", { benchmark });
                                if (info.onSelectionChange) {
                                    info.onSelectionChange(security);
                                }
                            }}
                            SecurityLookupRef={info.ref!}
                            selectionValueKey="desc1"
                            dropdownOffsetWidth={info.dropdownOffsetWidth}
                        />
                    );
                default:
                    return info.value;
            }
        },
        [info]
    );

    const getRenderStyle = (info: DetailsTableRowType) => {
        if (info.renderType === undefined || info.renderType !== "progress") return undefined;
        return {
            background: info.color!,
            width: info.renderValue! + "%"
        };
    };

    const getDataTestId = (info: DetailsTableRowType) => {
        return `${genericUtils.removeSpace(name, true)}-${genericUtils.removeSpace(info.label, true)}`;
    };

    let className = `aux-simple-table__cell--align-right ${info.className}`;
    if (info.renderType !== undefined) {
        className = `${className} progressTd`;
    }

    return (
        <>
            <tr key={info.label} className="executeTableRow">
                <td>{info.label}</td>
                {info.renderType === undefined ? (
                    <td data-test-id={getDataTestId(info)} className={className}>
                        {renderValue()}
                    </td>
                ) : (
                    <td data-test-id={getDataTestId(info)} className={className}>
                        <div
                            data-test-id={`${getDataTestId(info)}-container`}
                            className="progessContainer"
                            style={getRenderStyle(info)}
                        ></div>
                        <div data-test-id={`${getDataTestId(info)}-value`} className="progessValue">
                            {renderValue()}
                        </div>
                    </td>
                )}
            </tr>
            {info.separator && (
                <tr className="executeTableRow">
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
            )}
        </>
    );
}
