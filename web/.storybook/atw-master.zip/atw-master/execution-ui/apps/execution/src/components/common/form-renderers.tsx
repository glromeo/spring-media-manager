import { SecurityLookupProps } from "@atw/toolkit";
import {
    AuxCalendarValueChangedDetailInterface,
    AuxDatePicker,
    AuxDatePickerDateFormatEnum,
    AuxDatePickerInputTypeEnum,
    AuxInputMask,
    AuxInputMaskRawValueChangedDetailInterface,
    AuxRadioGroup,
    AuxRadioGroupChangedDetailInterface,
    AuxRadioInterface,
    AuxSelect,
    Validator
} from "@blk/aladdin-react-components-es";
import {
    AuxInputMaskBlurChangedDetailInterface,
    AuxInputMaskValueChangedDetailInterface,
    AuxSelectOption,
    AuxSelectOptionGroup,
    AuxSelectSelectionChangedDetailInterface
} from "@blk/aladdin-web-components";
import { useEffect, useRef, useState } from "react";
import { genericUtils } from "../../common/utils";
import { EMPTY_PLACE_HOLDER, NUM_PLACE_HOLDER, STRING_PLACE_HOLDER } from "../../models/common";
import { convertToNumber } from "@atx/commons/utils/size";

export type FormItemType = {
    formTitle: string;
    disabled?: boolean;
    field: string;
    field2?: string;
    label: string;
    value: number | boolean | string | FormSelectOptionType[] | AuxRadioInterface[];
    value2?: number | boolean | string | string[] | FormSelectOptionType;
    min?: number;
    max?: number;
    checked?: string;
    onValidate?: (id: string, hasError: boolean) => void;
    onValueChanged: (id: string, value: string | { label: string; value: string }) => void;
    validator?: validationCheck;
    atwSecurityLookupProps?: SecurityLookupProps;
};

export type FormSelectOptionType = {
    label: string;
    value: string;
    isDisabled?: boolean;
};
export type FormRadioType = {
    label: string;
};
export type validationCheck = () => ValidationCheckDetails;
export type ValidationCheckDetails = { isValid: boolean; errorMessage: string };

export const getDataTestId = (title: string, field: string) => {
    return `${genericUtils.removeSpace(title)}-control-${genericUtils.removeSpace(field)}`;
};

export function PriceRenderer({ formItemData }: { formItemData: FormItemType }) {
    const controlRef = useRef<HTMLAuxInputMaskElement>(null);
    const formItemRef = useRef<FormItemType>(formItemData);
    formItemRef.current = formItemData;
    useEffect(() => {
        if (typeof controlRef?.current?.validate === "function") {
            controlRef?.current?.validate();
        }
    }, []);
    const defaultValidator: Validator = {
        validate: (value: string) => {
            value = value.trim();
            const isValid =
                value.length > 1 ||
                (value.length === 1 && value !== EMPTY_PLACE_HOLDER && value !== "-" && value !== "+");
            if (formItemRef.current.onValidate) formItemRef.current.onValidate(formItemRef.current.field, isValid);
            return isValid;
        },
        errorMessage: "Requires min. 1 digit"
    };
    const defaultOnRawValueChanged = (event: CustomEvent<AuxInputMaskValueChangedDetailInterface>) => {
        const newValue = event.detail.value.trim();
        if (newValue === parseValue(formItemRef.current.value as number)) return;
        // negative is a precursor ...we wait until user actually typed something in ...
        if (newValue === "" || newValue === "-") return;
        formItemRef.current.onValueChanged(formItemRef.current.field, newValue);
        genericUtils.logTelemetryClick(formItemRef.current.label, formItemRef.current.field, newValue);
    };
    const parseValue = (value: number): string => {
        return value === undefined || value === NUM_PLACE_HOLDER ? EMPTY_PLACE_HOLDER : value.toString();
    };
    return (
        <AuxInputMask
            ref={controlRef}
            data-test-id={getDataTestId(formItemData.formTitle, formItemData.field)}
            value={parseValue(formItemData.value as number)}
            isRequired={true}
            textAlign="right"
            data-telemetry-id="PriceTextBox"
            isDisabled={formItemData.disabled}
            maskOptions={{
                mask: Number,
                scale: 20,
                signed: true,
                thousandsSeparator: ",",
                padFractionalZeros: false,
                normalizeZeros: false,
                radix: ".",
                mapToRadix: ["."]
            }}
            validator={[defaultValidator]}
            onRawValueChanged={defaultOnRawValueChanged}
        />
    );
}

export function SpreadRenderer({ formItemData }: { formItemData: FormItemType }) {
    const controlRef = useRef<HTMLAuxInputMaskElement>(null);
    const formItemRef = useRef<FormItemType>(formItemData);
    formItemRef.current = formItemData;

    useEffect(() => {
        if (typeof controlRef?.current?.validate === "function") {
            controlRef?.current?.validate();
        }
    }, []);

    const defaultValidator: Validator = {
        validate: (value: string) => {
            value = value.trim();
            const isValid =
                value.length > 1 ||
                (value.length === 1 && value !== EMPTY_PLACE_HOLDER && value !== "-" && value !== "+");
            if (formItemRef.current.onValidate) formItemRef.current.onValidate(formItemRef.current.field, isValid);
            return isValid;
        },
        errorMessage: "Requires min. 1 digit"
    };
    const defaultOnRawValueChanged = (event: CustomEvent<AuxInputMaskRawValueChangedDetailInterface>) => {
        const newValue = event.detail.value.trim();
        if (newValue === parseValue(formItemRef.current.value as number)) return;
        // negative is a precursor ...we wait until user actually typed something in ...
        if (newValue === "" || newValue === "-") return;
        formItemRef.current.onValueChanged(formItemRef.current.field, newValue);
        genericUtils.logTelemetryClick(formItemRef.current.label, formItemRef.current.field, newValue);
    };
    const parseValue = (value: number): string => {
        // toString() will convert it to "0" instead of "-0"
        if (value === -0) return value.toLocaleString();
        // refactor-todo: Spread can't have a num_place_holder as a default, beacuse that can be a valid number.. -999 for spread
        return value === undefined ? EMPTY_PLACE_HOLDER : value.toString();
    };

    const MASK_OPTIONS = {
        mask: [
            {
                mask: "positiveNum",
                blocks: {
                    positiveNum: {
                        mask: Number,
                        scale: 20,
                        signed: true,
                        thousandsSeparator: ",",
                        padFractionalZeros: false,
                        normalizeZeros: false,
                        radix: ".",
                        mapToRadix: ["."],
                        prepare: function (str: string, mask: any) {
                            if (parseInt(str) > 0 && mask.value === "") {
                                return "+" + str;
                            }
                            if (parseInt(str) === 0 && mask.value === "-") {
                                return mask.value;
                            }
                            return str;
                        }
                    }
                }
            }
        ]
    };
    return (
        <AuxInputMask
            ref={controlRef}
            data-test-id={getDataTestId(formItemData.formTitle, formItemData.field)}
            value={parseValue(formItemData.value as number)}
            data-telemetry-id="SpreadTextBox"
            isRequired={true}
            textAlign="left"
            isDisabled={formItemData.disabled}
            maskOptions={MASK_OPTIONS}
            validator={[defaultValidator]}
            onRawValueChanged={defaultOnRawValueChanged}
        />
    );
}

export function SizeRenderer({ formItemData }: { formItemData: FormItemType }) {
    const controlRef = useRef<HTMLAuxInputMaskElement>(null);
    const formItemRef = useRef<FormItemType>(formItemData);
    formItemRef.current = formItemData;
    const [size, setSize] = useState(
        formItemData.value === undefined ? NUM_PLACE_HOLDER.toString() : formItemData.value.toString()
    );
    useEffect(() => {
        if (typeof controlRef?.current?.validate === "function") {
            controlRef?.current?.validate();
        }
    }, [formItemData.max, size]);
    useEffect(() => {
        const updatedValue = formItemData.value ? formItemData.value.toString() : EMPTY_PLACE_HOLDER;
        setSize(updatedValue);
    }, [formItemData.value]);
    const validator: Validator = {
        validate: function (value: string) {
            value = value.trim();
            const curVal = convertToNumber(value);
            let isValid = true;
            if (!(curVal >= (formItemRef.current.min as number) && curVal <= (formItemRef.current.max as number))) {
                isValid = false;
                this.errorMessage = `Size range (${formItemRef.current.min as number} - ${genericUtils.formatSize(
                    formItemRef.current.max as number
                )})`;
            }
            const isValidNumber = !genericUtils.isFloat(curVal);
            if (!isValidNumber) {
                isValid = false;
                this.errorMessage = `Size must be a whole number`;
            }

            if (formItemRef.current.onValidate) formItemRef.current.onValidate(formItemRef.current.field, isValid);
            return isValid;
        }
    };
    const onRawValueChanged = (event: CustomEvent<AuxInputMaskValueChangedDetailInterface>) => {
        // need to listen to input value changes to reset acknowledge and send and enable/disable next button
        formItemRef.current.onValueChanged(formItemRef.current.field, event.detail.value);
    };
    const MASK_OPTIONS = {
        mask: [
            {
                mask: Number, // enable number mask
                thousandsSeparator: ",", // any single char
                radix: ".", // fractional delimiter
                mapToRadix: ["."], // symbols to process as radix
                max: 1000000000000, // max 1 trillion
                prepare: function (str: string, mask: any) {
                    // don't allow . as first character
                    if (str === "." && mask.value === "") {
                        return "";
                    }
                    return str;
                }
            },
            {
                // max 12 characters and any digits with only 1 decimal with option M or MM at end
                // mask: /(?=^.{1,12}$)^\d+\.?\d*M?M?$/i,
                mask: /(?=^.{1,12}$)^\d{1,13}\.?\d{0,13}M?M?$/i,
                prepare: function (str: string, mask: any) {
                    return str.toUpperCase();
                }
            }
        ]
    };
    const onBlurChanged = (event: CustomEvent<AuxInputMaskBlurChangedDetailInterface>) => {
        // wonder why we are doing onBlurChanged as oppose to (previously) onUpdate?
        // reason: ... now we are keeping single source of truth (redux) - where previously
        // we were having AWC keep state ... we always now udpate redux store ..as such
        // we have a problem ... if user types 55M ... it will immediately convert to 55000
        // but user really wanted to type 55MM (million) ... we could add a debouce (but that is not the greatest)
        // so we now only get value ...when user has focused out ...and we then update redux ...whew...
        const convertedValue = convertToNumber(event.detail.value).toString();
        setSize(convertedValue);
        // this if for the bug that if the store value is 5,000 and user inputs 5m, redux thinks value hasn't changed.
        // This forces an update to convert value to 5,000 on the input element.
        if (event.detail.value !== convertedValue) {
            const inputEl = (event.currentTarget as HTMLElement)?.shadowRoot?.querySelector("input");
            if (inputEl) inputEl.value = convertedValue;
        }
        formItemRef.current.onValueChanged(formItemRef.current.field, convertedValue);
        genericUtils.logTelemetryClick(formItemRef.current.label, formItemRef.current.field, convertedValue);
    };
    return (
        <AuxInputMask
            ref={controlRef}
            data-test-id={getDataTestId(formItemData.formTitle, formItemData.field)}
            data-telemetry-id="SizeTextBox"
            value={size}
            isRequired={true}
            textAlign="right"
            isDisabled={formItemData.disabled}
            maskOptions={MASK_OPTIONS}
            validator={[validator]}
            onRawValueChanged={onRawValueChanged}
            onBlurChanged={onBlurChanged}
        />
    );
}

export function SelectRenderer({ formItemData }: { formItemData: FormItemType }) {
    const controlRef = useRef<HTMLAuxSelectElement>(null);
    const formItemRef = useRef<FormItemType>(formItemData);
    const getDefaultValidation: validationCheck = () => {
        const { value2: selectedVal, label } = formItemRef.current;
        let errorMessage: string = "",
            isValid: boolean = true;

        if (selectedVal === STRING_PLACE_HOLDER) {
            isValid = false;
            errorMessage = `A ${label.toLowerCase()} must be selected`;
        }
        return { isValid, errorMessage };
    };
    let validationChecks: validationCheck[] = [getDefaultValidation];
    formItemRef.current = formItemData;

    useEffect(() => {
        if (typeof controlRef?.current?.validate === "function") {
            controlRef?.current?.validate();
        }
    }, [formItemData.value2]);
    const values =
        formItemRef.current.value === STRING_PLACE_HOLDER
            ? []
            : (formItemRef.current.value as FormSelectOptionType[]).map((item) => {
                  return {
                      displayValue: item.label,
                      value: item.value,
                      isDisabled: item.isDisabled ?? false,
                      isSelected: item.value === formItemData.value2,
                      auxId: `${getDataTestId(formItemData.formTitle, formItemData.field)}-${genericUtils.removeSpace(
                          item.value
                      )}`
                  };
              });
    const data: AuxSelectOptionGroup[] = [{ values }];
    const defaultOnSelection = (event: CustomEvent<AuxSelectSelectionChangedDetailInterface>) => {
        const newValue = (event.detail.value as AuxSelectOption).value;
        if (newValue === formItemRef.current.value2) return;
        formItemRef.current.onValueChanged(formItemRef.current.field2!, newValue);
        genericUtils.logTelemetryClick(formItemRef.current.label, formItemRef.current.field, newValue);
    };

    formItemData.validator && validationChecks.push(formItemData.validator);

    const validator: Validator = {
        validate: function () {
            let isValid = true,
                firstInvalidCheck: validationCheck | undefined = validationChecks.find(
                    (getValidation) => !getValidation().isValid
                );
            if (firstInvalidCheck) {
                this.errorMessage = firstInvalidCheck().errorMessage;
                isValid = false;
            }
            if (formItemRef.current.onValidate) formItemRef.current.onValidate(formItemRef.current.field, isValid);
            return isValid;
        }
    };
    return (
        <AuxSelect
            ref={controlRef}
            data-test-id={getDataTestId(formItemData.formTitle, formItemData.field)}
            data-telemetry-id="Aux-dropdown"
            type="simple"
            data={data}
            isDisabled={formItemData.disabled}
            selected={{
                displayValue: formItemData.value2 as string,
                isSelected: true,
                value: formItemData.value2 as string
            }}
            hasInitialOptionPlaceholder={false}
            validator={[validator]}
            onSelectionChanged={defaultOnSelection}
        />
    );
}

export function RadioRenderer({ formItemData }: { formItemData: FormItemType }) {
    const controlRef = useRef<HTMLAuxRadioGroupElement>(null);
    const formItemRef = useRef<FormItemType>(formItemData);
    formItemRef.current = formItemData;

    const defaultonRadioGroupChanged = (event: CustomEvent<AuxRadioGroupChangedDetailInterface>) => {
        const checkedData = event.detail.value.eventData;
        formItemRef.current.onValueChanged(`${formItemRef.current.field2}`, checkedData);
        genericUtils.logTelemetryClick(formItemRef.current.label, formItemRef.current.field, checkedData);
    };

    return (
        <AuxRadioGroup
            data-test-id={getDataTestId(formItemData.formTitle, formItemData.field)}
            ref={controlRef}
            data-telemetry-id="Aux-RadioGroup"
            data={formItemRef.current.value as AuxRadioInterface[]}
            onRadioGroupChanged={defaultonRadioGroupChanged}
        />
    );
}

export function DateRenderer({ formItemData }: { formItemData: FormItemType }) {
    const formItemRef = useRef<FormItemType>(formItemData);
    formItemRef.current = formItemData;

    const defaultValidator: Validator = {
        validate: (value: string) => {
            // why does AWC return undefined here??
            let isValid: boolean = true;
            if (value === "Invalid date") return false;
            if (value !== undefined) {
                isValid =
                    new Date(value).setHours(0, 0, 0, 0) >=
                    new Date(formItemRef.current.value2!.toString()).setHours(0, 0, 0, 0);
            }
            if (formItemRef.current.onValidate) formItemRef.current.onValidate(formItemRef.current.field, isValid);
            return isValid;
        },
        errorMessage: `Date must be a valid MM/DD/YYYY date after ${formItemRef.current.value2!.toString()}`
    };
    const defaultOnValueChanged = (event: CustomEvent<AuxCalendarValueChangedDetailInterface>) => {
        const newValue = event.detail.value;
        formItemRef.current.onValueChanged(formItemRef.current.field, newValue);
        genericUtils.logTelemetryClick(formItemRef.current.label, formItemRef.current.field, newValue);
    };
    return (
        <AuxDatePicker
            data-test-id={getDataTestId(formItemData.formTitle, formItemData.field)}
            value={formItemData.value.toString()}
            minDate={formItemData.value2!.toString()}
            isDisabled
            onValueChanged={defaultOnValueChanged}
            dateFormat={AuxDatePickerDateFormatEnum.MONTH_DAY_YEAR}
            closeCalendarOnBlur={false}
            validator={[defaultValidator]}
            inputType={AuxDatePickerInputTypeEnum.NO_INPUT_MASK}
        />
    );
}
