import {
    AuxProgressStepper,
    AuxProgressStepperInterface,
    AuxProgressStepperStepClickedDetailInterface
} from "@blk/aladdin-react-components-es";
import { useAppDispatch, useAppSelector } from "../../app";
import { StepperState, WORKFLOWS } from "../../features/stepper/stepper";
import { setStep } from "../../features/stepper/stepperActions";

export function HeaderBase({ isDisplayOnly }: { isDisplayOnly?: boolean }) {
    const dispatch = useAppDispatch();
    const stepper = useAppSelector((state) => state.stepper);
    const config = useAppSelector((store) => store.config);
    const onStep = (event: CustomEvent<AuxProgressStepperStepClickedDetailInterface>) => {
        const step = event.detail.data[event.detail.index];
        if (step.index === stepper.stepIdx) return;
        const workflow = WORKFLOWS[config.workflow];
        dispatch(setStep(step.index, workflow));
    };
    const getSteps = (): AuxProgressStepperInterface[] => {
        const currentWorkflow = WORKFLOWS[config.workflow];
        const getState = (idx: number) => {
            if (stepper.stepIdx === idx) return "active";
            if (stepper.stepIdx > idx) return "complete";
            return "disabled";
        };
        return currentWorkflow.map((step: StepperState, idx: number) => {
            return {
                index: idx,
                label: step.toString(),
                state: getState(idx),
                value: idx + 1
            };
        });
    };
    const hasValidWorkflow = () => {
        return config.workflow !== "NOTSET";
    };
    return (
        <div className="executionHeader">
            <div className={isDisplayOnly ? "display-only" : ""}>
                {hasValidWorkflow() ? (
                    <AuxProgressStepper
                        data-test-id="axe-stepper"
                        isResponsive={false}
                        onStepClicked={onStep}
                        steps={getSteps()}
                        type="button"
                    />
                ) : null}
            </div>
        </div>
    );
}
