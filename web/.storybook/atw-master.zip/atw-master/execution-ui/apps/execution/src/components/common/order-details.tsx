import { SecurityLookupProps } from "@atw/toolkit";
import React from "react";
import { useAppDispatch, useAppSelector } from "../../app";
import { configUtils, pricingTypeUtils } from "../../common/utils";
import { clearAlerts } from "../../features/alerts/alertsActions";
import { OrderDetail } from "../../features/order/order";
import { setOrderBenchmark } from "../../features/order/orderActions";
import { StepperState, WORKFLOWS } from "../../features/stepper/stepper";
import {
    BUY_PROGRESS_COLOR,
    DISABLED_PROGRESS_COLOR,
    NUM_PLACE_HOLDER,
    PRICING_TYPE_MAP,
    SELL_PROGRESS_COLOR,
    STRING_PLACE_HOLDER
} from "../../models/common";
import { DetailsTable, DetailsTableRowType } from "./details-table";

export function OrderDetails() {
    const dispatch = useAppDispatch();
    const orderInfo = useAppSelector((state) => state.orderInfo);
    const axeInfo = useAppSelector((state) => state.axeInfo);
    const config = useAppSelector((store) => store.config);
    const stepIdx = useAppSelector((store) => store.stepper.stepIdx);
    const countering = useAppSelector((store) => store.counteringInfo?.countering);
    const axeSizeLabel = configUtils.isAxeA2AMode() ? "A2A Axe Size" : "Axe Size";
    const currentWorkflow = WORKFLOWS[config.workflow];
    const priceSources = useAppSelector((store) => store.decodes["MD_PRICE_SOURCE"]);

    const prices = useAppSelector((state) => state.prices);
    const isSpread = pricingTypeUtils.isSpread(orderInfo.order, axeInfo.axe, config, countering);

    let orderBmkTableRowProps: Partial<SecurityLookupProps | DetailsTableRowType> = {
        editable: false
    };

    if (configUtils.isCares() && currentWorkflow[stepIdx] === StepperState.Order) {
        // only cares and order step can you edit
        orderBmkTableRowProps = {
            editable: true,
            onSelectionChange: (security: string) => {
                dispatch(clearAlerts());
                dispatch(setOrderBenchmark(security));
            },
            ref: (node: any) => {
                if (node.current && typeof node.current.validate === "function") {
                    // initial validation on mount, need to do this since there is no prop/ref access to underlying Aux input...
                    node.current.validate();
                }
            }
        };
    }

    const getOrderDetails = (): DetailsTableRowType[] => {
        const pricingType = pricingTypeUtils.getCurrentPricingType({ axeInfo, orderInfo, countering, config });
        // this is called way too many times, find a fix for this........
        return orderInfo.schema
            .filter((orderDetail: OrderDetail) => orderDetail.visibleFor.includes(PRICING_TYPE_MAP[pricingType]))
            .map((orderDetail: OrderDetail): DetailsTableRowType => {
                const value = orderInfo.order === undefined ? undefined : (orderInfo.order as any)[orderDetail.field];
                return {
                    label: orderDetail!.label,
                    value:
                        value === undefined
                            ? STRING_PLACE_HOLDER
                            : orderDetail.field === "side"
                            ? `You ${value}`
                            : value,
                    type: orderDetail!.type,
                    ...(orderDetail.field === "orderBmk" && {
                        ...orderBmkTableRowProps
                    }),
                    className: orderDetail.classNameFor(orderInfo.order.side, value)
                };
            });
    };

    const getLivePriceDetails = () => {
        const accessor = isSpread ? "spread" : "price";
        const labelSuffix = isSpread ? "Spread" : "Price";

        const data: DetailsTableRowType[] = prices.map((price) => {
            const sourceName = priceSources?.[price.source]?.replace(/ prices$/g, "");
            return {
                label: `${sourceName ?? price.source} ${labelSuffix}`,
                value: (
                    <div>
                        <span className={orderInfo.order.side === "BUY" ? "" : "live-price-details-sell"}>
                            {price.prices.bid[accessor]}
                        </span>
                        <span> / </span>
                        <span className={orderInfo.order.side === "BUY" ? "live-price-details-buy" : ""}>
                            {price.prices.ask[accessor]}
                        </span>
                    </div>
                ),
                type: "text"
            };
        });

        // Always display triton where enabled even if we not receiving streaming data
        if (!prices.find((price) => price.source.toLowerCase() === "triton") && priceSources?.["TRITON"]) {
            const sourceName = priceSources?.["TRITON"]?.replace(/ prices$/g, "");

            data.unshift({
                label: `${sourceName} ${labelSuffix}`,
                value: "- / -",
                type: "text"
            });
        }

        return data;
    };

    const getSubOrderDetails = () => {
        const data: DetailsTableRowType[] = [
            {
                label: axeSizeLabel,
                value: axeInfo.axe === undefined ? STRING_PLACE_HOLDER : axeInfo.axe.size,
                type: "size",
                renderType: "progress",
                renderValue: getAxePercent(),
                color:
                    orderInfo.order.side === "NOTSET"
                        ? DISABLED_PROGRESS_COLOR
                        : orderInfo.order.side === "BUY"
                        ? BUY_PROGRESS_COLOR
                        : SELL_PROGRESS_COLOR
            },
            {
                label: "Order Leaves",
                value: orderInfo.order === undefined ? STRING_PLACE_HOLDER : orderInfo.order.orderLeaves,
                type: "size",
                renderType: "progress",
                renderValue: getOrderPercent(),
                color:
                    orderInfo.order.side === "NOTSET"
                        ? DISABLED_PROGRESS_COLOR
                        : orderInfo.order.side === "BUY"
                        ? BUY_PROGRESS_COLOR
                        : SELL_PROGRESS_COLOR
            }
        ];
        return data;
    };
    const getAxePercent = () => {
        if (
            orderInfo.order.orderLeaves === 0 ||
            orderInfo.order.orderLeaves === NUM_PLACE_HOLDER ||
            axeInfo.axe.size === 0 ||
            axeInfo.axe.size === NUM_PLACE_HOLDER
        )
            return 0;
        if (axeInfo.axe.size > orderInfo.order.orderLeaves) return 100;
        return ((axeInfo.axe.size / orderInfo.order.orderLeaves) * 100).toFixed(1);
    };
    const getOrderPercent = () => {
        if (
            orderInfo.order.orderLeaves === 0 ||
            orderInfo.order.orderLeaves === NUM_PLACE_HOLDER ||
            axeInfo.axe.size === 0 ||
            axeInfo.axe.size === NUM_PLACE_HOLDER
        )
            return 0;
        if (orderInfo.order.orderLeaves > axeInfo.axe.size) return 100;
        return ((orderInfo.order.orderLeaves / axeInfo.axe.size) * 100).toFixed(1);
    };

    const livePrices = getLivePriceDetails();

    return (
        <div>
            <div className="tableHeader">Your Order</div>
            <DetailsTable name="yourorder" data={getOrderDetails()}></DetailsTable>
            {configUtils.isCares() ? null : (
                <React.Fragment>
                    <div className="tableSubHeader"></div>
                    <DetailsTable name="orderdetails" data={getSubOrderDetails()}></DetailsTable>
                </React.Fragment>
            )}
            {livePrices.length > 0 && (
                <React.Fragment>
                    <div className="tableSubHeader"></div>
                    <DetailsTable name="livepricedetails" data={livePrices}></DetailsTable>
                </React.Fragment>
            )}
        </div>
    );
}
