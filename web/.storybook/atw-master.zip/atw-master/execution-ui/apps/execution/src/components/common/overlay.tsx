import { logClick } from "@atw/toolkit/telemetry";
import { useEffect, useState } from "react";
import * as ReactDOM from "react-dom";
import { useAppSelector } from "../../app";
import { StepperStatusType, StepperSubStatusType } from "../../features/stepper/stepper";
import { Spinner } from "./spinner";

export function Overlay({ children }: { children: JSX.Element }) {
    const orderNumber = useAppSelector(({ config }) => config.orderNumber);
    useEffect(() => {
        overlayInd();
    }, []);

    function overlayInd() {
        logClick(`${children.props.title}`, { orderNumber });
    }
    return ReactDOM.createPortal(<div className="overlay">{children}</div>, document.body);
}

export function OverlayStatus({ status, subStatus }: { status: StepperStatusType; subStatus?: StepperSubStatusType }) {
    const [title, setTitle] = useState("");

    useEffect(() => {
        let title = "";
        switch (status) {
            case "VALIDATING":
                title = "Validating Order";
                break;
            case "SENDING":
                switch (subStatus) {
                    case "HITLIFT":
                        title = "Accepting Quote";
                        break;
                    case "MINI_REVIEW":
                        title = "Countering Quote";
                        break;
                    default:
                        title = "Sending Order";
                        break;
                }
        }
        setTitle(title);
    }, [status, subStatus]);

    return title ? (
        <Overlay>
            <Spinner title={title}></Spinner>
        </Overlay>
    ) : null;
}
