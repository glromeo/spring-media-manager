import { AuxIcon } from "@blk/aladdin-react-components-es";

export const Rating = ({ rating }: { rating: number }) => {
    const scale = [1, 2, 3, 4, 5];

    return (
        <div className="rating-container">
            {scale.map((scaleRating) => (
                <AuxIcon
                    key={`rating-${scaleRating}`}
                    type={scaleRating <= rating ? "favorite-bold" : "favorite-subtle"}
                    state={"primary-non-action"}
                />
            ))}
        </div>
    );
};
