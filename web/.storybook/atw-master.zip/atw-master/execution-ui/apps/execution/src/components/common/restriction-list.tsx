import {
    AuxButton,
    AuxButtonTypeEnum,
    AuxCard,
    AuxCardType,
    AuxNotificationGroup,
    AuxNotificationStyleEnum,
    AuxRadio
} from "@blk/aladdin-react-components-es";
import { useEffect, useState } from "react";
import { useAppDispatch, useAppSelector } from "../../app";
import { configUtils, genericUtils, orderUtils } from "../../common/utils";
import { Broker, BrokerEntity, BrokerRestrictionAllocation } from "../../features/order/order";
import { selectRestrictedBroker } from "../../features/order/orderActions";
import { resetTradeForm } from "../../features/tradeForm/tradeFormActions";

export function RestrictionList({ filteredBroker }: { filteredBroker?: BrokerEntity }) {
    const dispatch = useAppDispatch();
    const broker = useAppSelector((state) => state.orderInfo.order.broker);
    const brokerSelected = useAppSelector((state) => state.tradeFormInfo.tradeForm.brokerSelected);
    const [expandedMap, setExpandedMap] = useState(new Map<string, boolean>());
    const { formatSize, isValidNumber } = genericUtils;
    const { isCares } = configUtils;
    const [brokersWithRestrictions, setBrokersWithRestrictions] = useState<BrokerEntity[]>(broker.entity);

    useEffect(() => {
        // send a clear as well to reset ...we are back at start, wonder why for cares we don't reset??
        if (!isCares()) {
            dispatch(resetTradeForm());
        }
    }, []); // eslint-disable-line react-hooks/exhaustive-deps
    useEffect(() => {
        if (isCares()) {
            // Display the selected broker if it has a restriction
            setBrokersWithRestrictions(
                broker.entity.filter((entity) => {
                    return entity.name === brokerSelected && !orderUtils.isFullyAvailable(entity);
                })
            );
        } else {
            // Display everything
            setBrokersWithRestrictions(broker.entity);
        }
    }, [brokerSelected]);
    const onSelectRestrictedBroker = (idx: number) => {
        if (!isCares()) {
            dispatch(selectRestrictedBroker(idx));
        } else {
            // For cares, we always have 1 broker in the restricted list, so must look up the correct index
            const matchIndex = broker.entity.findIndex((entity) => entity.name === brokersWithRestrictions[0].name);
            dispatch(selectRestrictedBroker(matchIndex));
        }
    };
    const RenderRestrictedText = (restrictedPortfolios: string[]) => {
        const getPortfolios = () => {
            if (restrictedPortfolios.length > 5) {
                restrictedPortfolios.length = 5;
                return restrictedPortfolios.join(", ") + "...";
            }
            return restrictedPortfolios.join(", ");
        };

        let restrictedText;
        if (restrictedPortfolios.length === 0) {
            restrictedText = "No portfolios will be removed from this placement";
        } else {
            restrictedText = `Portfolio${
                restrictedPortfolios.length > 1 ? "s" : ""
            } ${getPortfolios()} will be removed from this placement`;
        }

        return <div className={"restrictionCardRemovedText"}>{restrictedText}</div>;
    };
    const RenderAllocations = ({
        allocations,
        restrictedPorfolios
    }: {
        allocations: BrokerRestrictionAllocation[];
        restrictedPorfolios: string[];
    }) => {
        return (
            <div>
                <table className="aux-simple-table aux-simple-table__container--vertical restrictionTable">
                    <tbody>
                        <tr>
                            <th>Restriction</th>
                            <th>Portfolio</th>
                            <th>Quantity</th>
                            <th>% of available</th>
                        </tr>
                        {allocations.map((allocation: BrokerRestrictionAllocation, idx: number) => {
                            return (
                                <tr key={allocation.name + idx}>
                                    <td className={allocation.isRestricted ? "restrictedLabel" : ""}>
                                        {allocation.isRestricted ? "Restricted" : "Eligible"}
                                    </td>
                                    <td>{allocation.name}</td>
                                    <td>{formatSize(allocation.quantity)}</td>
                                    <td>{formatSize(allocation.percent, 2) + "%"}</td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
                {RenderRestrictedText(restrictedPorfolios)}
            </div>
        );
    };
    const RenderEntity = ({
        entity,
        isSelected,
        brokerIdx
    }: {
        entity: BrokerEntity;
        isSelected: boolean;
        brokerIdx: number;
    }) => {
        const restrictedPorfolios: string[] = entity
            .restriction!.allocation.filter((allocation) => allocation.isRestricted)
            .map((allocation) => allocation.name);
        const getFooterText = () => {
            const restricted = entity.restriction!.allocation.filter((allocation) => allocation.isRestricted);
            if (restricted.length === 0) {
                return "There are no restrictions for this broker";
            } else {
                return `${restricted.length} of ${entity.restriction!.allocation.length} portfolios restricted`;
            }
        };
        const isExpanded = (name: string) => {
            if (!expandedMap.has(name)) {
                return false;
            }
            return expandedMap.get(name);
        };
        const toggleExpanded = (name: string) => {
            setExpandedMap(new Map(expandedMap.set(name, !isExpanded(name))));
        };
        return (
            <div data-test-id={"restrictioncard" + (brokerIdx + 1)} className="restrictionCard">
                {isSelected ? <div className="restrictionCardSelected"></div> : null}
                <AuxCard
                    isVerticallyExpanded={isExpanded(entity.name)}
                    header={"left-right" as AuxCardType}
                    className="aux-container"
                    borderPadding="8"
                >
                    <div slot="right" className="restrictionCardExpanderButton">
                        <AuxButton
                            data-test-id="expander"
                            icon={isExpanded(entity.name) ? "arrow-up" : "arrow-down"}
                            ref={(el) => el?.addEventListener("click", () => toggleExpanded(entity.name))}
                            type={AuxButtonTypeEnum.TERTIARY_SUBTLE}
                            ariaConfig={{
                                "aria-expanded": `${isExpanded(entity.name)}`
                            }}
                            isDisabled={false}
                        ></AuxButton>
                    </div>

                    <div slot="left" className="restrictionCardZindexFix">
                        <div className="restrictionCardHeader">
                            {
                                <div className="restrictionCardRadio">
                                    <AuxRadio
                                        data-test-id={"restrictionradio" + (brokerIdx + 1)}
                                        isChecked={isSelected}
                                        onRadioChanged={() => onSelectRestrictedBroker(brokerIdx)}
                                        isDisabled={orderUtils.isFullyRestricted(entity)}
                                    />
                                </div>
                            }
                            <div
                                className={
                                    orderUtils.isFullyRestricted(entity)
                                        ? "restrictionCardBroker restrictionCardDisabled"
                                        : "restrictionCardBroker"
                                }
                            >
                                {entity.name}
                            </div>
                            <div>
                                <span
                                    className={
                                        orderUtils.isFullyRestricted(entity)
                                            ? "restrictionCardQuantityNone"
                                            : "restrictionCardQuantity"
                                    }
                                >
                                    {`${formatSize(entity.restriction!.quantity)} / ${formatSize(
                                        entity.restriction!.percent,
                                        2
                                    )}%`}
                                </span>
                                <span> of available quantity</span>
                            </div>
                        </div>
                        <div className={"restrictionCardFooter"}>{getFooterText()}</div>
                        {isSelected && !isExpanded(entity.name) ? RenderRestrictedText(restrictedPorfolios) : null}
                    </div>

                    <div slot="content" className="restrictionCardZindexFix">
                        {isExpanded(entity.name) ? (
                            <RenderAllocations
                                allocations={entity.restriction!.allocation}
                                restrictedPorfolios={restrictedPorfolios}
                            ></RenderAllocations>
                        ) : null}
                    </div>
                </AuxCard>
            </div>
        );
    };
    const RenderBroker = (broker: Broker) => {
        return brokersWithRestrictions.map((entity: BrokerEntity, idx: number) => {
            return (
                <RenderEntity
                    key={entity.name}
                    entity={entity}
                    isSelected={
                        broker.selectedRestrictedBroker === idx ||
                        (isCares() && isValidNumber(broker.selectedRestrictedBroker))
                    }
                    brokerIdx={idx}
                ></RenderEntity>
            );
        });
    };
    const RenderInfo = (broker: Broker) => {
        const entity = orderUtils.getSelectedBrokerEntity(broker, brokerSelected!);
        if (entity !== undefined && orderUtils.isFullyAvailable(entity)) return null;
        if (entity === undefined && isCares()) return null;

        let msg = "";
        if (isCares()) msg = `There are portfolio allocations restricted from being executed with ${brokerSelected}.`;
        else {
            msg = `There are portfolio allocations restricted from being executed with ${broker.rollup}. These will be removed from this placement.`;
        }
        return (
            <AuxNotificationGroup
                key={brokerSelected}
                data-test-id="restrictions-notification-group"
                config={[
                    {
                        id: "1",
                        message: msg,
                        notificationStyle: AuxNotificationStyleEnum.WARNING,
                        showCloseIcon: false
                    }
                ]}
            />
        );
    };
    return (
        <div>
            {RenderInfo(broker)}
            {RenderBroker(broker)}
        </div>
    );
}
