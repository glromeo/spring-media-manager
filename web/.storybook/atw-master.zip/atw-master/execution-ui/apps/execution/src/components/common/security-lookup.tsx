import { AtwSecurityLookup, SecurityLookupProps, SecurityOption } from "@atw/toolkit";
import { ForwardedRef, forwardRef } from "react";

export type AtxSecurityLookupProps = Omit<SecurityLookupProps, "onLookupSuccess" | "columnOrder">;

export const SecurityLookup = forwardRef((props: AtxSecurityLookupProps, ref: ForwardedRef<HTMLElement>) => {
    return (
        <AtwSecurityLookup
            {...props}
            onLookupSuccess={(data: SecurityOption[]) => {
                return data.filter((sec: SecurityOption) => sec.secType === "GOVT");
            }}
            columnOrder={["ticker", "desc1", "cusip", "isin", "secGroup", "secType", "sedol"]}
        />
    );
});
