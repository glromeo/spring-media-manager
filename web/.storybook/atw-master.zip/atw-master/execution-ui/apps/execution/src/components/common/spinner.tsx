import {
    AuxProgressIndicator,
    AuxProgressIndicatorSizeEnum,
    AuxProgressIndicatorTypeEnum
} from "@blk/aladdin-react-components-es";
import { useAppSelector } from "../../app";
import { useEffect } from "react";
import { logClick } from "@atw/toolkit/telemetry";

export function Spinner({ title }: { title: string }) {
    const orderNumber = useAppSelector(({ config }) => config.orderNumber);
    useEffect(() => {
        progressInd();
    }, []);

    function progressInd() {
        {
            logClick(`${title}`, { orderNumber });
        }
    }

    return (
        <div className="restrictionLoading">
            <AuxProgressIndicator
                hasCounter
                hasLabel
                isSpinner
                loadingLabel={title}
                progress={30}
                size={AuxProgressIndicatorSizeEnum.LARGE}
                type={AuxProgressIndicatorTypeEnum.LOADING}
            />
        </div>
    );
}
