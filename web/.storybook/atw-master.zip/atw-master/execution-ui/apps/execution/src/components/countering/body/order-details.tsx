import React from "react";
import { counteringUtils, genericUtils, orderUtils } from "../../../common/utils";
import { Countering } from "../../../features/countering/countering";
import { Order } from "../../../features/order/order";
import { MessageBar } from "../../common/message-bar";

export function OrderDetails({ order, countering }: { order: Order; countering: Countering }) {
    const { formatPrice, formatSize, removeSpace } = genericUtils;
    const getMessageBarConfig = ():
        | { message: string; color: "RED" | "YELLOW" | "GREEN"; popup: boolean }
        | undefined => {
        const placement = orderUtils.getPlacement(order, countering.placementNum);
        const brokerName = placement ? counteringUtils.getValidQuote(placement, order.side)?.counterparty.shortName : undefined;

        switch (countering.state) {
            case "BROKER_ACCEPTED":
            case "BROKER_ACCEPTED_DISABLE":
                return {
                    popup: true,
                    message: "Please accept to proceed",
                    color: "GREEN"
                };
            case "REPEAT_ORIGINAL":
                return {
                    popup: true,
                    message: `Broker ${brokerName} has repeated`,
                    color: "YELLOW"
                };
            case "COUNTER_NEW":
                return {
                    popup: true,
                    message: `Broker ${brokerName} has countered`,
                    color: "YELLOW"
                };
            case "COUNTER_CANCELED":
                return {
                    popup: true,
                    message: "Counter canceled",
                    color: "RED"
                };
            case "DUE_IN_EXPIRED":
                return {
                    popup: true,
                    message: `Due in timer expired`,
                    color: "RED"
                };
            case "COUNTER_REJECTED":
                return {
                    popup: true,
                    message: `Broker ${brokerName} has rejected`,
                    color: "RED"
                };
            case "COUNTER_TIMEOUT":
                return {
                    popup: true,
                    message: `Counter has timed out`,
                    color: "RED"
                };
        }
    };
    switch (countering.state) {
        case "BROKER_ACCEPTED":
        case "BROKER_ACCEPTED_DISABLE":
        case "REPEAT_ORIGINAL":
        case "COUNTER_NEW":
        case "COUNTER_REJECTED":
        case "COUNTER_CANCELED":
        case "DUE_IN_EXPIRED":
        case "COUNTER_TIMEOUT":
            return (
                <div>
                    <MessageBar config={getMessageBarConfig()!} />
                    <span
                        data-test-id={removeSpace("Popup-Ticker")}
                        className="counteringPopupValue"
                    >{`${order.side.toString()} ${order.bond}`}</span>

                    <div data-test-id={removeSpace("Popup-Order-Details")} className="counteringPopupContentRow">
                        <div className="counteringPopupValuePair">
                            <div className="counteringPopupLabel"> Order # </div>
                            <div className="counteringPopupValue">{`${order.id}`}</div>
                        </div>
                        <div className="counteringPopupValuePair">
                            <div className="counteringPopupLabel"> Placement # </div>
                            <div className="counteringPopupValue">{`${countering.placementNum}`}</div>
                        </div>
                        <div className="counteringPopupValuePair">
                            <div className="counteringPopupLabel"> Order Size </div>
                            <div className="counteringPopupValue">{`${formatSize(order.origSize)}`}</div>
                        </div>
                        <div className="counteringPopupValuePair">
                            <div className="counteringPopupLabel"> Order Leaves </div>
                            <div className="counteringPopupValue">{`${formatSize(order.orderLeaves)}`}</div>
                        </div>
                        {order.limit ? (
                            <React.Fragment>
                                <div className="counteringPopupValuePair">
                                    <div className="counteringPopupLabel"> Price Limit </div>
                                    <div className="counteringPopupValue">{`$${formatPrice(order.limit)}`}</div>
                                </div>
                            </React.Fragment>
                        ) : null}
                    </div>
                </div>
            );
        case "ACCEPT_BROKER":
        case "ACCEPT_ORIGINAL":
        case "ACCEPT_NEW":
        case "PASSING_BROKER":
        case "PASSING_ORIGINAL":
        case "PASSING_NEW":
            return (
                <div data-test-id={removeSpace("Popup-Order-Details")} className="counteringPopupContentRow">
                    <div className="counteringPopupValuePair">
                        <div className="counteringPopupLabel"> Order # </div>
                        <div className="counteringPopupValue">{`${order.id}`}</div>
                    </div>
                    <div className="counteringPopupValuePair">
                        <div className="counteringPopupLabel"> Placement # </div>
                        <div className="counteringPopupValue">{`${countering.placementNum}`}</div>
                    </div>
                </div>
            );
        default:
            return <div data-test-id={removeSpace("Popup-Unknown")}></div>;
    }
}
