import { counteringUtils, genericUtils, windowUtils } from "../../../common/utils";
import { Countering } from "../../../features/countering/countering";
import { Order } from "../../../features/order/order";
import { HIGH_YIELD } from "../../../models/common";
import "./quote-history.scss";

export function QuoteHistory({ order, countering }: { order: Order; countering: Countering }) {
    const { formatSize, removeSpace } = genericUtils;
    let valueLabel = "Price $";
    const getData = (showCompleteHistory: boolean) => {
        if (countering.history) {
            if (countering.history.length > 3) {
                const extra = countering.history.length - 3;
                const adjustedHeight = 425 + extra * 55; // add 55 px for each extra row
                windowUtils.resizeWindow({ width: 700, height: adjustedHeight });
            }
            const lastHistory = countering.history[countering.history?.length - 1];
            const negotiationQuality = lastHistory.quality || order.quality;

            valueLabel = negotiationQuality == HIGH_YIELD ? "Price $" : "Spread";
            columnLabels = ["Status", valueLabel, "Size"];

            if (showCompleteHistory) {
                return countering.history.map((row) => {
                    // Assume price or spread based on the last broker quote
                    return {
                        Status: row.status,
                        [valueLabel]: counteringUtils.formatHistoryPriceBasedOnQuality(row, negotiationQuality),
                        Size: row.size ? formatSize(row.size) : "-"
                    };
                });
            } else {
                return [
                    {
                        Side: order.side,
                        Bond: order.bond,
                        Size: lastHistory.size ? formatSize(lastHistory.size) : "-",
                        [valueLabel]: counteringUtils.formatHistoryPriceBasedOnQuality(lastHistory, negotiationQuality),
                        Broker: lastHistory.broker ? lastHistory.broker : order.broker.rollup
                    }
                ];
            }
        } else {
            // default - return the order information
            return [
                {
                    Side: order.side,
                    Bond: order.bond,
                    Size: order.origSize,
                    [valueLabel]: order.price,
                    Broker: order.broker.rollup
                }
            ];
        }
    };
    let columnLabels: string[] = [];
    let data: any[] = [];
    switch (countering.state) {
        case "BROKER_ACCEPTED":
        case "BROKER_ACCEPTED_DISABLE":
        case "REPEAT_ORIGINAL":
        case "COUNTER_NEW":
        case "COUNTER_REJECTED":
        case "COUNTER_CANCELED":
        case "DUE_IN_EXPIRED":
        case "COUNTER_TIMEOUT":
            data = getData(true);
            columnLabels = ["Status", valueLabel, "Size"];
            break;
        case "ACCEPT_BROKER":
        case "ACCEPT_ORIGINAL":
        case "ACCEPT_NEW":
        case "PASSING_BROKER":
        case "PASSING_ORIGINAL":
        case "PASSING_NEW":
            data = getData(false);
            columnLabels = ["Side", "Bond", "Size", valueLabel, "Broker"];
            break;
    }
    const getAdditonalContent = () => {
        switch (countering.state) {
            case "ACCEPT_BROKER":
            case "ACCEPT_ORIGINAL":
            case "ACCEPT_NEW":
            case "PASSING_BROKER":
            case "PASSING_ORIGINAL":
            case "PASSING_NEW":
                return "Would you still like to proceed?";
            default:
                return "";
        }
    };
    const getCellClassName = (rowIndex: number, label: string) => {
        const isPriceLabel = label === "Price $" || label === "Spread";
        const isSizeLabel = label === "Size";
        const isCounteredOrRepeated = countering.state === "REPEAT_ORIGINAL" || countering.state === "COUNTER_NEW";

        let name = isPriceLabel || isSizeLabel ? "justify-right" : "justify-left";
        if (
            // only apply checks for last row
            countering.history?.length &&
            rowIndex === countering.history?.length - 1 &&
            countering.history?.length > 2
        ) {
            if (
                // highlight size if broker size ≠ trader size
                (isCounteredOrRepeated &&
                    isSizeLabel &&
                    countering.history[countering.history.length - 1].size !==
                        countering.history[countering.history.length - 2].size) ||
                // highlight price if broker price/spread ≠ trader price/spread
                (isCounteredOrRepeated &&
                    isPriceLabel &&
                    countering.history[countering.history.length - 1].value !==
                        countering.history[countering.history.length - 2].value)
            ) {
                name += " countering-popup-body__cell--highlighted";
            }
        }

        return name;
    };
    return (
        <div
            className="countering-popup-quote-history"
            data-test-id={removeSpace("Popup-Quote-History")}
            style={{ width: "100%", height: "100%", minHeight: "6rem" }}
        >
            <table className="atw-table">
                <thead>
                    <tr>
                        {columnLabels.map((label, colIndex) => (
                            <th
                                key={colIndex}
                                className={
                                    label === "Price $" || label === "Spread" || label === "Size"
                                        ? "justify-right"
                                        : "justify-left"
                                }
                            >
                                {label}
                            </th>
                        ))}
                    </tr>
                </thead>
                <tbody>
                    {data.map((row, rowIndex) => (
                        <tr key={rowIndex}>
                            {columnLabels.map((label, colIndex) => (
                                <td key={colIndex} className={getCellClassName(rowIndex, label)}>
                                    {row[label]}
                                </td>
                            ))}
                        </tr>
                    ))}
                </tbody>
            </table>
            <div
                data-test-id={removeSpace("Popup-Additional-Content")}
                className={getAdditonalContent() && "counteringPopupAdditonalContent"}
            >
                {getAdditonalContent()}
            </div>
        </div>
    );
}
