import { AuxButton, AuxButtonSizeEnum, AuxButtonTypeEnum } from "@blk/aladdin-react-components-es";
import { useEffect, useState } from "react";
import { useAppDispatch, useAppSelector } from "../../app";
import { TEXT } from "../../common/constants";
import { counteringUtils, genericUtils } from "../../common/utils";
import { Alert } from "../../features/alerts/alert";
import { ACCEPT_STATES, ActionType, Countering } from "../../features/countering/countering";
import { setCounteringState, validateBeforeSend } from "../../features/countering/counteringActions";
import { Order } from "../../features/order/order";

export function Footer({ countering, order }: { countering: Countering; order: Order }) {
    const dispatch = useAppDispatch();
    const [acceptButtonDisabled, setAcceptButtonDisabled] = useState(false);
    const [confirmButtonAction, setConfirmButtonAction] = useState("SEND");
    const { removeSpace } = genericUtils;

    const alerts = useAppSelector((state) => state.alerts);

    const RenderCounter = () => {
        return (
            <AuxButton
                data-test-id={removeSpace("Popup-CounterButton")}
                data-telemetry-id="Popup-CounterButton"
                label="Counter"
                size={AuxButtonSizeEnum.REGULAR}
                type={AuxButtonTypeEnum.SECONDARY}
                onClick={() => onWorkflowClick("COUNTER")}
            />
        );
    };

    const RenderClose = () => {
        return (
            <AuxButton
                data-test-id={removeSpace("Popup-CloseButton")}
                data-telemetry-id="Popup-CloseButton"
                label="Close"
                size={AuxButtonSizeEnum.REGULAR}
                type={AuxButtonTypeEnum.SECONDARY}
                onClick={() => onWorkflowClick("CLOSE")}
            />
        );
    };

    const onWorkflowClick = (action: ActionType) => {
        if (action === "SEND" && ACCEPT_STATES.includes(countering.state)) {
            const latestCounteringSize = countering.history![countering.history!.length - 1].size!;
            dispatch(validateBeforeSend({ order, placementNumber: countering.placementNum, latestCounteringSize }));
        } else {
            dispatch(setCounteringState({ action }));
        }
    };

    const getConfirmButtonLabel = (): string => {
        if (countering.state.includes("PASSING")) {
            return TEXT.PASS;
        }
        // may need to modify based on countering state
        if (confirmButtonAction === "SEND") {
            return TEXT.SEND;
        } else if (confirmButtonAction === "ACKSEND") {
            return TEXT.ACK_SEND_BUTTON_LABEL;
        }
        return confirmButtonAction;
    };

    useEffect(() => {
        if (countering.hasValidData) {
            const counteringNotifications: Alert[] = counteringUtils
                .getCounteringNotifications(order, countering)
                .concat(alerts);
            if (counteringNotifications.some((a) => a.type === "ERROR")) {
                setAcceptButtonDisabled(true);
            } else if (counteringNotifications.filter((a) => a.type === "WARNING").length > 0) {
                setConfirmButtonAction("ACKSEND");
            } else {
                setConfirmButtonAction("SEND");
            }
        }
    }, [alerts, countering.hasValidData]);

    switch (countering.state) {
        // LIVE STATES
        case "BROKER_ACCEPTED":
        case "BROKER_ACCEPTED_DISABLE":
        case "REPEAT_ORIGINAL":
        case "COUNTER_NEW":
            return (
                <div className="counteringPopupFooter">
                    <div className="counteringPopupFooterContent">
                        <AuxButton
                            data-test-id={removeSpace("Popup-AcceptButton")}
                            data-telemetry-id="Popup-AcceptButton"
                            label="Accept"
                            size={AuxButtonSizeEnum.REGULAR}
                            type={AuxButtonTypeEnum.SECONDARY}
                            isDisabled={countering.state === "BROKER_ACCEPTED_DISABLE" || acceptButtonDisabled}
                            onClick={() => onWorkflowClick("ACCEPT")}
                        />
                        {RenderCounter()}
                        <AuxButton
                            data-test-id={removeSpace("Popup-PassButton")}
                            data-telemetry-id="Popup-PassButton"
                            label="Pass"
                            size={AuxButtonSizeEnum.REGULAR}
                            type={AuxButtonTypeEnum.SECONDARY}
                            isDisabled={countering.state === "BROKER_ACCEPTED_DISABLE"}
                            onClick={() => onWorkflowClick("PASS")}
                        />
                    </div>
                </div>
            );
        // CONFIRM ACTION STATES
        case "ACCEPT_BROKER":
        case "ACCEPT_ORIGINAL":
        case "ACCEPT_NEW":
        case "PASSING_BROKER":
        case "PASSING_ORIGINAL":
        case "PASSING_NEW":
            return (
                <div className="counteringPopupFooter">
                    <div className="counteringPopupFooterContent">
                        <AuxButton
                            data-test-id={removeSpace("Popup-ConfirmButton")}
                            data-telemetry-id="Popup-ConfirmButton"
                            label={getConfirmButtonLabel()}
                            size={AuxButtonSizeEnum.REGULAR}
                            type={AuxButtonTypeEnum.PRIMARY}
                            isDisabled={counteringUtils.isPassingState(countering.state) ? false : acceptButtonDisabled}
                            onClick={() => onWorkflowClick(confirmButtonAction as ActionType)}
                        />
                        <AuxButton
                            data-test-id={removeSpace("Popup-CancelButton")}
                            data-telemetry-id="Popup-CancelButton"
                            label="Cancel"
                            size={AuxButtonSizeEnum.REGULAR}
                            type={AuxButtonTypeEnum.SECONDARY}
                            onClick={() => onWorkflowClick("CANCEL")}
                        />
                    </div>
                </div>
            );
        // this is technically a LIVE state ... so we have to check against axe for counter
        case "COUNTER_TIMEOUT":
        // DEAD STATES
        case "COUNTER_REJECTED":
        case "COUNTER_CANCELED":
        case "DUE_IN_EXPIRED":
        default:
            return (
                <div className="counteringPopupFooter">
                    <div className="counteringPopupFooterContent">{RenderClose()}</div>
                </div>
            );
    }
}
