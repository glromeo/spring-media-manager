import { useAppDispatch } from "../../app";
import { TEXT } from "../../common/constants";
import { genericUtils, windowUtils } from "../../common/utils";
import { CounteringState } from "../../features/countering/countering";
import { setCounteringState } from "../../features/countering/counteringActions";
import { Side } from "../../models/common";
import { CountDown } from "../common/countdown";

export function Header({ state, timer, orderSide }: { state: CounteringState; timer: number; orderSide?: Side }) {
    const dispatch = useAppDispatch();
    let title = "";
    let showCountDown = true;
    switch (state) {
        case "BROKER_ACCEPTED":
        case "BROKER_ACCEPTED_DISABLE":
            title = TEXT.BROKER_ACCEPTED_TITLE;
            break;
        case "REPEAT_ORIGINAL":
            title = orderSide === "BUY" ? "Offer Repeated" : "Bid Repeated";
            break;
        case "COUNTER_NEW":
            title = orderSide === "BUY" ? "Offer Countered" : "Bid Countered";
            break;
        case "COUNTER_CANCELED":
            showCountDown = false;
            title = "Counter Canceled";
            break;
        case "COUNTER_REJECTED":
            showCountDown = false;
            title = "Counter Rejected";
            break;
        case "COUNTER_TIMEOUT":
            showCountDown = false;
            title = "Counter Timed Out";
            break;
        case "DUE_IN_EXPIRED":
            showCountDown = false;
            title = "Counter Canceled - Due In Timer Expired";
            break;
        case "ACCEPT_BROKER":
        case "ACCEPT_ORIGINAL":
        case "ACCEPT_NEW":
            title = "Confirm Accept";
            break;
        case "PASSING_BROKER":
            title = "Confirm Pass";
            break;
        case "PASSING_ORIGINAL":
        case "PASSING_NEW":
            title = "Confirm Pass";
            break;

        default:
            showCountDown = false;
            title = "Unable to retrieve placement info - please try again";
            break;
    }
    genericUtils.updateBrowserTitle(title);
    return (
        <div className="counteringPopupHeader">
            {showCountDown ? (
                <div className="counteringPopupContentTimer">
                    <CountDown
                        type="countering"
                        timer={Number(timer)}
                        onCountDownEnd={() => {
                            dispatch(setCounteringState({ action: "TIMEOUT" }));
                            windowUtils.closeWindow("countering good for timer expired");
                        }}
                    />
                </div>
            ) : null}
            <div data-test-id={genericUtils.removeSpace("Popup-Title")} className="counteringPopupHeaderTitle">
                {title}
            </div>
        </div>
    );
}
