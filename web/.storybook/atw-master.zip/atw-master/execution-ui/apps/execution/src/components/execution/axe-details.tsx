import { useMemo } from "react";
import { useAppDispatch, useAppSelector } from "../../app";
import { configUtils, pricingTypeUtils } from "../../common/utils";
import { clearAlerts } from "../../features/alerts/alertsActions";
import { AxeSchema } from "../../features/axe/axe";
import { setAxeBenchmark } from "../../features/axe/axeActions";
import { StepperState, WORKFLOWS } from "../../features/stepper/stepper";
import { COUNTERPARTY_TYPE_MAP, PRICING_TYPE_MAP, STRING_PLACE_HOLDER } from "../../models/common";
import { DetailsTable, DetailsTableRowType } from "../common/details-table";
import { SecurityLookupProps } from "@atw/toolkit";

export function AxeDetails() {
    const dispatch = useAppDispatch();
    const axeInfo = useAppSelector((state) => state.axeInfo);
    const orderInfo = useAppSelector((state) => state.orderInfo);
    const config = useAppSelector((store) => store.config);
    const countering = useAppSelector((store) => store.counteringInfo?.countering);
    const stepIdx = useAppSelector((store) => store.stepper.stepIdx);
    const currentWorkflow = WORKFLOWS[config.workflow];
    const isA2A = configUtils.isAxeA2AMode();
    const axeDetailsTitle = useMemo(() => {
        if (isA2A) {
            return "A2A Axe";
        }

        return "Axe";
    }, [isA2A]);

    const getAxeBmkTableRowProps = () => {
        // have to set props up first on initial render, then add editable.....function props weren't being added correctly when switching from hit/lift to counter
        // refactor-todo: find a way to ensure function props are updated and referenced properly when setting them after initial render
        let axeBmkTableRowProps: Partial<SecurityLookupProps | DetailsTableRowType> = {
            editable: false,
            onSelectionChange: (security: string) => {
                dispatch(clearAlerts());
                dispatch(setAxeBenchmark(security));
            },
            ref: (node: any) => {
                if (node.current && typeof node.current.validate === "function") {
                    // initial validation on mount, need to do this since there is no prop/ref access to underlying Aux input...
                    node.current.validate();
                }
            },
            dropdownOffsetWidth: 0
        };

        if (configUtils.isCounteringMode(config) && currentWorkflow[stepIdx] === StepperState.Order) {
            // only countering mode and order step can you edit
            axeBmkTableRowProps.editable = true
        }
        return axeBmkTableRowProps;
    };

    const getAxeDetails = (): DetailsTableRowType[] => {
        const pricingType = pricingTypeUtils.getCurrentPricingType({ axeInfo, orderInfo, config, countering });
        return axeInfo.schema
            .filter((schema: AxeSchema) => schema.visibleFor(PRICING_TYPE_MAP[pricingType], config, axeInfo.axe))
            .map((schema: AxeSchema): DetailsTableRowType => {
                let value = axeInfo.axe === undefined ? STRING_PLACE_HOLDER : (axeInfo.axe as any)[schema.field];
                if (schema.field === "counterPartyType") {
                    value = COUNTERPARTY_TYPE_MAP[value] ?? STRING_PLACE_HOLDER;
                }

                return {
                    label: schema!.label,
                    value:
                        schema.field === "code"
                            ? orderInfo.order !== undefined
                                ? `${orderInfo.order.broker.rollup}${isA2A ? " A2A " : " "}Axed to ${
                                      orderInfo.order.side === "BUY" ? "SELL" : "BUY"
                                  }`
                                : value
                            : value,
                    type: schema!.type,
                    ...(schema.field === "axeBmk" && {
                        ...getAxeBmkTableRowProps()
                    }),
                    separator: schema.separator && schema.separator(axeInfo.axe),
                    className: schema.classNameFor(orderInfo.order.side, value)
                };
            });
    };
    return (
        <div>
            <div className="tableHeader">{axeDetailsTitle}</div>
            <DetailsTable name="axe" data={getAxeDetails()}></DetailsTable>
        </div>
    );
}
