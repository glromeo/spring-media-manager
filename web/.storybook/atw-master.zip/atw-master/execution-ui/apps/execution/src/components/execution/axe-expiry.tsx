import { useCallback } from "react";
import { useAppDispatch } from "../../app";

import { useSettings } from "../../common/hooks/useSettings";
import { configUtils } from "../../common/utils";
import { CountDown } from "../common/countdown";

import { NUM_PLACE_HOLDER } from "../../models/common";

import { Alert } from "../../features/alerts/alert";
import { setAlert } from "../../features/alerts/alertsActions";
import { fatalStep } from "../../features/stepper/stepperActions";

import "./axe-expiry.scss";

export const AxeExpiry = () => {
    const dispatch = useAppDispatch();

    const config = useSettings();
    const expiryTime = config.axeExpiryTime !== NUM_PLACE_HOLDER ? config.axeExpiryTime : null;

    const onCountDownEnd = useCallback(() => {
        const expiryAlert: Alert = {
            id: expiryTime ?? 1,
            message: "The Axe has expired. Unable to send trade to broker.",
            type: "ALERT"
        };

        dispatch(setAlert([expiryAlert]));
        dispatch(fatalStep());
    }, [dispatch]);

    return configUtils.isAxeA2AMode() && expiryTime !== null ? (
        <CountDown title="Due in " type="axeExpiry" onCountDownEnd={onCountDownEnd} timer={expiryTime} />
    ) : null;
};
