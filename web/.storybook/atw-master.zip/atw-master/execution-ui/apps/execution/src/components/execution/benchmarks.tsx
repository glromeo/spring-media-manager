import { useEffect } from "react";
import { useAppDispatch, useAppSelector } from "../../app";
import { configUtils, genericUtils, pricingTypeUtils } from "../../common/utils";
import { Alert } from "../../features/alerts/alert";
import { setAlert } from "../../features/alerts/alertsActions";
import { fatalStep } from "../../features/stepper/stepperActions";
import { SPREAD } from "../../models/common";

export function Benchmarks() {
    const dispatch = useAppDispatch();
    const alerts = useAppSelector((state) => state.alerts);
    const axeInfo = useAppSelector((state) => state.axeInfo);
    const orderInfo = useAppSelector((state) => state.orderInfo);
    const config = useAppSelector((store) => store.config);
    const countering = useAppSelector((store) => store.counteringInfo?.countering);
    const { axeBmk, axeBmkId } = axeInfo.axe;
    const { orderBmk, orderBmkId } = orderInfo.order;
    const { isValidString } = genericUtils;

    useEffect(() => {
        const hasValidData = () => (configUtils.isCares() || axeInfo.axe.hasValidData) && orderInfo.order.hasValidData;
        // only this for for spread based
        if (
            hasValidData() &&
            pricingTypeUtils.getCurrentPricingType({ axeInfo, orderInfo, countering, config }) === SPREAD
        ) {
            // if we have already popped a notification - then don't do again...
            const hasAlerted = alerts.filter((alert: Alert) => alert.message.indexOf("Benchmark") > -1).length > 0;
            if (hasAlerted) return;
            // throw an error based on criteria
            if (configUtils.isCares()) {
                if (!orderInfo.order.hasValidData) return;
                // assumption here is if there is no orderBmk or axeBmk description, there wasn't a successful response for the bonds
                // just because you get an axeBmkId from the query param or orderBmkId from order query doesn't mean it's "real"
                if (!isValidString(orderBmk)) {
                    const alert: Alert = {
                        id: 1,
                        message: "Aladdin Security Benchmark not found. Please enter a security benchmark.",
                        type: "WARNING"
                    };
                    dispatch(setAlert([alert]));
                }
            } else {
                if (!axeInfo.axe.hasValidData) return;
                if (!isValidString(orderBmk) && !isValidString(axeBmk) && !configUtils.isCounteringMode(config)) {
                    const alert: Alert = {
                        message:
                            "Aladdin Security Benchmark and Axe Benchmark not found. Unable to send trade to broker.",
                        type: "ALERT"
                    };
                    dispatch(setAlert([alert]));
                    dispatch(fatalStep());
                } else if (isValidString(orderBmk) && !isValidString(axeBmk) && !configUtils.isCounteringMode(config)) {
                    const alert: Alert = {
                        message: "Axe Benchmark not found. Unable to send trade to broker.",
                        type: "ALERT"
                    };
                    dispatch(setAlert([alert]));
                    dispatch(fatalStep());
                } else if (!isValidString(orderBmk) && isValidString(axeBmk)) {
                    const alert: Alert = {
                        id: 1,
                        message: `Aladdin Security Benchmark not found. The Axe Benchmark [${axeInfo.axe.axeBmk}] will be sent to the broker.`,
                        type: "WARNING"
                    };

                    dispatch(setAlert([alert]));
                } else if (orderBmkId !== axeBmkId && isValidString(orderBmk) && isValidString(axeBmk)) {
                    const alert: Alert = {
                        id: 1,
                        message: `Aladdin Security Benchmark [${orderInfo.order.orderBmk}] is different from the Axe Benchmark [${axeInfo.axe.axeBmk}]. The Axe Benchmark will be sent to the broker.`,
                        type: "WARNING"
                    };

                    dispatch(setAlert([alert]));
                }
            }
        }
    }, [config.axeQuality, axeInfo.axe.hasValidData, orderInfo.order.hasValidData, axeInfo.axe.axeBmk, config.mode]); // eslint-disable-line react-hooks/exhaustive-deps
    return null;
}
