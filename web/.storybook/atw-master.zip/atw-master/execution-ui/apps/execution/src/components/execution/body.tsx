import { Workflow } from "./workflow";

export function Body() {
    return (
        <div className="executionBody">
            <Workflow></Workflow>
        </div>
    );
}
