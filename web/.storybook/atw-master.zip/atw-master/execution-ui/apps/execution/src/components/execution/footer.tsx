import { logClick } from "@atw/toolkit/telemetry";
import { AuxButton, AuxButtonSizeEnum, AuxButtonTypeEnum } from "@blk/aladdin-react-components-es";
import { useEffect, useState } from "react";
import { useAppDispatch, useAppSelector } from "../../app";
import { useNavigate } from "react-router-dom";
import { TEXT } from "../../common/constants";
import { useSettings } from "../../common/hooks/useSettings";
import { configUtils, genericUtils, orderUtils, pricingTypeUtils, windowUtils } from "../../common/utils";
import { alertUtils } from "../../common/utils/alertUtils";
import { clearAlerts } from "../../features/alerts/alertsActions";
import { resetAxe } from "../../features/axe/axeActions";
import { setAction, setConfig } from "../../features/config/configActions";
import { setCounteringState } from "../../features/countering/counteringActions";
import { getCounteringUrl } from "../../features/countering/counteringApi";
import { BrokerEntity } from "../../features/order/order";
import { StepperState, WORKFLOWS } from "../../features/stepper/stepper";
import {
    lastStep,
    nextStep,
    previousStep,
    sendOrder,
    setStep,
    validateOrder
} from "../../features/stepper/stepperActions";
import { resetTradeForm } from "../../features/tradeForm/tradeFormActions";
import { NUM_PLACE_HOLDER, STRING_PLACE_HOLDER } from "../../models/common";

export function Footer() {
    const dispatch = useAppDispatch();
    const navigate = useNavigate();
    const counteringInfo = useAppSelector((state) => state.counteringInfo);
    const alerts = useAppSelector((state) => state.alerts);
    const stepper = useAppSelector((state) => state.stepper);
    const axeInfo = useAppSelector((state) => state.axeInfo);
    const orderInfo = useAppSelector((state) => state.orderInfo);
    const tradeFormInfo = useAppSelector((state) => state.tradeFormInfo);
    const config = useAppSelector((store) => store.config);
    const [isDisabled, setIsDisabled] = useState<boolean>(true);
    const { removeSpace } = genericUtils;
    const currentWorkflow = WORKFLOWS[config.workflow];
    const onNext = () => {
        const nextStepLabel = getNextStepLabel().toUpperCase();

        if (nextStepLabel == "SEND" || stepper.status === "ACK_VALIDATION") {
            // user is about to bypass - and ignore notifications - just clear them out of the way first
            dispatch(clearAlerts());
        }
        logClick(`User clicked on ` + nextStepLabel);
        const workflow = WORKFLOWS[config.workflow];
        dispatch(nextStep(workflow));
    };
    const onPrevious = () => {
        const workflow = WORKFLOWS[config.workflow];
        dispatch(previousStep(workflow));
        dispatch(clearAlerts());
        logClick(`User clicked on Back to order`);
    };
    const clearStateAndSwitch = () => {
        // when going between execution and countering - we clear our execution state
        dispatch(setCounteringState({ action: "CANCEL" }));
        dispatch(setStep(0, WORKFLOWS["COUNTERED"]));
        dispatch(resetTradeForm());
        dispatch(resetAxe());
        dispatch(clearAlerts());
    };
    const onCancel = () => {
        if (counteringInfo.countering.state === "FORM") {
            logClick(
                `User clicked Cancel on execution form - going back to previous state ${counteringInfo.countering.prevState}`
            );
            clearStateAndSwitch();
        } else {
            const click = "User clicked on Cancel";
            windowUtils.closeWindow(click);
            logClick(`User clicked Cancel on execution window.`);
        }
    };

    const isRestrictedWorkflow = () => orderUtils.hasBrokerRestrictions(orderInfo.order); // TBD - once Catriona has API ...this might need to change
    const isValidSelectedBroker = (broker?: BrokerEntity) => {
        return broker && broker.code !== NUM_PLACE_HOLDER;
    };
    const isFullyAvailable = (broker?: BrokerEntity) => {
        if (isValidSelectedBroker(broker)) {
            return orderUtils.isFullyAvailable(broker!);
        }
        return false;
    };
    const getNextStepLabel = () => {
        const selectedBrokerEntity = orderUtils.getSelectedBrokerEntity(
            orderInfo.order.broker,
            tradeFormInfo.tradeForm.brokerSelected!
        );
        const inLastStep = stepper.stepIdx === currentWorkflow.length - 1;
        const isValidating = stepper.status === "ACK_VALIDATION";

        if (isRestrictedWorkflow()) {
            let selectedBroker = selectedBrokerEntity;
            if (!configUtils.isCares()) {
                // Selected broker via restriction list
                const brokerEntities = orderInfo.order.broker.entity;
                const selectedRestrictedBrokerIndex = orderInfo.order.broker.selectedRestrictedBroker;
                selectedBroker = genericUtils.isValidNumber(selectedRestrictedBrokerIndex)
                    ? brokerEntities[selectedRestrictedBrokerIndex!]
                    : undefined;
            }
            if (inLastStep) {
                // Return 'ACK & SEND' if we are validating, otherwise either SPLIT & SEND or SEND
                return isValidating
                    ? TEXT.ACK_SEND_BUTTON_LABEL
                    : isValidSelectedBroker(selectedBroker) && !isFullyAvailable(selectedBroker)
                    ? TEXT.SPLIT_AND_SEND
                    : TEXT.SEND;
            } else {
                // All internal 'Next' cases
                return !isValidSelectedBroker(selectedBroker) || isFullyAvailable(selectedBroker)
                    ? TEXT.NEXT
                    : TEXT.SPLIT_AND_NEXT;
            }
        } else {
            if (inLastStep) {
                // Return 'ACK & SEND' if we are validating
                return stepper.status === "ACK_VALIDATION" ? TEXT.ACK_SEND_BUTTON_LABEL : TEXT.SEND;
            } else {
                return TEXT.NEXT;
            }
        }
    };
    const getPreviousStepLabel = () => {
        const currentStep = currentWorkflow[stepper.stepIdx - 1];
        return `<< Back to ${currentStep.toString().toLowerCase()}`;
    };
    const isCurrentStepScreenValid = () => {
        const isInSplitStep = () => currentWorkflow[stepper.stepIdx] === StepperState.Split;
        const isInOrderStep = () => currentWorkflow[stepper.stepIdx] === StepperState.Order;
        const isInRestrictedWorkflow = () => config.workflow === "RESTRICTIONS" || isRestrictedWorkflow();

        if (alertUtils.hasFatalErrorOrHardNotification(alerts)) return false;

        if (isInSplitStep()) {
            // Must choose a valid broker via restriction list
            return genericUtils.isRestrictedBrokerSelected(orderInfo);
        }

        if (isInOrderStep()) {
            let hasValidRestrictedBrokerSelection = true;
            if (isInRestrictedWorkflow()) {
                if (genericUtils.isValidNumber(orderInfo.order.broker.selectedRestrictedBroker)) {
                    // If user selected a restricted broker via restriction list, must be valid
                    hasValidRestrictedBrokerSelection = genericUtils.isRestrictedBrokerSelected(orderInfo);
                } else if (
                    tradeFormInfo.tradeForm.brokerSelected &&
                    tradeFormInfo.tradeForm.brokerSelected !== STRING_PLACE_HOLDER
                ) {
                    // If user selected a broker via the broker selection dropdown...
                    const brokerEntity = orderUtils.getSelectedBrokerEntity(
                        orderInfo.order.broker,
                        tradeFormInfo.tradeForm.brokerSelected!
                    );
                    if (orderUtils.isRestrictedBrokerEntity(brokerEntity!)) {
                        // ...and they selected a restricted broker, check they've also selected the broker via the list
                        // which forces the traders to confirm the size
                        hasValidRestrictedBrokerSelection = genericUtils.isRestrictedBrokerSelected(orderInfo);
                    }
                } else {
                    // Haven't selected a broker via dropdown or restriction list
                    hasValidRestrictedBrokerSelection = false;
                }
            }

            if (
                hasValidRestrictedBrokerSelection &&
                tradeFormInfo.tradeForm.hasValidData &&
                orderInfo.order.hasValidData
            ) {
                if (pricingTypeUtils.isSpread(orderInfo.order, axeInfo.axe, config, counteringInfo.countering)) {
                    if (configUtils.isCares()) {
                        return genericUtils.isValidString(orderInfo.order.orderBmk);
                    }
                    return genericUtils.isValidString(axeInfo.axe.axeBmk);
                }
                return true;
            } else {
                // Either the restrictions, trade form, or order is not valid
                return false;
            }
        }

        return true;
    };

    useEffect(() => {
        switch (stepper.status) {
            case "VALIDATING":
                dispatch(
                    validateOrder({
                        order: orderInfo.order,
                        tradeForm: tradeFormInfo.tradeForm,
                        axe: axeInfo.axe,
                        config: config,
                        stepper: stepper,
                        countering: counteringInfo.countering
                    })
                );
                break;
            case "SENDING":
                dispatch(
                    sendOrder({
                        order: orderInfo.order,
                        tradeForm: tradeFormInfo.tradeForm,
                        axe: axeInfo.axe,
                        config: config,
                        stepper: stepper,
                        countering: counteringInfo.countering
                    })
                );
                break;
        }
    }, [stepper.status]); // eslint-disable-line react-hooks/exhaustive-deps

    useEffect(() => {
        if (counteringInfo.countering.state !== "NOT_SET" && counteringInfo.countering.state !== "FORM") {
            // user canceled - wants to go back to countering workflow popups
            const url = getCounteringUrl(counteringInfo.countering, orderInfo.order);
            const queryString = url.replace("/index.html", "");
            const queryUpdate = useSettings(queryString);
            if (config.action !== "NOT_SET") queryUpdate.action = config.action;
            dispatch(setConfig(queryUpdate));
            navigate(url);
        }
    }, [counteringInfo.countering, counteringInfo.countering.state, navigate, orderInfo.order]);

    useEffect(() => {
        if (config.action === "BACK") {
            console.log(
                "REFRESH_DATA action fired, we are on NOT on countering popup screen - we will switch back to popup to display new countered data"
            );
            dispatch(setAction("RELOAD"));
            onCancel();
        }
    }, [dispatch, config.action, onCancel]);

    useEffect(() => {
        if ((stepper.status === "VALIDATING" || stepper.status === "SENDING") && alerts.length > 0) {
            const workflow = WORKFLOWS[config.workflow];
            if (alertUtils.hasAlertType(alerts, "ERROR") || alertUtils.hasAlertType(alerts, "ALERT")) {
                // in this case - we do not allow user to pass - he has to fix hard validation errors
                dispatch(lastStep(workflow));
            } else if (alertUtils.hasAlertType(alerts, "WARNING")) {
                // in this case - we can allow the user to bypass validation - even though there are soft validation errors
                dispatch(lastStep(workflow, "ACK_VALIDATION"));
            }
            // check if all alerts and data on screen is good for user to click on next
        } else if (isCurrentStepScreenValid()) {
            setIsDisabled(false);
        } else {
            setIsDisabled(true);
        }
    }, [
        stepper.status,
        alerts,
        tradeFormInfo.tradeForm.hasValidData,
        orderInfo.order.hasValidData,
        tradeFormInfo.tradeForm.pricingProtocolChecked,
        axeInfo.axe.axeBmk,
        orderInfo.order.orderBmk,
        orderInfo.order.broker.selectedRestrictedBroker,
        tradeFormInfo.tradeForm.brokerSelected,
        config.workflow
    ]); // eslint-disable-line react-hooks/exhaustive-deps
    return (
        <div className="executionFooter">
            <div>
                {stepper.stepIdx > 0 ? (
                    <div className="executionFooterBackButton">
                        <AuxButton
                            data-test-id={removeSpace(getPreviousStepLabel()) + "button"}
                            isDisabled={false}
                            label={getPreviousStepLabel()}
                            onClick={onPrevious}
                            size={AuxButtonSizeEnum.REGULAR}
                            type={AuxButtonTypeEnum.TERTIARY}
                        />
                    </div>
                ) : null}
            </div>
            <div className="executionFooterButtons">
                <AuxButton
                    data-test-id={removeSpace(getNextStepLabel()) + "button"}
                    data-telemetry-id="ExecuteButton"
                    isDisabled={isDisabled}
                    label={getNextStepLabel()}
                    onClick={onNext}
                    size={AuxButtonSizeEnum.REGULAR}
                    type={AuxButtonTypeEnum.PRIMARY}
                />
                <AuxButton
                    data-test-id={removeSpace("Cancel") + "button"}
                    data-telemetry-id="CancelButton"
                    isDisabled={false}
                    label="Cancel"
                    onClick={onCancel}
                    size={AuxButtonSizeEnum.REGULAR}
                    type={AuxButtonTypeEnum.SECONDARY}
                    className="executionFooterCancel"
                />
            </div>
        </div>
    );
}
