import { useMemo } from "react";
import { BROWSER_TITLES } from "../../common/constants";
import { axeUtils, configUtils, genericUtils } from "../../common/utils";
import { HeaderBase } from "../common/header-base";

export function Header() {
    const isCares = configUtils.isCares();
    const isA2A = configUtils.isAxeA2AMode();
    const isIndAxe = axeUtils.isIndAxe();

    useMemo(() => {
        let title;
        switch (true) {
            case isCares:
                title = BROWSER_TITLES.VOICE_STP;
                break;
            case isIndAxe:
                title = BROWSER_TITLES.IND_AXE;
                break;
            case isA2A:
                title = BROWSER_TITLES.A2A;
                break;
            default:
                title = BROWSER_TITLES.ACTIONABLE;
                break;
        }

        genericUtils.updateBrowserTitle(title);
    }, [isCares, isA2A, isIndAxe]);

    return <HeaderBase />;
}
