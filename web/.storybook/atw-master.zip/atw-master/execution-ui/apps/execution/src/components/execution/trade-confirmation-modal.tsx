import { AuxButton, AuxModal } from "@blk/aladdin-react-components-es";
import { useEffect, useState } from "react";
import * as ReactDOM from "react-dom";
import { useAppSelector } from "../../app";
import { CONFIG } from "../../common/constants";
import { configUtils, genericUtils, windowUtils } from "../../common/utils";
import { TradeSummary } from "./trade/trade-summary";

export function TradeConfirmationModal() {
    const config = useAppSelector((store) => store.config);
    const stepper = useAppSelector((state) => state.stepper);
    const cancelAutoClose = config?.cancelAutoClose;
    const [timeoutId, setTimeoutId] = useState<NodeJS.Timeout | null>(null);

    useEffect(() => {
        if (stepper.status === "SENT") {
            const id = setTimeout(() => {
                onClosed("auto closing " + CONFIG.COUNTER_REQUEST_AUTO_CLOSE_SECS + " secs after " + header);
            }, CONFIG.COUNTER_REQUEST_AUTO_CLOSE_SECS * 1000);
            setTimeoutId(id);
        }
    }, [stepper]);

    useEffect(() => {
        if (cancelAutoClose && timeoutId) {
            // clear a countdown if it was previously triggered
            clearTimeout(timeoutId);
        }
    }, [cancelAutoClose, timeoutId]);

    const onClosed = (reason: string) => {
        windowUtils.closeWindow(reason);
    };
    const header = configUtils.isCounteringMode(config) ? "Counter Request Sent" : "Trade Request Sent";
    return ReactDOM.createPortal(
        <AuxModal closeAllModalsOnEscape={false} header={header} type="action" isOpen={true}>
            <div data-test-id={genericUtils.removeSpace(header)} slot="content" className="trade-confirmation-modal">
                <TradeSummary isReview={false}></TradeSummary>
            </div>
            <AuxButton
                data-test-id={genericUtils.removeSpace(header) + "closebutton"}
                label="Close"
                onClick={() => onClosed("User clicked close on " + header)}
                slot="primary-button"
                isDisabled={false}
            />
        </AuxModal>,
        document.body
    );
}
