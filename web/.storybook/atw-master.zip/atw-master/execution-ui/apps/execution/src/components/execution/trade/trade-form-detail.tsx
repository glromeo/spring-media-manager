import { AuxBadge, AuxBadgeStyleEnum, AuxBadgeTypeEnum } from "@blk/aladdin-react-components-es";
import { useEffect } from "react";
import { useAppDispatch, useAppSelector } from "../../../app";
import { configUtils, genericUtils, pricingTypeUtils } from "../../../common/utils";
import { fetchDecode } from "../../../features/decodes/decodesAction";
import { TradeFormSchema } from "../../../features/tradeForm/tradeForm";
import { PRICING_TYPE_MAP } from "../../../models/common";
import { DetailsTable } from "../../common/details-table";

export function TradeFormDetail() {
    const dispatch = useAppDispatch();

    const axeInfo = useAppSelector((state) => state.axeInfo);
    const tradeFormInfo = useAppSelector((state) => state.tradeFormInfo);
    const orderInfo = useAppSelector((state) => state.orderInfo);
    const config = useAppSelector((store) => store.config);
    const countering = useAppSelector((store) => store.counteringInfo?.countering);
    const stepper = useAppSelector((state) => state.stepper);

    const brokerDecodes = useAppSelector((state) => state.decodes["PLACEMENT_SEND"]);
    const spotTimeDecodes = useAppSelector((state) => state.decodes["SPOT_TIMES"]);
    useEffect(() => {
        if (brokerDecodes === undefined && configUtils.isAxeA2AMode()) {
            dispatch(fetchDecode("PLACEMENT_SEND"));
        }
    }, [brokerDecodes]);

    const getTradeFormDetails = () => {
        const pricingType = pricingTypeUtils.getCurrentPricingType({ axeInfo, orderInfo, countering, config });
        return tradeFormInfo.schema
            .filter(
                (schema: TradeFormSchema) =>
                    schema.visibleFor(PRICING_TYPE_MAP[pricingType], config, stepper) && schema.summarize === true
            )
            .map((schema: TradeFormSchema) => {
                const field = schema.type === "select" ? schema.field + "Selected" : schema.field;

                let value = (tradeFormInfo.tradeForm as any)[field];
                if (configUtils.isAxeA2AMode() && field === "brokerSelected" && brokerDecodes) {
                    value = brokerDecodes[value] ?? value;
                }

                if (field === "spotTimeSelected" && spotTimeDecodes) {
                    value = spotTimeDecodes[value] ?? value;
                }

                return {
                    label: configUtils.isCares() && schema.caresLabel ? schema.caresLabel : schema.label,
                    value: value,
                    type: schema.type
                };
            });
    };
    const getExecutionTitle = () =>
        configUtils.isCounteringMode(config)
            ? "Countering  the Axe"
            : genericUtils.getSideTitle(orderInfo.order.side) + " the Axe";
    const title = configUtils.isCares() ? "Trade Details" : getExecutionTitle();
    const sideTitle = genericUtils.removeSpace(title);
    return (
        <div>
            {stepper.subStatus === "DEFAULT_ACTION" ? (
                <div className="tableHeader">
                    <div>{title}</div>
                    <div className="tradeFormDetailBadge">
                        <AuxBadge
                            badgeStyle={
                                orderInfo.order.side === "BUY" ? AuxBadgeStyleEnum.IN_PROGRESS : AuxBadgeStyleEnum.ALERT
                            }
                            type={AuxBadgeTypeEnum.CUSTOM}
                        >
                            <div slot="custom">{`${genericUtils.titleCase(orderInfo.order.side)} Order`}</div>
                        </AuxBadge>
                    </div>
                </div>
            ) : null}
            <DetailsTable name={sideTitle} data={getTradeFormDetails()}></DetailsTable>
        </div>
    );
}
