import { logClick } from "@atw/toolkit";
import { AuxRadioInterface, AuxSegmentedControl } from "@blk/aladdin-react-components-es";
import { useCallback, useEffect, useRef, useState } from "react";
import { useAppDispatch, useAppSelector } from "../../../app";
import { useSettings } from "../../../common/hooks/useSettings";
import {
    configUtils,
    counteringUtils,
    genericUtils,
    orderUtils,
    pricingTypeUtils,
    tradeFormUtils
} from "../../../common/utils";
import { alertUtils } from "../../../common/utils/alertUtils";
import { clearAlerts } from "../../../features/alerts/alertsActions";
import { invalidateAxeInfo } from "../../../features/axe/axeActions";
import { disableCountering, enableCountering, setPricingType } from "../../../features/config/configActions";
import { BrokerEntity, Desk, Placement } from "../../../features/order/order";
import { invalidateOrderInfo, selectRestrictedBroker } from "../../../features/order/orderActions";
import { TradeForm as TradeFormState, TradeFormInfo, TradeFormSchema } from "../../../features/tradeForm/tradeForm";
import { setTradeForm } from "../../../features/tradeForm/tradeFormActions";
import {
    BondQuality,
    NUM_PLACE_HOLDER,
    PRICING_TYPE_MAP,
    PricingProtocol,
    SPREAD,
    STRING_PLACE_HOLDER
} from "../../../models/common";
import { BrokerMarkup } from "../../common/broker-markup";
import {
    DateRenderer,
    FormSelectOptionType,
    getDataTestId as getAuxDataTestId,
    PriceRenderer,
    RadioRenderer,
    SelectRenderer,
    SizeRenderer,
    SpreadRenderer,
    validationCheck
} from "../../common/form-renderers";
import { Benchmarks } from "../benchmarks";
import { CODE } from "../../../common/constants";
import { AuxWrapper } from "../../common/aux-wrapper";

// Trade Form is used for both Axe workflow and Cares workflow - however for Cares - we get quality from order instead of axe
export function TradeForm() {
    const dispatch = useAppDispatch();
    const settings = useSettings();

    const alerts = useAppSelector((state) => state.alerts);
    const stepper = useAppSelector((state) => state.stepper);
    const axeInfo = useAppSelector((state) => state.axeInfo);
    const orderInfo = useAppSelector((state) => state.orderInfo);
    const tradeFormInfo = useAppSelector((state) => state.tradeFormInfo);
    const config = useAppSelector((store) => store.config);
    const pricingType = useAppSelector(({ config }) => config.axeQuality);
    const countering = useAppSelector((store) => store.counteringInfo?.countering);
    const [toggle, setToggle] = useState(false);
    const [validationMap, setValidationMap] = useState(new Map<string, boolean>());
    const isA2A = configUtils.isAxeA2AMode();
    const tradeFormInfoRef = useRef<TradeFormInfo>(tradeFormInfo);
    tradeFormInfoRef.current = tradeFormInfo;
    const getDataTestId = (title: string, field: string) => {
        return genericUtils.removeSpace(`${title}-${field}`);
    };

    const brokerDecodes = useAppSelector((state) => state.decodes["PLACEMENT_SEND"]);
    const benchmarkSpotDecodes = useAppSelector((state) => state.decodes["AT_BENCH2SPOT"]);
    const spotTimeDecodes = useAppSelector((state) => state.decodes["SPOT_TIMES"]);
    const trdBmkDecodes = useAppSelector((state) => state.decodes["TRD_BENCHMARK"]);

    const getTradeFormInfo = () => tradeFormInfoRef.current;

    useEffect(() => {
        if (orderHasData()) {
            // if we are here this means (first time) - or that user has gone back ...in that case we need to reset the settle date back to original value
            if (!tradeFormHasData()) {
                dispatch(setTradeForm(getInitialTradeForm()));
            }

            genericUtils.dumpStore();
        }
        validate();
    }, []);

    useEffect(() => {
        validate();
    }, [tradeFormInfo.tradeForm.pricingProtocolChecked]);

    const isValidBrokerSelected = (brokerSelected?: string) => {
        return brokerSelected && brokerSelected !== STRING_PLACE_HOLDER;
    };

    const publishSizeChange = (newSize: number | undefined) => {
        publishTradeForm({
            ...getTradeFormInfo().tradeForm,
            size: newSize
        });
        validate();
    };
    useEffect(() => {
        const brokerSelected = getTradeFormInfo().tradeForm.brokerSelected;
        if (isValidBrokerSelected(brokerSelected) && configUtils.isCares()) {
            const matchIndex = orderInfo.order.broker.entity.findIndex((entity) => entity.name === brokerSelected);
            if (orderUtils.isRestrictedBrokerEntity(orderInfo.order.broker.entity[matchIndex])) {
                // If the user selects a restricted broker via the broker selection,
                // we clear the size and unselect any restricted broker
                dispatch(selectRestrictedBroker(undefined));
                publishSizeChange(undefined);
                console.log(`User selected restricted broker ${brokerSelected} via dropdown, clearing size input`);
            } else {
                // If the user toggled back to a unrestricted broker, size down if necessary
                const size = getTradeFormInfo().tradeForm.size;
                const maxSize = getMaxSize(brokerSelected!);
                if (!size || size > maxSize) {
                    publishSizeChange(maxSize);
                    console.log(
                        `User selected unrestricted broker with invalid size, updating size to order leaves<${maxSize}>: ${maxSize}`
                    );
                }
            }
        }
        // Will only run when the user selects via broker selection
    }, [getTradeFormInfo().tradeForm.brokerSelected]);

    useEffect(() => {
        // Once the user selects a restricted broker via the restriction list...
        const brokerSelected = getTradeFormInfo().tradeForm.brokerSelected;
        if (
            isValidBrokerSelected(brokerSelected) &&
            genericUtils.isValidNumber(orderInfo.order.broker.selectedRestrictedBroker) &&
            configUtils.isCares()
        ) {
            //...set the size on the form to the max unrestricted amount
            const maxSize = getMaxSize(brokerSelected!);
            publishSizeChange(maxSize);
            console.log(
                `User clicked radio button for ${brokerSelected}, updating size input to max unrestricted amount<${maxSize}>: ${maxSize}`
            );
        }
        // Will only run when the user selects via restriction list
    }, [orderInfo.order.broker.selectedRestrictedBroker]);

    useEffect(() => {
        if (orderHasData() && tradeFormHasData()) {
            publishTradeForm({
                ...getTradeFormInfo().tradeForm,
                broker: tradeFormUtils.getBrokerNames(orderInfo.order)
            });
        }
    }, [pricingType]); // eslint-disable-line react-hooks/exhaustive-deps

    const getDefaultSpotTime = useCallback(() => {
        let spotTime;
        // For A2A we default the spot time to the trading benchmark or "AUTO" if there's no trading benchmark
        if (isA2A) {
            spotTime = CODE.SPOT_NOW;

            const trdBmk = orderInfo.order.tradingBmk;
            if (trdBmk && trdBmkDecodes) {
                const trdBmkCde = Object.keys(trdBmkDecodes).find((key) => trdBmkDecodes[key] === trdBmk);

                if (trdBmkCde && benchmarkSpotDecodes?.[trdBmkCde]) {
                    spotTime = benchmarkSpotDecodes?.[trdBmkCde];
                }
            }
        }

        // Fall back to Spot Now
        return spotTime && tradeFormInfo.tradeForm.spotTime?.includes(spotTime) ? spotTime : CODE.SPOT_NOW;
    }, [benchmarkSpotDecodes, orderInfo]);

    const onEnableCountering = () => {
        if (configUtils.isCounteringMode(config)) return;
        dispatch(enableCountering(stepper.fatal));
        setToggle(!toggle);
    };

    const onDisableCountering = () => {
        if (!configUtils.isCounteringMode(config)) return;
        dispatch(disableCountering());
        // set back the original price/spread that the user may have had before...
        const tradeForm = getUpdatedTradeForm();
        tradeForm.price = getOriginalPrice();
        tradeForm.spread = getOriginalSpread();
        const originalPricingProtocol = pricingTypeUtils.getQualityFromAxePriceType({
            axeInfo,
            orderInfo,
            config,
            countering
        });
        if (
            originalPricingProtocol !==
            PRICING_TYPE_MAP[getTradeFormInfo().tradeForm.pricingProtocolChecked?.toUpperCase() as "PRICE" | "SPREAD"]
        ) {
            handlePricingProtocolChange(originalPricingProtocol);
        }
        tradeForm.pricingProtocolChecked = originalPricingProtocol === "IG" ? "Spread" : "Price";
        tradeForm.size =
            getTradeFormInfo().tradeForm.size === undefined || getTradeFormInfo().tradeForm.size! > getOriginalSize()
                ? getOriginalSize()
                : getTradeFormInfo().tradeForm.size!;
        publishTradeForm(tradeForm);
        setToggle(!toggle);
    };
    const validate = () => {
        // eslint-disable-next-line
        for (let [_key, value] of validationMap) {
            if (value === false) {
                dispatch(setTradeForm({ hasValidData: false }));
                return false;
            }
        }
        dispatch(setTradeForm({ hasValidData: true }));

        //TODO: move this logic as isValid should only be validating the trade form values
        // do we have a benchmark alert that is fatal? cannot continue
        if (alertUtils.hasFatalError(alerts)) return false;

        if (pricingTypeUtils.getCurrentPricingType({ axeInfo, orderInfo, countering, config }) === SPREAD) {
            const isValidBenchmark =
                orderInfo.order.orderBmkId !== STRING_PLACE_HOLDER || axeInfo.axe.axeBmkId !== STRING_PLACE_HOLDER;
            if (!isValidBenchmark) {
                return false;
            }
        }
        return true;
    };

    const onValidate = (id: string, valid: boolean) => {
        if (validationMap.get(id) === valid) return;
        setValidationMap(new Map(validationMap.set(id, valid)));
        validate();
    };
    const hasTradeFormChanged = (id: string, value: string | { label: string; value: string }) => {
        const tradeFormItemValue = getTradeFormInfo().tradeForm[id as keyof TradeFormState];
        const updatedValue = tradeFormItemValue ? tradeFormItemValue.toString() : tradeFormItemValue;
        return updatedValue !== value;
    };
    const handlePricingProtocolChange = (quality: BondQuality) => {
        dispatch(clearAlerts());
        if (!configUtils.isCares()) dispatch(invalidateAxeInfo());
        dispatch(invalidateOrderInfo());
        dispatch(setPricingType(quality));
    };
    const onValueChanged = (id: string, value: string | { label: string; value: string }) => {
        if (!hasTradeFormChanged(id, value)) return;
        const tradeForm = getUpdatedTradeForm(id, value);
        if (id === "pricingProtocolChecked") {
            const quality = value === "Spread" ? "IG" : "HY";
            handlePricingProtocolChange(quality);
        }
        // broker is not a straight publish ...
        if (
            id === "brokerSelected" &&
            getTradeFormInfo().tradeForm.brokerSelected &&
            getTradeFormInfo().tradeForm.brokerSelected !== value
        ) {
            // in this case - we need to update the desk select, based on selected broker...
            tradeForm.desk = tradeFormUtils.getDesks(orderInfo.order, tradeForm.brokerSelected!);
            tradeForm.deskSelected = tradeFormUtils.getDefaultDesk(orderInfo.order, tradeForm.brokerSelected!);
            // also reset the spot time
            tradeForm.spotTimeSelected = getDefaultSpotTime();
            publishTradeForm(tradeForm);
        } else {
            publishTradeForm(tradeForm);
        }
    };
    const orderHasData = () => orderInfo.order.hasValidData;
    const tradeFormHasData = () => getTradeFormInfo().tradeForm.hasValidData;

    const getUpdatedTradeForm = (
        key?: string,
        value?: string | { label: string; value: string }
    ): Partial<TradeFormState> => {
        let tradeForm: Partial<TradeFormState> = {};
        if (key === undefined) return tradeForm;
        const schema = getTradeFormInfo().schema.find((schema) => schema.field === key);
        if (schema === undefined) {
            (tradeForm as any)[key] = value;
        } else {
            switch (schema!.type) {
                case "boolean":
                    (tradeForm as any)[key] = Boolean(value);
                    break;
                case "size":
                case "spread":
                case "price":
                    (tradeForm as any)[key] = Number(genericUtils.removeCommas(value as string));
                    break;
                default:
                    (tradeForm as any)[key] = value;
                    break;
            }
        }
        return tradeForm;
    };
    const isSelectDisabled = (field: string) => {
        if (
            (field === "desk" && getTradeFormInfo().tradeForm.deskSelected === "") ||
            (counteringUtils.isLiveNegotiationState(countering.prevState) &&
                ["broker", "desk"].includes(field) &&
                configUtils.isCounteringMode(config))
        )
            return true;
        return false;
    };
    const getMaxSize = (selectedBroker: string, counterMode?: boolean) => {
        let inCounteringMode = counterMode !== undefined ? counterMode : configUtils.isCounteringMode(config);
        const findBrokerIdx = () => orderInfo.order.broker.entity.findIndex((entity) => entity.name === selectedBroker);
        // max size is a min(axe size, order leaves, broker restriction (if exists)) - if counter mode - then max is orderleaves
        let maxSize;
        if (genericUtils.isValidNumber(axeInfo.axe.size) && !inCounteringMode && !configUtils.isCares()) {
            maxSize = Math.min(axeInfo.axe.size, orderInfo.order.orderLeaves);
            console.log(
                `In axe-based workflow, updating max size to min(axe size<${axeInfo.axe.size}>, orderLeaves<${orderInfo.order.orderLeaves}>): ${maxSize}`
            );
        } else {
            maxSize = orderInfo.order.orderLeaves;
            console.log(
                `In non-axe-based workflow, updating max size to orderLeaves<${orderInfo.order.orderLeaves}>: ${maxSize}`
            );
        }
        if (orderUtils.hasBrokerRestrictions(orderInfo.order) && isValidBrokerSelected(selectedBroker)) {
            const idx = findBrokerIdx();
            if (orderInfo.order.broker.entity[idx] === undefined) {
                console.log(
                    `Selected broker ${selectedBroker} did not map to valid broker entity, using initial max size: ${maxSize}`
                );
                return maxSize;
            }
            const brokerQuantity = orderInfo.order.broker.entity[idx].restriction!.quantity;
            const prevMax = maxSize;
            maxSize = Math.min(prevMax, brokerQuantity);
            console.log(
                `In restrictions workflow with ${selectedBroker} selected, updating max size to min(initial max<${prevMax}>, max unrestricted amount<${brokerQuantity}>): ${maxSize}`
            );
        }
        return maxSize;
    };
    const getMinSize = () => {
        if (isA2A && settings.axeMinSize != NUM_PLACE_HOLDER) {
            return settings.axeMinSize;
        }

        return 1; // no longer need to look at orderInfo.order.minTrdSize (this will be handled via backend validation before send)
    };
    const getSelectData = (data: string[], field: string) => {
        const isDelayedBroker = () => {
            const selectedBroker =
                getTradeFormInfo().tradeForm.brokerSelected === STRING_PLACE_HOLDER
                    ? tradeFormUtils.getDefaultSelectedBroker(orderInfo.order)
                    : getTradeFormInfo().tradeForm.brokerSelected;
            return orderInfo.order.broker.entity.find((entity) => entity.name === selectedBroker)?.isDelayedSpot;
        };
        if (field === "spotTime") {
            if (!isDelayedBroker()) {
                // in this case - we remove options for delayed spot time - and only leave spot now
                data = data.slice(0, 1);
            }
        }

        // select data has {label, value} pairs
        let formData: FormSelectOptionType[] = [];
        if (field === "broker") {
            formData = data.map((value) => ({
                label: (brokerDecodes && brokerDecodes[value]) ?? value,
                value
            }));
        } else if (field === "spotTime") {
            formData = data.map((value) => ({
                label: (spotTimeDecodes && spotTimeDecodes[value]) ?? value,
                value
            }));
        } else {
            formData = data.map((value) => {
                return { label: value, value };
            });
        }

        // for spotTime or dueIn we need in a very specific order - so don't sort...
        if (field === "spotTime" || field === "dueIn") return formData;

        return formData.sort((a, b) => String(a.label).localeCompare(b.label));
    };

    const getOriginalPrice = () => (configUtils.isCares() ? NUM_PLACE_HOLDER : axeInfo.axe.price);
    // refactor-todo: Spread can't have a num_place_holder as a default, because -999 that can be a valid spread number
    const getOriginalSpread = () => (configUtils.isCares() ? undefined : axeInfo.axe.spread);
    const getOriginalSize = () => {
        const brokerSelected = tradeFormUtils.getDefaultSelectedBroker(orderInfo.order);
        return getMaxSize(brokerSelected, false);
    };
    const getInitialTradeForm = (): TradeFormState => {
        const currentPricingType = pricingTypeUtils.getCurrentPricingType({ axeInfo, orderInfo, config, countering });
        const placement: Placement | undefined = orderUtils.getPlacement(orderInfo.order, countering.placementNum);
        let tradeForm: TradeFormState = tradeFormUtils.getDefaultTradeForm(orderInfo.order);
        tradeForm.pricingProtocolChecked = genericUtils.titleCase(currentPricingType) as PricingProtocol;
        tradeForm.price = getOriginalPrice();
        tradeForm.spread = getOriginalSpread();
        tradeForm.spotTimeSelected = getDefaultSpotTime();
        tradeForm.size = getMaxSize(
            tradeForm.brokerSelected!,
            configUtils.isCounteringModeOnly(config) ? false : undefined
        );

        if (
            counteringUtils.isLiveNegotiationState(countering.prevState) &&
            configUtils.isCounteringMode(config) &&
            countering.history &&
            placement
        ) {
            tradeForm = fillTradeFormWithLastCounter(tradeForm, placement);
        }
        return tradeForm;
    };

    const fillTradeFormWithLastCounter = (tradeForm: TradeFormState, placement: Placement) => {
        if (!placement.quotes) return tradeForm;
        let lastQuote = counteringUtils.getValidQuote(placement, orderInfo.order.side);
        let lastQuoteTradeForm: TradeFormState = { hasValidData: true };
        const getDesk = (desks: Desk[], id: number) => {
            return desks.find((desk) => desk.subBrokerID === id);
        };
        const getCurrentDeskKeyName = () => {
            const currentBroker: BrokerEntity | undefined = orderInfo.order.broker.entity.find(
                (entity: BrokerEntity) => entity.name === placement.broker.shortName
            );
            return tradeFormUtils.getDeskKey(getDesk(currentBroker!.desk, placement.desk.subBrokerID)!);
        };
        if (lastQuote?.type === "PRICE") {
            lastQuoteTradeForm.price = lastQuote.price;
        }
        if (lastQuote?.type === "SPREAD") {
            lastQuoteTradeForm.spread = lastQuote.spread;
        }
        lastQuoteTradeForm.brokerSelected = placement.broker.shortName;
        lastQuoteTradeForm.deskSelected = getCurrentDeskKeyName();
        lastQuoteTradeForm.size = lastQuote?.quantity;
        lastQuoteTradeForm.desk = tradeFormUtils.getDesks(orderInfo.order, placement.broker.shortName);
        lastQuoteTradeForm.settleDate = placement.settleDate ?? STRING_PLACE_HOLDER;
        tradeForm = {
            ...tradeForm,
            ...lastQuoteTradeForm
        };
        return tradeForm;
    };

    const publishTradeForm = (tradeForm: Partial<TradeFormState>) => {
        dispatch(setTradeForm(tradeForm));
    };

    const priceSpreadShouldDisable = () => {
        if (configUtils.isCounteringMode(config) || configUtils.isAxeA2AMode()) return false;
        return configUtils.isCares() ? false : true;
    };
    const RenderForm = () => {
        // eslint-disable-next-line
        const pricingType = pricingTypeUtils.getCurrentPricingType({ axeInfo, orderInfo, config, countering });
        const isFatal = alertUtils.hasFatalError(alerts);
        return getTradeFormInfo().schema.map((schema: TradeFormSchema) => {
            if (!schema.visibleFor(PRICING_TYPE_MAP[pricingType], config, stepper)) return null;
            const isControlDisabled = schema.disabledFor(PRICING_TYPE_MAP[pricingType], config, stepper) || isFatal;
            const label = configUtils.isCares() && schema.caresLabel ? schema.caresLabel : schema.label;
            const isModeCounteringOrCares = configUtils.isCounteringMode(config) || configUtils.isCares();
            const isModeA2AorCounteringLive =
                configUtils.isAxeA2AMode() ||
                (counteringUtils.isLiveNegotiationState(countering.prevState) && configUtils.isCounteringMode(config));
            switch (schema.type) {
                case "price": {
                    const isDisabledOverride = isControlDisabled || priceSpreadShouldDisable();
                    return (
                        <div data-test-id={getDataTestId(title, schema.field)} className="tradeFormItem" key={label}>
                            <label className="tradeFormLabel">{label}</label>
                            <div className="tradeFormValue">
                                <PriceRenderer
                                    formItemData={{
                                        formTitle: title,
                                        label: label,
                                        field: schema.field,
                                        value: getTradeFormInfo().tradeForm[schema.field]! as number,
                                        value2: getTradeFormInfo().tradeForm[schema.field]! as number,
                                        disabled: isDisabledOverride,
                                        onValidate,
                                        onValueChanged
                                    }}
                                ></PriceRenderer>
                            </div>
                        </div>
                    );
                }
                case "allInLevel":
                    const auxDataTestID = `${getAuxDataTestId(title, schema.field)}`;

                    return (
                        <div data-test-id={getDataTestId(title, schema.field)} className="tradeFormItem" key={label}>
                            <label className="tradeFormLabel">{label}</label>
                            <div className="tradeFormValue">
                                <BrokerMarkup dataTestID={auxDataTestID} />
                            </div>
                        </div>
                    );
                case "spread": {
                    const isDisabledOverride = isControlDisabled || priceSpreadShouldDisable();
                    return (
                        <div data-test-id={getDataTestId(title, schema.field)} className="tradeFormItem" key={label}>
                            <label className="tradeFormLabel">{label}</label>
                            <div className="tradeFormValue">
                                <SpreadRenderer
                                    formItemData={{
                                        formTitle: title,
                                        label: label,
                                        field: schema.field,
                                        value: getTradeFormInfo().tradeForm[schema.field]! as number,
                                        value2: getTradeFormInfo().tradeForm[schema.field]! as number,
                                        disabled: isDisabledOverride,
                                        onValidate,
                                        onValueChanged
                                    }}
                                ></SpreadRenderer>
                            </div>
                        </div>
                    );
                }
                case "radio": {
                    let isDisabledOverride = false;
                    if (schema.field === "pricingProtocol") {
                        isDisabledOverride = !isModeCounteringOrCares || isModeA2AorCounteringLive;
                    }
                    const checkedField = schema.field + "Checked";
                    const checkedValue = getTradeFormInfo().tradeForm[checkedField as keyof TradeFormState];
                    const value: AuxRadioInterface[] = (getTradeFormInfo().tradeForm[schema.field] as string[]).map(
                        (item) => ({
                            label: item,
                            eventData: item,
                            checked: checkedValue === item,
                            disabled: isDisabledOverride
                        })
                    );
                    return (
                        <div data-test-id={getDataTestId(title, schema.field)} className="tradeFormItem" key={label}>
                            <label className="tradeFormLabel">{label}</label>
                            <div className="tradeFormValue">
                                <RadioRenderer
                                    formItemData={{
                                        formTitle: title,
                                        label: label,
                                        field: schema.field,
                                        value: value,
                                        field2: checkedField,
                                        value2: checkedValue as string,
                                        onValidate,
                                        onValueChanged
                                    }}
                                ></RadioRenderer>
                            </div>
                        </div>
                    );
                }
                case "size": {
                    const maxSize = getMaxSize(getTradeFormInfo().tradeForm.brokerSelected!);
                    return (
                        <div data-test-id={getDataTestId(title, schema.field)} className="tradeFormItem" key={label}>
                            <label className="tradeFormLabel">{label}</label>
                            <div className="tradeFormValue">
                                <SizeRenderer
                                    formItemData={{
                                        formTitle: title,
                                        label: label,
                                        field: schema.field,
                                        value: getTradeFormInfo().tradeForm[schema.field]! as number,
                                        disabled: isControlDisabled,
                                        min: getMinSize(),
                                        max: maxSize,
                                        onValidate,
                                        onValueChanged
                                    }}
                                ></SizeRenderer>
                            </div>
                        </div>
                    );
                }
                case "select": {
                    // in case of select - field2/value2 holds the selected value (where field/value contains the original data value(s))
                    // selects also transforms the data into {label,value}
                    const field2 = schema.field + "Selected";
                    const value2 = getTradeFormInfo().tradeForm[field2 as keyof TradeFormState];
                    let value: FormSelectOptionType[] = getSelectData(
                        getTradeFormInfo().tradeForm[schema.field]! as [],
                        schema.field
                    );
                    const isDisabledOverride = isControlDisabled || isSelectDisabled(schema.field);
                    let validator: validationCheck = () => ({ isValid: true, errorMessage: "" });

                    const getBrokerValidation: validationCheck = () => {
                        let errorMessage: string = "",
                            isValid: boolean = true;

                        // only validate broker for countering in initial request, before placement is created
                        if (!orderUtils.isBrokerCounterEnabled(orderInfo.order.broker.entity, value2 as string) && !genericUtils.isValidNumber(countering.placementNum)) {
                            errorMessage = `Broker ${value2} is not configured for Countering`;
                            isValid = false;
                        }
                        return { isValid, errorMessage };
                    };

                    if (schema.field == "broker" && configUtils.isCounteringMode(config)) {
                        validator = getBrokerValidation;
                    }
                    return (
                        <div data-test-id={getDataTestId(title, schema.field)} className="tradeFormItem" key={label}>
                            <label className="tradeFormLabel">{label}</label>
                            <div className="tradeFormValue">
                                <SelectRenderer
                                    formItemData={{
                                        formTitle: title,
                                        disabled: isDisabledOverride,
                                        label: label,
                                        field: schema.field,
                                        value: value,
                                        field2: field2,
                                        value2: value2 as string,
                                        onValidate,
                                        onValueChanged,
                                        validator
                                    }}
                                ></SelectRenderer>
                            </div>
                        </div>
                    );
                }
                case "date": {
                    const isDisabledOverride =
                        isControlDisabled ||
                        (counteringUtils.isLiveNegotiationState(countering.prevState) &&
                            configUtils.isCounteringMode(config));
                    const value = getTradeFormInfo().tradeForm[schema.field]! as string;
                    const value2 = schema.minValue ?? getTradeFormInfo().tradeForm[schema.field]!;
                    return (
                        <div data-test-id={getDataTestId(title, schema.field)} className="tradeFormItem" key={label}>
                            <label className="tradeFormLabel">{label}</label>
                            <div className="tradeFormValue">
                                <DateRenderer
                                    formItemData={{
                                        formTitle: title,
                                        field: schema.field,
                                        label: label,
                                        value: value,
                                        value2: value2 as string,
                                        disabled: isDisabledOverride,
                                        onValidate,
                                        onValueChanged
                                    }}
                                ></DateRenderer>
                            </div>
                        </div>
                    );
                }
            }
            return null;
        });
    };

    const title = configUtils.isCares() || isA2A ? "Trade Details" : genericUtils.getSideTitle(orderInfo.order.side);
    const isCounterDisabled = orderInfo?.order?.broker?.entity?.every(
        (entity: BrokerEntity) => !entity.isCounteringEnabled
    );
    const isTradeFormDisabled =
        configUtils.isCounteringModeOnly(config) ||
        // if spread mode and countering mode and axe benchmark id is undefined or axe's default axebmkId doesn't match trader selected axebmkId
        (config.axeQuality === "IG" &&
            configUtils.isCounteringMode(config) &&
            (useSettings().axeBmkId !== axeInfo.axe.axeBmkId || axeInfo.axe.axeBmk === STRING_PLACE_HOLDER));

    return (
        <div data-test-id="trade-form" className={`tradeFormContainer ${isA2A ? "tradeFormContainer--A2A" : ""}`}>
            <Benchmarks />
            {!isA2A && (
                <>
                    {configUtils.isCares() ? (
                        <div data-test-id={`${genericUtils.removeSpace(title)}`} className="tableHeader">
                            {title}
                        </div>
                    ) : (
                        <div className="counteringButtonContainer">
                            <AuxWrapper size={100} selector={"label"}>
                                <AuxSegmentedControl
                                    data-test-id={`${genericUtils.removeSpace(title)}`}
                                    data={[
                                        {
                                            label: title,
                                            checked: !configUtils.isCounteringMode(config),
                                            disabled: isTradeFormDisabled
                                        },
                                        {
                                            label: "Counter",
                                            checked: configUtils.isCounteringMode(config),
                                            disabled: isCounterDisabled
                                        }
                                    ]}
                                    onControlSelectionChanged={({ detail }) => {
                                        dispatch(clearAlerts());
                                        if (detail.index === 0) onDisableCountering();
                                        else onEnableCountering();
                                        logClick(`User changed mode to ${detail.data.label}`);
                                    }}
                                />
                            </AuxWrapper>
                        </div>
                    )}
                </>
            )}
            {RenderForm()}
        </div>
    );
}
