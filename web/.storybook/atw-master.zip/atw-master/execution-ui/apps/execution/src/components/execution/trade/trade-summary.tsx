import { AtwColumnDef, AtwTable } from "@atw/toolkit";
import React from "react";
import { useAppSelector } from "../../../app";
import { STYLE, TEXT } from "../../../common/constants";
import { configUtils, genericUtils, pricingTypeUtils } from "../../../common/utils";
import { DEFAULT_TRADEFORM_SCHEMA, TradeFormSchema } from "../../../features/tradeForm/tradeForm";
import { PRICE, SPREAD } from "../../../models/common";
import "./trade-summary.scss";

export function TradeSummary({ isReview }: { isReview: boolean }) {
    const orderInfo = useAppSelector((state) => state.orderInfo);
    const tradeFormInfo = useAppSelector((state) => state.tradeFormInfo);
    const axeInfo = useAppSelector((state) => state.axeInfo);
    const stepper = useAppSelector((state) => state.stepper);
    const confirmValue = `${orderInfo.order.side} ${
        stepper.subStatus === "MINI_REVIEW" ? "" : "order for"
    } ${genericUtils.formatSize(tradeFormInfo.tradeForm.size!)}`;
    const config = useAppSelector((store) => store.config);
    const countering = useAppSelector((store) => store.counteringInfo?.countering);
    const pricingType = pricingTypeUtils.getCurrentPricingType({ axeInfo, orderInfo, countering, config });
    const getReviewText = () => {
        if (isReview) {
            if (stepper.subStatus === "MINI_REVIEW") return "You will send a Counter Request to";
            else return TEXT.CONFIRM_SEND;
        } else {
            if (configUtils.isCounteringMode(config)) return "Counter Sent";
            return "Sent";
        }
    };
    const priceSpreadLabel = genericUtils.titleCase(pricingType);
    const columnDefs: AtwColumnDef<any>[] = [
            { type: "string", field: "side", label: "Side", width: STYLE.SIDE_COLUMN_WIDTH },
            { type: "string", field: "security", label: "Security", width: STYLE.SECURITY_COLUMN_WIDTH },
            { type: "string", field: "size", label: "Size", width: STYLE.SIZE_COLUMN_WIDTH },
            { type: "string", field: priceSpreadLabel.toLowerCase(), label: priceSpreadLabel, width: 80 },
            { type: "string", field: "broker", label: "Broker", width: 80 }
        ],
        side = orderInfo.order.side,
        security = orderInfo.order.bond,
        size = genericUtils.formatSize(tradeFormInfo.tradeForm.size!),
        price =
            pricingType === PRICE &&
            `$${genericUtils.formatPrice(tradeFormInfo.tradeForm.price!)} ${orderInfo.order.currency}`,
        spread = pricingType === SPREAD && `${genericUtils.formatSpread(tradeFormInfo.tradeForm.spread!)}`,
        broker = tradeFormInfo.tradeForm.brokerSelected,
        data: any[] = [
            {
                side,
                security,
                size,
                [priceSpreadLabel.toLowerCase()]: price || spread,
                broker
            }
        ];
    React.useEffect(() => {
        // temp workaround until AtwTable creates a type "side" or can add classname to each td/cell
        const sideEls = document.getElementsByClassName("atw-grid-cell-content side");
        if (sideEls[0]) {
            sideEls[0].classList.add(side.toLowerCase());
        }
        const spreadEls = document.getElementsByClassName("atw-grid-cell-content spread");
        if (spreadEls[0]) {
            spreadEls[0].classList.add("justify-left");
        }
    }, []);
    const TradeSummaryText = () => {
        const dueInSchema: TradeFormSchema | undefined = DEFAULT_TRADEFORM_SCHEMA.find(
            (input) => input.field === "dueIn" && input.visibleFor("-", config, stepper)
        );
        const dueIn = tradeFormInfo.tradeForm.dueInSelected;
        const dueInText = dueInSchema?.label === "Good For" ? "for" : "due in";
        return (
            <div>
                {getReviewText()}
                <span className="trade-summary-value">{confirmValue}</span> of
                <span className="trade-summary-value">{security}</span> at
                <span className="trade-summary-value">{price || spread}</span>
                <span> to</span>
                <span className="trade-summary-value">{broker}</span>
                {configUtils.isCounteringMode(config) || stepper.subStatus === "MINI_REVIEW" ? (
                    <React.Fragment>
                        <span> {dueInText}</span>
                        <span className="trade-summary-value">{dueIn}</span>
                    </React.Fragment>
                ) : null}
            </div>
        );
    };
    const TradeSummaryTable = () => {
        const dueInSchema: TradeFormSchema | undefined = DEFAULT_TRADEFORM_SCHEMA.find(
            (input) => input.field === "dueIn" && input.visibleFor("-", config, stepper)
        );

        if (dueInSchema) {
            columnDefs.push({ type: "string", field: "dueIn", label: "Good For", width: 80 });
            const dueIn = tradeFormInfo.tradeForm.dueInSelected;
            data[0].dueIn = dueIn;
        }

        return (
            <div data-test-id="trade-confirmation-modal-table" className="trade-confirmation-modal_table">
                <div className="trade-confirmation-modal-table-header">
                    <span className="trade-summary-value">Summary</span>
                </div>
                <AtwTable rowHeight={25} headerHeight={25} rowData={data} columnDefs={columnDefs} columnWidth={80} />
            </div>
        );
    };
    return (
        <div data-test-id="trade-summary" className="trade-summary">
            {isReview ? TradeSummaryText() : TradeSummaryTable()}
        </div>
    );
}
