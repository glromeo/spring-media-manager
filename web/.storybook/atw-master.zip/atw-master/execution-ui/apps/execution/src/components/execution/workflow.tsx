import React, { useEffect } from "react";
import { useAppDispatch, useAppSelector } from "../../app";
import { configUtils, orderUtils } from "../../common/utils";
import { setWorkflow } from "../../features/config/configActions";
import { fetchDecode } from "../../features/decodes/decodesAction";
import { StepperState, WORKFLOWS } from "../../features/stepper/stepper";
import { OrderDetails } from "../common/order-details";
import { OverlayStatus } from "../common/overlay";
import { RestrictionList } from "../common/restriction-list";
import { Spinner } from "../common/spinner";
import { AxeDetails } from "./axe-details";
import { AxeExpiry } from "./axe-expiry";
import { TradeConfirmationModal } from "./trade-confirmation-modal";
import { TradeForm } from "./trade/trade-form";
import { TradeFormDetail } from "./trade/trade-form-detail";
import { TradeSummary } from "./trade/trade-summary";

const { isCares, isAxeA2AMode } = configUtils;

function switchStep(step: StepperState, hasRestrictions: boolean) {
    switch (step) {
        case StepperState.Split:
            return <RestrictionList></RestrictionList>;
        case StepperState.Order:
            return (
                <div>
                    <AxeExpiry />
                    {isCares() ? null : <AxeDetails></AxeDetails>}
                    <TradeForm></TradeForm>
                    {isCares() && hasRestrictions ? <RestrictionList></RestrictionList> : null}
                </div>
            );
        case StepperState.Review:
            return (
                <div>
                    <AxeExpiry />
                    {isCares() ? null : <AxeDetails></AxeDetails>}
                    <TradeFormDetail></TradeFormDetail>
                    <TradeSummary isReview={true}></TradeSummary>
                </div>
            );
    }
}

export function Workflow() {
    const dispatch = useAppDispatch();
    const query = useAppSelector((state) => state.config);
    const stepper = useAppSelector((state) => state.stepper);
    const orderInfo = useAppSelector((state) => state.orderInfo);
    const alerts = useAppSelector((state) => state.alerts);
    const axeInfo = useAppSelector((state) => state.axeInfo);
    const benchmarkSpotDecodes = useAppSelector((state) => state.decodes["AT_BENCH2SPOT"]);
    const currentWorkflow = WORKFLOWS[query.workflow];
    const currentStep = currentWorkflow[stepper.stepIdx];

    const HasDataOrError = () => {
        const isA2ADecodeReady = benchmarkSpotDecodes !== undefined;
        const hasError = alerts.filter((alert) => alert.type === "ERROR" || alert.type === "ALERT").length > 0;
        return (
            (orderInfo.order.hasValidData &&
                (!isAxeA2AMode() || isA2ADecodeReady) &&
                (axeInfo.axe.hasValidData || isCares())) ||
            hasError
        );
    };

    const hasRestrictions = orderUtils.hasBrokerRestrictions(orderInfo.order);
    useEffect(() => {
        const orderHasData = () => orderInfo.order.hasValidData;
        const workflowNotSet = () => query.workflow === "NOTSET";
        if (orderHasData() && workflowNotSet()) {
            if (query.workflow !== "NOTSET") {
                dispatch(setWorkflow({ wf: query.workflow }));
            } else if (hasRestrictions) {
                dispatch(setWorkflow({ wf: "RESTRICTIONS" }));
            } else {
                dispatch(setWorkflow({ wf: "EXECUTION" }));
            }
        }
    }, [query.workflow, orderInfo]); // eslint-disable-line react-hooks/exhaustive-deps

    useEffect(() => {
        dispatch(fetchDecode(["MD_PRICE_SOURCE"]));
        if (isAxeA2AMode()) {
            dispatch(fetchDecode(["PLACEMENT_SEND", "AT_BENCH2SPOT", "TRD_BENCHMARK"]));
        }
    }, []);

    return (
        <React.Fragment>
            <OverlayStatus status={stepper.status}></OverlayStatus>
            {!HasDataOrError() ? (
                <Spinner title="Loading Order Details"></Spinner>
            ) : (
                <React.Fragment>
                    <OrderDetails></OrderDetails>
                    <div>
                        {switchStep(currentStep, hasRestrictions)}
                        {stepper.status === "SENT" ? <TradeConfirmationModal /> : null}
                    </div>
                </React.Fragment>
            )}
        </React.Fragment>
    );
}
