import { useEffect } from "react";
import { useAppSelector } from "../app";
import { genericUtils } from "../common/utils";
import { ContextMenu } from "../components/common/context-menu";
import { Countering } from "./countering";
import { Execution } from "./execution";

import "./execution.scss";

export function Base() {
    const config = useAppSelector((state) => state.config);

    useEffect(() => {
        if (config.workflow !== "NOTSET" && config.mode !== "NOTSET") {
            genericUtils.logTelemetryView(config.workflow, config.mode);
        }
    }, [config.workflow, config.mode]);

    return (
        <div className="execution">
            {config.workflow === "COUNTERED" ? <Countering /> : <Execution />}
            <ContextMenu />
        </div>
    );
}
