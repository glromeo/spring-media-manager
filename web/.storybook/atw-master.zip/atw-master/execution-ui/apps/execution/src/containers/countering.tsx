import React, { useEffect } from "react";
import { useAppDispatch, useAppSelector } from "../app";
import { useNavigate } from "react-router-dom";
import { useSettings } from "../common/hooks/useSettings";
import { Alerts } from "../components/common/alerts";
import DebugInfo from "../components/common/debugInfo";
import { Overlay } from "../components/common/overlay";
import Rec from "../components/common/rec";
import { Spinner } from "../components/common/spinner";
import { OrderDetails } from "../components/countering/body/order-details";
import { QuoteHistory } from "../components/countering/body/quote-history";
import { Footer } from "../components/countering/footer";
import { Header } from "../components/countering/header";
import { setConfig, setWorkflow } from "../features/config/configActions";
import { fetchCountering } from "../features/countering/counteringActions";
import { getCounteringUrl } from "../features/countering/counteringApi";
import { PartialOrder } from "../features/order/order";
import { fetchOrder } from "../features/order/orderActions";
import "./execution.scss";
import { useBenchmark } from "@atx/commons/benchmark/useBenchmark";
import { setAlert } from "../features/alerts/alertsActions";
import { counteringUtils } from "../common/utils";

const { getCounteringNotifications } = counteringUtils;

// bunch of different scenarios for countering
export function Countering() {
    const { order } = useAppSelector((state) => state.orderInfo);
    const { countering } = useAppSelector((state) => state.counteringInfo);
    const config = useAppSelector((store) => store.config);
    const alerts = useAppSelector((state) => state.alerts);
    const dispatch = useAppDispatch();
    const navigate = useNavigate();

    const benchmark = useBenchmark(config.cusip);

    useEffect(() => {
        // initialize
        if (window.location && benchmark) {
            dispatch(setWorkflow({ wf: "COUNTERED" }));
            const partialOrder: PartialOrder = {
                id: Number(config.orderNumber),
                side: config.side,
                cusip: config.cusip
            };
            dispatch(
                fetchOrder({
                    orderNumber: Number(config.orderNumber),
                    cusip: config.cusip,
                    axeBroker: config.axeBroker,
                    axeCode: config.axeCode,
                    axeQuality: config.axeQuality,
                    benchmark
                })
            );
            console.log(
                `New Countered workflow initiated at location: ${document.location.href}, Order: ${JSON.stringify(
                    partialOrder
                )}`
            );
        }
    }, [window.location, benchmark]); // eslint-disable-line react-hooks/exhaustive-deps

    useEffect(() => {
        if (order.hasValidData && !countering.hasValidData) {
            dispatch(fetchCountering({ order: order, placementNumber: config.placementNumber }));
        }

        if (order.hasValidData && countering.hasValidData) {
            const counteringNotifications = getCounteringNotifications(order, countering);
            if (getCounteringNotifications(order, countering).length > 0) {
                dispatch(setAlert(counteringNotifications));
            }
        }
    }, [order.hasValidData, countering.hasValidData]);

    useEffect(() => {
        if (config.action === "RELOAD") {
            console.log("REFRESH_DATA action fired, refreshing screen!");
            window.location.reload();
        }
    }, [dispatch, config.action]);

    useEffect(() => {
        if (countering.state === "FORM") {
            // we are about to get out of countered popup workflow and into the main countering workflow ... update redux before we navigate
            const url = getCounteringUrl(countering, order);
            const queryString = url.replace("/index.html", "");
            const queryUpdate = useSettings(queryString);
            dispatch(setConfig(queryUpdate));
            navigate(url);
        }
    }, [dispatch, history, countering, countering.state, order]);

    return (
        <div className="execution">
            {alerts.length == 0 && (!order.hasValidData || !countering.hasValidData) ? (
                <Overlay>
                    <Spinner title="Loading order" />
                </Overlay>
            ) : (
                <React.Fragment>
                    <div>
                        <DebugInfo />
                        <Rec />
                        <Alerts />
                    </div>
                    <Header state={countering.state} timer={countering.timer ?? 0} orderSide={order.side} />
                    <section className="counteringPopupContent">
                        <OrderDetails order={order} countering={countering} />
                        <QuoteHistory order={order} countering={countering} />
                    </section>
                    <Footer countering={countering} order={order} />
                </React.Fragment>
            )}
        </div>
    );
}
