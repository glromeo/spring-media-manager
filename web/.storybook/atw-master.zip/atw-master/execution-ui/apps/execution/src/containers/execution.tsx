import { useEffect } from "react";
import { useAppDispatch, useAppSelector } from "../app";
import { useSettings } from "../common/hooks/useSettings";
import { configUtils } from "../common/utils";
import { Alerts } from "../components/common/alerts";
import DebugInfo from "../components/common/debugInfo";
import Rec from "../components/common/rec";
import { Body } from "../components/execution/body";
import { Footer } from "../components/execution/footer";
import { Header } from "../components/execution/header";
import { getAxeFromSettings } from "../features/axe/axe";
import { setAxe } from "../features/axe/axeActions";
import { getPartialOrderFromSettings } from "../features/order/order";
import { fetchOrder, setPartialOrder } from "../features/order/orderActions";
import "./execution.scss";
import { useBenchmark } from "@atx/commons/benchmark/useBenchmark";

export function Execution() {
    const dispatch = useAppDispatch();
    const queryParams = useSettings();
    const config = useAppSelector((store) => store.config);
    let query = config;
    if (configUtils.isCounteringModeOnly(queryParams)) {
        // in this case we came from countered back to execution (countering) - so we need to grab axe from query string (instead of config)
        query = queryParams;
        query.axeQuality = config.axeQuality; // user may have changed quality - honor that (should we have a generic way to honor new changes??)
    }

    const partialOrder = getPartialOrderFromSettings(config);
    const axe = getAxeFromSettings(config);
    const benchmark = useBenchmark(config.cusip);

    useEffect(() => {
        if (axe.quality && benchmark) {
            dispatch(setPartialOrder(partialOrder));
            if (!configUtils.isCares()) {
                console.log(
                    `New Execution workflow initiated at location: ${document.location.href}, Order: ${JSON.stringify(
                        partialOrder
                    )}, Axe: ${JSON.stringify(axe)}`
                );
                dispatch(setAxe({ axe }));
            } else {
                console.log(
                    `New Cares workflow initiated at location: ${document.location.href}, Order: ${JSON.stringify(
                        partialOrder
                    )}`
                );
            }
            dispatch(
                fetchOrder({
                    orderNumber: partialOrder.id!,
                    cusip: partialOrder.cusip!,
                    axeBroker: axe.broker,
                    axeCode: axe.code,
                    axeQuality: axe.quality,
                    benchmark
                })
            );
        }
    }, [axe.quality, benchmark]); // eslint-disable-line react-hooks/exhaustive-deps

    return (
        <div className="execution">
            <DebugInfo />
            <Rec />
            <Alerts></Alerts>
            <Header></Header>
            <Body></Body>
            <Footer></Footer>
        </div>
    );
}
