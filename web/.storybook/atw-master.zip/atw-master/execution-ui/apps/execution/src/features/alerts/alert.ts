// "ERROR" and "WARNING" maps to notifications on the top that notifities a user and maybe prevent them from continuing workflow
// "ALERT" maps to a popup that forces user to close window
export type AlertType = "PROMPT" | "ALERT" | "ERROR" | "MESSAGE" | "SUCCESS" | "WARNING";

export type Alert = {
    id?: number;
    name?: string;
    message: string | string[];
    type: AlertType;
    timeout?: number;
    isFatal?: boolean;
};
