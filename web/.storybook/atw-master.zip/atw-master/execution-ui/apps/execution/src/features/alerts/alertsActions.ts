import { createAction } from "@reduxjs/toolkit";
import { Alert } from "./alert";

export const setAlert = createAction("SET_ALERT", (alert: Alert[]) => {
    return { payload: alert };
});
export const clearAlert = createAction("CLEAR_ALERT", (id: number) => {
    return { payload: id };
});
export const clearAlerts = createAction("CLEAR_ALERTS");
