import { createReducer } from "@reduxjs/toolkit";
import { apiUtils, genericUtils } from "../../common/utils";
import { setAxe } from "../axe/axeActions";
import { fetchCountering, validateBeforeSend } from "../countering/counteringActions";
import { fetchOrder } from "../order/orderActions";
import { sendOrder, validateOrder } from "../stepper/stepperActions";
import { Alert } from "./alert";
import { clearAlert, clearAlerts, setAlert } from "./alertsActions";

export const alerts = createReducer([] as Alert[], (builder) =>
    builder
        .addCase(setAxe.rejected, apiUtils.reduceApiErrorTo("ALERT"))
        .addCase(fetchOrder.rejected, apiUtils.reduceApiErrorTo("ALERT"))
        .addCase(sendOrder.rejected, apiUtils.reduceApiErrorTo("ALERT"))
        .addCase(fetchCountering.rejected, apiUtils.reduceApiErrorTo("ALERT"))
        .addCase(validateOrder.rejected, apiUtils.reduceApiErrorsToNotification)
        .addCase(validateBeforeSend.rejected, apiUtils.reduceApiErrorsToNotification)
        .addCase(clearAlert, (current, { payload: id }) => current.filter((alert: Alert) => alert.id !== id))
        .addCase(clearAlerts, () => [])
        .addCase(setAlert, (current, { payload: alert }) => {
            alert.forEach((a: Alert) => {
                a.id = genericUtils.nextNumber();
                a.timeout = a.timeout ?? 3600000;
                console.log(`alerts -- ${a.name}: ${a.message}`);
            });
            return [...current, ...alert];
        })
);
