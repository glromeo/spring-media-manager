import { logError } from "@atw/toolkit/telemetry";
import {
    GraphQLCounteringValidationResponse,
    GraphQLError,
    GraphQlExecutePlacementQuoteVariables,
    GraphQLOrderCreationVariables,
    GraphQLOrderValidationResponse,
    GraphQLPlacementCreationVariables,
    GraphQLValidationResponse,
    validatePlacementsMutation,
    validatePlacementsCounteringMutation,
    validatePlacementsExecutionMutation
} from "../../../api/types";
import { apiUtils, counteringUtils, genericUtils, orderUtils } from "../../../common/utils";
import { Axe } from "../../axe/axe";
import { Config } from "../../config/config";
import { Countering } from "../../countering/countering";
import { createPlacement } from "../../countering/counteringApi";
import { Order } from "../../order/order";
import { TradeForm } from "../../tradeForm/tradeForm";
import { Alert } from "../alert";

export async function performOrderValidation(
    order: Order,
    tradeForm: TradeForm,
    axe: Axe,
    config: Config,
    countering: Countering
): Promise<boolean> {
    const validationAction = "executing on an order";
    let alerts: Alert[] = [];
    try {
        const orderValidationVariables = apiUtils.createOrder(order, tradeForm, axe, config, countering);
        console.log(`Running validation on ${validationAction}: ${JSON.stringify(orderValidationVariables)}`);
        await apiUtils.apiQuery<GraphQLOrderCreationVariables, GraphQLOrderValidationResponse>(
            validatePlacementsMutation,
            orderValidationVariables,
            {
                fixture: `/order-validation/${order.id}`,
                telemetry: ["validatePlacements", "perform validation"]
            }
        );
    } catch (e: any) {
        if (e.data) {
            alerts = parseAlertsFromGraphQLError(e.errors, validationAction);
        } else {
            const validateErrorMessage = `Error encountered in performing validation for ${validationAction} on order ${order.id}`;
            const errorMessage = e.errors
                .map((e: any) => e.message + "\n")
                .toString()
                .trim();
            logError(validateErrorMessage, {
                message: errorMessage
            });
            alerts.push({
                name: "Error Validating Order Execution",
                message: errorMessage,
                type: "ERROR"
            });
        }
    }

    if (alerts.length > 0) {
        throw apiUtils.apiErrors(alerts);
    }
    return true;
}

export async function validateBeforeUpdatingPlacementQuote(
    order: Order,
    placementNum: number,
    tradeForm?: TradeForm
): Promise<boolean> {
    const validationAction = "updating placement quote";
    let alerts: Alert[] = [];
    const placement = orderUtils.getPlacement(order, placementNum)!;
    let quantity: number | undefined;
    let tradeValue: number | undefined;
    if (tradeForm) {
        quantity = tradeForm.size;
        tradeValue = placement.limitType === "PRICE" ? tradeForm.price : tradeForm.spread;
    } else {
        const validQuote = counteringUtils.getValidQuote(placement, order.side);
        quantity = validQuote?.quantity;
        tradeValue = placement.limitType === "PRICE" ? validQuote?.price : validQuote?.spread;
    }
    const vars = {
        quantity: quantity as number,
        tradeValue: tradeValue as number,
        ...(tradeForm && { dueInTime: genericUtils.getConvertedDueTime(parseInt(tradeForm.dueInSelected!)) })
    };
    const executePlacementQuoteVars = apiUtils.createUpdatePlacementQuoteVars(placement, vars);
    try {
        console.log(`Running validation on ${validationAction}: ${JSON.stringify(executePlacementQuoteVars)}`);
        await apiUtils.apiQuery<GraphQlExecutePlacementQuoteVariables, GraphQLValidationResponse>(
            validatePlacementsExecutionMutation,
            executePlacementQuoteVars,
            {
                fixture: `placement_quote-update-validation/${order.id}`,
                telemetry: ["validatePlacementsExecution", "validate update placement quote"]
            }
        );
    } catch (e: any) {
        // if successful call with warnings/errors
        if (e.data) {
            alerts = parseAlertsFromGraphQLError(e.errors, validationAction);
        } else {
            const validateErrorMessage = `Error encountered in performing validation for ${validationAction} on placement ${placementNum}`;
            const errorMessage = e.errors
                .map((e: any) => e.message + "\n")
                .toString()
                .trim();
            logError(validateErrorMessage, {
                message: errorMessage
            });
            alerts.push({ name: "Error Validating Quote Update", message: errorMessage, type: "ERROR" });
        }
    }
    if (alerts.length > 0) {
        throw apiUtils.apiErrors(alerts);
    }
    return true;
}

export async function performCounteringValidation(
    order: Order,
    tradeForm: TradeForm,
    axe: Axe,
    config: Config,
    countering: Countering
): Promise<boolean> {
    const validationAction = "countering an order";
    let alerts: Alert[] = [];
    try {
        const placementCreationVariables = createPlacement(order, tradeForm, axe, config, countering);
        console.log(`Validating countering: ${JSON.stringify(placementCreationVariables)}`);
        await apiUtils.apiQuery<GraphQLPlacementCreationVariables, GraphQLCounteringValidationResponse>(
            validatePlacementsCounteringMutation,
            placementCreationVariables,
            {
                fixture: `/countering-validation/${order.id}`,
                telemetry: ["performCounteringValidation", "performing countering validation"]
            }
        );
    } catch (e: any) {
        // if successful call with warnings/errors
        if (e.data) {
            alerts = parseAlertsFromGraphQLError(e.errors, validationAction);
        } else {
            const validateErrorMessage = `Error encountered in performing validation for ${validationAction} on order ${order.id}`;
            const errorMessage = e.errors
                .map((e: any) => e.message + "\n")
                .toString()
                .trim();
            logError(validateErrorMessage, {
                message: errorMessage
            });
            alerts.push({ name: "Error Validating Quote Creation", message: errorMessage, type: "ERROR" });
        }
    }

    if (alerts.length > 0) {
        throw apiUtils.apiErrors(alerts);
    }
    return true;
}

// the parsing here has to be changed.....find a clean way to show what errors....
export function parseAlertsFromGraphQLError(errors: Partial<GraphQLError>[] | [], validationAction: string): Alert[] {
    let alerts: Alert[] = [];
    if (!errors) {
        alerts = [
            {
                message: `Unable to run validation for ${validationAction}, received a null or invalid API response`,
                type: "ERROR"
            }
        ];
    } else {
        alerts =
            errors && errors.length > 0
                ? errors?.map((error: Partial<GraphQLError>) => {
                      if (!error.message) {
                          return {
                              message: `When running validation for ${validationAction}, received ${error.errorType} type error without a message`,
                              type: "ERROR"
                          };
                      }
                      const validationResponse = error.message.split(",");
                      if (validationResponse.length !== 3) {
                          return {
                              message: `When running validation for ${validationAction}, received error message "${error.message}"`,
                              type: "ERROR"
                          };
                      } else {
                          return {
                              message: validationResponse[2],
                              type: validationResponse[0].indexOf("warning") < 0 ? "ERROR" : "WARNING"
                          };
                      }
                  })
                : [];
    }
    alerts.forEach((alert) => logError(`Received ${alert.type} during validation`, { message: alert.message }));
    return alerts;
}
