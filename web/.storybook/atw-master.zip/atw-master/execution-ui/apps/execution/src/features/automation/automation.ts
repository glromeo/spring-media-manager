import { StepperState } from "../stepper/stepper";

export type StepperTrigger = {
    stepper: StepperState;
    action: string;
    delay: number;
};

export type TimeoutTrigger = {
    action: string;
    timeout: number;
};

export type AutomationParams = {
    trigger: StepperTrigger | TimeoutTrigger;
    repeat: number;
    interval: number;
};
