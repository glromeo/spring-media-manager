import { configUtils } from "../../common/utils";
import { BondQuality, FieldType, NUM_PLACE_HOLDER, STRING_PLACE_HOLDER, Side } from "../../models/common";
import { Config } from "../config/config";

export type AxeSchema = {
    field: keyof Axe;
    label: string;
    type: FieldType;
    visibleFor: (quality: BondQuality, config?: Config, axe?: Axe) => boolean;
    separator?: (axe: Axe) => boolean;
    classNameFor: (side: Side, value?: number) => string;
};

export type Axe = {
    aid: string;
    id: string;
    code: number;
    price: number;
    spread: number | undefined;
    yield: number;
    yieldType: string;
    quality: BondQuality;
    size: number;
    time: number;
    broker: string;
    axeBmk: string;
    axeBmkId: string;
    hasValidData: boolean;
    counterPartyRating: number;
    counterPartyType: string;
    brokerFee: number;
};

export type AxeInfo = {
    axe: Axe;
    schema: AxeSchema[];
};

export const DEFAULT_AXE_SCHEMA: AxeSchema[] = [
    {
        field: "code",
        label: "Broker",
        type: "side",
        visibleFor: () => true,
        classNameFor: (side: Side) => {
            return side === "BUY" ? "detail-side-row-buy" : "detail-side-row-sell";
        }
    },
    {
        field: "counterPartyType",
        label: "Ext Counterparty Type",
        type: "text",
        visibleFor: () => {
            return configUtils.isAxeA2AMode();
        },
        classNameFor: () => {
            return "";
        }
    },
    {
        field: "counterPartyRating",
        label: "Ext Counterparty Rating",
        type: "rating",
        visibleFor: () => {
            return configUtils.isAxeA2AMode();
        },
        separator: () => true,
        classNameFor: () => {
            return "";
        }
    },
    {
        field: "price",
        label: "Price",
        type: "price",
        visibleFor: (quality: BondQuality, _config?: Config, axe?: Axe) => {
            if (configUtils.isAxeA2AMode()) {
                return quality !== "IG" && Boolean(axe?.price) && axe?.price !== NUM_PLACE_HOLDER;
            }

            return true;
        },
        separator: () => configUtils.isAxeA2AMode(),
        classNameFor: () => {
            return "";
        }
    },
    {
        field: "spread",
        label: "Spread",
        type: "spread",
        visibleFor: (quality: BondQuality, _config?: Config, axe?: Axe) => {
            if (configUtils.isAxeA2AMode()) {
                return quality === "IG" && Boolean(axe?.spread) && axe?.spread !== undefined;
            }

            return true;
        },
        separator: (axe: Axe) => {
            if (configUtils.isAxeA2AMode()) {
                return Boolean(axe.yield);
            }

            return false;
        },
        classNameFor: () => {
            return "";
        }
    },
    {
        field: "yield",
        label: "Yield",
        type: "price",
        visibleFor: (quality: BondQuality, _config?: Config, axe?: Axe) => {
            if (configUtils.isAxeA2AMode()) {
                return !!axe?.yield && axe?.yield !== NUM_PLACE_HOLDER;
            }

            return true;
        },
        separator: () => configUtils.isAxeA2AMode(),
        classNameFor: () => {
            return "";
        }
    },
    {
        field: "axeBmk",
        label: "Axe Bmk",
        type: "security",
        visibleFor: (quality: BondQuality) => {
            if (quality === "HY") {
                return false;
            }

            return !configUtils.isAxeA2AMode();
        },
        classNameFor: () => {
            return "";
        }
    },
    {
        field: "size",
        label: "Axe Size",
        type: "size",
        visibleFor: () => {
            return !configUtils.isAxeA2AMode();
        },
        classNameFor: () => {
            return "";
        }
    },
    {
        field: "axeBmk",
        label: "A2A Axe Bmk",
        type: "security",
        visibleFor: (quality: BondQuality) => {
            if (quality === "HY") {
                return false;
            }

            return configUtils.isAxeA2AMode();
        },
        classNameFor: () => {
            return "";
        }
    },
    {
        field: "size",
        label: "A2A Axe Size",
        type: "size",
        visibleFor: () => {
            return configUtils.isAxeA2AMode();
        },
        classNameFor: () => {
            return "";
        }
    },
    {
        field: "time",
        label: "Time In",
        type: "time",
        visibleFor: () => {
            return !configUtils.isAxeA2AMode();
        },
        classNameFor: () => {
            return "";
        }
    }
];

export const DEFAULT_AXE: Axe = {
    aid: STRING_PLACE_HOLDER,
    id: STRING_PLACE_HOLDER,
    code: NUM_PLACE_HOLDER,
    price: NUM_PLACE_HOLDER,
    spread: undefined,
    yield: NUM_PLACE_HOLDER,
    yieldType: STRING_PLACE_HOLDER,
    quality: STRING_PLACE_HOLDER,
    size: NUM_PLACE_HOLDER,
    time: NUM_PLACE_HOLDER,
    broker: STRING_PLACE_HOLDER,
    axeBmk: STRING_PLACE_HOLDER,
    axeBmkId: STRING_PLACE_HOLDER,
    hasValidData: false,
    counterPartyRating: NUM_PLACE_HOLDER,
    counterPartyType: STRING_PLACE_HOLDER,
    brokerFee: NUM_PLACE_HOLDER
};

export function getAxeFromSettings(config: Config): Axe {
    let quality = config.axeQuality;
    if (configUtils.isAxeA2AMode()) {
        if (config.axePriceType === "AXE_PRICE_TYPE_PRICE") {
            quality = "HY";
        } else if (config.axePriceType === "AXE_PRICE_TYPE_SPREAD") {
            quality = "IG";
        }
    }

    return {
        aid: config.axeOrigId,
        id: config.axeId,
        price: config.axePrice,
        spread: config.axeSpread,
        yield: config.axeYield,
        yieldType: config.axeYieldType,
        quality,
        size: config.axeSize,
        code: config.axeCode,
        time: config.axeTime,
        broker: config.axeBroker,
        axeBmkId: config.axeBmkId,
        axeBmk: STRING_PLACE_HOLDER,
        hasValidData: false,
        counterPartyRating: config.axeCounterPartyRating,
        counterPartyType: config.axeCounterPartyType,
        brokerFee: config.axeBrokerFee
    };
}
