import { queryBenchmarkDescriptor } from "@atx/commons/benchmark/useBenchmark";
import { createAction, createAsyncThunk } from "@reduxjs/toolkit";
import { HIGH_YIELD, STRING_PLACE_HOLDER } from "../../models/common";
import { Axe } from "./axe";

export const invalidateAxeInfo = createAction("INVALIDATE_AXE_INFO");
export const resetAxe = createAction("RESET_AXE");
export const setAxe = createAsyncThunk<Axe, { axe: Axe }>("FETCH_AXE", async (params) => {
    if (params.axe.quality === HIGH_YIELD) {
        params.axe.axeBmk = STRING_PLACE_HOLDER;
    } else {
        const benchmarkDesc = await queryBenchmarkDescriptor(params.axe.axeBmkId);

        if (!benchmarkDesc) {
            params.axe.axeBmk = STRING_PLACE_HOLDER;
        } else {
            params.axe.axeBmk = benchmarkDesc;
        }
    }
    return params.axe;
});
export const setAxeBenchmark = createAction("SET_AXE_BENCHMARK", (security: any) => {
    return { payload: security };
});
