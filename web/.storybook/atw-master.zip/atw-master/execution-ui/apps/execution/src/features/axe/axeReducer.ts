import { createReducer } from "@reduxjs/toolkit";
import { DEFAULT_AXE, DEFAULT_AXE_SCHEMA } from "./axe";
import { invalidateAxeInfo, resetAxe, setAxe, setAxeBenchmark } from "./axeActions";

export const axeInfo = createReducer({ axe: DEFAULT_AXE, schema: DEFAULT_AXE_SCHEMA }, (builder) =>
    builder
        .addCase(setAxe.fulfilled, (current, { payload: axe }) => {
            axe.hasValidData = true;
            return { axe, schema: current.schema };
        })
        .addCase(invalidateAxeInfo, (current) => {
            return { axe: { ...current.axe, hasValidData: false }, schema: current.schema };
        })
        .addCase(resetAxe, () => {
            return { axe: { ...DEFAULT_AXE }, schema: DEFAULT_AXE_SCHEMA };
        })
        .addCase(setAxeBenchmark, (current, { payload: security }) => {
            return {
                axe: {
                    ...current.axe,
                    axeBmk: security.desc1,
                    axeBmkId: security.cusip ? security.cusip : security.isin
                },
                schema: current.schema
            };
        })
);
