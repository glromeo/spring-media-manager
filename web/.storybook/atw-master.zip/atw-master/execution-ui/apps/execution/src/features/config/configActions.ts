import { createAction, createAsyncThunk } from "@reduxjs/toolkit";
import { RefreshActionType } from "../../common/hooks/useSettings";
import { BondQuality } from "../../models/common";
import { ModeType, WorkflowMode, WorkflowType } from "../stepper/stepper";
import { Config } from "./config";

export const setWorkflow = createAsyncThunk<
    WorkflowMode,
    { wf: WorkflowType },
    { state: { config: Config; tokens: any } }
>("SET_WORKFLOW", (params, state) => {
    const {
        config,
        tokens: { entries: { AT_execution_mode } }
    } = state.getState();
    let mode: ModeType = "NORMAL";
    if (AT_execution_mode !== undefined) {
        mode = AT_execution_mode.toUpperCase() as ModeType;
    }
    // always use query as overwrite
    if (config.mode !== "NOTSET") {
        mode = config.mode;
    }
    return { workflow: params.wf, mode: mode };
});
export const enableCountering = createAction("ENABLE_COUNTERING", (fatal: boolean) => {
    return { payload: fatal };
});
export const disableCountering = createAction("DISABLE_COUNTERING");
export const setConfig = createAction("SET_CONFIG", (config: Config) => {
    return { payload: config };
});
export const setPricingType = createAction<BondQuality>("SET_PRICING_TYPE");

export const setAction = createAction("SET_ACTION", (action: RefreshActionType) => {
    return { payload: action };
});
export const refreshData = createAction("REFRESH_DATA");
export const setDebugInfo = createAction("SET_DEBUG_INFO", (open: boolean) => {
    return { payload: open };
});
