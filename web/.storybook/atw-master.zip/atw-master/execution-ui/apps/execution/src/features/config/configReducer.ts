import { createReducer } from "@reduxjs/toolkit";
import { RefreshActionType, useSettings } from "../../common/hooks/useSettings";
import { STRING_PLACE_HOLDER } from "../../models/common";
import { setAxeBenchmark } from "../axe/axeActions";
import { fetchOrder } from "../order/orderActions";
import {
    disableCountering,
    enableCountering,
    refreshData,
    setAction,
    setConfig,
    setDebugInfo,
    setPricingType,
    setWorkflow
} from "./configActions";

export const config = createReducer(useSettings(), (builder) =>
    builder
        .addCase(setConfig, (_current, { payload: newConfig }) => {
            return {
                ...newConfig
            };
        })
        .addCase(setDebugInfo, (current, { payload: open }) => {
            return {
                ...current,
                debugInfo: open
            };
        })
        .addCase(setPricingType, (current, { payload: priceType }) => {
            return {
                ...current,
                axeQuality: priceType
            };
        })
        .addCase(setAxeBenchmark, (current, { payload: security }) => {
            return {
                ...current,
                axeBmk: security.cusip ? security.cusip : security.isin
            };
        })
        .addCase(setWorkflow.fulfilled, (current, { payload: wfm }) => {
            return {
                ...current,
                workflow: wfm.workflow,
                mode: wfm.mode
            };
        })
        .addCase(enableCountering, (current, { payload: fatal }) => {
            if (fatal) return current;
            return {
                ...current,
                mode: "COUNTERING"
            };
        })
        .addCase(disableCountering, (current) => {
            return {
                ...current,
                mode: "NORMAL"
            };
        })
        .addCase(refreshData, (current) => {
            let action: RefreshActionType;
            if (current.workflow === "COUNTERED") {
                action = "RELOAD";
                console.log(`received REFRESH_DATA from dashboard. This should trigger a browser reload!`);
            } else {
                action = "BACK";
                console.log(`received REFRESH_DATA from dashboard. This should trigger a browser reload!`);
            }
            return {
                ...current,
                action: action,
                cancelAutoClose: true
            };
        })
        .addCase(setAction, (current, { payload: action }) => {
            return {
                ...current,
                action: action
            };
        })
        .addCase(fetchOrder.fulfilled, (current, { payload: order }) => ({
            ...current,
            axeQuality:
                current.workflow === "CARE" && current.axeQuality === STRING_PLACE_HOLDER
                    ? order.quality
                    : current.axeQuality
        }))
);
