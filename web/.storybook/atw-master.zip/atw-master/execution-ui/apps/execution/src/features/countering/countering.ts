import { BondQuality, NUM_PLACE_HOLDER } from "../../models/common";
import { Order } from "../order/order";

export type CounteringState =
    | "NOT_SET"
    | "BROKER_ACCEPTED"
    | "BROKER_ACCEPTED_DISABLE"
    | "REPEAT_ORIGINAL"
    | "COUNTER_NEW"
    | "COUNTER_REJECTED"
    | "COUNTER_TIMEOUT"
    | "DUE_IN_EXPIRED"
    | "COUNTER_CANCELED"
    | "ACCEPT_BROKER"
    | "ACCEPT_ORIGINAL"
    | "ACCEPT_NEW"
    | "PASSING_BROKER"
    | "PASSING_ORIGINAL"
    | "PASSING_NEW"
    | "FORM"
    | "CLOSE"
    | "DISABLE"
    | "UNKNOWN";

export const ACCEPT_STATES: CounteringState[] = ["ACCEPT_BROKER", "ACCEPT_NEW", "ACCEPT_ORIGINAL"];

export type ActionType =
    | "ACCEPT"
    | "COUNTER"
    | "PASS"
    | "ACKSEND"
    | "OK"
    | "SEND"
    | "CANCEL"
    | "CLOSE"
    | "TIMEOUT"
    | "NOT_SET";

export type CounteringHistory = {
    status: string;
    value?: number;
    size?: number;
    broker?: string;
    quality: BondQuality;
};
export type Countering = {
    placementNum: number;
    prevState: CounteringState;
    action: ActionType;
    state: CounteringState;
    hasValidData: boolean;
    timer?: number;
    history?: CounteringHistory[];
};

export type CounteringInfo = {
    countering: Countering;
    // room for expansion? (to be similar to other 'infos')
};

export const DEFAULT_COUNTERING: Countering = {
    placementNum: NUM_PLACE_HOLDER,
    prevState: "NOT_SET",
    action: "NOT_SET",
    state: "NOT_SET",
    hasValidData: false
};

export type performCounteringActionConfig = {
    action: ActionType;
    nextState: CounteringState;
    currentState: CounteringState;
    order: Order;
    placementNumber: number;
};

export const LIVE_NEGOTIATION_STATES: CounteringState[] = [
    "BROKER_ACCEPTED",
    "BROKER_ACCEPTED_DISABLE",
    "REPEAT_ORIGINAL",
    "COUNTER_NEW",
    "COUNTER_TIMEOUT"
];
export const DEAD_NEGOTIATION_STATES: CounteringState[] = ["COUNTER_REJECTED", "COUNTER_CANCELED", "DUE_IN_EXPIRED"];

export const PASSING_STATES: CounteringState[] = ["PASSING_BROKER", "PASSING_NEW", "PASSING_ORIGINAL"];
