import { createAsyncThunk } from "@reduxjs/toolkit";
import { orderUtils } from "../../common/utils";
import { Alert } from "../alerts/alert";
import { validateBeforeUpdatingPlacementQuote } from "../alerts/validate/validateApi";
import { Order, OrderInfo } from "../order/order";
import { ActionType, Countering, CounteringInfo, CounteringState } from "./countering";
import {
    cancelPlacements,
    getCounteringByPlacmentNumber,
    getNextCounteringState,
    performCounteringAction
} from "./counteringApi";
import { throwOrderLeavesValidationError, validateOrderLeaves } from "../stepper/stepperActions";
import { getOrderLeavesAndRequestSize } from "../order/orderApi";

export const fetchCountering = createAsyncThunk<Countering, { order: Order; placementNumber: number }>(
    "FETCH_COUNTERING",
    async (params) => {
        const stateObject = await getCounteringByPlacmentNumber(params.order, params.placementNumber);
        const placement = orderUtils.getPlacement(params.order, params.placementNumber);
        if (placement?.modifyReason.toUpperCase() == "REJECTED") {
            await cancelPlacements(params.order, [params.placementNumber]);
        }
        return stateObject;
    }
);
export const setCounteringState = createAsyncThunk<
    { action: ActionType; nextState: CounteringState },
    { action: ActionType },
    { state: { alerts: Alert[]; counteringInfo: CounteringInfo; orderInfo: OrderInfo } }
>("SETSTATE_COUNTERING", async (params, thunkAPI) => {
    const {
        counteringInfo: { countering },
        orderInfo: { order },
        alerts
    }: {
        alerts: Alert[];
        counteringInfo: { countering: Countering };
        orderInfo: { order: Order };
    } = thunkAPI.getState();
    const config = {
        action: params.action,
        nextState: getNextCounteringState(countering, params.action),
        currentState: countering.state,
        order,
        placementNumber: countering.placementNum
    };
    // "ALERT" type alerts map to any state where user must now end session and window to CLOSE
    // In this case the COUNTERING pop-up CLOSE button has to map to "CLOSE" since we not rendering an actual alert component
    if (alerts.length > 0 && alerts.find((alert) => alert.type === "ALERT")) config.nextState = "CLOSE";

    return performCounteringAction(config);
});
export const validateBeforeSend = createAsyncThunk<
    boolean,
    { order: Order; placementNumber: number; latestCounteringSize: number }
>("VALIDATE_BEFORE_SEND", async (params, { dispatch }: any) => {
    let [oldOrderLeaves, newOrderLeaves, requestSize] = await getOrderLeavesAndRequestSize(
        params.latestCounteringSize,
        params.order
    );
    let response = await dispatch(validateOrderLeaves({ oldOrderLeaves, newOrderLeaves, requestSize }));
    if (response.payload) {
        const success = await validateBeforeUpdatingPlacementQuote(params.order, params.placementNumber);
        if (success) {
            dispatch(setCounteringState({ action: "SEND" }));
        }
        return true;
    } else {
        throwOrderLeavesValidationError(requestSize, newOrderLeaves);
    }
    return false;
});
