import { logClick, logError } from "@atw/toolkit/telemetry";
import { benchmarkApi } from "@atx/commons/benchmark/useBenchmark";
import _ from "lodash";
import {
    GraphQLPlacementCreationResponse,
    GraphQLPlacementCreationVariables,
    GraphQlCancelErrorPlacementsResponse,
    GraphQlCancelErrorPlacementsVariables,
    GraphQlCounterPlacementQuoteResponse,
    GraphQlCounterPlacementQuoteVariables,
    GraphQlExecutePlacementQuoteResponse,
    GraphQlExecutePlacementQuoteVariables,
    GraphQlPassPlacementQuotesResponse,
    GraphQlPassPlacementQuotesVariables,
    cancelErrorPlacementsMutation,
    counterPlacementQuoteMutation,
    executePlacementQuoteMutation,
    passPlacementQuoteMutation,
    requestPlacementQuoteMutation
} from "../../api/types";
import { store } from "../../app/store";
import { CODE, CONFIG } from "../../common/constants";
import { useSettings } from "../../common/hooks/useSettings";
import {
    apiUtils,
    configUtils,
    counteringUtils,
    genericUtils,
    orderUtils,
    pricingTypeUtils,
    tradeFormUtils,
    windowUtils,
} from "../../common/utils/";
import { BondQuality, Dimension, HIGH_YIELD, INVESTMENT_GRADE, PartialRecord } from "../../models/common";
import { Axe } from "../axe/axe";
import { Config } from "../config/config";
import { Order } from "../order/order";
import { ModeType } from "../stepper/stepper";
import { TradeForm } from "../tradeForm/tradeForm";
import {
    ActionType,
    Countering,
    CounteringHistory,
    CounteringState,
    performCounteringActionConfig
} from "./countering";

const { getQualityFromPlacement } = pricingTypeUtils;
const { getLastHistoryFromPlacement, checkQuoteValidity } = counteringUtils;

type PriceAndQuantity = {
    price: number;
    size: number;
    quality: BondQuality;
};

export function getNextCounteringState(countering: Countering, action: ActionType): CounteringState {
    const state = countering.state;
    if (action === "CANCEL") return countering.prevState;
    const key = state + ":" + action;
    const fsm: any = {
        "BROKER_ACCEPTED:ACCEPT": "ACCEPT_BROKER",
        "BROKER_ACCEPTED:TIMEOUT": "BROKER_ACCEPTED_DISABLE",
        "BROKER_ACCEPTED:COUNTER": "FORM",
        "BROKER_ACCEPTED:PASS": "PASSING_BROKER",
        "BROKER_ACCEPTED_DISABLE:COUNTER": "FORM",
        "REPEAT_ORIGINAL:ACCEPT": "ACCEPT_ORIGINAL",
        "REPEAT_ORIGINAL:COUNTER": "FORM",
        "REPEAT_ORIGINAL:PASS": "PASSING_ORIGINAL",
        "COUNTER_NEW:ACCEPT": "ACCEPT_NEW",
        "COUNTER_NEW:COUNTER": "FORM",
        "COUNTER_NEW:PASS": "PASSING_NEW",
        "COUNTER_NEW:TIMEOUT": "CLOSE",
        "COUNTER_REJECTED:COUNTER": "FORM",
        "COUNTER_REJECTED:CLOSE": "CLOSE",
        "COUNTER_CANCELED:COUNTER": "FORM",
        "COUNTER_CANCELED:CLOSE": "CLOSE",
        "DUE_IN_EXPIRED:COUNTER": "FORM",
        "DUE_IN_EXPIRED:CLOSE": "CLOSE",
        "COUNTER_TIMEOUT:COUNTER": "FORM",
        "COUNTER_TIMEOUT:CLOSE": "CLOSE",
        "ACCEPT_BROKER:SEND": "CLOSE",
        "ACCEPT_BROKER:ACKSEND": "CLOSE",
        "ACCEPT_BROKER:CANCEL": "BROKER_ACCEPTED",
        "ACCEPT_ORIGINAL:SEND": "CLOSE",
        "ACCEPT_ORIGINAL:ACKSEND": "CLOSE",
        "ACCEPT_NEW:SEND": "CLOSE",
        "ACCEPT_NEW:ACKSEND": "CLOSE",
        "PASSING_BROKER:SEND": "CLOSE",
        "PASSING_ORIGINAL:SEND": "CLOSE",
        "PASSING_NEW:SEND": "CLOSE",
        "UNKNOWN:CLOSE": "CLOSE"
    };
    return fsm[key];
}

export function getCounteringPopupSize(state: CounteringState): Dimension {
    const brokerActionDimension: Dimension = { width: 700, height: 455 };
    const traderActionDimension: Dimension = { width: 700, height: 365 };
    const fullsizeDimension: Dimension = { width: 640, height: 885 };

    const fsm: any = {
        BROKER_ACCEPTED: brokerActionDimension,
        REPEAT_ORIGINAL: brokerActionDimension,
        COUNTER_NEW: brokerActionDimension,
        COUNTER_REJECTED: brokerActionDimension,
        COUNTER_CANCELED: brokerActionDimension,
        DUE_IN_EXPIRED: brokerActionDimension,
        ACCEPT_BROKER: traderActionDimension,
        ACCEPT_ORIGINAL: traderActionDimension,
        ACCEPT_NEW: traderActionDimension,
        PASSING_BROKER: traderActionDimension,
        PASSING_ORIGINAL: traderActionDimension,
        PASSING_NEW: traderActionDimension,
        COUNTER_TIMEOUT: brokerActionDimension,
        FORM: fullsizeDimension,
        NOT_SET: fullsizeDimension
    };
    return fsm[state] as Dimension;
}

export function getCounteringUrl(countering: Countering, order: Order): string {
    const query = useSettings(),
        placement = orderUtils.getPlacement(order, countering.placementNum),
        { axeID, axeLevel, axeQty } = placement!.axe,
        originalAxeId = axeID,
        aPrice = placement?.limitType === "PRICE" ? axeLevel : null,
        aSpread = placement?.limitType === "SPREAD" ? axeLevel : null,
        aSize = axeQty,
        aQuality = placement?.limitType === "SPREAD" ? "IG" : "HY";
    let mode: ModeType = "NOTSET";

    if (countering.state === "FORM") {
        if (countering.action === "COUNTER") {
            mode = "COUNTERING_ONLY";
        }
        // simulate a url we typically get from Market-Depth plugin
        // FORM URL
        return `/index.html?orderNumber=${order.id}&mode=${mode.toLowerCase()}&embedded=true&side=${order.side}&cusip=${
            order.cusip
        }&aquality=${aQuality}&theme=${query.theme}&user=${query.user}&aoid=${originalAxeId}&aid=${
            placement!.externRefID
        }&asize=${aSize}&aprice=${aPrice}&aspread=${aSpread}&ayield=null&aytype=nullType&abmk=${query.axeBmkId}&acode=${
            query.axeCode
        }&abroker=${query.axeBroker}&scale=${query.scale}&placement=${placement!.placementNum}`;
    } else if (countering.state !== "NOT_SET") {
        // POPUP URL
        return `/index.html?orderNumber=${order.id}&mode=NORMAL&workflow=COUNTERED&embedded=true&placement=${
            placement!.placementNum
        }&cusip=${order.cusip}&theme=${query.theme}&user=${query.user}&acode=${query.axeCode}&abmk=${
            query.axeBmkId
        }&abroker=${query.axeBroker}&scale=${query.scale}`;
    }
    return "";
}

export async function getCounteringByPlacmentNumber(order: Order, placementNumber: number): Promise<Countering> {
    try {
        checkQuoteValidity(order, placementNumber);
        const state = getStatus(placementNumber, order);
        return {
            placementNum: placementNumber,
            prevState: "NOT_SET",
            action: "NOT_SET",
            state: state,
            timer: getTimeout(placementNumber, order, state),
            history: getHistory(placementNumber, order, state),
            hasValidData: true
        };
    } catch (e: any) {
        if (typeof e === "string") {
            throw e;
        } else {
            logError("Error fetching countering info", { message: e });
            throw apiUtils.apiError(e.title || "Error fetching Countering Info", e.message);
        }
    }
}

export async function performCounteringAction(
    config: performCounteringActionConfig
): Promise<{ action: ActionType; nextState: CounteringState }> {
    const { action, nextState, currentState, order, placementNumber } = config;

    try {
        switch (nextState) {
            case "CLOSE":
                switch (action) {
                    case "ACKSEND":
                    case "SEND":
                        switch (currentState) {
                            // Secondary confirmation for trader action
                            case "ACCEPT_BROKER":
                            // broker accepts what user first sent
                            case "ACCEPT_NEW":
                            // broker countered new
                            case "ACCEPT_ORIGINAL": // broker repeated original again
                                CounteringApi.acceptPlacementQuote(order, placementNumber);
                                break;
                            case "PASSING_NEW":
                            case "PASSING_BROKER":
                            case "PASSING_ORIGINAL":
                                CounteringApi.passPlacementQuotes(placementNumber);
                                break;
                        }
                        break;
                }
                windowUtils.closeWindow("countering next state is CLOSE");
                break;
            default:
                windowUtils.resizeWindow(getCounteringPopupSize(nextState));
                break;
        }
        return { action, nextState };
    } catch (e: any) {
        if (typeof e === "string") {
            throw e;
        } else {
            logError("Error calling countering action", { message: e });
            throw apiUtils.apiError("Error fetching Order", e.message);
        }
    }
}


function getStatus(placementNumber: number, order: Order): CounteringState {
    const originalAxeInfo = getPriceAndQuantity(order, placementNumber, "original");
    const traderInfo = getPriceAndQuantity(order, placementNumber, "mine");
    const brokerInfo = getPriceAndQuantity(order, placementNumber, "theirs");
    const myPlacement = orderUtils.getPlacement(order, placementNumber);
    let state: CounteringState = "UNKNOWN";
    if (myPlacement === undefined) return state;
    state = (() => {
        switch (myPlacement.modifyReason.toUpperCase()) {
            case "QUOTED": // RQQA
                return mapQuotedModifyReasonToState(originalAxeInfo, traderInfo, brokerInfo);
            case "QUOTE CANCELLED":
            // RQQC
            case "QUOTE PASSED":
            // RQQP
            case "LIFT REJECTED":
            // RQLR
            case "REJECTED": // REJ
                return "COUNTER_REJECTED";
            case "QUOTE SUBJECTED": // QSUB
                return "COUNTER_TIMEOUT";
            case "CANCEL REQUEST":
            // CR
            case "CANCELATION": // C
                if (isDueInExpired(myPlacement.modifiedBy ?? "")) return "DUE_IN_EXPIRED";
            case "MANUAL CANCELATION":
            // MC
            case "QUOTE EXPIRED": // RQQE
                return "COUNTER_CANCELED";
            default:
                return "UNKNOWN";
        }
    })();
    console.log(
        `Received placement with modify reason ${myPlacement.modifyReason}, mapping to countering popup state ${state}`
    );
    return state;
}

function getTimeout(placementNumber: number, order: Order, _state: CounteringState): number | undefined {
    const myPlacement = orderUtils.getPlacement(order, placementNumber);
    if (myPlacement === undefined) return undefined;
    const myQuote = counteringUtils.getValidQuote(myPlacement, order.side);
    if (myQuote === undefined) return undefined;
    return myQuote.expTime;
}

export function getPriceAndQuantity(
    order: Order,
    placementNumber: number,
    source: "mine" | "theirs" | "original"
): PriceAndQuantity {
    // make it obvious - if no counterparty found
    const myPlacement = orderUtils.getPlacement(order, placementNumber);
    const defaultQuality: BondQuality = HIGH_YIELD;
    const defaultPriceAndQuantity = {
        price: 0,
        size: 0,
        quality: defaultQuality
    };
    if (myPlacement === undefined) {
        console.log("method: getPriceAndQuantity, unable to find placement for placement number: " + placementNumber);
        return defaultPriceAndQuantity;
    }
    const quality = getQualityFromPlacement(myPlacement)!;
    const getMine = (): PriceAndQuantity => {
        return {
            price: myPlacement.limitValue,
            size: myPlacement.quantity,
            quality
        };
    };
    const getTheirs = (): PriceAndQuantity => {
        const brokerQuote = counteringUtils.getValidQuote(myPlacement, order.side);
        if (brokerQuote !== undefined) {
            const priceVal = quality === INVESTMENT_GRADE ? brokerQuote.spread : brokerQuote.price;
            return {
                price: priceVal,
                size: brokerQuote.quantity,
                quality
            };
        }
        return defaultPriceAndQuantity;
    };
    const getOriginal = (): PriceAndQuantity => {
        // this is off, try to fix this......
        if (myPlacement.axe === null || myPlacement.axe === undefined) {
            console.log(
                `Unable to retrieve placement generic fields on order: ${JSON.stringify(
                    order
                )} for placement: ${placementNumber}`
            );
        } else {
            return {
                price: myPlacement.axe.axeLevel,
                size: myPlacement.axe.axeQty,
                quality: quality
            };
        }
        return defaultPriceAndQuantity;
    };

    switch (source) {
        case "mine":
            return getMine();
        case "theirs":
            return getTheirs();
        default:
            return getOriginal();
    }
}

function getHistory(placementNumber: number, order: Order, state: CounteringState): CounteringHistory[] | undefined {
    const traderCounterInfo = getPriceAndQuantity(order, placementNumber, "mine");
    const originalAxeInfo = getPriceAndQuantity(order, placementNumber, "original");
    const brokerQuoteInfo = getPriceAndQuantity(order, placementNumber, "theirs");
    const placement = orderUtils.getPlacement(order, placementNumber);
    const brokerName = (
        placement ? counteringUtils.getValidQuote(placement, order.side)?.counterparty?.shortName : ""
    ) as string;

    const originalOfferRow: CounteringHistory = {
        status: order.side === "BUY" ? "Initial Offer" : "Initial Bid",
        value: originalAxeInfo.price,
        size: originalAxeInfo.size,
        quality: originalAxeInfo.quality
    };

    const traderCounterRow: CounteringHistory = {
        status: "You Countered",
        value: traderCounterInfo.price,
        size: traderCounterInfo.size,
        quality: traderCounterInfo.quality
    };

    const brokerQuoteRow = {
        value: brokerQuoteInfo.price,
        size: brokerQuoteInfo.size,
        quality: brokerQuoteInfo.quality
    };

    switch (state) {
        case "BROKER_ACCEPTED":
        case "BROKER_ACCEPTED_DISABLE":
        case "REPEAT_ORIGINAL":
        case "COUNTER_NEW":
            return [
                originalOfferRow,
                traderCounterRow,
                {
                    status: mapStatetoTextStatus(state, brokerName),
                    ...brokerQuoteRow,
                    broker: brokerName
                }
            ];
        case "COUNTER_REJECTED":
        case "COUNTER_TIMEOUT":
        case "COUNTER_CANCELED":
        case "DUE_IN_EXPIRED":
            let rows = [
                originalOfferRow,
                traderCounterRow,
                {
                    status: mapStatetoTextStatus(state, brokerName),
                    quality: brokerQuoteInfo.quality
                }
            ];
            // If broker previously submitted valid quote
            if (brokerQuoteInfo.price && brokerQuoteInfo.size) {
                const brokeQuoteState = mapQuotedModifyReasonToState(
                    originalAxeInfo,
                    traderCounterInfo,
                    brokerQuoteInfo
                );
                const row = {
                    status: mapStatetoTextStatus(brokeQuoteState, brokerName),
                    ...brokerQuoteRow,
                    broker: brokerName
                };
                rows.splice(2, 0, row);
            }
            return rows;
        default:
            return undefined;
    }
}

function mapQuotedModifyReasonToState(
    origInfo: { price: number; size: number },
    traderInfo: { price: number; size: number },
    brokerInfo: { price: number; size: number }
): CounteringState {
    if (traderInfo.price === brokerInfo.price && traderInfo.size === brokerInfo.size) {
        return "BROKER_ACCEPTED";
    } else if (origInfo.price === brokerInfo.price && origInfo.size === brokerInfo.size) {
        return "REPEAT_ORIGINAL";
    } else {
        return "COUNTER_NEW";
    }
}

function isDueInExpired(modifiedBy: string): boolean {
    const {
        tokens: { entries: { "DB.USER.TRADING.RO": readOnlyUser, "DB.USER.TRADING.RW": readWriteUser } }
    } = store.getState();

    const serviceAccountLogins = [readOnlyUser?.toUpperCase(), readWriteUser?.toUpperCase(), CONFIG.TSGOPS];
    return serviceAccountLogins.includes(modifiedBy.toUpperCase()) && modifiedBy !== "";
}

function mapStatetoTextStatus(state: CounteringState, brokerName: string): string {
    const lib: PartialRecord<CounteringState, string> = {
        BROKER_ACCEPTED: `Broker ${brokerName} Responded`,
        REPEAT_ORIGINAL: `Broker ${brokerName} Repeated`,
        COUNTER_NEW: `Broker ${brokerName} Countered`,
        COUNTER_REJECTED: `Broker ${brokerName} Rejected`,
        COUNTER_TIMEOUT: `You Timed Out`,
        COUNTER_CANCELED: `Counter Canceled`,
        DUE_IN_EXPIRED: `Counter Canceled`
    };
    return lib[state] || "";
}

export function createPlacement(
    order: Order,
    tradeForm: TradeForm,
    axe: Axe,
    config: Config,
    countering?: Countering
): GraphQLPlacementCreationVariables {
    const isSpread = pricingTypeUtils.isSpread(order, axe, config, countering);
    const user = configUtils.getUser();
    const broker = tradeFormUtils.getSelectedBrokerEntity(order, tradeForm)!;
    const desk = tradeFormUtils.getSelectedDesk(broker, tradeForm)!;
    const axeLevel = isSpread ? axe.spread : axe.price;
    const axeQty = axe.size;

    const placementVariables: GraphQLPlacementCreationVariables = {
        request: {
            ordNum: order.id,
            brokers: [{ broker: broker.name, subBrokerId: desk.subBrokerID }],
            placementAllocationStrategy: {
                strategy: "EXACT_AMOUNT",
                value: tradeForm.size!
            },
            limitType: isSpread ? "S" : "P",
            dueInTime: genericUtils.getConvertedDueTime(parseInt(tradeForm.dueInSelected!)),
            limitValue: isSpread ? tradeForm.spread! : tradeForm.price!,
            externRefID: axe.id,
            axeLevel: genericUtils.isValidNumber(axeLevel) ? axeLevel : undefined,
            axeQty,
            settleDate: tradeForm.settleDate!,
            axeID: axe.aid
        },
        user: user
    };
    if (isSpread) {
        placementVariables.request.spreadIndex = axe.axeBmkId;
        placementVariables.request.spotType = tradeForm.spotTimeSelected!;
    }
    return placementVariables;
}

// Initial counter -> against the initial axe. Will create a placement
export async function counterAxe(
    order: Order,
    tradeForm: TradeForm,
    axe: Axe,
    config: Config,
    countering: Countering
): Promise<boolean> {
    try {
        let placementCreationVariables = createPlacement(order, tradeForm, axe, config, countering);
        if (
            pricingTypeUtils.isSpread(order, axe, config, countering) &&
            placementCreationVariables.request.spreadIndex &&
            tradeForm.spotTimeSelected === CODE.SPOT_NOW
        ) {
            const twebPrice = await benchmarkApi.getTWEBPrice(
                placementCreationVariables.request.spreadIndex,
                order.side
            );
            if (genericUtils.isValidNumber(twebPrice)) {
                placementCreationVariables.request.benchPrice = twebPrice!;
            }
        }
        console.log(`Requesting countering placement: ${JSON.stringify(placementCreationVariables)}`);
        const { requestPlacementQuote }: GraphQLPlacementCreationResponse = await apiUtils.apiQuery<
            GraphQLPlacementCreationVariables,
            GraphQLPlacementCreationResponse
        >(requestPlacementQuoteMutation, placementCreationVariables, {
            fixture: `placement-creation/${order.id}`,
            telemetry: ["requestCounteringPlacement", "request countering placement"]
        });

        // todo-refactor: rename to something clearer
        const placement = counteringUtils.getMostRecentPlacementNumber(requestPlacementQuote);

        // tell market-depth-plugin to associate this form with this newly created placement
        windowUtils.registerPlacementForUrl(placement.placementNum);
        logClick("User created placement", {
            "order no": order.id,
            "placement no": placement.placementNum,
            workflow: "COUNTERED"
        });
        console.log(`placed order#: ${order.id}, placement#: ${placement.placementNum}`);
        return true;
    } catch (e: any) {
        if (e.errors?.length > 0) {
            throw apiUtils.handleGQLErrorRes(e.errors, `Error creating placement on order: ${order.id}`);
        } else {
            logError("Error creating placement", { message: e });
            throw apiUtils.apiError("Error creating placement", e.message);
        }
    }
}

// Subsequent counters - against a specific placement
export async function counterPlacementQuote(
    order: Order,
    placementNum: number,
    tradeForm: TradeForm
): Promise<boolean> {
    try {
        const placement = orderUtils.getPlacement(order, placementNum)!;
        const quantity = tradeForm.size;
        const tradeValue = placement.limitType === "PRICE" ? tradeForm.price : tradeForm.spread;
        const vars = {
            tradeValue: tradeValue as number,
            quantity: quantity as number,
            dueInTime: genericUtils.getConvertedDueTime(parseInt(tradeForm.dueInSelected!))
        };
        const counterPlacementQuoteVars = apiUtils.createUpdatePlacementQuoteVars(placement, vars);
        const req = counterPlacementQuoteVars.request;
        console.log(`countering placement quote: ${JSON.stringify(counterPlacementQuoteVars)}`);
        const { counterPlacementQuote }: GraphQlCounterPlacementQuoteResponse = await apiUtils.apiQuery<
            GraphQlCounterPlacementQuoteVariables,
            GraphQlCounterPlacementQuoteResponse
        >(counterPlacementQuoteMutation, counterPlacementQuoteVars, {
            fixture: `placement_quote-counter/${order.id}`,
            telemetry: ["counterPlacementQuote", "counter placement quote"]
        });

        if (counterPlacementQuote?.length > 0) {
            const ordNum = _.get(counterPlacementQuote[0], "order.ordNum");
            logClick("User countered placement quote", {
                "order no": ordNum,
                // graphql response doesn't return the mutated placementNum/quoteID, using req var for now
                "placement no": req.placementNum,
                "quote no": req.externId,
                workflow: "COUNTERED"
            });
            console.log(
                `countered order#: ${ordNum}, placement#: ${req.placementNum},
                quote#: ${req.externId}`
            );
            return true;
        } else {
            return apiUtils.HandleInvalidGQLRes(order, req, "Unable to counter placement quote");
        }
    } catch (e: any) {
        logError("Error countering placement quote", { message: e });
        throw apiUtils.apiError("Error countering placement quote", e.message);
    }
}

export function createCancelErrorPlacementsVars(placementNumList: number[]): GraphQlCancelErrorPlacementsVariables {
    return {
        placementNumList: placementNumList,
        user: configUtils.getUser()
    };
}

export async function cancelPlacements(order: Order, placementNumList: number[]): Promise<boolean> {
    try {
        const cancelErrorPlacementsVars = createCancelErrorPlacementsVars(placementNumList);
        console.log(`Canceling Error Placements for Rejected: ${JSON.stringify(cancelErrorPlacementsVars)}`);
        const { cancelErrorPlacements }: GraphQlCancelErrorPlacementsResponse = await apiUtils.apiQuery<
            GraphQlCancelErrorPlacementsVariables,
            GraphQlCancelErrorPlacementsResponse
        >(cancelErrorPlacementsMutation, cancelErrorPlacementsVars, {
            fixture: `cancelErrorPlacements/${order.id}`,
            telemetry: ["cancelPlacements", "cancel error placements"]
        });
        if (cancelErrorPlacements?.length > 0) {
            const placementNum = cancelErrorPlacements[0].placementNum;
            logClick("Cancel error placement", {
                "order no": order.id,
                "placement no": placementNum,
                workflow: "COUNTERED"
            });
            console.log(`placed order#: ${order.id}, placement#: ${placementNum}`);
            return true;
        } else {
            logError("Error canceling placement", { "order id": order.id });
            throw new Error("Unable to cancel placements: " + cancelErrorPlacementsVars.placementNumList);
        }
    } catch (e: any) {
        logError("Error Canceling Placements", { message: e });
        throw apiUtils.apiError("Error Canceling Placements", e.message);
    }
}

export async function acceptPlacementQuote(order: Order, placementNum: number): Promise<boolean> {
    try {
        const placement = orderUtils.getPlacement(order, placementNum)!;
        const lastHistory = getLastHistoryFromPlacement(placement, true);
        const { size, value } = lastHistory!;
        const vars = {
            tradeValue: value as number,
            quantity: size as number
        };
        const executePlacementQuoteVars = apiUtils.createUpdatePlacementQuoteVars(placement, vars),
            req = executePlacementQuoteVars.request;
        console.log(`Accepting placement quote: ${JSON.stringify(executePlacementQuoteVars)}`);
        const { executePlacementQuote }: GraphQlExecutePlacementQuoteResponse = await apiUtils.apiQuery<
            GraphQlExecutePlacementQuoteVariables,
            GraphQlExecutePlacementQuoteResponse
        >(executePlacementQuoteMutation, executePlacementQuoteVars, {
            fixture: `placement_quote-accept/${order.id}`,
            telemetry: ["acceptPlacementQuote", "accept placement quote"]
        });

        if (executePlacementQuote?.length > 0) {
            const ordNum = _.get(executePlacementQuote[0], "order.ordNum");
            logClick("User accepted placement quote", {
                "order no": ordNum,
                // graphql response doesn't return the mutated placementNum/quoteID, using req var for now
                "placement no": req.placementNum,
                "quote no": req.externId,
                workflow: "COUNTERED"
            });
            console.log(
                `accepted order#: ${ordNum}, placement#: ${req.placementNum},
                quote#: ${req.externId}`
            );
            return true;
        } else {
            return apiUtils.HandleInvalidGQLRes(order, req, "Unable to accept placement quote");
        }
    } catch (e: any) {
        logError("Error accepting placement quote", { message: e });
        throw apiUtils.apiError("Error accepting placement quote", e.message);
    }
}

export async function passPlacementQuotes(placementNum: number): Promise<boolean> {
    try {
        const req = {
            placementNumList: [placementNum],
            user: configUtils.getUser()
        };
        console.log(`Passing placement quote: ${JSON.stringify(req)}`);
        const { passPlacementQuotes }: GraphQlPassPlacementQuotesResponse = await apiUtils.apiQuery<
            GraphQlPassPlacementQuotesVariables,
            GraphQlPassPlacementQuotesResponse
        >(passPlacementQuoteMutation, req, {
            fixture: `placement_quote-pass/${placementNum}`,
            telemetry: ["passPlacementQuotes", "pass placement quotes"]
        });

        if (passPlacementQuotes?.length > 0) {
            logClick("User passed placement quote", {
                "placement no": placementNum,
                workflow: "COUNTERED"
            });
            console.log(`passed placement# ${placementNum}`);
            return true;
        } else {
            logError("Error passing placement quote", {
                "placement no": placementNum
            });
            return false;
        }
    } catch (e: any) {
        logError("Error passing placement quote", { message: e });
        return false;
    }
}

export const CounteringApi = {
    acceptPlacementQuote,
    performCounteringAction,
    counterPlacementQuote,
    cancelPlacements,
    passPlacementQuotes
};
