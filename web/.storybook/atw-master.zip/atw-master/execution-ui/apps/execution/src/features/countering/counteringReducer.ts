import { createReducer } from "@reduxjs/toolkit";
import { fetchCountering, setCounteringState } from "./counteringActions";
import { DEFAULT_COUNTERING } from "./countering";

export const counteringInfo = createReducer({ countering: DEFAULT_COUNTERING }, (builder) =>
    builder
        .addCase(fetchCountering.fulfilled, (current, { payload: countering }) => {
            return { countering };
        })
        .addCase(setCounteringState.fulfilled, (current, { payload: config }) => {
            return {
                countering: {
                    ...current.countering,
                    prevState: current.countering.state,
                    state: config.nextState,
                    action: config.action
                }
            };
        })
);
