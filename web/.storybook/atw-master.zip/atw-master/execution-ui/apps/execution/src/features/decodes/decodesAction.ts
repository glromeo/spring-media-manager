import { getDecodes } from "@atw/toolkit";
import { createAsyncThunk } from "@reduxjs/toolkit";

export type DecodeRecords = Record<string, string>;
export type DecodesActionResult = Record<string, DecodeRecords | null>;

export const fetchDecode = createAsyncThunk<DecodesActionResult, string | string[]>(
    "FETCH_DECODE",
    async (requiredDecodes, thunkApi) => {
        const { decodes } = thunkApi.getState() as any;

        let decodesToRequest = requiredDecodes instanceof Array ? requiredDecodes : [requiredDecodes];
        decodesToRequest = decodesToRequest.filter((decode) => decodes[decode] === undefined);

        const result: DecodesActionResult = {};
        if (decodesToRequest.length > 0) {
            try {
                const response = await getDecodes(decodesToRequest);
                decodesToRequest.forEach((decodeName) => {
                    if (!response[decodeName]) {
                        result[decodeName] = null;
                        return;
                    }

                    const records: DecodeRecords = {};
                    response[decodeName]?.decodes.forEach(
                        (decodeEntry) => (records[decodeEntry.code] = decodeEntry.decode)
                    );
                    result[decodeName] = records;
                });
            } catch (err) {
                decodesToRequest.forEach((decodeName) => (result[decodeName] = null));
            }
        }

        return result;
    }
);
