import { createReducer } from "@reduxjs/toolkit";
import { fetchOrder } from "../order/orderActions";
import { DecodeRecords, fetchDecode } from "./decodesAction";

export const decodes = createReducer<Record<string, DecodeRecords | null>>({}, (builder) =>
    builder
        .addCase(fetchDecode.fulfilled, (current, { payload: updates }) => {
            return {
                ...current,
                ...updates
            };
        })
        .addCase(fetchOrder.fulfilled, (current, { payload: order }) => {
            if (!order.spotTimes) {
                return current;
            }

            const spotTimesDecode: DecodeRecords = {};
            order.spotTimes.forEach((spotTime) => {
                spotTimesDecode[spotTime.code] = spotTime.displayName;
            });

            return {
                ...current,
                SPOT_TIMES: spotTimesDecode
            };
        })
);
