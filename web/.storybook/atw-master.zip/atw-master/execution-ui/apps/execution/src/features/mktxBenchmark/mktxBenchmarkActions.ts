import { createAction } from "@reduxjs/toolkit";

export const setMarketAxessBenchmark = createAction("SECURITY_BENCHMARK_PUSH", (benchmark) => ({
    payload: { benchmark }
}));
