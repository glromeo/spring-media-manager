import { createReducer } from "@reduxjs/toolkit";
import { setMarketAxessBenchmark } from "./mktxBenchmarkActions";

export const mktxBenchmark = createReducer({ benchmarkId: null }, (builder) =>
    builder.addCase(setMarketAxessBenchmark, (current, { payload: { benchmark: benchmarkId } }) => {
        return {
            benchmarkId
        };
    })
);
