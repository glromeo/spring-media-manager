import {
    BondQuality,
    FieldType,
    HIGH_YIELD,
    INVESTMENT_GRADE,
    NUM_PLACE_HOLDER,
    PartialPick,
    Side,
    SpotTime,
    STRING_PLACE_HOLDER
} from "../../models/common";
import { Config } from "../config/config";

export type OrderDetail = {
    field: keyof Order;
    label: string;
    type: FieldType;
    visibleFor: BondQuality[];
    classNameFor: (side: Side, value?: number) => string;
};

export type Desk = {
    brokerType: string;
    salesman: string;
    subBrokerID: number;
};

export type BrokerRestrictionAllocation = {
    isRestricted: boolean;
    name: string;
    code: number;
    quantity: number;
    percent: number;
    expiryTime?: number | null;
    effectiveTime?: number;
};

export type BrokerRestriction = {
    quantity: number;
    percent: number;
    allocation: BrokerRestrictionAllocation[];
};

export type BrokerEntity = {
    name: string;
    code: number;
    desk: Desk[];
    isDelayedSpot: boolean;
    restriction?: BrokerRestriction;
    defaultDesk?: number;
    isCounteringEnabled: boolean;
    isSpreadFlowEnabled?: boolean;
};

export type Broker = {
    rollup: string;
    entity: BrokerEntity[];
    selectedRestrictedBroker?: number;
};

export type Quote = {
    requestID: string;
    spread: number;
    price: number;
    quoteID: string;
    expTime: number;
    quantity: number;
    counterparty: CounterParty;
    type: "PRICE" | "SPREAD";
    side?: "ASK" | "BID";
};


export type CounterParty = {
    ticker: string;
    shortName: string;
    code: number;
};

export type Placement = {
    placementNum: number;
    limitValue: number;
    dueInTime?: number;
    ordNum?: number;
    limitType: "PRICE" | "SPREAD";
    quantity: number;
    status: string;
    modifyReason: string;
    modifiedTime?: number;
    modifiedBy?: string;
    externRefID: string;
    quotes: Quote[];
    axe: Axe;
    broker: CounterParty;
    desk: Desk;
    settleDate: string;
    spreadIndex?: string;
};

export type Axe = {
    axeID: number;
    axeLevel: number;
    axeQty: number;
};

export type Placements = Placement[] | [] | undefined;

export type Order = {
    id: number;
    side: Side;
    bond: string;
    orderBmk: string;
    orderBmkId: string;
    cusip: string;
    isin: string;
    origSize: number;
    unbookedAmt: number;
    orderLeaves: number;
    limit?: number;
    limitType?: string;
    instructions: string;
    tradingBmk: string;
    settleDate: string;
    broker: Broker;
    currency: string;
    minTrdSize: number;
    hasValidData: boolean;
    price: number;
    quality: BondQuality;
    placements: Placement[];
    spotTimes?: SpotTime[];
};

export type OrderInfo = {
    order: Order;
    schema: OrderDetail[];
};

export type PartialOrder = PartialPick<Order, "id" | "side" | "cusip">;

export const DEFAULT_ORDER_DETAIL_SCHEMA: OrderDetail[] = [
    {
        field: "side",
        label: "Side",
        type: "side",
        visibleFor: [INVESTMENT_GRADE, HIGH_YIELD],
        classNameFor: (side: Side) => {
            return side === "BUY" ? "detail-side-row-buy" : "detail-side-row-sell";
        }
    },
    {
        field: "bond",
        label: "Bond",
        type: "text",
        visibleFor: [INVESTMENT_GRADE, HIGH_YIELD],
        classNameFor: () => {
            return "";
        }
    },
    {
        field: "orderBmk",
        label: "Security Bmk",
        type: "security",
        visibleFor: [INVESTMENT_GRADE],
        classNameFor: () => {
            return "";
        }
    },
    {
        field: "currency",
        label: "CCY",
        type: "text",
        visibleFor: [INVESTMENT_GRADE, HIGH_YIELD],
        classNameFor: () => {
            return "";
        }
    },
    {
        field: "cusip",
        label: "CUSIP",
        type: "text",
        visibleFor: [INVESTMENT_GRADE, HIGH_YIELD],
        classNameFor: () => {
            return "";
        }
    },
    {
        field: "isin",
        label: "ISIN",
        type: "text",
        visibleFor: [INVESTMENT_GRADE, HIGH_YIELD],
        classNameFor: () => {
            return "";
        }
    },
    {
        field: "origSize",
        label: "Original Size",
        type: "size",
        visibleFor: [INVESTMENT_GRADE, HIGH_YIELD],
        classNameFor: () => {
            return "";
        }
    },
    {
        field: "unbookedAmt",
        label: "Unbooked Amt",
        type: "size",
        visibleFor: [INVESTMENT_GRADE, HIGH_YIELD],
        classNameFor: () => {
            return "";
        }
    },
    {
        field: "orderLeaves",
        label: "Order Leaves",
        type: "size",
        visibleFor: [INVESTMENT_GRADE, HIGH_YIELD],
        classNameFor: () => {
            return "";
        }
    },
    {
        field: "limit",
        label: "Limit",
        type: "price",
        visibleFor: [INVESTMENT_GRADE, HIGH_YIELD],
        classNameFor: (side: Side, value?: number) => {
            if (value && value !== NUM_PLACE_HOLDER) {
                return side === "BUY" ? "detail-limit-row-buy" : "detail-limit-row-sell";
            } else {
                return "";
            }
        }
    },
    {
        field: "limitType",
        label: "Limit Type",
        type: "text",
        visibleFor: [INVESTMENT_GRADE, HIGH_YIELD],
        classNameFor: () => {
            return "";
        }
    },
    {
        field: "instructions",
        label: "Instructions",
        type: "text",
        visibleFor: [INVESTMENT_GRADE, HIGH_YIELD],
        classNameFor: () => {
            return "";
        }
    },
    {
        field: "tradingBmk",
        label: "Trading Bmk",
        type: "text",
        visibleFor: [INVESTMENT_GRADE, HIGH_YIELD],
        classNameFor: () => {
            return "";
        }
    }
];

export const DEFAULT_ORDER: Order = {
    id: NUM_PLACE_HOLDER,
    side: "NOTSET",
    bond: STRING_PLACE_HOLDER,
    orderBmk: STRING_PLACE_HOLDER,
    orderBmkId: STRING_PLACE_HOLDER,
    cusip: STRING_PLACE_HOLDER,
    isin: STRING_PLACE_HOLDER,
    origSize: NUM_PLACE_HOLDER,
    unbookedAmt: NUM_PLACE_HOLDER,
    orderLeaves: NUM_PLACE_HOLDER,
    limit: NUM_PLACE_HOLDER,
    limitType: STRING_PLACE_HOLDER,
    instructions: STRING_PLACE_HOLDER,
    tradingBmk: STRING_PLACE_HOLDER,
    settleDate: STRING_PLACE_HOLDER,
    broker: {
        rollup: STRING_PLACE_HOLDER,
        entity: [
            {
                name: STRING_PLACE_HOLDER,
                code: NUM_PLACE_HOLDER,
                isDelayedSpot: false,
                desk: [],
                isCounteringEnabled: false
            }
        ]
    },
    currency: STRING_PLACE_HOLDER,
    minTrdSize: NUM_PLACE_HOLDER,
    quality: STRING_PLACE_HOLDER,
    price: NUM_PLACE_HOLDER,
    hasValidData: false,
    placements: []
};

export function getPartialOrderFromSettings(config: Config): PartialOrder {
    return { id: Number(config.orderNumber), side: config.side, cusip: config.cusip };
}
