import { createAction, createAsyncThunk } from "@reduxjs/toolkit";
import { getOrderByOrderNumber } from "../../features/order/orderApi";
import { BondQuality } from "../../models/common";
import { Settings } from "../settings/settings";
import { Order, OrderInfo, PartialOrder } from "./order";
import { Benchmark } from "@atx/commons/benchmark/useBenchmark";

export const resetOrder = createAction("RESET_ORDER");
export const fetchOrder = createAsyncThunk<
    Order,
    {
        orderNumber: number;
        cusip: string;
        axeBroker: string;
        axeCode: number;
        axeQuality: BondQuality;
        benchmark: Benchmark;
    },
    { state: { settings: Settings; orderInfo: OrderInfo } }
>("FETCH_ORDER", async (params, thunkAPI) => {
    const {
        settings,
        orderInfo: { order }
    }: {
        orderInfo: { order: Order };
        settings: Settings;
    } = thunkAPI.getState();

    if (order.hasValidData) return order;
    const orderResponse = await getOrderByOrderNumber(
        params.orderNumber,
        params.cusip,
        params.axeBroker,
        params.axeCode,
        params.axeQuality,
        params.benchmark
    );

    return orderResponse;
});
export const invalidateOrderInfo = createAction("INVALIDATE_ORDER_INFO");
export const selectRestrictedBroker = createAction("SELECT_RESTRICTED_BROKER", (idx: number | undefined) => {
    return { payload: idx };
});
export const setOrderBenchmark = createAction("SET_ORDER_BENCHMARK", (security: any) => {
    return { payload: security };
});
export const setPartialOrder = createAction("SET_PARTIAL_ORDER", (partialOrder: PartialOrder) => {
    return { payload: partialOrder };
});
export const setOrderLeaves = createAction("SET_ORDER_LEAVES", (order: Partial<Order>) => {
    return { payload: order };
});
