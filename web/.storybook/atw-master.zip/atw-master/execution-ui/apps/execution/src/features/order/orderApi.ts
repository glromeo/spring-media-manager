import { logClick, logError } from "@atw/toolkit";
import { Benchmark, benchmarkApi } from "@atx/commons/benchmark/useBenchmark";
import {
    GraphQLBrokerAllocation,
    GraphQLBrokerEntity,
    GraphQLBrokerVariables,
    GraphQLOrderCreationResponse,
    GraphQLOrderCreationVariables,
    GraphQLOrderDetails,
    GraphQLOrderSummary,
    GraphQLOrderSummaryResponse,
    GraphQLOrderSummaryVariables,
    GraphQLPlacement,
    GraphQLPlacements,
    GraphQLPorfolioAllocation,
    GraphQLSpotTimes,
    brokerQuery,
    orderA2AQuery,
    orderLTXQuery,
    orderCaresQuery,
    orderLeavesQuery,
    orderMutation,
    orderQuery
} from "../../api/types";
import { store } from "../../app/store";
import { CODE, TEXT } from "../../common/constants";
import {
    apiUtils,
    axeUtils,
    configUtils,
    genericUtils,
    orderUtils,
    pricingTypeUtils,
    windowUtils
} from "../../common/utils";
import { BondQuality, INVESTMENT_GRADE, NUM_PLACE_HOLDER, STRING_PLACE_HOLDER } from "../../models/common";
import { Axe } from "../axe/axe";
import { Config } from "../config/config";
import { Countering } from "../countering/countering";
import { TradeForm } from "../tradeForm/tradeForm";
import { Broker, BrokerRestriction, BrokerRestrictionAllocation, Order, Placement } from "./order";

const getBrokerInfo = (brokerEntity: GraphQLBrokerEntity[], axeBroker: string, axeCode: number): Broker => {
    const found = brokerEntity.find((entity) => {
        return entity.value.includes(axeCode.toString());
    });
    if (!found) {
        // hmmm, just create a dummy broker rollup...might not have consituents
        return {
            rollup: axeBroker,
            entity: [
                {
                    name: axeBroker,
                    code: axeCode,
                    isDelayedSpot: false,
                    isCounteringEnabled: false,
                    desk: []
                }
            ]
        };
    } else {
        return {
            rollup: found.key,
            entity: found.value.map((value) => {
                return {
                    name: STRING_PLACE_HOLDER,
                    code: parseInt(value),
                    isDelayedSpot: false,
                    desk: [],
                    isCounteringEnabled: false
                };
            })
        };
    }
};

const reconcileBrokerAllocations = (
    brokerInfo: Broker,
    fiOrderSummary: GraphQLOrderSummary,
    quality: BondQuality
): Broker => {
    const getPorfolioName = (code: number) => {
        const porfolioInfo = fiOrderSummary.orderDetails!.find((details) => {
            return details.portfolio.portfolioCode === code;
        });
        if (porfolioInfo === undefined) {
            console.log("method: getPorfolioName, unable to return porfolioInfo against broker code: " + code);
            return "";
        }
        return porfolioInfo.portfolio.portfolioName;
    };
    const getBrokerAllocations = (code: number) => {
        return fiOrderSummary.brokerAllocations!.find((allocation) => {
            return allocation.broker.code === code;
        });
    };
    const getPortfolioAllocations = (brokerAllocation: GraphQLBrokerAllocation): BrokerRestrictionAllocation[] => {
        const getPercent = (portfolioAllocation: GraphQLPorfolioAllocation) => {
            if (brokerAllocation.availablePlacementQuantity === 0) return 0;
            return (
                (Math.abs(portfolioAllocation.quantityAvailable) / brokerAllocation.availablePlacementQuantity) * 100
            );
        };
        const allocations = brokerAllocation.portfolioAllocations.map(
            (portfolioAllocation: GraphQLPorfolioAllocation) => {
                return {
                    name: getPorfolioName(portfolioAllocation.portfolioCode),
                    code: portfolioAllocation.portfolioCode,
                    quantity: Math.abs(portfolioAllocation.quantityAvailable),
                    percent: getPercent(portfolioAllocation),
                    isRestricted: false
                } as BrokerRestrictionAllocation;
            }
        );
        // this is a little tricky - we don't get what is restricted in allocations, we have to look at the order details ... and that will tell us
        // we then see - what is in order details that is not in allocations ... what's is the retrictions
        const restrictedAllocations: BrokerRestrictionAllocation[] = [];
        if (brokerAllocation.availablePlacementQuantity !== brokerAllocation.eligiblePlacementQuantity) {
            fiOrderSummary.orderDetails!.forEach((detail: GraphQLOrderDetails) => {
                const code = detail.portfolio.portfolioCode;
                if (!orderUtils.isAllocated(allocations, code)) {
                    restrictedAllocations.push({
                        name: detail.portfolio.portfolioName,
                        code: detail.portfolio.portfolioCode,
                        quantity: Math.abs(detail.quantity),
                        percent: Math.abs((detail.quantity / brokerAllocation.availablePlacementQuantity) * 100),
                        isRestricted: true
                    });
                }
            });
        }
        // this allows us to put the 'fully' restricted portfolios at start...
        allocations.unshift(...restrictedAllocations);
        return allocations;
    };
    const getBrokerRestrictions = (brokerAllocation: GraphQLBrokerAllocation): BrokerRestriction => {
        return {
            quantity: brokerAllocation.eligiblePlacementQuantity,
            percent: brokerAllocation.eligiblePlacementQuantityAsPct,
            allocation: getPortfolioAllocations(brokerAllocation)
        };
    };
    const isDelayedBroker = (code: number) =>
        fiOrderSummary.delayedSpotEnabled ? fiOrderSummary.delayedSpotEnabled.includes(code) : false;

    const isSpreadFlowEnabled = (code: number) =>
        fiOrderSummary.spreadFlowEnabled ? fiOrderSummary.spreadFlowEnabled.includes(code) : false;

    const isMifidEnabled = (code: number) =>
        fiOrderSummary.mifidTagEnabled ? fiOrderSummary.mifidTagEnabled.includes(code) : false;

    const getBrokerEntitiesFromOrder = () => {
        return fiOrderSummary.brokerAllocations!.map((allocation) => {
            return {
                name: STRING_PLACE_HOLDER,
                code: allocation.broker.code,
                isDelayedSpot: false,
                desk: [],
                isCounteringEnabled: false
            };
        });
    };
    const getDefaultDesk = (brokerAllocation: GraphQLBrokerAllocation) => {
        if (brokerAllocation.broker.defaultDesk === undefined) return undefined;
        const found = brokerAllocation.broker.desks.findIndex(
            (desk) => desk.subBrokerID.toString() === brokerAllocation.broker.defaultDesk
        );
        return found === -1 ? undefined : found;
    };
    if (configUtils.isCares()) {
        // for cares we actually don't get brokers from incoming axe - we get it directly via the fiOrderSummary graphql response
        // as such - we need to 'cheat' and modify the brokerInfo by iterating the actually order summary (care) brokers and returning the broker code
        // everything else should just then 'work'
        brokerInfo.entity = getBrokerEntitiesFromOrder();
    }
    const {
        tokens: { entries: { AladdinTraderMIFIDEligible: isClientMifidEligible = "true" } }
    } = store.getState();
    const isWorkflowMifidEligible = isClientMifidEligible === "true" && fiOrderSummary.userMifidEligibility === "true";
    // if mifid is enabled in this workflow, and the asset is mifid eligible, see if brokers are mifid enabled
    if (isWorkflowMifidEligible && fiOrderSummary.fiAsset?.isMiFID2Eligible) {
        brokerInfo.entity = brokerInfo.entity.filter((entity) => {
            if (!isMifidEnabled(entity.code)) {
                console.log(`Broker ${entity.name} is not MIFID enabled - will be excluded from eligible list`);
                return false;
            }
            return true;
        });
    }

    let hasAtleastOneAllocation = false;
    let hasAtLeastOneRestrictedEntity = false;
    const inEligibleEntityList: number[] = [];
    brokerInfo.entity.forEach((entity) => {
        const brokerAllocations = getBrokerAllocations(entity.code);
        entity.isDelayedSpot = isDelayedBroker(entity.code);
        entity.isCounteringEnabled = axeUtils.isCounteringModeIndicative()
            ? // note: this only checks when clicking on initial indicative axe. On live countering, this check won't work, which is fine since countering enabled check is only for initial request. We need MKD or placementGenericField to send axeType if we need this
              fiOrderSummary?.counteringEnabled?.includes(entity.code) ?? false
            : fiOrderSummary?.actionableCounteringEnabled?.includes(entity.code) ?? false;
        entity.isSpreadFlowEnabled = isSpreadFlowEnabled(entity.code);
        if (brokerAllocations !== undefined) {
            if (brokerAllocations.broker.desks.length === 0) {
                // in this case we have to exclude this broker entity
                console.log(
                    `Broker ${brokerAllocations.broker.shortName} has no associated desks - will be excluded from eligible list`
                );
                inEligibleEntityList.push(entity.code);
            } else {
                entity.desk = brokerAllocations.broker.desks;
                entity.defaultDesk = getDefaultDesk(brokerAllocations);
                entity.restriction = getBrokerRestrictions(brokerAllocations);
                if (orderUtils.isRestrictedBrokerEntity(entity)) hasAtLeastOneRestrictedEntity = true;
            }
            entity.name = brokerAllocations.broker.shortName;
            hasAtleastOneAllocation = true;
        } else {
            console.log(`Broker ${entity.name} has no associated allocations - will be excluded from eligible list`);
            // this entity has bad data (no allocations) - just remove it
            inEligibleEntityList.push(entity.code);
        }
    });

    if (quality === INVESTMENT_GRADE) {
        // for countering/execution, we pre-emptively filter out spread/price enabled brokers
        brokerInfo.entity = brokerInfo.entity.filter((entity) => {
            if (!entity.isSpreadFlowEnabled) {
                console.log(`Broker ${entity.name} is not spread flow enabled - will be excluded from eligible list`);
                return false;
            }
            return true;
        });
    }

    // if we haven't gotten any allocations - this is bad (i.e. could happen) - whereby for regional brokers ... let's say JPM/JPMSL - whereby only JPM has allocations
    // and JPMSL does not - this is ok - we do not display other broker then ...however if NONE have allocations (likely an error) - then we STOP
    if (!hasAtleastOneAllocation || brokerInfo.entity.length === 0) {
        throw apiUtils.apiError("Error Fetching Broker Info", TEXT.NO_BROKERS_CERTIFIED);
    }

    // now check if we need to remove any brokers from list - (inEligible) - because no desks have been defined
    if (inEligibleEntityList.length > 0) {
        brokerInfo.entity = brokerInfo.entity.filter((entity) => {
            return !inEligibleEntityList.includes(entity.code);
        });
        console.log(
            `The following (${
                inEligibleEntityList.length
            }) brokers were excluded for not having valid desks configured: (${inEligibleEntityList.join(",")})`
        );
    }

    if (hasAtLeastOneRestrictedEntity) {
        // Sort by percent available, fully available first
        brokerInfo.entity.sort((a, b) => (a.restriction!.percent < b.restriction!.percent ? 1 : -1));
    }

    // do one last check - have we filtered everything out?
    if (brokerInfo.entity.length === 0) {
        throw apiUtils.apiError("Error Fetching Broker Info", TEXT.NO_BROKERS_CERTIFIED);
    } else {
        // set selected (if only 1 - else user has to select)
        if (brokerInfo.entity.length === 1) {
            brokerInfo.selectedRestrictedBroker = 0;
        }
    }

    return brokerInfo;
};

export const reconcilePlacements = (placements: GraphQLPlacements): Placement[] => {
    if (!placements || !placements.length) return [];

    return placements.map((placement: GraphQLPlacement): Placement => {
        const { placementGenFields, ...filteredPlacements } = placement,
            settleDate = genericUtils.formatDate(placement.settleDate, { fullYear: true }) as string,
            limitType = placement.limitType?.toUpperCase() as "PRICE" | "SPREAD",
            axeInfo = {
                axeID: parseInt(placement.axeID),
                axeLevel: parseFloat(placementGenFields?.find((field) => field.key === "axeLevel")?.value || ""),
                axeQty: parseFloat(placementGenFields?.find((field) => field.key === "axeQty")?.value || "")
            };

        let reconciledPlacement: Placement = {
            ...filteredPlacements,
            axe: axeInfo,
            settleDate,
            limitType
        };

        return reconciledPlacement;
    });
};

export const getSpotTimesFromOrder = (orderSummary: GraphQLOrderSummary) => {
    if (!orderSummary.spotTimes || orderSummary.spotTimes?.length === 0) {
        // spot times are empty, we default it to spot now and create the following array.
        orderSummary.spotTimes = [
            {
                "venue": "TWEB",
                "spotTime": [
                    {
                        "code": "A",
                        "displayName": "Spot Now"
                    }
                ]
            },
            {
                "venue": "DIRECT",
                "spotTime": [
                    {
                        "code": "A",
                        "displayName": "Spot Now"
                    }
                ]
            }
        ];
        return getSpotTimesForOrder(orderSummary.spotTimes);
    } else {
        return getSpotTimesForOrder(orderSummary.spotTimes);
    }
};

function getSpotTimesForOrder(spotTimes: GraphQLSpotTimes[]) {
    if (configUtils.isAxeA2AMode()) {
        return spotTimes.find((response) => response.venue === "TWEB")?.spotTime;
    }
    return spotTimes.find((response) => response.venue === "DIRECT")?.spotTime;
}

async function getBrokersByOrderNumber(orderNumber: number): Promise<GraphQLBrokerEntity[]> {
    const brokerVariables: GraphQLBrokerVariables = { ordNum: orderNumber };
    try {
        const {
            fiOrderSummary: { brokerEntity }
        } = await apiUtils.apiQuery<GraphQLBrokerVariables, GraphQLOrderSummaryResponse>(brokerQuery, brokerVariables, {
            fixture: `brokers/${orderNumber}`,
            telemetry: ["getBrokersByOrderNumber", "get brokers by order number"]
        });
        if (brokerEntity) {
            return brokerEntity;
        }
        throw new Error();
    } catch (e: any) {
        if (e.errors?.length > 0) {
            throw apiUtils.handleGQLErrorRes(e.errors, `Unable to fetch broker entities for order: ${orderNumber}`);
        }
        throw apiUtils.apiError(
            "Error fetching Broker Info",
            `Unable to fetch broker entities for order: ${orderNumber}`
        );
    }
}

type OrderSummaryQueryVariant = {
    query: string;
    variables: GraphQLOrderSummaryVariables;
};

function getOrderSummaryQueryVariant(ordNum: number, brokerInfo: Broker): OrderSummaryQueryVariant {
    const user = configUtils.getUser();
    const orderSummaryVariables: GraphQLOrderSummaryVariables = { ordNum, user };

    let orderSummaryQuery = orderQuery;
    if (configUtils.isCares()) {
        orderSummaryVariables.care = true;
        orderSummaryQuery = orderCaresQuery;
    } else {
        if (configUtils.isAxeA2AMode()) {
            orderSummaryVariables.a2a = true;
            orderSummaryQuery = orderA2AQuery;
        }
        else if (configUtils.isLtxMode()){
            orderSummaryVariables.ltx = true;
            orderSummaryQuery = orderLTXQuery;
        }
        const brokerList = brokerInfo.entity.map((broker) => broker.code);
        orderSummaryVariables.brokerList = brokerList;
    }

    return {
        query: orderSummaryQuery,
        variables: orderSummaryVariables
    };
}

function getOrderLeavesQuery(ordNum: number): OrderSummaryQueryVariant {
    const user = configUtils.getUser();
    const orderSummaryVariables: GraphQLOrderSummaryVariables = { ordNum, user };

    return {
        query: orderLeavesQuery,
        variables: orderSummaryVariables
    };
}

export async function getOrderByOrderNumber(
    orderNumber: number,
    cusip: string,
    axeBroker: string,
    axeCode: number,
    axeQuality: BondQuality,
    benchmark: Benchmark
): Promise<Order> {
    try {
        const brokerEntity = await getBrokersByOrderNumber(orderNumber);
        const brokerInfo = getBrokerInfo(brokerEntity, axeBroker, axeCode);
        const { query, variables } = getOrderSummaryQueryVariant(orderNumber, brokerInfo);
        const { fiOrderSummary }: GraphQLOrderSummaryResponse = await apiUtils.apiQuery<
            GraphQLOrderSummaryVariables,
            GraphQLOrderSummaryResponse
        >(query, variables, {
            fixture: `orders/${orderNumber}`,
            telemetry: ["getOrderByOrderNumber", "get order by order number"]
        });
        if (!fiOrderSummary) throw new Error();
        const totalBooked = fiOrderSummary.orderDetails!.reduce(
            (total: number, { quantityBooked }: any) => total + Math.abs(quantityBooked),
            0
        );
        let quality = fiOrderSummary.fiAsset!.bondQuality as BondQuality;
        if (axeQuality !== STRING_PLACE_HOLDER) {
            quality = axeQuality;
        }
        const order: Order = {
            id: orderNumber,
            side: fiOrderSummary.order!.effectiveTranType,
            bond: `${fiOrderSummary.fiAsset!.bAsset.ticker} ${
                fiOrderSummary.fiAsset!.couponValue === null ? "" : fiOrderSummary.fiAsset!.couponValue + "%"
            } ${
                fiOrderSummary.fiAsset!.bAsset.maturity === null
                    ? ""
                    : genericUtils.formatDate(fiOrderSummary.fiAsset!.bAsset.maturity, { fullYear: false })
            }`,
            orderBmk: STRING_PLACE_HOLDER,
            orderBmkId: STRING_PLACE_HOLDER,
            cusip: fiOrderSummary.fiAsset!.bAsset.cusip,
            isin: fiOrderSummary.fiAsset!.isin,
            origSize: Math.abs(fiOrderSummary.order!.face),
            unbookedAmt: Math.abs(fiOrderSummary.order!.face) - totalBooked,
            orderLeaves: Math.abs(fiOrderSummary.order!.orderLeaves),
            limit: fiOrderSummary.order!.limitValue === null ? undefined : fiOrderSummary.order!.limitValue,
            limitType: fiOrderSummary.order!.limitType === null ? STRING_PLACE_HOLDER : fiOrderSummary.order!.limitType,
            instructions:
                fiOrderSummary.order!.updateInstr === null ? STRING_PLACE_HOLDER : fiOrderSummary.order!.updateInstr,
            settleDate: `${
                fiOrderSummary.fiAsset!.defaultSettleDate === null
                    ? STRING_PLACE_HOLDER
                    : genericUtils.formatDate(fiOrderSummary.fiAsset!.defaultSettleDate, { fullYear: true })
            }`,
            tradingBmk:
                fiOrderSummary.order!.tradingBenchmark === null
                    ? STRING_PLACE_HOLDER
                    : fiOrderSummary.order!.tradingBenchmark,
            broker: reconcileBrokerAllocations(brokerInfo, fiOrderSummary, quality),
            currency: fiOrderSummary.order!.priceCurrency,
            minTrdSize: fiOrderSummary.fiAsset!.bAsset.minTrdSize,
            quality,
            price: NUM_PLACE_HOLDER,
            placements: reconcilePlacements(fiOrderSummary.placements),
            hasValidData: true,
            spotTimes: getSpotTimesFromOrder(fiOrderSummary)
        };
        order.orderBmk = benchmark.benchmarkDescription || STRING_PLACE_HOLDER;
        order.orderBmkId = benchmark.benchmarkId || STRING_PLACE_HOLDER;
        order.price = benchmark.benchmarkPrice || NUM_PLACE_HOLDER;
        validateOrderAttributes(order);
        return order;
    } catch (e: any) {
        if (typeof e === "string") {
            throw e;
        } else {
            if (e.errors?.length > 0) {
                throw apiUtils.handleGQLErrorRes(e.errors, `Unable to fetch order: ${orderNumber}`);
            } else {
                logError(e.title || "Error fetching Order", { message: e });
                if (e.name && e.message && e.message !== "Query Failure") {
                    throw e;
                } else {
                    throw apiUtils.apiError("Error fetching Order", `Unable to fetch order: ${orderNumber}`);
                }
            }
        }
    }
}

export async function placeOrder(
    order: Order,
    tradeForm: TradeForm,
    axe: Axe,
    config: Config,
    countering: Countering
): Promise<boolean> {
    try {
        //if axe benchmark exists ... pass to placement ...else use security benchmark ... (order)
        let orderCreationVariables = apiUtils.createOrder(order, tradeForm, axe, config, countering);
        if (
            pricingTypeUtils.isSpread(order, axe, config, countering) &&
            orderCreationVariables.request.spreadIndex &&
            tradeForm.spotTimeSelected === CODE.SPOT_NOW
        ) {
            const twebPrice = await benchmarkApi.getTWEBPrice(orderCreationVariables.request.spreadIndex, order.side);
            if (genericUtils.isValidNumber(twebPrice)) {
                orderCreationVariables.request.benchPrice = twebPrice!;
            }
        }

        console.log(`Placing order: ${JSON.stringify(orderCreationVariables)}`);
        const { multiQuickPlace }: GraphQLOrderCreationResponse = await apiUtils.apiQuery<
            GraphQLOrderCreationVariables,
            GraphQLOrderCreationResponse
        >(orderMutation, orderCreationVariables, {
            fixture: `order-creation/${order.id}`,
            telemetry: ["placeOrder", "place order"]
        });
        if (multiQuickPlace?.length > 0) {
            const placementNum = multiQuickPlace[0].placementNum;
            windowUtils.registerPlacementForUrl(placementNum);
            logClick("User placed order", {
                "order no": order.id,
                "placement no": placementNum,
                workflow: configUtils.isCares() ? "CARE" : ""
            });
            console.log(`placed order#: ${order.id}, placement#: ${placementNum}`);
            return true;
        } else {
            logError("Error placing out Order", { "order id": order.id });
            throw new Error("Unable to place out order on order: " + order.id);
        }
    } catch (e: any) {
        if (e.errors?.length > 0) {
            throw apiUtils.handleGQLErrorRes(e.errors, `Unable to place out order on order: ${order.id}`);
        } else {
            logError(e.title || "Error placing out Order", { message: e });
            if (e.name && e.message && e.message !== "Query Failure") {
                throw e;
            } else {
                throw apiUtils.apiError("Error placing out Order", `Unable to place out order on order: ${order.id}`);
            }
        }
    }
}
export async function getOrderLeavesAndRequestSize(requestSize: number, order: Order) {
    let oldOrderLeaves = order.orderLeaves;
    // query for any updates to order leaves
    let newOrderLeaves = await getOrderLeaves(order.id);
    newOrderLeaves = Math.abs(newOrderLeaves!);
    requestSize = Math.abs(requestSize);
    return [oldOrderLeaves, newOrderLeaves, requestSize];
}
export async function getOrderLeaves(orderNumber: number) {
    try {
        const { query, variables } = getOrderLeavesQuery(orderNumber);
        const { fiOrderSummary }: GraphQLOrderSummaryResponse = await apiUtils.apiQuery<
            GraphQLOrderSummaryVariables,
            GraphQLOrderSummaryResponse
        >(query, variables, {
            fixture: `orderLeaves/${orderNumber}`,
            telemetry: [getOrderLeaves.name, "get order leaves"]
        });
        return fiOrderSummary.order!.orderLeaves;
    } catch (e: any) {
        logError(e.message);
        throw apiUtils.apiErrors([
            {
                name: `Error fetching Order to retrieve order leaves for order number: ${orderNumber}`,
                message: "An error occurred when querying for updated order leaves from latest order data.",
                type: "ERROR"
            }
        ]);
    }
}
function validateOrderAttributes(order: Order) {
    // validate that certain fields exist - expand this list as needed
    order.placements?.forEach((placement) => {
        placement.quotes?.forEach((quote) => {
            if (quote.counterparty) {
                if (
                    quote.counterparty.code === 0 ||
                    quote.counterparty.shortName === null ||
                    quote.counterparty.ticker === null
                ) {
                    console.error(`no broker defined for counterparty against quote: ${JSON.stringify(quote)}`);
                }
            } else {
                console.error(`no counterparty defined for quote: ${JSON.stringify(quote)}`);
            }
        });
    });
}
