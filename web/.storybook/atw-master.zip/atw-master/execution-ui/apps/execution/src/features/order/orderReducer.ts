import { createReducer } from "@reduxjs/toolkit";
import { DEFAULT_ORDER, DEFAULT_ORDER_DETAIL_SCHEMA, Order } from "./order";
import {
    fetchOrder,
    invalidateOrderInfo,
    resetOrder,
    selectRestrictedBroker,
    setOrderBenchmark,
    setOrderLeaves,
    setPartialOrder
} from "./orderActions";

export const orderInfo = createReducer({ order: DEFAULT_ORDER, schema: DEFAULT_ORDER_DETAIL_SCHEMA }, (builder) =>
    builder
        .addCase(fetchOrder.fulfilled, (current, { payload: order }) => {
            return { order, schema: current.schema };
        })
        .addCase(setPartialOrder, (current, { payload: partialOrder }) => {
            const order: Order = {
                ...current.order,
                id: partialOrder.id!,
                side: partialOrder.side!
            };
            return { order, schema: current.schema };
        })
        .addCase(setOrderLeaves, (current, { payload: order }) => {
            return { order: { ...current.order, orderLeaves: order.orderLeaves! }, schema: current.schema };
        })
        .addCase(setOrderBenchmark, (current, { payload: security }: { payload: any }) => ({
            ...current,
            order: {
                ...current.order,
                orderBmk: security.desc1,
                orderBmkId: security.cusip ? security.cusip : security.isin
            }
        }))
        .addCase(selectRestrictedBroker, (current, { payload: idx }) => {
            const broker = { ...current.order.broker };
            broker.selectedRestrictedBroker = idx;
            const order: Order = {
                ...current.order,
                broker
            };
            return { order, schema: current.schema };
        })
        .addCase(invalidateOrderInfo, (current) => {
            return { order: { ...current.order, hasValidData: false }, schema: current.schema };
        })
        .addCase(resetOrder, () => {
            return { order: { ...DEFAULT_ORDER }, schema: DEFAULT_ORDER_DETAIL_SCHEMA };
        })
);
