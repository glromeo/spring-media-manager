// #################### UPDATE TRACKING ####################
// Last updated: 8/1/2023
// https://tst.blackrock.com/apps/decodes/edit/PLCMNT_STATUS
// #########################################################

export const PLACEMENT_STATUS: Record<PlacementStatusCodes, string> = {
    P: "OPEN",
    ERR: "ERROR",
    PA: "PENDING_ACTIVE",
    A: "ACTIVE",
    S: "SENT",
    Q: "QUOTED",
    PF: "PARTIALLY_FILLED",
    PCL: "PENDING_CANCEL",
    PCG: "PENDING_CHANGE",
    PQL: "PENDING_QUOTE_LIFT",
    PQCG: "PENDING_QUOTE_CHANGE",
    F: "FILLED",
    AFB: "ACCEPTED_FOR_BIDDING",
    C: "CANCELLED",
    X: "EXPIRED",
    COM: "COMPLETED"
};

type PlacementStatusCodes =
    | "P"
    | "ERR"
    | "PA"
    | "A"
    | "S"
    | "Q"
    | "PF"
    | "PCL"
    | "PCG"
    | "PQL"
    | "PQCG"
    | "F"
    | "AFB"
    | "C"
    | "X"
    | "COM";
