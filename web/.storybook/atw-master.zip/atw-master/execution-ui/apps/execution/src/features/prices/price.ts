export type Price = {
    source: string;
    prices: {
        bid: {
            price: string;
            spread: string;
        };
        ask: {
            price: string;
            spread: string;
        };
    };
};

export type PriceData = Record<
    string,
    {
        bid: number | null;
        ask: number | null;
        bidSpread: number | null;
        askSpread: number | null;
    }
>;
