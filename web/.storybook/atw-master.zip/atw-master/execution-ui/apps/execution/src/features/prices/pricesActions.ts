import { createAction } from "@reduxjs/toolkit";
import { windowUtils } from "../../common/utils";
import { PriceData } from "./price";

(() => {
    if (windowUtils.host.bfmCefQuery) {
        windowUtils.host.bfmCefQuery({
            request: "subscribePrice",
            onSuccess: () => {},
            onFailure: () => {}
        });
    }
})();

export const setLivePrices = createAction("LIVE_PRICES", (payload: PriceData) => {
    return { payload };
});
