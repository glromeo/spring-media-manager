import { formatPrice, formatSpread } from "@atw/toolkit";
import { createReducer } from "@reduxjs/toolkit";

import { Price } from "./price";
import { setLivePrices } from "./pricesActions";

const formatPriceValue = (value: number | string | null, type: "spread" | "price") => {
    const num = Number(value);
    if (isNaN(num) || num === 0) {
        return "-";
    }

    return type === "spread" ? formatSpread(num) : formatPrice(num);
};

export const prices = createReducer<Price[]>([], (builder) =>
    builder.addCase(setLivePrices, (current, { payload }) => {
        const prices = current.filter((price) => !payload[price.source]);

        const combined = [
            ...prices,
            ...Object.keys(payload).map((source) => ({
                source,
                prices: {
                    bid: {
                        price: formatPriceValue(payload[source].bid, "price"),
                        spread: formatPriceValue(payload[source].bidSpread, "spread")
                    },
                    ask: {
                        price: formatPriceValue(payload[source].ask, "price"),
                        spread: formatPriceValue(payload[source].askSpread, "spread")
                    }
                }
            }))
        ];

        // Sort by TRITON first and then alphabetically
        return combined.sort((first, second) => {
            const firstSource = first.source.toLowerCase();
            const secondSource = second.source.toLowerCase();

            if (firstSource === "triton") {
                return -1;
            } else if (secondSource === "triton") {
                return 1;
            }

            return firstSource > secondSource ? 1 : -1;
        });
    })
);
