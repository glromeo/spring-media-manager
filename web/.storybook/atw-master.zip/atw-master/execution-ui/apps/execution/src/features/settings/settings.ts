import { initialSettings } from "@atw/toolkit";

export type Settings = {
    version: string;
    desks: string; // store as JSON ... seems a bug in atw mergesettings
};

export const DEFAULT_SETTINGS: Settings = {
    version: "0.0.0",
    desks: ""
};

export const INITIAL_SETTINGS = initialSettings(DEFAULT_SETTINGS);
