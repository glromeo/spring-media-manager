import { createAction } from "@reduxjs/toolkit";

export const clearSettings = createAction("CLEAR_SETTINGS");
export const clearLocalStorage = createAction("CLEAR_LOCALSTORAGE");
