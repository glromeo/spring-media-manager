import { extendSettingsReducer } from "@atw/toolkit";
import { removePrefs } from "@atw/toolkit/utility/prefsApi";
import { INITIAL_SETTINGS } from "./settings";
import { clearLocalStorage, clearSettings } from "./settingsActions";

export const settings = extendSettingsReducer(INITIAL_SETTINGS, (builder) =>
    builder
        .addCase(clearSettings, (_current) => {
            removePrefs(["settings"]); // note this is really here for testing ... i.e. don't worry that this is hardcoded ...i don't think we'll ever need it
            localStorage.clear();
            return { ...INITIAL_SETTINGS, desks: "" };
        })
        .addCase(clearLocalStorage, (current) => {
            localStorage.clear();
            return current;
        })
);
