// Mode - means the overall TYPE of application (type seemed too generic?)
// Working - means a specific usercase (within) that mode
export type ModeType = "NORMAL" | "COUNTERING" | "COUNTERING_ONLY" | "NOTSET" | "AXE_A2A";
export type WorkflowType = "RESTRICTIONS" | "EXECUTION" | "CARE" | "COUNTERED" | "NOTSET";
export type StepperStatusType = "STEPS" | "VALIDATING" | "ACK_VALIDATION" | "SEND" | "SENDING" | "SENT";
export type StepperSubStatusType =
    | "DEFAULT_ACTION"
    | "HITLIFT"
    | "MINI_FORM"
    | "MINI_REVIEW"
    | "CANCELING"
    | "CANCELED";
export type Workflow = StepperState[];

export type WorkflowMode = {
    workflow: WorkflowType;
    mode: ModeType;
};

export type Stepper = {
    stepIdx: number;
    status: StepperStatusType;
    subStatus: StepperSubStatusType;
    fatal: boolean;
};

export enum StepperState {
    Split = "Split",
    Order = "Order",
    Review = "Review",
    Popup = "Popup"
}

export const WORKFLOWS: Record<WorkflowType, Workflow> = {
    CARE: [StepperState.Order, StepperState.Review],
    COUNTERED: [StepperState.Popup],
    EXECUTION: [StepperState.Order, StepperState.Review],
    RESTRICTIONS: [StepperState.Split, StepperState.Order, StepperState.Review],
    NOTSET: []
};

export const DEFAULT_STEPPER: Stepper = {
    stepIdx: 0,
    status: "STEPS",
    subStatus: "DEFAULT_ACTION",
    fatal: false
};
