import { logError } from "@atw/toolkit/telemetry";
import { createAction, createAsyncThunk } from "@reduxjs/toolkit";
import { apiUtils, configUtils, genericUtils } from "../../common/utils";
import {
    performCounteringValidation,
    performOrderValidation,
    validateBeforeUpdatingPlacementQuote
} from "../alerts/validate/validateApi";
import { Axe } from "../axe/axe";
import { Config } from "../config/config";
import { counterAxe, counterPlacementQuote } from "../countering/counteringApi";
import { Order } from "../order/order";
import { setOrderLeaves } from "../order/orderActions";
import { getOrderLeavesAndRequestSize, placeOrder } from "../order/orderApi";
import { TradeForm as ExecutionTradeForm } from "../tradeForm/tradeForm";
import { setTradeForm } from "../tradeForm/tradeFormActions";
import { Countering, LIVE_NEGOTIATION_STATES } from "./../countering/countering";
import { Stepper, StepperStatusType, StepperSubStatusType, Workflow } from "./stepper";

export const fatalStep = createAction("FATAL_STEP");
export const lastStep = createAction("LAST_STEP", (workflow: Workflow, status?: StepperStatusType) => {
    return { payload: { workflow, status } };
});
export const setStep = createAction("SET_STEP", (stepIdx: number, workflow: Workflow) => {
    return { payload: { stepIdx, workflow } };
});
export const sendOrder = createAsyncThunk<
    boolean,
    {
        order: Order;
        tradeForm: ExecutionTradeForm;
        axe: Axe;
        config: Config;
        stepper: Stepper;
        countering: Countering;
    }
>("SEND_ORDER", async (params) => {
    const isLiveNegotiationState = LIVE_NEGOTIATION_STATES.includes(params.countering.prevState);
    if (configUtils.isCounteringMode(params.config)) {
        if (isLiveNegotiationState) {
            return counterPlacementQuote(params.order, params.countering.placementNum, params.tradeForm);
        }
        return counterAxe(params.order, params.tradeForm, params.axe, params.config, params.countering);
    }
    return placeOrder(params.order, params.tradeForm, params.axe, params.config, params.countering);
});
export const validateOrder = createAsyncThunk<
    boolean,
    {
        order: Order;
        tradeForm: ExecutionTradeForm;
        axe: Axe;
        config: Config;
        stepper: Stepper;
        countering: Countering;
    }
>("VALIDATE_ORDER", async (params, { dispatch }) => {
    let [oldOrderLeaves, newOrderLeaves, requestSize] = await getOrderLeavesAndRequestSize(
        params.tradeForm.size!,
        params.order
    );
    let response = await dispatch(validateOrderLeaves({ oldOrderLeaves, newOrderLeaves, requestSize }));
    if (response.payload) {
        const isLiveNegotiationState = LIVE_NEGOTIATION_STATES.includes(params.countering.prevState);
        return validate(isLiveNegotiationState, params);
    } else {
        throwOrderLeavesValidationError(requestSize, newOrderLeaves);
        return false;
    }
});
export const validateOrderLeaves = createAsyncThunk<
    boolean,
    {
        oldOrderLeaves: number;
        newOrderLeaves: number;
        requestSize: number;
    }
>("VALIDATE_ORDER_LEAVES", async (params, { dispatch }) => {
    // if order leaves has changed update the order leaves data in state
    if (params.oldOrderLeaves !== params.newOrderLeaves) {
        dispatch(
            setOrderLeaves({
                orderLeaves: params.newOrderLeaves
            })
        );
    }
    if (params.requestSize > params.newOrderLeaves) {
        // request size is no longer valid (order leaves has changed and is smaller than size)
        dispatch(
            setTradeForm({
                hasValidData: false
            })
        );
        return false;
    }
    return true;
});
export const setStatus = createAction("SET_STATUS", (status: StepperStatusType, subStatus?: StepperSubStatusType) => {
    return { payload: { status, subStatus } };
});
export const previousStep = createAsyncThunk("PREVIOUS_STEP", (workflow: Workflow, { getState, dispatch }) => {
    const {
        stepper: { stepIdx },
        orderInfo: { order },
        tradeFormInfo: { tradeForm }
    } = getState() as {
        stepper: Stepper;
        orderInfo: { order: Order };
        tradeFormInfo: { tradeForm: ExecutionTradeForm };
    };

    const newStepIdx = stepIdx - 1;
    if (newStepIdx === 0 && order.hasValidData && tradeForm.hasValidData) {
        if (tradeForm.settleDate !== order.settleDate) {
            dispatch(
                setTradeForm({
                    ...tradeForm,
                    settleDate: order.settleDate
                })
            );
        }
    }
    dispatch(setStep(newStepIdx, workflow));
});
export const nextStep = createAsyncThunk("NEXT_STEP", (workflow: Workflow, { getState, dispatch }) => {
    const {
        stepper: { stepIdx }
    } = getState() as { stepper: Stepper };

    dispatch(setStep(stepIdx + 1, workflow));
});
const validate = (
    isLiveNegotiationState: boolean,
    params: { order: Order; countering: Countering; tradeForm: ExecutionTradeForm; axe: Axe; config: Config }
) => {
    if (configUtils.isCounteringMode(params.config)) {
        if (isLiveNegotiationState) {
            // if countering mode and in a live state, validate for calls that update placements IE counterPlacementQuote, executePlacementQuote
            return validateBeforeUpdatingPlacementQuote(
                params.order,
                params.countering.placementNum,
                params.tradeForm as ExecutionTradeForm
            );
        }
        // if countering mode and dead state, validate for creating new placement, IE requestPlacementQuote
        return performCounteringValidation(
            params.order,
            params.tradeForm as ExecutionTradeForm,
            params.axe,
            params.config,
            params.countering
        );
    }
    // if lift/hit mode, validate for lift/hit on order, IE multiQuickPlace
    return performOrderValidation(
        params.order,
        params.tradeForm as ExecutionTradeForm,
        params.axe,
        params.config,
        params.countering
    );
};
export const throwOrderLeavesValidationError = (requestSize: number, orderLeaves: number) => {
    const errorMessage = `Request size of ${genericUtils.formatSize(
        requestSize
    )} exceeds the new order leaves of ${genericUtils.formatSize(orderLeaves)}.`;
    logError(errorMessage);
    throw apiUtils.apiErrors([
        {
            name: `Error in validating Order, order leaves has changed`,
            message: errorMessage,
            type: "ERROR"
        }
    ]);
};
