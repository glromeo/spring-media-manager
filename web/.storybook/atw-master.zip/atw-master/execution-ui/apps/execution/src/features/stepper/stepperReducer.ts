import { createReducer } from "@reduxjs/toolkit";
import { DEFAULT_STEPPER, StepperStatusType } from "./stepper";
import { fatalStep, lastStep, sendOrder, setStatus, setStep, validateOrder } from "./stepperActions";

export const stepper = createReducer(DEFAULT_STEPPER, (builder) =>
    builder
        .addCase(fatalStep, (current) => {
            return {
                ...current,
                fatal: true
            };
        })
        .addCase(setStep, (current, { payload }) => {
            if (current.fatal) return current;

            let newStepIdx = payload.stepIdx;
            if (newStepIdx < 0) {
                newStepIdx = 0;
            }

            let status: StepperStatusType = "STEPS";
            if (newStepIdx == payload.workflow.length - 1) {
                status = current.status;
            } else if (newStepIdx >= payload.workflow.length) {
                if (current.status === "SENT") return current; // final state
                newStepIdx = payload.workflow.length - 1;
                if (current.status === "ACK_VALIDATION") status = "SENDING";
                else status = "VALIDATING";
            }

            return {
                ...current,
                stepIdx: newStepIdx,
                status
            };
        })
        .addCase(lastStep, (current, { payload }) => {
            if (current.fatal) return current;
            return {
                ...current,
                stepIdx: payload.workflow.length - 1,
                status: payload.status ? payload.status : "STEPS"
            };
        })
        .addCase(setStatus, (current, { payload }) => {
            return {
                ...current,
                status: payload.status,
                subStatus: payload.subStatus ? payload.subStatus : current.subStatus
            };
        })
        .addCase(validateOrder.fulfilled, (current) => {
            console.log("validateOrder.fulfilled : SENDING");
            return {
                ...current,
                status: "SENDING"
            };
        })
        .addCase(sendOrder.fulfilled, (current) => {
            console.log("sendOrder.fulfilled : SENT");
            if (current.subStatus === "CANCELING") {
                return {
                    ...current,
                    subStatus: "CANCELED",
                    status: "SENT"
                };
            }
            return {
                ...current,
                status: "SENT"
            };
        })
);
