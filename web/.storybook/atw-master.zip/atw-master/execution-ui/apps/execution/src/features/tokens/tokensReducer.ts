import { createTokensReducer } from "@atw/toolkit/redux";

export const tokens = createTokensReducer({
    // Set Required Files.Dat Tokens here
    TRITON_PRICE_ENABLED: "",
    AT_benchmark_date: "",
    COMPOSITE_PRICE_ENABLED: "",
    AT_execution_mode: "",
    AladdinTraderMIFIDEligible: "true",
    "DB.USER.TRADING.RO": "",
    "DB.USER.TRADING.RW": ""
});
