import { CODE } from "../../common/constants";
import { configUtils, genericUtils } from "../../common/utils";
import { BondQuality, FieldType, NUM_PLACE_HOLDER, PricingProtocol, STRING_PLACE_HOLDER } from "../../models/common";
import { Config } from "../config/config";
import { Stepper, StepperState, WORKFLOWS } from "../stepper/stepper";

export type TradeFormSchema = {
    caresLabel?: string;
    field: keyof TradeForm;
    label: string;
    minValue?: string;
    type: FieldType;
    visibleFor: (quality: BondQuality, _config?: Config, stepper?: Stepper) => boolean;
    disabledFor: (quality: BondQuality, _config?: Config, stepper?: Stepper) => boolean;
    summarize?: boolean;
};

export type TradeForm = {
    spread?: number;
    price?: number;
    size?: number;
    pricingProtocol?: string[];
    pricingProtocolChecked?: PricingProtocol;
    broker?: string[];
    allInLevel?: number[];
    desk?: string[];
    spotTime?: string[];
    dueIn?: string[];
    settleDate?: string;
    brokerSelected?: string;
    deskSelected?: string;
    spotTimeSelected?: string;
    dueInSelected?: string;
    hasValidData: boolean;
};

export type TradeFormInfo = {
    tradeForm: TradeForm;
    schema: TradeFormSchema[];
};

export const DEFAULT_TRADEFORM_SCHEMA: TradeFormSchema[] = [
    {
        field: "pricingProtocol",
        label: "Pricing Protocol",
        type: "radio",
        visibleFor: (_quality: BondQuality, _config?: Config, stepper?: Stepper) => {
            if (stepper?.subStatus === "MINI_FORM" || stepper?.subStatus === "MINI_REVIEW") return false;
            return true;
        },
        disabledFor: () => {
            return false;
        },
        summarize: false
    },
    {
        field: "price",
        label: "Price $",
        type: "price",
        visibleFor: (quality: BondQuality) => {
            return quality === "HY";
        },
        disabledFor: () => {
            return false;
        },
        summarize: true
    },
    {
        field: "spread",
        label: "Spread",
        type: "spread",
        visibleFor: (quality: BondQuality) => {
            return quality === "IG";
        },
        disabledFor: () => {
            return false;
        },
        summarize: true
    },
    {
        field: "allInLevel",
        label: "All-in-Level",
        type: "allInLevel",
        visibleFor: () => configUtils.isAxeA2AMode(),
        disabledFor: () => {
            return false;
        },
        summarize: true
    },
    {
        field: "dueIn",
        label: "Good For",
        type: "select",
        visibleFor: (_quality: BondQuality, _config?: Config, stepper?: Stepper) => {
            if (stepper?.subStatus === "MINI_FORM" || stepper?.subStatus === "MINI_REVIEW") return false;
            return _config ? configUtils.isCounteringMode(_config) : false;
        },
        disabledFor: () => {
            return false;
        },
        summarize: true
    },
    {
        field: "dueIn",
        label: "Due in",
        type: "select",
        visibleFor: (_quality: BondQuality, _config?: Config, stepper?: Stepper) => {
            if (stepper?.subStatus === "MINI_FORM" || stepper?.subStatus === "MINI_REVIEW") return true;
            return false;
        },
        disabledFor: () => {
            return false;
        },
        summarize: true
    },
    {
        field: "size",
        label: "Size",
        type: "size",
        visibleFor: () => {
            return true;
        },
        disabledFor: (_quality: BondQuality, _config?: Config, stepper?: Stepper) => {
            if (stepper?.subStatus === "MINI_FORM" || stepper?.subStatus === "MINI_REVIEW") return true;
            return false;
        },
        summarize: true
    },
    {
        field: "broker",
        label: "Broker",
        type: "select",
        visibleFor: () => {
            return true;
        },
        disabledFor: (_quality: BondQuality, _config?: Config, stepper?: Stepper) => {
            if (stepper?.subStatus === "MINI_FORM" || stepper?.subStatus === "MINI_REVIEW") return true;
            if (_config?.workflow === "RESTRICTIONS" && stepper?.stepIdx !== undefined) {
                // User cannot update broker selection during restrictions
                const currentWorkflow = WORKFLOWS[_config.workflow];
                return currentWorkflow[stepper?.stepIdx] === StepperState.Order;
            }
            return false;
        },
        summarize: true
    },
    {
        field: "desk",
        label: "Desk",
        type: "select",
        visibleFor: () => {
            return true;
        },
        disabledFor: (_quality: BondQuality, _config?: Config, stepper?: Stepper) => {
            if (stepper?.subStatus === "MINI_FORM" || stepper?.subStatus === "MINI_REVIEW") return true;
            return false;
        },
        summarize: true
    },
    {
        field: "spotTime",
        label: "Spot Time",
        type: "select",
        visibleFor: (quality: BondQuality, _config?: Config, stepper?: Stepper) => {
            if (stepper?.subStatus === "MINI_FORM" || stepper?.subStatus === "MINI_REVIEW") return false;
            return quality === "IG";
        },
        disabledFor: () => {
            return false;
        },
        summarize: true
    },
    {
        field: "settleDate",
        label: "Settle Date",
        type: "date",
        visibleFor: (_quality: BondQuality, _config?: Config, stepper?: Stepper) => {
            if (stepper?.subStatus === "MINI_FORM" || stepper?.subStatus === "MINI_REVIEW") return false;
            return true;
        },
        disabledFor: () => {
            return false;
        },
        minValue: genericUtils.getTodaysDate(true),
        summarize: true
    }
];

export const DEFAULT_TRADEFORM: TradeForm = {
    pricingProtocol: ["Price", "Spread"],
    pricingProtocolChecked: STRING_PLACE_HOLDER,
    price: NUM_PLACE_HOLDER,
    spread: NUM_PLACE_HOLDER,
    size: NUM_PLACE_HOLDER,
    broker: [],
    desk: [],
    dueIn: ["1 minute", "2 minutes", "5 minutes", "10 minutes"],
    spotTime: [],
    settleDate: STRING_PLACE_HOLDER,
    brokerSelected: STRING_PLACE_HOLDER,
    deskSelected: STRING_PLACE_HOLDER,
    spotTimeSelected: CODE.SPOT_NOW,
    dueInSelected: "5 minutes",
    hasValidData: false
};
