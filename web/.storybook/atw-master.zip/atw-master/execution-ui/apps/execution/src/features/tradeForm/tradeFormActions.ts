import { createAction } from "@reduxjs/toolkit";
import { TradeForm as TradeFormState } from "./tradeForm";

export const resetTradeForm = createAction("RESET_TRADEFORM");
export const setTradeForm = createAction("SET_TRADEFORM", (tradeForm: Partial<TradeFormState>) => {
    return { payload: tradeForm };
});
