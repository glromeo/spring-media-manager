import { createReducer } from "@reduxjs/toolkit";
import { fetchOrder } from "../order/orderActions";
import { DEFAULT_TRADEFORM, DEFAULT_TRADEFORM_SCHEMA } from "./tradeForm";
import { resetTradeForm, setTradeForm } from "./tradeFormActions";

export const tradeFormInfo = createReducer(
    { tradeForm: DEFAULT_TRADEFORM, schema: DEFAULT_TRADEFORM_SCHEMA },
    (builder) =>
        builder
            .addCase(setTradeForm, (current, { payload: tradeForm }) => {
                return { tradeForm: { ...current.tradeForm, ...tradeForm }, schema: current.schema };
            })
            .addCase(resetTradeForm, (current) => {
                // Don't want to override the spot times (originally set in fetchOrder.fulfilled)
                return {
                    tradeForm: { ...DEFAULT_TRADEFORM, spotTime: { ...current.tradeForm }.spotTime },
                    schema: current.schema
                };
            })
            .addCase(fetchOrder.fulfilled, (current, { payload: order }) => {
                if (!order.spotTimes) {
                    return current;
                }

                const spotTimes = order.spotTimes.map((val) => val.code);

                const customSpots = spotTimes.filter((val) => !val.match(/^[\d]/g)).sort();
                const specificSpots = spotTimes.filter((val) => val.match(/^[\d]/g)).sort();

                return {
                    ...current,
                    tradeForm: {
                        ...current.tradeForm,
                        spotTime: [...customSpots, ...specificSpots]
                    }
                };
            })
);
