import { bootstrapComponents } from "@atw/toolkit/awc";
import { bootstrapTelemetry } from "@atw/toolkit/telemetry";
import React from "react";
import { createRoot } from "react-dom/client";
import App from "./app/app";
import { configUtils, genericUtils } from "./common/utils";
import { Base } from "./containers/base";
import { AtxErrorBoundary, injectLogPrefix } from "@atx/toolkit";
import "./index.scss";

injectLogPrefix();
bootstrapComponents();
bootstrapTelemetry(genericUtils.getAppname(), configUtils.getUser(), 4);

const container = document.getElementById("root");
const root = createRoot(container!);
const basePath = location.pathname.replace("/index.html", "");

root.render(
    <React.StrictMode>
        <AtxErrorBoundary>
            <App basename={basePath}>
                <Base />
            </App>
        </AtxErrorBoundary>
    </React.StrictMode>
);
