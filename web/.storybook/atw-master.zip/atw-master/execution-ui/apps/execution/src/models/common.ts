export type FieldType =
    | "spread"
    | "price"
    | "size"
    | "select"
    | "date"
    | "time"
    | "text"
    | "security"
    | "boolean"
    | "side"
    | "progress"
    | "radio"
    | "rating"
    | "securityLookup"
    | "allInLevel";

export type PricingProtocol = "Price" | "Spread" | typeof STRING_PLACE_HOLDER;
export type Side = "BUY" | "SELL" | "NOTSET";

export type SideColor = string;
export const BUY_COLOR: SideColor = "var(--buy-primary__background-color_hover)";
export const SELL_COLOR: SideColor = "var(--sell-primary__background-color_hover)";
export const DISABLED_COLOR: SideColor = "var(--grid__border-color--disabled)";

export const BUY_PROGRESS_COLOR: SideColor = "var(--grid__heatmap-blue-60)";
export const SELL_PROGRESS_COLOR: SideColor = "var(--grid__heatmap-red-40)";

export const DISABLED_PROGRESS_COLOR: SideColor = "var(--grid__border-color--disabled)";

export const STRING_PLACE_HOLDER = "-";
export const EMPTY_PLACE_HOLDER = "";
export const NUM_PLACE_HOLDER = -999;
export const HIGH_YIELD = "HY";
export const INVESTMENT_GRADE = "IG";
export const PRICE = "PRICE";
export const SPREAD = "SPREAD";
export const PRICING_TYPE_MAP = {
    PRICE: HIGH_YIELD as BondQuality,
    SPREAD: INVESTMENT_GRADE as BondQuality
};
export const COUNTERPARTY_TYPE_MAP: Record<string, string> = {
    "1": "Client",
    "2": "Dealer"
};

export type PartialPick<T, K extends keyof T> = {
    [P in K]?: T[P];
};

export type BondQuality = "HY" | "IG" | "BOTH" | typeof STRING_PLACE_HOLDER;
export type SpotTime = { code: string; displayName: string };

export type PartialRecord<K extends keyof any, T> = Partial<Record<K, T>>;
export interface Dimension {
    width: number;
    height: number;
}

export interface KeyValueNumber {
    [index: string]: number;
}

export interface KeyValueBoolean {
    [index: string]: boolean;
}
