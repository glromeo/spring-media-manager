# Introduction

We use [Cypress](https://www.cypress.io/) to automate various functionality that an end user would do. APIs are written in [Cucumber](https://cucumber.io/) style using the table syntax.
Please refer to docs below to start writing your own tests. If API functionality is lacking please write your own helper methods and update this wiki.

**note** - try to write methods that are reusable

# Getting Started

In order to get started writing your own tests. First a primer on how Cypress works.

-   All cypress methods are async
-   You can also make use of basic cypress apis, including the fantasic [Testing Library](https://testing-library.com/docs/cypress-testing-library/intro/)
-   Cypress allows proxying of calls - via fixtures
-   Sometimes you may need to reach down into the shadow DOM in order to automate a component - this is especially true - because of our use of the [AWC Components](https://tst.blackrock.com/apps/apgux/#/docs/guides/home)

# BDD / Unit testing

Unfortunately Cypress is split into 2 parts

-   BDD style tests (i.e. integration tests)
-   Unit style tests (i.e. component level)

APIs below are with respect to BDD (cucumber style) - Unit tests (TBD) - will use regular Assert style type of testing

# Setup

-   Cucumber tests are written via the **Given**/**When**/**Then** syntax and make use of a 'feature' file (to intercept REST calls) - these are located under the **/bdd** folder.
-   Fixtures for various tests can be places under the **/fixtures** folder
-   Features represent the overall (test suite) - i.e. your grouping (example Execution workflow feature, or Cares workflow feature)
-   Scenario represent the actual (test) - break this up in useful end user workflows (example: HY, or IG or Restricted cases etc...)

Every scenario starts off the same way - you start of by describing the order (this is really how Market Depth calls Execution) via a query string similar to this.

https://tst.blackrock.com/apps/execution/477209185?side=Buy&cusip=02005NBM1&aid=A106709_1474274511_SELL_0_150600_CSus&asize=100000&aprice=101.03&acode=66402&abroker=NYFIXIOI&atime=1624619927000&aquality=ig&aspread=25&ayield=20&abmk=12&user=kburgess

As such - in order to create a 'new' scenario - you can grab the query string from Market Depth (Ctrl-Shift-X) and also grab the 'graphql' response object as a Cypress intercept fixture

# APIS

Alot of the APIs below - have 'slots' available that allow user defined input to drive the tests (tables, and other methods) - if you look at the underlying code (located under **/bdd/common**) - you will note the syntax

```
Then("blah blah {} something {} blah blah", () => {
    /// where {} allow you to grab the input and do something with it ...
});

```

You can use the above _style_ to augment your own methods ...

The following APIs are available for use ...

## **API INTERCEPTORS**

These Cypress APIs help us set up and intercept API calls by providing custom responses.

## API - I have an order with attributes

**Context:**
This is the starting API that is used to setup a scenario test - remember to grab the URL from Market Depth and update the table below with the results

**Usage:**

```
Given I have an order with attributes
      |key|value|
      |order|505125984|
      |side|Buy|
      |aid|DemoData-test1|
      |cusip|02005NBM1|
      |asize|2000000|
      |aprice|103.24|
      |aspread|0|
      |ayield|0|
      |aytype|0Type|
      |aquality|HY|
      |abmk||
      |acode|61860|
      |abroker|SIMEQ|
      |atime|2021-08-17T18:03:08.000Z|
      |user|kburgess|
```

**Behind the scenes:** This will intercept the calls to fetch the broker entities and to retrive order data for a given order number. To add your own response, you can add a fixture under **/bdd/fixtures/orders/505125984.json**, where the name of the json must exactly match the order number provided here. For now, the only "keys" supported are those in the execution URL.

## API - I have an order with attributes that will fail due to {}

**Context:** This is the same as the above API, but will return a given error when the UI tries to retrieve the order information.

**Usage:**

-   {reason} - must be case-insensitive version of a WorkflowError (see BTS).

```
Given I have an order with attributes that will fail due to Broker Entity response null
      |key|value|
      |order|505125984|
      |side|Buy|
      |aid|DemoData-test1|
      |cusip|02005NBM1|
      |asize|2000000|
      |aprice|103.24|
      |aspread|0|
      |ayield|0|
      |aytype|0Type|
      |aquality|HY|
      |abmk||
      |acode|61860|
      |abroker|SIMEQ|
      |atime|2021-08-17T18:03:08.000Z|
      |user|kburgess|
```

**Behind the scenes:** In test/common.utils.ts, you will see an enum **WorkflowError**, i.e.

```
export enum WorkflowError {
    BROKER_ENTITY_RESPONSE_NULL = "BROKER_ENTITY_RESPONSE_NULL",
    VALIDATION_MIN_AMOUNT = "VALIDATION_MIN_AMOUNT",
    // etc
}
```

This sentence reads a bit clunky in English, but basically, the slot after "due to" should match (in upper or lower case) the name of one of these enums. In the example above, the code will translate "Broker Entity response null" to BROKER_ENTITY_RESPONSE_NULL, and it will return a specific fixture mapped to that enum.

If you want to add your own error case, add another enum value to WorkflowError and then edit test/common.ts - setupGraphQLIntercepts() to add another if clause to the if statement. You can return either a custom body or add a new fixture.

## API - The API calls will have status

**Context:** This is a more general API set up than the above. An important thing to note is that the above API is specifically for the two initial order APIs, i.e. retrieving broker entities and order data for an order #. This method should be used for subsequent calls. Please note that every time you use this API method to set up API calls, it will **replace** whatever you set up previously. If you don't explicitly indicate success for each individual API, this API method will default to success (but you do need to call this API method at least once).

**Usage:**

```
And the API calls will have status
      | API         | status  | reason     |
      | Validation  | failure | min amount |
      | Quick Place | success |            |
```

**Behind the scenes:** In test/common.utils.ts, you will see an enum **WorkflowError**, i.e.

```
export enum WorkflowError {
    BROKER_ENTITY_RESPONSE_NULL = "BROKER_ENTITY_RESPONSE_NULL",
    VALIDATION_MIN_AMOUNT = "VALIDATION_MIN_AMOUNT",
    // etc
}
```

Essentially, the code is joining (case-insensitive) whatever you put in the "API" column and the "reason" column to match against this API. In this example, the code will search for an error handling against WorkflowError.VALIDATION_MIN_AMOUNT.

If you want to add your own error case, add another enum value to WorkflowError and then edit test/common.ts - setupIntercepts() to add another if clause to the if statement. You can return either a custom body or add a new fixture.

## **UTILITY**

These Cypress APIs are helper functions

## API - assertConsole

**Context:** This will assert that any output to console can be verified

**Usage:**

```
  And console logs should contain
            | log                                                                                                   |
            | Broker SIMEQ has no associated desks - will be excluded from eligible list                            |
            | Broker GSNR has no associated desks - will be excluded from eligible list                             |
            | Broker BNP has no associated desks - will be excluded from eligible list                              |
            | The following (3) brokers (61860,1624,3961) have been filtered out - because no desks exist for them   |
```

## API - visit

**Context:** This will visit the url as normal (but also captures/spies on console to be use later for verifying)

**Usage:**

```
    visit(url) - used to replace cy.visit(url)
```

## **ASSERT UI ELEMENTS**

These Cypress APIs help us assert that various elements of the page are rendered correctly.

## API - header should have attributes

**Context:** This will assert that the header has the given "steppers."

**Usage:**

-   num should be zero-indexed, # of the stepper
-   value should be the text value of each stepper
-   state should be
    -   **active** - currently active
    -   **disabled** - currently disabled (i.e. future steps)
    -   **completed** - currently completed (i.e. past steps)

```
Then header should have attributes
      | num | value     | state     |
      | 0   | 1. Split  | completed |
      | 1   | 2. Order  | active    |
      | 2   | 3. Review | disabled  |
```

**Behind the scenes:** This method relies on two things -- the title of the table and the key referring to each row. You should be able to use the obvious title (bolded) and each row "name", but if your test is failing and you can't figure out why, it probably has to do with that. You can try inspecting the HTML to see what the title actually is.

## API - {} table should have attributes

**Context:** This will assert that the different rows in a table have given information.

**Usage:**

-   {table name} - must match case-insensitive name of the table, i.e. the bold header. Examples: Your Order, Axe, Lift the Axe, Hit the Axe

```
Then Your Order table should have attributes
      | key           | value             |
      | Side          | You SELL          |
      | Bond          | ALLY 4.7 12/31/79 |
      | CCY           | USD               |
      | CUSIP         | 02005NBM1         |
      | ISIN          | US02005NBM11      |
      | Original Size | 3,000,000         |
      | Unbooked Amt  | 3,000,000         |
      | Order Leaves  | 3,000,000         |
      | Limit         | -                 |
      | Limit Type    | -                 |
      | Instructions  | -                 |
      | Trading Bmk   | -                 |
```

**Behind the scenes:** This method relies on two things -- the title of the table and the key referring to each row. You should be able to use the obvious title (bolded) and each row "name", but if your test is failing and you can't figure out why, it probably has to do with that. You can try inspecting the HTML to see what the title actually is.

## API - {} form should have attributes

**Context:** This will assert that the different rows in a form have given information.

**Usage:**

-   {form name} - must match case-insensitive name of the form, i.e. the bold header. Examples: Lift the Axe, Hit the Axe

```
And Hit[Hit] form should have attributes
      | key         | value                 | type   |
      | Price       | 102.76                | input  |
      | Size        | 1000000               | input  |
      | Broker      | JPMSL                 | select |
      | Desk        | LOAN - DUMMY CONTACT  | select |
      | Settle Date | 08/24/2021            | date   |
```

**Behind the scenes:** This method relies on three things -- the title of the table, the key referring to each row, and the type of the form item. You should be able to use the obvious title (bolded) and each row "name", but if your test is failing and you can't figure out why, it probably has to do with that. You can try inspecting the HTML to see what the title actually is. Please be sure to pass the type of each form item as well.

## API - {} popup should have attributes

**Context:** This will assert that the text in a popup contain given attributes.

**Usage:**

-   {popup name} - must match case-insensitive name of the popup, i.e. the bold header. Examples: Trade Request Sent

```
And Trade Request Sent popup should have attributes
      | key       | value             |
      | Side      | SELL              |
      | Bond      | ALLY 4.7 12/31/79 |
      | Price     | 102.76            |
      | Size      | 1,000,000         |
      | Broker    | JPMSL             |
```

**Behind the scenes:** This method is not really using the "key"/"value" super meaningfully. For now, it just looks up the popup by name (look at the header) and then asserts that the confirmation text contains each "value".

## API - {} dialog should have attributes

**Context:** This will assert that the (alert) text in a dialog contain given attributes. This is basically the same as the above implementation, but doesn't require you to know what the title of the dialog will be. Use this for alerts only.

**Usage:**

-   {dialog type} - currently only supports 'Alert' dialog types

```
Then Alert dialog should have attributes
      | key   | value                            |
      | Error | Unable to fetch order: 505125984 |
```

**Behind the scenes:** This method is not really using the "key"/"value" super meaningfully. For now, it just looks up the "alert-dialog" and then asserts that the confirmation text contains each "value".

## API - [{}] should be {} OR [{}] should not be {}

**Context:** This will assert that a given element should or should not be something. Currently supports enabled, disabled, visible, or just "contains text."

**Usage:**

-   {name of control}
-   {command}
    -   **enabled** - determines if control is enabled
    -   **disabled** - determines if control is disabled
    -   **visible** - determines if control is visible
    -   **_equality_** - determines if control (text) content is similar to supplied value

```
And [Cancel button] should be enabled
And [Next button] should be disabled
And [Debug Info] should be visible
And [Trade-Summary] should be You will send aBUY order for 1,978,000 ofALLY 4.7 12/31/79 at103.24 USD toSIMEQ

```

**Behind the scenes:** This method looks up the html element by the name of it. For buttons, add button; for others, just include the name. If you don't know what the name is, you can look at the data-test-id by inspecting the element.

## API - I should see a {} notification -OR- I should see a {} notification for [{}]

**Context:** This will assert that a warning/alert notification is shown with a given message.

**Usage:**

-   {notification type} - alert or warning
-   {alert message} - substring of the notification's message

```
Then I should see a error notification
Then I should see a error notification for [null API response]
And I should see a warning notification for [portfolio allocations restricted]

```

**Behind the scenes:** This method supports you specifying either warning/alert for the type of notification (warning = yellow, alert = red). The part in the brackets is just part of the error text. You can put the entire text or just the important part, or just leave that part blank.

## API - {} form should show error

**Context:** This will assert that a given form is showing a given error for a given field/row.

**Usage:**

-   {form name} - must match case-insensitive name of the form, i.e. the bold header. Examples: Lift the Axe, Hit the Axe

```
And Lift[Lift] form should show error
      | key         | error                            | type |
      | Settle Date | Date cannot be before 08/20/2021 | date |
```

**Behind the scenes:** This method will find the form by the name of it (see above for more information), find the row for the key, and check to see if it is showing an error. Please provide all three fields. For the error, you can provide the entire error or just the important snippet.

## API - I should see {} options for {}

**Context:** On the base level, this will assert that a given # of a certain type of element are shown. This API only supports restrictions right now, but we can add more to it if necessary.

Restrictions: will also check that the Restriction Card button/card contains any provided information.

**Usage:**

-   {numOptions} - # of options
-   {control} - name of the control. Currently supports
    -   **restrictions** (see below)
    -   any selector for data-test-id, if you know it

```
And I should see 2 options for restrictions
      | num | key        | value                                    |
      | 0   | broker     | JPM                                      |
      | 0   | available  | 2,000,000 / 66.67% of available quantity |
      | 0   | restricted | 1 of 3 portfolios restricted             |
      | 1   | broker     | JPMSL                                    |
      | 1   | available  | 1,000,000 / 33.33% of available quantity |
      | 1   | restricted | 2 of 3 portfolios restricted             |
```

**Behind the scenes:** This method will take in the second slot as the 'selector' and search for the matching element. For restrictions, just pass in the word 'restrictions' and it will create the selector for you, but in theory this would work for anything if you knew what the data-test-id was for that element (can see in Inspect Element).

Also for restrictions, you can pass in a table of data (see above) and it will check that the restriction contains that information as part of the text. Please note it is 0-indexed.

## **PERFORM USER ACTIONS**

These Cypress APIs help us assert that various elements of the page are rendered correctly.

## API - I have {} [{}]

**Context:** This is intended to be a super general method to encapsulate a lot of user actions. Right now, however, it only really supports clicking on things. I can add more to it pretty easily if it becomes necessary. If you want to initialize a form with data, look at "I populated the {} form with"

**Usage:**

-   {command} - what action you did. Currently supports
    -   **clicked**
    -   **checked** (basically clicked, but for radio buttons)

```
And I have clicked [Split & Next button]
And I have checked [Restriction Card 1]
```

**Behind the scenes:** This method will take in the action and the element (in brackets), following the same naming convention as the other APIs. If you don't know the name of the element, you can look it up the data-test-id with Inspect Element, but it should hopefully be pretty obvious. Also remember to add 'button' for buttons and 'radio' for radio buttons. This is case-insensitive.

Currently this API only supports clicking (and, for radio buttons, 'checking' which is just clicking).

## API - I populated the {} form with

**Context:** This allows you to enter data into the form, as if the user typed it. This will only work on enabled elements, i.e. you can't force it to change one of the fields that is disabled (i.e. on the Lift[Lift] form, you can't change the price).

**Usage:**

-   {form name} - must match case-insensitive name of the form, i.e. the bold header. Examples: Lift the Axe, Hit the Axe

```
And I populated the Lift[Lift] form with
      | key         | value      | type  |
      | Size        | 5          | input |
      | Settle Date | 08/18/2021 | date  |
```

**Behind the scenes:** This method relies on you entering the name of the form (should match the bolded name on top), the row that you want to edit (key = the name of the field on the form), and the type of field that it is (date/input/select) Then it will simulate the user entering that value.

Please note that if you run this with the cypress GUI, sometimes it fails randomly. You can go into test/common.ts populateForm and try adding a cy.wait(), or run the test again.

## API - I {} Ctrl Shift X

**Context:** This is a super small API to simulate the user either entering or releasing ctrl-shift-x to toggle the debug mode. However, we can add an API to allow the user more generally to perform key actions if that is necessary (like ctrl-c).

**Usage:**

-   {command} - what action you did. Currently supports
    -   **press**
    -   **release**

```
Then I press Ctrl Shift X
Then I release Ctrl Shift X
```

**Behind the scenes:** If you use 'press', the method simulates the user pressing Ctrl-Shift-X together and not releasing it. If you use 'release', it releases the key downs.

## **WAIT FOR THINGS**

These Cypress APIs help us wait for different things, generally API calls.

## API - HY order has loaded

**Context:** This API specifically waits for the HY order API calls to finished, i.e. waits for broker query and order query.

**Usage:**

```
Given HY order has loaded
```

**Behind the scenes:** We use an alias to each API, and then we wait for those APIs to finish.

## API - IG order has loaded

**Context:** This API specifically waits for the IG order API calls to finished, i.e. waits for broker query, order query, prices query, and benchmark query.

**Usage:**

```
Given IG order has loaded
```

**Behind the scenes:** We use an alias to each API, and then we wait for those APIs to finish.

## API - HY CARE order has loaded

**Context:** This API specifically waits for the HY CARE order API calls to finished, i.e. waits for broker query and order care query.

**Usage:**

```
Given HY CARE order has loaded
```

**Behind the scenes:** We use an alias to each API, and then we wait for those APIs to finish.

## API - IG CARE order has loaded

**Context:** This API specifically waits for the HY order API calls to finished, i.e. waits for broker query, order care query, prices query, and benchmark query.

**Usage:**

```
Given IG CARE order has loaded
```

**Behind the scenes:** We use an alias to each API, and then we wait for those APIs to finish.

## API - Broker entities has completed

**Context:** This API specifically waits for the broker entities call to finished, i.e. retrieving what broker entities are available

**Usage:**

```
Given Broker entities has completed
```

**Behind the scenes:** We use an alias to 'name' the broker entities API, and then we wait for that API to finish.

## API - {} has finished

**Context:** This API is meant to more generally wait for APIs. However, it only supports the order, broker entity, quick place, and validation calls as of now. If you need more, you can add it in test/common.ts waitFor() and add to the if statements as shown.

**Usage:**

-   {action name} - what action you are waiting for. Currently supports
    -   **Orders**
    -   **Broker Entity**
    -   **Validation**
    -   **Quick Place**

```
And Validate Quick Place has finished
And Quick Place has finished
```

**Behind the scenes:** We use an alias to 'name' the API, and then we wait for that API to finish.

## **Common Options**

There are some common options you may include or see repeated in many APIs. These are:

### Table Titles

-   **Your Order** - describes what info an order has
-   **Order Details** - describes (Axe and Order Leaves) info
-   **Axe** - describes (Axe) detail info

### Form Titles

-   **Lift the Axe** - enter axe info for BUY
-   **Hit the Axe** - enter axe info for SELL

### Popup Titles

-   **Trade Request Sent** - the trade request confirmation popup

### Dialog Titles/Types

-   **Alert** - Alert dialogs display as popups, rather than notifications.

### Notification Types

-   **Alert** - Alert notifications are red and usually prevent further action.
-   **Warning** - Warning notifications are yellow and usually allow further action.

### Element Names to Act On

-   **Buttons** - Buttons should follow the convention (Text from the button + "button"), i.e. Next button, Split & Next button, Cancel button.

### Input Types

-   **date** - datetime
-   **input** - text or number
-   **select** - select combo box

## **Get Started Making Your Own integration tests**

These follow the Given/Then/And framework. Don't worry too much about which one you are using. The more important part is usually matching the right RegEx.

You should usually start by setting up an order with "Given I have an order with attributes". As a sanity check, you can wait for "HY order has loaded" and then assert the attributes of the Lift[Lift] form. Look at any of the Happy Paths.

Please note that this framework is very much a WIP. That means that you may want to use an existing API for a use case that is not explicitly covered. I encourage you to try to add to the existing code in common.ts, but if not, please feel free to reach out.

A very basic overview of how this workflow works:

Define the regex matching part in common.steps.ts. Look through common.ts -- is there a method that is already handling what you want? If not, you can create your own.

```
<div  data-test-id="myawesomecontrol">
   my awesome control - with a test attribute
</div>
```

This allows the cypress to **_find_** this control via the attribute and then you can perform an operation on it (like check for enabled/disabled) or equality test

You generally need to find the element on the page by searching for the **data-test-id**:

```
cy.get(`[${DATA_TEST_ID_PREFIX}"${formTitle}"]`).should("have.text", formName);
```

But you can cy.get any CSS selector, i.e.

```
cy.get(".dialogmessage > div").should($div => {
        table.hashes().forEach(elem => {
            expect($div).prop("innerText").to.contain(elem["value"]);
        });
    });

```

If the element you want doesn't already have a data-test-id set, you'll have to find the appropriate .tsx file and add it to the html code.

A few hints if you can't get your element:

-   try passing in { includeShadowDom: true }
-   try looking for an inner element, using **within**

```
cy.get(selector).within(() => {
        cy.get("input").should("have.value", value);
});
```
