/// <reference types="cypress" />
import { TableDefinition } from "cypress-cucumber-preprocessor";
import { Given, Then } from "cypress-cucumber-preprocessor/steps";
import { GraphQLOrderSummaryResponse } from "../../../src/api/types";
import { AppState } from "../../../src/app";
import { genericUtils } from "../../../src/common/utils";
import { Alert, AlertType } from "../../../src/features/alerts/alert";
import { setAlert } from "../../../src/features/alerts/alertsActions";
import {
    assertAuxCard,
    assertAuxNotification,
    assertAuxSelectDropdownOptions,
    assertAuxSelectText,
    assertAuxStepper,
    assertConsole,
    assertDialog,
    assertElementContainsText,
    assertElementExists,
    assertElementHasLabel,
    assertElementHasText,
    assertElementNotExists,
    assertForm,
    assertFormError,
    assertFormFieldsMode,
    assertNumElements,
    assertPopup,
    assertSelectOptionState,
    assertTable,
    calledAtMostOnce,
    closeAuxNotification,
    dispatchStore,
    performCommand,
    performCtrlShift,
    populateForm,
    selectOption,
    setAuxStepper,
    setupCommonIntercepts,
    setupDecodesIntercept,
    setupExecutionIntercepts,
    setupGraphQLIntercepts,
    setupSecuritySearchIntercept,
    setupTelemetryIntercept,
    toggleExpandOnAuxCard,
    verifyElementState,
    verifyLocalStorage,
    verifyStore,
    verifyStyle,
    visit,
    waitFor
} from "../../common";
import {
    DATA_TEST_ID_PREFIX,
    WorkflowError,
    convertNumberStringToNumber,
    convertToWorkflowEnum,
    getTestSelector
} from "../../common.utils";
const { removeSpace } = genericUtils;

Cypress.on("uncaught:exception", (err, runnable) => {
    // aux related error that happens intermittently
    if (err.message.includes("Cannot read properties of undefined (reading 'openDropdown')")) {
        return false;
    }
    throw err;
});

Cypress.on("fail", (error, runnable) => {
    // we now have access to the err instance
    // and the mocha runnable this failed on
    throw error; // throw error to have test still fail
});

// set files dat tokens into local storage
function cacheRequiredTokens(tokens: any) {
    localStorage.setItem(
        "execution.tokens",
        JSON.stringify({
            tokens,
            lastModified: Date.now()
        })
    );
}

beforeEach(() => {
    window.localStorage.clear();
    cacheRequiredTokens({
        AT_execution_mode: "normal",
        AT_benchmark_date: "11/21/2021",
        AladdinTraderMIFIDEligible: "true",
        COMPOSITE_PRICE_ENABLED: "False",
        "DB.USER.TRADING.RO": "svc_trading_ro",
        "DB.USER.TRADING.RW": "svc_trading_rw"
    });
});

afterEach(() => {
    Cypress.env().api.count.requestplacementquote = 0;
    Cypress.env().workflow = "";
});

/**************************
 **** API INTERCEPTORS ****
 **************************/

Given("I have loaded a HY order scenario - {}", (scenario: string) => {
    let url = "",
        fixtureFile;
    let waitForOrder = true;
    let waitForPrices = false;
    switch (scenario) {
        case "some brokers have countering disabled":
            url =
                "/index.html?orderNumber=505125972&side=Buy&aid=DemoData-test1&cusip=02005NBM1&asize=2000000&aprice=103.24&aspread=0&ayield=0&aytype=0Type&aquality=HY&abmk=&acode=61860&abroker=SIMEQ&atime=2021-08-17T18:03:08.000Z&user=testuser";
            fixtureFile = "orders/505125972";
            break;
        case "all brokers have countering disabled":
            url =
                "/index.html?orderNumber=505125971&side=Buy&aid=DemoData-test1&cusip=02005NBM1&asize=2000000&aprice=103.24&aspread=0&ayield=0&aytype=0Type&aquality=HY&abmk=&acode=61860&abroker=SIMEQ&atime=2021-08-17T18:03:08.000Z&user=testuser";
            fixtureFile = "orders/505125971";
            break;
        case "with restrictions":
            url =
                "/index.html?orderNumber=505125884&side=Sell&aid=DemoData-test1&cusip=02005NBM1&asize=1000000&aprice=102.76&aspread=0&ayield=0&aytype=0Type&aquality=HY&abmk=&acode=25&abroker=JPM&atime=2021-08-17T18:03:08.000Z&user=testuser";
            fixtureFile = "orders/505125884";
            break;
        case "with spread data":
            url =
                "/index.html?orderNumber=484134985&side=Buy&aid=DemoData-test1&cusip=92343VGJ7&asize=8505000&aprice=0&aspread=86&ayield=0&aytype=&aquality=HY&abmk=91282CCB5&acode=12&abroker=MSIOI&atime=2021-08-17T18:03:08.000Z&user=testuser";
            fixtureFile = "orders/484134985";
            break;
        case "via CARE":
            url = "/index.html?orderNumber=505126084&side=Sell&cusip=02005NBM1&workflow=CARE&user=testuser";
            fixtureFile = "care/505126084";
            waitForOrder = false;
            break;
        case "via CARE with one broker":
            url = "/index.html?orderNumber=505125984&side=Sell&cusip=02005NBM1&workflow=CARE&user=testuser";
            fixtureFile = "care/505125984";
            waitForOrder = false;
            break;
        case "via CARE with restrictions":
            url =
                "/index.html?orderNumber=205125784&embedded=true&side=Buy&cusip=02005NBM1&user=testuser&workflow=care";
            fixtureFile = "care/205125784";
            waitForOrder = false;
            break;
        case "via CARE with a spread enabled broker":
            url = "/index.html?orderNumber=484135285&side=Buy&cusip=92343VGJ7&user=testuser&workflow=CARE";
            fixtureFile = "care/484135285";
            waitForOrder = false;
            waitForPrices = true;
            break;
        case "changed order leaves":
            url =
                "/index.html?orderNumber=505125987&side=Buy&aid=DemoData-test1&cusip=02005NBM1&asize=2000000&aprice=103.24&aspread=0&ayield=0&aytype=0Type&aquality=HY&abmk=&acode=61860&abroker=SIMEQ&atime=2021-08-17T18:03:08.000Z&user=testuser&embedded=true";
            fixtureFile = "orders/505125987";
            break;
        default:
            url =
                "/index.html?orderNumber=505125984&side=Buy&aid=DemoData-test1&cusip=02005NBM1&asize=2000000&aprice=103.24&aspread=0&ayield=0&aytype=0Type&aquality=HY&abmk=&acode=61860&abroker=SIMEQ&atime=2021-08-17T18:03:08.000Z&user=testuser&embedded=true";
            fixtureFile = "orders/505125984";
            break;
    }
    cy.fixture(fixtureFile).then((order: any) => {
        switch (scenario) {
            case "upsized":
                order.data.fiOrderSummary.order.orderLeaves = 10000000;
                break;
            case "all brokers have countering disabled":
                order.data.fiOrderSummary.counteringEnabled = [];
                break;
            default:
                break;
        }

        if (fixtureFile.includes("care/")) Cypress.env().workflow = "CARES";
        setupGraphQLIntercepts({
            editedFixtures: { order }
        });
        setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
        setupDecodesIntercept("MD_PRICE_SOURCE");
        setupSecuritySearchIntercept();
        visit(url);
        waitFor("brokerEntity");
        if (waitForOrder) waitFor("orders");
        else waitFor("care");
        if (waitForPrices) waitFor("prices");
        cy.wait(2000);
    });
});

function setupMDPIntercepts(intercepts: { type; payload }[]) {
    cy.window().then((win: any) => {
        console.log(">>>>>>>>>>>>>>>>>");
        intercepts.forEach((intercept) => {
            win.store.dispatch(intercept);
        });
    });
}

Given("I have loaded the playback recording screen", () => {
    const url = "/index.html?mode=playback";
    visit(url);
});

Given("I have loaded an automation playback recording scenario - {}", (scenario: string) => {
    let url = "";
    let waitForOrder = true;
    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    visit(url);
    waitFor("brokerEntity");
    if (waitForOrder) waitFor("orders");
});

Given("I have loaded a generic order", () => {
    const url =
        "/index.html?orderNumber=505125985&embedded=true&side=Buy&cusip=02005NBM1&aquality=HY&theme=light&user=testuser&aid=DemoData-mbehal-1632209898689&asize=1000000&aprice=103.238&aspread=0&ayield=0&aytype=0Type&abmk=&acode=25,4036&abroker=JPMIOI&atime=2021-09-21T07:38:51.000Z";
    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    visit(url);
    waitFor("brokerEntity");
    waitFor("orders");
});

Given("I have loaded a generic order - some entities with empty desks", () => {
    const url =
        "/index.html?orderNumber=505125986&embedded=true&side=Buy&cusip=02005NBM1&aquality=HY&theme=light&user=testuser&aid=DemoData-mbehal-1632209898689&asize=1000000&aprice=103.238&aspread=0&ayield=0&aytype=0Type&abmk=&acode=25,4036&abroker=JPMIOI&atime=2021-09-21T07:38:51.000Z";
    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    visit(url);
    waitFor("brokerEntity");
    waitFor("orders");
});

Given("I have loaded some brokers that have no desks via CARE", () => {
    const url =
        "/index.html?orderNumber=505488184&embedded=true&side=SELL&cusip=02005NBM1&aquality=HY&theme=light&user=testuser&workflow=care";
    Cypress.env().workflow = "CARES";
    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    visit(url);
    waitFor("brokerEntity");
    waitFor("care");
});

Given("I am loading a HY order that will fail due to a {} API error: {}", (apiName: string, errorMessage: string) => {
    const url =
        "/index.html?orderNumber=505125984&side=Buy&aid=DemoData-test1&cusip=02005NBM1&asize=2000000&aprice=103.24&ayield=0&aytype=0Type&aquality=HY&abmk=&acode=61860&abroker=SIMEQ&atime=2021-08-17T18:03:08.000Z&user=testuser";
    const workflowError = convertToWorkflowEnum(apiName, errorMessage);
    setupGraphQLIntercepts({ workflowError: [workflowError] });
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    visit(url);
    waitFor("brokerEntity");
    if (errorMessage.includes("Order Query")) {
        waitFor("orders");
    }
});

Given("I have loaded scenario {}", (scenario: string) => {
    let url = "",
        fixtureFile;
    switch (scenario) {
        case "broker-accepted-timeout":
        case "broker-accepted":
        case "broker-accepted-nocounterparty":
        case "broker-accepted-regional":
        case "broker-accepted-original-axe-order-HY-placement-IG":
        case "broker-accepted-placement-effectiveTime-is-null":
        case "broker-accepted-goodFor-stub":
        case "spread-original-axe":
        case "broker-repeated-original-axe":
        case "broker-repeated-nocounterparty":
        case "broker-new-counter-diff-price-original-axe":
        case "broker-new-counter-original-axe":
        case "broker-new-nocounterparty":
        case "broker-new-counter-diff-quantity-original-axe":
        case "broker-rejected-original-axe":
        case "manual-canceled":
        case "offer-timeout":
            url =
                "/index.html?orderNumber=540561285&workflow=countered&placement=196021185&cusip=00033AAA6&theme=light&user=testuser&abmk=912810SU3&acode=61860&abroker=SIMEQ1860&abroker=SIMEQ";
            fixtureFile = "orders/540561285";
            break;
        case "broker-accepted-changed-orderleaves":
            url =
                "/index.html?orderNumber=540561286&workflow=countered&placement=196021185&cusip=00033AAA6&theme=light&user=testuser&abmk=912810SU3&acode=61860&abroker=SIMEQ1860&abroker=SIMEQ";
            fixtureFile = "orders/540561286";
            break;
        case "broker-accepted-changed-orderleaves-valid":
            url =
                "/index.html?orderNumber=540561288&workflow=countered&placement=196021185&cusip=00033AAA6&theme=light&user=testuser&abmk=912810SU3&acode=61860&abroker=SIMEQ1860&abroker=SIMEQ";
            fixtureFile = "orders/540561288";
            break;
        case "broker-accepted-size_>_orderleaves":
            url =
                "/index.html?orderNumber=540561285&workflow=countered&placement=196021185&cusip=00033AAA6&theme=light&user=testuser&abmk=912810SU3&acode=61860&abroker=SIMEQ1860&abroker=SIMEQ";
            fixtureFile = "orders/540561285";
            break;
        case "live-states-plcmt-spread-others-price":
            url =
                "/index.html?orderNumber=540561287&workflow=countered&placement=196021185&cusip=00033AAA6&theme=light&user=testuser&abmk=912810SU3&acode=61860&abroker=SIMEQ1860&abroker=SIMEQ";
            fixtureFile = "orders/540561287";
            break;
        case "trader-cancels-cancelation":
        case "trader-cancels-cancel-request":
        case "broker-cancels":
        case "broker-rejected":
        case "broker-counter-expire-placement-effectiveTime-is-null":
        case "broker-counter-expire-expiry-not-null":
        case "broker-counter-expire":
        case "broker-mismatch":
        case "order-side-mismatch":
            url =
                "/index.html?orderNumber=583666783&workflow=countered&placement=198601283&cusip=037833EA4&theme=light&user=testuser&abmk=912810SX7&acode=61860&abroker=SIMEQ1860&abroker=SIMEQ";
            fixtureFile = "orders/583666783";
            break;
        case "due-in-expire":
        case "due-in-expire-rw-user":
        case "due-in-expire-ro-user":
        case "due-in-expire-no-user":
            url =
                "index.html?user=testuser&orderNumber=718676284&placement=224466784&cusip=02005NBM1&aoid=1270921644&acode=61860&abroker=SIMEQ&workflow=COUNTERED";
            fixtureFile = "orders/718676284";
            break;
        case "broker-rejected-no-bench":
            url =
                "/index.html?orderNumber=583666783&workflow=countered&placement=198601283&cusip=037833EA4&theme=light&user=testuser&abmk=91282CCB6&acode=61860&abroker=SIMEQ1860&abroker=SIMEQ";
            fixtureFile = "orders/583666783";
            break;
        case "dead-states-plcmt-spread-others-price":
            url =
                "/index.html?orderNumber=583666785&workflow=countered&placement=198601283&cusip=037833EA4&theme=light&user=testuser&abmk=912810SX7&acode=61860&abroker=SIMEQ1860&abroker=SIMEQ";
            fixtureFile = "orders/583666785";
            break;
    }
    cy.fixture(fixtureFile).then((order: any) => {
        let orderSummary: GraphQLOrderSummaryResponse = order.data;
        // set new expTime...in GMT ... weird why typescript does have type for toGMTString ...
        let expTime = new Date(new Date("08/10/2021").getTime() + 60 * 10 * 999).getTime();
        orderSummary.fiOrderSummary.placements![0].placementGenFields = [
            {
                "key": "numOfCompetitors",
                "value": "1"
            },
            {
                "key": "axeLevel",
                "value": "222.0"
            },
            {
                "key": "axeQty",
                "value": "100"
            }
        ];

        switch (scenario) {
            case "broker-accepted-original-axe-order-HY-placement-IG":
                orderSummary.fiOrderSummary.placements![0].limitType = "Spread";
                orderSummary.fiOrderSummary.placements![0].quotes[0].spread = 111.0;
                break;
            case "manual-canceled":
                orderSummary.fiOrderSummary.placements![0].modifyReason = "Manual Cancelation";
                break;
            case "offer-timeout":
                orderSummary.fiOrderSummary.placements![0].modifyReason = "Quote Subjected";
                break;
            case "broker-cancels":
            case "trader-cancels":
                orderSummary.fiOrderSummary.placements![0].modifyReason = "Quote Cancelled";
                break;
            case "trader-cancels-cancelation":
                orderSummary.fiOrderSummary.placements![0].modifyReason = "Cancelation";
                break;
            case "trader-cancels-cancel-request":
                orderSummary.fiOrderSummary.placements![0].modifyReason = "Cancel Request";
                break;
            case "broker-accepted-timeout":
                expTime = new Date(new Date("08/10/2021").getTime() + 4000).getTime();
                break;
            case "broker-accepted-size_>_orderleaves":
                orderSummary.fiOrderSummary.placements![0].quotes[0].quantity = 10000;
                break;
            case "spread-original-axe":
                orderSummary.fiOrderSummary.fiAsset!.bondQuality = "IG";
                orderSummary.fiOrderSummary.placements![0].quotes[0].spread = 111.0;
                break;
            case "broker-repeated-original-axe":
                // need to make broker quote same as what original is
                orderSummary.fiOrderSummary.placements![0].quotes[0].price = 222.0;
                orderSummary.fiOrderSummary.placements![0].quotes[0].quantity = 100;
                break;
            case "broker-repeated-nocounterparty":
                // need to make broker quote same as what original is
                orderSummary.fiOrderSummary.placements![0].quotes[0].price = 222.0;
                orderSummary.fiOrderSummary.placements![0].quotes[0].quantity = 100;
                (orderSummary.fiOrderSummary.placements![0].quotes[0].counterparty as any) = {
                    ticker: null,
                    shortName: null,
                    code: 0
                };
                break;
            case "broker-new-counter-original-axe":
                // same quantity, diff price
                orderSummary.fiOrderSummary.placements![0].quotes[0].price = 333.0;
                orderSummary.fiOrderSummary.placements![0].quotes[0].quantity = 100;
                break;
            case "broker-new-nocounterparty":
                // same quantity, diff price
                orderSummary.fiOrderSummary.placements![0].quotes[0].price = 333.0;
                orderSummary.fiOrderSummary.placements![0].quotes[0].quantity = 100;
                (orderSummary.fiOrderSummary.placements![0].quotes[0].counterparty as any) = {
                    ticker: null,
                    shortName: null,
                    code: 0
                };
                break;
            case "broker-new-counter-diff-price-original-axe":
                // same quantity, diff price
                orderSummary.fiOrderSummary.placements![0].quotes[0].price = 333.0;
                break;
            case "broker-new-counter-diff-quantity-original-axe":
                // same price, diff quantity
                orderSummary.fiOrderSummary.placements![0].quantity = 100.0;
                orderSummary.fiOrderSummary.placements![0].quotes[0].price = 111.0;
                orderSummary.fiOrderSummary.placements![0].quotes[0].quantity = 200;
                break;
            case "broker-rejected-original-axe":
                // need to make broker quote same as what original is
                orderSummary.fiOrderSummary.placements![0].modifyReason = "REJECTED";
                orderSummary.fiOrderSummary.placements![0].quotes[0].price = 0;
                orderSummary.fiOrderSummary.placements![0].quotes[0].quantity = 0;
                break;
            case "broker-counter-expire":
                orderSummary.fiOrderSummary.placements![0].modifyReason = "Quote Expired";
                break;
            case "broker-accepted-goodFor-stub":
                cy.wait(1000);
                cy.clock(expTime, ["setInterval", "setTimeout"]);
                break;
            case "broker-accepted-nocounterparty":
                (orderSummary.fiOrderSummary.placements![0].quotes[0].counterparty as any) = {
                    ticker: null,
                    shortName: null,
                    code: 0
                };
                break;
            case "due-in-expire-rw-user":
                orderSummary.fiOrderSummary.placements![0].modifiedBy = "svc_trading_rw";
                break;
            case "due-in-expire-ro-user":
                orderSummary.fiOrderSummary.placements![0].modifiedBy = "svc_trading_ro";
                break;
            case "due-in-expire-no-user":
                orderSummary.fiOrderSummary.placements![0].modifiedBy = "";
                break;
            case "live-states-plcmt-spread-others-price":
            case "dead-states-plcmt-spread-others-price":
                orderSummary.fiOrderSummary.placements![0].placementGenFields = [
                    {
                        "key": "numOfCompetitors",
                        "value": "1"
                    },
                    {
                        "key": "axeLevel",
                        "value": "33.0"
                    },
                    {
                        "key": "axeQty",
                        "value": "100"
                    }
                ];
                break;
            case "broker-mismatch":
                orderSummary.fiOrderSummary.placements![0].quotes[0].counterparty.code = 987;
                break;
            case "order-side-mismatch":
                orderSummary.fiOrderSummary.placements![0].quotes[0].side = "ASK";
                break;
        }

        // code now expects in UTC unixtime format
        orderSummary.fiOrderSummary.placements![0].quotes[0].expTime = expTime;

        setupGraphQLIntercepts({ editedFixtures: { order } });
        setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
        visit(url);
        waitFor("brokerEntity");
        waitFor("orders");
        waitFor("prices");
        waitFor("benchmark");
    });
});

Given(
    "I am loading a HY order via CARE that will fail due to a {} API error: {}",
    (apiName: string, errorMessage: string) => {
        const url = "/index.html?orderNumber=505126084&side=Sell&cusip=02005NBM1&workflow=CARE&user=testuser";
        const workflowError = convertToWorkflowEnum(apiName, errorMessage);
        Cypress.env().workflow = "CARES";
        setupGraphQLIntercepts({ workflowError: [workflowError] });
        setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
        visit(url);
        waitFor("brokerEntity");
        waitFor("care");
    }
);

Given("I have loaded a broker with no desks", () => {
    const url =
        "/index.html?orderNumber=484303085&side=Buy&aid=DemoData-mbehal-1632382145442&asize=2000000&aprice=0&aspread=88.95&ayield=0&aytype=&aquality=IG&acode=61860&abroker=SIMEQ&abmk=91282CCB5&atime=ThuSep23202100:30:06GMT-0700(PacificDaylightTime)&cusip=92343VGJ7&user=testuser";
    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    visit(url);
    waitFor("brokerEntity");
    waitFor("orders");
});

Given("I have loaded a broker with no allocations", () => {
    const url =
        "/index.html?orderNumber=605125984&embedded=true&side=Buy&cusip=02005NBM1&aquality=HY&theme=light&user=testuser&aid=DemoData-mbehal-1632209898689&asize=1000000&aprice=103.238&aspread=0&ayield=0&aytype=0Type&abmk=&acode=61380&abroker=SIMEQ&atime=2021-09-21T07:38:51.000Z";
    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    visit(url);
    waitFor("brokerEntity");
    waitFor("orders");
});

Given("I have loaded an IG order", () => {
    const url =
        "/index.html?orderNumber=484134985&side=Buy&aid=DemoData-test1&cusip=92343VGJ7&asize=8505000&&aspread=86&ayield=0&aytype=&aquality=IG&abmk=91282CCB5&acode=12&abroker=MSIOI&atime=2021-08-17T18:03:08.000Z&user=testuser";
    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    visit(url);
    waitFor("brokerEntity");
    waitFor("orders");
    waitFor("prices");
    waitFor("benchmark");
});

Given("I have loaded an IG order with composite price enabled", () => {
    const url =
        "/index.html?orderNumber=484134985&side=Buy&aid=DemoData-test1&cusip=92343VGJ7&asize=8505000&&aspread=86&ayield=0&aytype=&aquality=IG&abmk=91282CCB5&acode=12&abroker=MSIOI&atime=2021-08-17T18:03:08.000Z&user=testuser";
    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    cacheRequiredTokens({ COMPOSITE_PRICE_ENABLED: "True" });
    visit(url);
    waitFor("brokerEntity");
    waitFor("orders");
    waitFor("prices");
    waitFor("benchmark");
    setupMDPIntercepts([
        {
            type: "TWEB_COMPOSITE_PRICE_INFO_PUSH",
            payload: {
                twebCompositePriceDTO: {
                    assetId: "91282CDB4",
                    orderSide: "BUY",
                    askPrice: 94.68359375,
                    bidPrice: 94.625
                }
            }
        }
    ]);
});

Given("I have loaded an IG order with a mix of restrictions", () => {
    const url =
        "/index.html?orderNumber=484135088&side=Sell&aid=DemoData-test1&cusip=92343VGJ7&asize=6000000&aprice=0&aspread=88.95&ayield=0&aytype=&aquality=IG&abmk=91282CCB5&acode=25,4036,4053&abroker=JPMIOI&atime=2021-08-17T18:03:08.000Z&user=testuser";
    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    visit(url);
    waitFor("brokerEntity");
    waitFor("orders");
    waitFor("prices");
    waitFor("benchmark");
});

Given("I have loaded an IG order with restrictions", () => {
    const url =
        "/index.html?orderNumber=484135085&side=Sell&aid=DemoData-test1&cusip=92343VGJ7&asize=6000000&aprice=0&aspread=88.95&ayield=0&aytype=&aquality=IG&abmk=91282CCB5&acode=25,4036&abroker=JPMIOI&atime=2021-08-17T18:03:08.000Z&user=testuser";
    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    visit(url);
    waitFor("brokerEntity");
    waitFor("orders");
    waitFor("prices");
    waitFor("benchmark");
});

Given("I have loaded an IG indicative countering sell order", () => {
    const url =
        "/index.html?orderNumber=484135089&side=Sell&aid=DemoData-test1&cusip=92343VGJ7&asize=1000000&aprice=0&aspread=88.95&ayield=0&aytype=&aquality=IG&abmk=91282CCB5&acode=25,4036&abroker=JPMIOI&atime=2021-08-17T18:03:08.000Z&user=testuser&mode=COUNTERING_ONLY";
    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    visit(url);
    waitFor("brokerEntity");
    waitFor("orders");
    waitFor("prices");
    waitFor("benchmark");
});

Given("I have loaded an IG indicative countering order with restrictions", () => {
    const url =
        "/index.html?orderNumber=484135086&side=Sell&aid=DemoData-test1&cusip=92343VGJ7&asize=1000000&aprice=0&aspread=88.95&ayield=0&aytype=&aquality=IG&abmk=91282CCB5&acode=25,4036&abroker=JPMIOI&atime=2021-08-17T18:03:08.000Z&user=testuser&mode=COUNTERING_ONLY";
    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    visit(url);
    waitFor("brokerEntity");
    waitFor("orders");
    waitFor("prices");
    waitFor("benchmark");
});

Given("I have loaded an IG indicative countering order with a single restriction", () => {
    const url =
        "/index.html?orderNumber=484135087&side=Sell&aid=DemoData-test1&cusip=92343VGJ7&asize=1000000&aprice=0&aspread=88.95&ayield=0&aytype=&aquality=IG&abmk=91282CCB5&acode=25,4036&abroker=JPMIOI&atime=2021-08-17T18:03:08.000Z&user=testuser&mode=COUNTERING_ONLY";
    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    visit(url);
    waitFor("brokerEntity");
    waitFor("orders");
    waitFor("prices");
    waitFor("benchmark");
});

Given("I have loaded an IG order with a broker enabled for delayed spot time", () => {
    const url =
        "/index.html?orderNumber=485911985&side=Sell&cusip=92343VGJ7&aquality=IG&theme=light&user=testuser&aid=DemoData&asize=1000000&aprice=0&aspread=88.95&ayield=0&aytype=0Type&abmk=91282CCB5&acode=25,4036&abroker=JPMIOI&atime=2021-09-15T22:05:41.000Z";
    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    visit(url);
    waitFor("brokerEntity");
    waitFor("orders");
    waitFor("prices");
    waitFor("benchmark");
});

Given("I have loaded an IG order with no spread enabled brokers", () => {
    const url =
        "/index.html?orderNumber=484135185&side=Buy&aid=DemoData-test1&cusip=92343VGJ7&asize=8505000&aprice=0&aspread=86&ayield=0&aytype=&aquality=IG&abmk=91282CCB5&acode=12&abroker=MSIOI&atime=2021-08-17T18:03:08.000Z&user=testuser";
    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    visit(url);
    waitFor("brokerEntity");
    waitFor("orders");
});

Given("I have loaded an IG order with a spread enabled broker", () => {
    const url =
        "/index.html?orderNumber=484135285&side=Buy&aid=DemoData-test1&cusip=92343VGJ7&asize=8505000&aprice=0&aspread=86&ayield=0&aytype=&aquality=IG&abmk=91282CCB5&acode=12&abroker=MSIOI&atime=2021-08-17T18:03:08.000Z&user=testuser";
    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    visit(url);
    waitFor("brokerEntity");
    waitFor("orders");
});

Given("I have loaded an IG order via CARE with a broker that is not spread enabled", () => {
    const url = "/index.html?orderNumber=484135385&side=Buy&cusip=92343VGJ7&user=testuser&workflow=CARE";
    Cypress.env().workflow = "CARES";
    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    visit(url);
    waitFor("brokerEntity");
    waitFor("care");
    waitFor("prices");
});

Given(
    "I have loaded an IG order with MiFID eligible asset, no MiFID enabled brokers, client is MiFID eligible, user associated is MiFID eliigible",
    () => {
        const url =
            "/index.html?orderNumber=484135385&side=Buy&aid=DemoData-test1&cusip=92343VGJ7&asize=8505000&aprice=0&aspread=86&ayield=0&aytype=&aquality=IG&abmk=91282CCB5&acode=12&abroker=MSIOI&atime=2021-08-17T18:03:08.000Z&user=testuser";
        setupGraphQLIntercepts({});
        setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
        visit(url);
        waitFor("brokerEntity");
        waitFor("orders");
    }
);

Given(
    "I have loaded an IG order with MiFID eligible asset, MiFID enabled brokers, client is MiFID eligible, user associated is not MiFID eliigible",
    () => {
        const url =
            "/index.html?orderNumber=484135485&side=Buy&aid=DemoData-test1&cusip=92343VGJ7&asize=8505000&aprice=0&aspread=86&ayield=0&aytype=&aquality=IG&abmk=91282CCB5&acode=12&abroker=MSIOI&atime=2021-08-17T18:03:08.000Z&user=testuser";
        setupGraphQLIntercepts({});
        setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
        visit(url);
        waitFor("brokerEntity");
        waitFor("orders");
        waitFor("prices");
        waitFor("benchmark");
    }
);

Given(
    "I have loaded an IG order with MiFID eligible asset, no MiFID enabled brokers, client is MiFID ineligible, user associated is MiFID eliigible",
    () => {
        const url =
            "/index.html?orderNumber=484135585&side=Buy&aid=DemoData-test1&cusip=92343VGJ7&asize=8505000&aprice=0&aspread=86&ayield=0&aytype=&aquality=IG&abmk=91282CCB5&acode=12&abroker=MSIOI&atime=2021-08-17T18:03:08.000Z&user=testuser";
        setupGraphQLIntercepts({});
        cacheRequiredTokens({
            AladdinTraderMIFIDEligible: "false"
        });
        setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
        visit(url);
        waitFor("brokerEntity");
        waitFor("orders");
        waitFor("prices");
        waitFor("benchmark");
    }
);

Given(
    "I have loaded an IG order with MiFID eligible asset, no MiFID enabled brokers, client is MiFID eligible, user associated is not MiFID eliigible",
    () => {
        const url =
            "/index.html?orderNumber=484135586&side=Buy&aid=DemoData-test1&cusip=92343VGJ7&asize=8505000&aprice=0&aspread=86&ayield=0&aytype=&aquality=IG&abmk=91282CCB5&acode=12&abroker=MSIOI&atime=2021-08-17T18:03:08.000Z&user=testuser";
        setupGraphQLIntercepts({});
        setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
        visit(url);
        waitFor("brokerEntity");
        waitFor("orders");
        waitFor("prices");
        waitFor("benchmark");
    }
);

Given("I have loaded an IG order via CARE", () => {
    const url = "/index.html?orderNumber=484135185&side=Buy&cusip=92343VGJ7&workflow=CARE&user=testuser";
    Cypress.env().workflow = "CARES";
    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    setupSecuritySearchIntercept();
    visit(url);
    waitFor("brokerEntity");
    waitFor("care");
    waitFor("prices");
    waitFor("benchmark");
});

Given("I have loaded an IG order via CARE with a valid MKTX Benchmark", () => {
    const url = "/index.html?orderNumber=484135185&side=Buy&cusip=92343VGJ7&workflow=CARE&user=testuser";
    Cypress.env().workflow = "CARES";
    setupGraphQLIntercepts({});
    setupTelemetryIntercept();
    setupSecuritySearchIntercept();
    visit(url, { mktxBenchmark: true });
    waitFor("brokerEntity");
    waitFor("care");
    waitFor("prices");
    waitFor("benchmark");
});

Given("I have loaded an IG order via CARE with restrictions", () => {
    const url = "/index.html?orderNumber=384135185&side=Sell&cusip=92343VGJ7&workflow=CARE&user=testuser";
    Cypress.env().workflow = "CARES";
    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    visit(url);
    waitFor("brokerEntity");
    waitFor("care");
    waitFor("prices");
    waitFor("benchmark");
});

Given(
    "I am loading an IG order via CARE that will fail due to a {} API error: {}",
    (apiName: string, errorMessage: string) => {
        const url =
            "/index.html?orderNumber=505126084&side=Sell&cusip=02005NBM1&workflow=CARE&user=testuser&aquality=IG";
        const workflowError = convertToWorkflowEnum(apiName, errorMessage);
        Cypress.env().workflow = "CARES";
        setupGraphQLIntercepts({ workflowError: [workflowError] });
        setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
        setupSecuritySearchIntercept();
        visit(url);
        waitFor("brokerEntity");
        waitFor("care");
    }
);

Given("I am loading an IG order that will fail due to a {} API error: {}", (apiName: string, errorMessage: string) => {
    const url =
        "/index.html?orderNumber=484134985&side=Buy&aid=DemoData-test1&cusip=92343VGJ7&asize=8505000&aprice=0&aspread=86&ayield=0&aytype=&aquality=IG&abmk=91282CCB5&acode=12&abroker=MSIOI&atime=2021-08-17T18:03:08.000Z&user=testuser";
    const workflowError = convertToWorkflowEnum(apiName, errorMessage);
    setupGraphQLIntercepts({ workflowError: [workflowError] });
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    visit(url);
    waitFor("brokerEntity");
    waitFor("orders");
    waitFor("prices");
    waitFor("benchmark");
});

Given("I have loaded an A2A HY BUY order", () => {
    const url =
        "/index.html?orderNumber=637418485&side=Buy&cusip=92343VGJ7&aquality=HY&aoid=787705991&aid=DemoData-qauser22-1663302290479&asize=400000&aytype=&abmk=&atime=2022-09-16T04:25:39.000Z&abrokerfee=0.7&acounterpartytype=1&acounterpartyrating=3&acode=1947&abroker=TWEB&mode=AXE_A2A&user=testuser&aprice=102";

    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    setupDecodesIntercept("EMPTY");
    visit(url);
    waitFor("brokerEntity");
    waitFor("a2a");
});

Given("I have loaded an A2A HY SELL order", () => {
    const url =
        "/index.html?orderNumber=637418487&side=Sell&cusip=92343VGJ7&aquality=HY&aoid=787705991&aid=DemoData-qauser22-1663302290479&asize=400000&aytype=&abmk=&atime=2022-09-16T04:25:39.000Z&abrokerfee=-0.45&acounterpartytype=1&acounterpartyrating=3&acode=1947&abroker=TWEB&mode=AXE_A2A&user=testuser&aprice=102";

    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    setupDecodesIntercept("EMPTY");
    visit(url);
    waitFor("brokerEntity");
    waitFor("a2a");
});

Given("I have loaded an A2A HY order that expires in {} seconds", (seconds: string) => {
    cy.window().then((win) => {
        const ms = parseInt(seconds) * 1000;
        const expiryTime = new Date(win.Date()).getTime() + ms;

        const url = `/index.html?orderNumber=637418485&side=Buy&cusip=92343VGJ7&aquality=HY&aoid=787705991&aid=DemoData-qauser22-1663302290479&asize=400000&aytype=&abmk=&atime=2022-09-16T04:25:39.000Z&abrokerfee=0.7&acounterpartytype=1&acounterpartyrating=3&acode=1947&abroker=TWEB&mode=AXE_A2A&user=testuser&aexpirytime=${expiryTime}`;

        setupGraphQLIntercepts({});
        setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
        setupDecodesIntercept("EMPTY");
        visit(url);
        waitFor("brokerEntity");
        waitFor("a2a");

        cy.wait(ms > 0 ? ms : 1000);
        cy.tick(ms > 0 ? ms + 1000 : 1000);
    });
});

Given("I have loaded an A2A IG BUY order", () => {
    const url =
        "/index.html?orderNumber=637418485&side=Buy&cusip=92343VGJ7&aquality=IG&aoid=787705991&aid=DemoData-qauser22-1663302290479&asize=400000&aytype=&abmk=91282CCB5&atime=2022-09-16T04:25:39.000Z&abrokerfee=-0.00256&acounterpartytype=1&acounterpartyrating=3&acode=1947&abroker=TWEB&mode=AXE_A2A&user=testuser&aspread=101.2";

    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    setupDecodesIntercept("EMPTY");
    visit(url);
    waitFor("brokerEntity");
    waitFor("a2a");
    waitFor("prices");
});

Given("I have loaded an A2A IG SELL order", () => {
    const url =
        "/index.html?orderNumber=637418487&side=Sell&cusip=92343VGJ7&aquality=IG&aoid=787705991&aid=DemoData-qauser22-1663302290479&asize=400000&aytype=&abmk=91282CCB5&atime=2022-09-16T04:25:39.000Z&abrokerfee=0.0070&acounterpartytype=1&acounterpartyrating=3&acode=1947&abroker=TWEB&mode=AXE_A2A&user=testuser&aspread=101.2";

    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    setupDecodesIntercept("EMPTY");
    visit(url);
    waitFor("brokerEntity");
    waitFor("a2a");
    waitFor("prices");
});

Given("I have loaded an A2A HY order with an axe price type of spread", () => {
    const url =
        "index.html?orderNumber=637418485&side=Buy&cusip=92343VGJ7&aquality=HY&aoid=787705991&aid=DemoData-qauser22-1663302290479&asize=400000&aytype=&abmk=91282CCB5&atime=2022-09-16T04:25:39.000Z&abrokerfee=0.7&acounterpartytype=1&acounterpartyrating=3&acode=1947&abroker=TWEB&mode=AXE_A2A&user=testuser&aspread=101.2&apricetype=AXE_PRICE_TYPE_SPREAD";

    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    setupDecodesIntercept("EMPTY");
    visit(url);
    waitFor("brokerEntity");
    waitFor("a2a");
    waitFor("prices");
});

Given("I have loaded an A2A IG order with spot times", () => {
    const url =
        "/index.html?orderNumber=637418486&side=Buy&cusip=92343VGJ7&aquality=IG&aoid=787705991&aid=DemoData-qauser22-1663302290479&asize=400000&aytype=&abmk=91282CCB5&atime=2022-09-16T04:25:39.000Z&abrokerfee=0.0070&acounterpartytype=1&acounterpartyrating=3&acode=1947&abroker=TWEB&mode=AXE_A2A&user=testuser&aspread=101.2";

    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    setupDecodesIntercept("AT_BENCH2SPOT");
    visit(url);
    waitFor("brokerEntity");
    waitFor("a2a");
    waitFor("prices");
});

Given("I have loaded an A2A HY order with broker decodes", () => {
    const url =
        "/index.html?orderNumber=637418485&side=Buy&cusip=92343VGJ7&aquality=HY&aoid=787705991&aid=DemoData-qauser22-1663302290479&asize=400000&aytype=&abmk=&atime=2022-09-16T04:25:39.000Z&abrokerfee=0.7&acounterpartytype=1&acounterpartyrating=3&acode=1947&abroker=TWEB&mode=AXE_A2A&user=testuser&aprice=102";

    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    setupDecodesIntercept("PLACEMENT_SEND");
    visit(url);
    waitFor("brokerEntity");
    waitFor("a2a");
});

Given("I have loaded an A2A IG order with a minimum size of {}", (minSize: number) => {
    const url = `/index.html?orderNumber=637418485&side=Buy&cusip=92343VGJ7&aquality=IG&aoid=787705991&aid=DemoData-qauser22-1663302290479&asize=400000&aytype=&abmk=91282CCB5&atime=2022-09-16T04:25:39.000Z&abrokerfee=0.0070&acounterpartytype=1&acounterpartyrating=3&acode=1947&abroker=TWEB&mode=AXE_A2A&user=testuser&aspread=101.2&aminsize=${minSize}`;

    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    setupDecodesIntercept("EMPTY");
    visit(url);
    waitFor("brokerEntity");
    waitFor("a2a");
    waitFor("prices");
});

Given(
    "I am loading a Countering workflow that will fail due to a {} API error: {}",
    (apiName: string, errorMessage: string) => {
        const url =
            "/index.html?orderNumber=540561285&workflow=countered&placement=196021185&cusip=00033AAA6&theme=light&user=testuser&abmk=912810SU3&acode=61860&abroker=SIMEQ1860&abroker=SIMEQ";
        const workflowError = convertToWorkflowEnum(apiName, errorMessage);
        setupGraphQLIntercepts({ workflowError: [workflowError] });
        setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
        visit(url);
    }
);

Given("I have an order with attributes", (table: TableDefinition) => {
    let params: string[] = [];
    table.hashes().forEach((elem) => {
        if (elem["key"] === "order") params.unshift(elem["value"]);
        else params.push(`${elem["key"]}=${elem["value"]}`);
        // if (elem["key"] === "cusip") cusip = elem["value"];
    });
    let url = params.join("&").replace(params[0] + "&", "/index.html?orderNumber=" + params[0] + "&");
    setupGraphQLIntercepts({});
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    visit(url);
});

Given("I have an order with attributes that will fail because {}", (error: string, table: TableDefinition) => {
    let params: string[] = [];
    table.hashes().forEach((elem) => {
        if (elem["key"] === "order") params.unshift(elem["value"]);
        else params.push(`${elem["key"]}=${elem["value"]}`);
    });
    let url = params.join("&").replace(params[0] + "&", "/index.html?orderNumber=" + params[0] + "&");
    const workflowError = convertToWorkflowEnum(error);
    setupGraphQLIntercepts({ workflowError: [workflowError] });
    setupCommonIntercepts({ filesDat: "AT_benchmark_date" });
    visit(url);
});

Given("the date is {}", (date: string) => {
    const components = date.split("/"); // MM / DD / YYYY
    const s = components[2] + "-" + components[0] + "-" + components[1] + "T04:00:00.000Z";
    const d = new Date(s);
    cy.clock(new Date(d).getTime(), ["Date"]);
});

Given("the time is frozen and the date is {}", (date: string) => {
    cy.clock().invoke("restore");
    const components = date.split("/"); // MM / DD / YYYY
    const s = components[2] + "-" + components[0] + "-" + components[1] + "T04:00:00.000Z";
    const d = new Date(s);
    cy.clock(new Date(d).getTime(), ["Date", "setInterval", "setTimeout", "clearInterval", "clearTimeout"]);
});

Given("the API calls will have status", (table: TableDefinition) => {
    let errorList: WorkflowError[] = [];
    table.hashes().forEach((elem) => {
        if (elem["status"] === "failure") {
            errorList.push(convertToWorkflowEnum(elem["API"], elem["reason"]));
        }
    });
    setupGraphQLIntercepts({ workflowError: errorList });
    setupExecutionIntercepts({ workflowError: errorList });
});

Given("I have the following live streaming prices", (table: TableDefinition) => {
    cy.window().then((win: any) => {
        const payload = {};
        table.hashes().forEach((price) => {
            payload[price["Source"]] = {
                bid: price["Bid"],
                ask: price["Ask"],
                bidSpread: price["Bid Spread"],
                askSpread: price["Ask Spread"]
            };
        });

        win.store.dispatch({
            type: "LIVE_PRICES",
            payload
        });
    });
});

/*************************
 **** ASSERT UI ELEMS ****
 *************************/
// And header should have attributes
//  |num|value|state}
Then("header should have attributes", (table: TableDefinition) => {
    assertAuxStepper(table.hashes().length, table);
});

// And Lift Table should have attributes
//  |key|value|
Then("{} table should have attributes", (tableName: string, table: TableDefinition) => {
    assertTable(tableName.toLowerCase(), table);
});

// And Lift[Lift] form should have attributes
//  |key|value|type
Then("{} form should have attributes", (formName: string, table: TableDefinition) => {
    assertForm(formName, table);
});

// And Confirmation form should have attributes
//  |key|value
Then("{} popup should have attributes", (formName: string, table: TableDefinition) => {
    assertPopup(formName, table);
});

// And Alert dialog should have attributes
//  |key|value
Then("{} dialog should have attributes", (formName: string, table: TableDefinition) => {
    assertDialog(formName, table);
});

// And Next button should be enabled
Then("[{}] should be {}", (control: string, command: string) => {
    if (control.includes("splitbutton")) {
        // for selecting more complicated elements without direct data-test-id access IE Aladdin Web Components
        performCommand(control, command);
    } else {
        verifyElementState(control, command, false);
    }
});

// And Next should not be enabled
Then("[{}] should not be {}", (control: string, command: string) => {
    verifyElementState(control, command, true);
});

// I should see a warning alert notification
Then("I should see a {} {} notification", (style: string, type: "restrictions" | "alert" | "message bar") => {
    assertAuxNotification({ type, style });
});

// I should see a warning alert notification for [minTrdSize]
Then(
    "I should see a {} {} notification for [{}]",
    (style: string, type: "restrictions" | "alert" | "message bar", message: string) => {
        assertAuxNotification({ type, style }, message);
    }
);

// I should not see a warning alert notification for [minTrdSize]
Then(
    "I should not see a {} {} notification for [{}]",
    (style: string, type: "restrictions" | "alert" | "message bar", message: string) => {
        assertAuxNotification({ type, style }, message, true);
    }
);

// I close error alert notification
Then("I close {} {} notification", (style: string, type: "restrictions" | "alert" | "message bar") => {
    closeAuxNotification({ type, style });
});

// I should see a yellow message bar with message [Confirm Cancel]
Then("I should see a {} message bar with message [{}]", (color: string, message: string) => {
    let style = "error";
    if (color === "green") style = "success";
    if (color === "yellow") style = "warning";
    assertAuxNotification({ type: "message bar", style }, message);
});

// And Lift[Lift] form should show error
// | key  | error | type |
Then("{} form should {} error", (formName: string, type: "show" | "not show", table: TableDefinition) => {
    assertFormError(formName, table, type);
});

// And Lift[Lift] form have disabled fields
// | key  | error | type |
Then("{} form should have disabled fields", (formName: string, table: TableDefinition) => {
    assertFormFieldsMode(formName, table, false);
});

// And Lift[Lift] form have enabled fields
// | key  | error | type |
Then("{} form should have enabled fields", (formName: string, table: TableDefinition) => {
    assertFormFieldsMode(formName, table, true);
});

//  And I should see 2 options for restrictions
// | num | key | value
Then("I should see {} options for {}", (numOptions: number, control: string, table?: TableDefinition) => {
    let selector;
    switch (control) {
        case "restrictions":
            for (let i = 0; i < numOptions; i++) {
                selector = `[${DATA_TEST_ID_PREFIX}"restrictioncard${i + 1}"]`;
                assertAuxCard(selector, table!, i);
            }
            break;
        default:
            selector = control;
    }
});

Then("element {} contains text {}", (element: string, text: string) => {
    // this is a substring test
    assertElementContainsText(element, text);
});

Then("element {} should have text {}", (element: string, text: string) => {
    // this is an exact test for text content
    assertElementHasText(element, text);
});

Then("button {} should have label {}", (element: string, text: string) => {
    // this is an exact test for text content
    assertElementHasLabel(element, text);
});

Then("element {} exists", (element: string) => {
    assertElementExists(element);
});

Then("element {} does not exist", (element: string) => {
    assertElementNotExists(element);
});

// for asserting AUX Select Option State
Then("select option {} should be {}", (value: string, state: string) => {
    assertSelectOptionState(value, state);
});

Then(`{}-pricingprotocol should be disabled`, (element: string) => {
    const selector = `[${DATA_TEST_ID_PREFIX}"${element}-pricingprotocol"]`;
    cy.get(selector).find('[data-test="aux-radio--input"]').should("be.disabled");
});

Then(`{}-pricingprotocol should be enabled`, (element: string) => {
    const selector = `[${DATA_TEST_ID_PREFIX}"${element}-pricingprotocol"]`;
    cy.get(selector).find('[data-test="aux-radio--input"]').should("be.enabled");
});

Then("icon {} has type {}", (selector: string, type: string) => {
    cy.get(`[${DATA_TEST_ID_PREFIX}"${selector}"]`).invoke("attr", "type").should("contain", type);
});

Then("I verify select {} has option set to {}", (element: string, value: string) => {
    assertAuxSelectText(element, value);
});

Then("I see {} elements for this selector {} under {}", (num: string, selector: string, element: string) => {
    const n = parseInt(num);
    assertNumElements(n, selector, element === "none" ? undefined : element);
});

Then("the {} {} benchmark is not editable", (table: string, type: string) => {
    let selector = `${removeSpace(table)}-${type}bmk`;

    cy.get(`[${DATA_TEST_ID_PREFIX}"${selector}"]`).find("aux-icon[type='edit']").should("not.exist");
});

/*************************
 ******** UTILITY ********
 *************************/

// And console logs should contain
// | value
Then("console logs should contain", (table: TableDefinition) => {
    assertConsole(table);
});

Then("I dispatch {}", (payload: any) => {
    dispatchStore(payload);
});

Then("I verify store slice {} has state {}", (slice: string, state: any) => {
    verifyStore(slice, state);
});

Then("I verify localStorage has state {}", (state: any) => {
    verifyLocalStorage(state);
});

Then("I pop a {} dialog with text {}", (type: AlertType, message: string) => {
    const alert: Alert = {
        id: 1,
        message: message,
        type: type
    };
    dispatchStore(setAlert([alert]));
});

// And I have style [{offsetWidth: 60px}] for [Counter-Placement]
Then("I have style {} for [{}]", (style: string, control: string) => {
    verifyStyle(control, style);
});

// And I have classname filled-broker for [simjs-filled-row]
Then("I have classname {} for [{}]", (classname: string, control: string) => {
    control = removeSpace(control);
    const selector = getTestSelector(control);
    cy.get(selector).should("have.attr", "class", classname);
});

/*******************************
 **** PERFORM USER ACTIONS  ****
 *******************************/

// for selecting an AUX Select option from dropdown
Then("I select option {}", (value: string) => {
    selectOption(value);
});

// And I have clicked [Next]
Then("I have {} [{}]", (command: string, control: string) => {
    performCommand(control, command);
});

// When I populate the Lift[Lift] form with
//  | key  | value | type  |
Then("I populate the {} form with", (formName: string, table: TableDefinition) => {
    populateForm(formName, table);
});

// And I press/release Ctrl Shift X or C
Then("I {} Ctrl Shift {}", (command: string, key: string) => {
    performCtrlShift(key, removeSpace(command) === "release");
});

Then("I select the {} header option", (n: string) => {
    const num = convertNumberStringToNumber(n);
    setAuxStepper(num);
});

Then("I {} the {} restriction", (action: string, n: string) => {
    const num = convertNumberStringToNumber(n);
    const selector = `[${DATA_TEST_ID_PREFIX}"restrictioncard${num + 1}"]`;
    toggleExpandOnAuxCard(selector, num);
});

Then(`I set the {} radio group to {}`, (name: string, category: string) => {
    const selector = `[${DATA_TEST_ID_PREFIX}${name}]`;
    cy.get(selector).find(`aux-radio[label="${category}"]`).find("input").click({ force: true });
});

Then("I see select options for [{}]", (control: string, table: TableDefinition) => {
    let options: string[] = [];
    table.hashes().forEach((elem) => {
        options.push(elem["option"]);
    });
    performCommand(control, "opened select");
    assertAuxSelectDropdownOptions(control, options);
    // close dropdown by clicking outside of it to return to normal state
    cy.get("body").click(0, 0);
});

Then("I click to edit the {} {} benchmark", (table: string, type: string) => {
    let selector = `${removeSpace(table)}-${type}bmk`;

    cy.get(`[${DATA_TEST_ID_PREFIX}"${selector}"]`).find("aux-icon").click({ multiple: true, force: true });
    cy.get(`[${DATA_TEST_ID_PREFIX}"${selector}"]`).find("aux-text-input").should("be.visible");
});

Then("I type {} in the {} {} benchmark", (value: string, table: string, type: string) => {
    let selector = `${removeSpace(table)}-${type}bmk`;
    cy.get(`[${DATA_TEST_ID_PREFIX}"${selector}"]`).find("aux-text-input").find("input").type(value, { force: true });
});

Then("I see no {} result in the {} {} benchmark", (value: string) => {
    cy.get(`.aux-type-ahead__table-cell div[title="${value}"]`).should("not.exist");
});

Then("I set the {} {} benchmark to {}", (table: string, type: string, value: string) => {
    let selector = `${removeSpace(table)}-${type}bmk`;
    cy.get(`[${DATA_TEST_ID_PREFIX}"${selector}"]`).find("aux-text-input").find("input").type(value, { delay: 50 });
    cy.wait(1000);
    cy.get(`.aux-type-ahead__table-cell div[title="${value}"]`).click();
});

Then("I right click to open context menu and click on {}", (menuItem: string) => {
    const selector = "context-menu";

    cy.get("body").rightclick();
    cy.get(`[${DATA_TEST_ID_PREFIX}"${selector}"]`).contains(menuItem).click();
});

Then("I click on {} key", (key: string) => {
    cy.get("body").type(`{${key}}`);
});

/**************************
 **** WAIT FOR THINGS  ****
 **************************/

Then("Broker entities has completed", () => {
    waitFor("brokerEntity");
});

Then("HY CARE order has loaded", () => {
    waitFor("brokerEntity");
    waitFor("care");
});

Then("IG CARE order has loaded", () => {
    waitFor("brokerEntity");
    waitFor("care");
    waitFor("prices");
    waitFor("benchmark");
});

Then("HY order has loaded", () => {
    // wait that we have data
    waitFor("brokerEntity");
    waitFor("orders");
});

Then("IG order has loaded", () => {
    // wait that we have data
    waitFor("brokerEntity");
    waitFor("orders");
    waitFor("prices");
    waitFor("benchmark");
});

// And Validate Quick Place has finished
Then("{} has finished", (control: string) => {
    waitFor(control);
});

// And Validate Quick Place has not finished
Then("{} has not finished", (control: string) => {
    calledAtMostOnce(control);
});

// And Validate Quick Place has finished with req variables
Then("{} has finished with", (control: string, table: TableDefinition) => {
    waitFor(control, table);
});

Then("I wait for the page to change", () => {
    cy.wait(1000);
});

Then("I wait {} secs", (secs: string) => {
    cy.wait(parseInt(secs) * 1000);
});

// NOTE: Be careful using this with API calls, ATW will return "REJECTED" if it passes 5-10 seconds by default.
// Waiting for a GQL to be finished won't work here since the ATW wrapper is what dispatches the "REJECTED" action
Then("{} {} pass", (amount: string, timeUnit: "secs" | "mins" | "hours") => {
    let miliseconds;
    switch (timeUnit) {
        case "secs":
            miliseconds = parseInt(amount) * 1000;
            break;
        case "mins":
            miliseconds = parseInt(amount) * 60000;
            break;
        case "hours":
            miliseconds = parseInt(amount) * 3600000;
            break;
    }
    cy.tick(miliseconds);
    // re-focus on cypress body in case tick unfocuses it
    cy.get("body").click(0, 0);
});

Then("I wait until {} state is ready", (state: string) => {
    // wait until the redux state of (order,axe,lift)
    cy.waitUntil(() =>
        cy.window().then((win: any) => {
            let appState: AppState = win.store.getState();
            switch (state) {
                case "order":
                    return appState.orderInfo.order.hasValidData;
                case "axe":
                    return appState.axeInfo.axe.hasValidData;
                case "trade form":
                    return appState.tradeFormInfo.tradeForm.hasValidData;
                default:
                    return true;
            }
        })
    );
});
