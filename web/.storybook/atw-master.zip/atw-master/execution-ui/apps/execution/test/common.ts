/// <reference types="cypress" />

import { PriceInfo } from "@atx/commons/benchmark/useBenchmark";
import { TableDefinition } from "cypress-cucumber-preprocessor";
import { CyHttpMessages } from "cypress/types/net-stubbing";
import { genericUtils } from "../src/common/utils";
import {
    ApiAliases,
    ApiQuery,
    cleanJSON,
    convertTableDefinitionToList,
    DATA_TEST_ID_PREFIX,
    getTestSelector,
    getWaitString,
    stripAllWhitespace,
    WorkflowError
} from "./common.utils";

// PUT ANY REUSABLE UTIL FUNCTIONS HERE

// https://github.com/annaet/cypress-cucumber-typescript-example/tree/custom-parameters
// https://cucumber.io/docs/cucumber/cucumber-expressions/#parameter-types

const { removeSpace } = genericUtils;
const lib = {
    a2a: ApiQuery.ORDER_A2A_QUERY,
    benchmark: ApiQuery.BENCHMARK_QUERY,
    prices: ApiQuery.PRICES_QUERY,
    orders: ApiQuery.ORDER_QUERY,
    orderLeaves: ApiQuery.ORDERLEAVES_QUERY,
    care: ApiQuery.ORDER_CARE_QUERY,
    brokerentity: ApiQuery.BROKER_QUERY,
    validatequickplace: ApiQuery.VALIDATE_PLACEMENTS_MUTATION,
    quickplace: ApiQuery.QUICK_PLACE_QUERY,
    counteraccept: ApiQuery.COUNTER_ACCEPT_QUERY,
    validatecounteraccept: ApiQuery.VALIDATE_PLACEMENTS_EXECUTION_MUTATION,
    validatecountercounter: ApiQuery.VALIDATE_PLACEMENTS_EXECUTION_MUTATION,
    validaterequestplacementquote: ApiQuery.VALIDATE_PLACEMENTS_COUNTERING_MUTATION,
    counterpass: ApiQuery.COUNTER_PASS_QUERY,
    requestplacementquote: ApiQuery.REQUEST_PLACEMENT_QUOTE_QUERY,
    countercounter: ApiQuery.COUNTER_COUNTER_QUERY,
    cancelerrorplacements: ApiQuery.CANCEL_ERROR_PLACEMENTS_MUTATION
};

export function visit(url: string, config?: { mktxBenchmark: boolean }) {
    cy.visit(url, {
        onBeforeLoad(window: any) {
            cy.spy(window.console, "log").as("consoleLog");
            cy.spy(window.console, "warn").as("consoleWarn");
            cy.spy(window.console, "error").as("consoleError");

            const host = {
                query(name, payload) {
                    switch (name) {
                        case "MKTXS_BENCHMARK":
                            if (!config?.mktxBenchmark) return null;

                            return "912810SU3";
                        case "FETCH_TWEB_COMPOSITE_PRICE":
                            return {
                                assetId: "91282CDB4",
                                askPrice: 94.68359375,
                                bidPrice: 94.625
                            } as PriceInfo;
                        default:
                            throw "bfmCefQuery not available"; // WARN: Cypress wraps this in its own Cypress.Error
                    }
                }
            };

            window.bfmCefQuery = function ({ request, onSuccess, onFailure }) {
                try {
                    const index = request.indexOf(":");
                    const name = index < 0 ? request : request.slice(0, index);
                    const payload = index < 0 ? undefined : request.slice(index + 1);
                    onSuccess(host.query(name, payload));
                } catch (error: any) {
                    onFailure(0, error.message);
                }
            };
            cy.spy(host, "query").as("queryHost");
        }
    });
}

export function assertConsole(table: TableDefinition) {
    table.hashes().forEach((elem) => {
        let msg = elem["log"];
        cy.get(`@consoleLog`).should("be.calledWith", msg);
    });
}

type gqlFixtures = {
    order?: any;
    requestPlacementQuote?: any;
};

type setupGraphQLInterceptsConfig = {
    workflowError?: WorkflowError[];
    editedFixtures?: gqlFixtures;
};

export function setupGraphQLIntercepts({ workflowError, editedFixtures }: setupGraphQLInterceptsConfig) {
    return cy.intercept("POST", "/oemsgqlserver/graphql", (req) => {
        const query = stripAllWhitespace(req.body.query);
        if (query.includes(ApiQuery.BROKER_QUERY)) {
            req.alias = ApiAliases[ApiQuery.BROKER_QUERY];
            if (workflowError?.find((e) => e === WorkflowError.BROKER_QUERY_RESPONSE_NULL)) {
                req.reply({
                    body: null
                });
            } else if (workflowError?.find((e) => e === WorkflowError.BROKER_QUERY_RESPONSE_DATA_NULL)) {
                req.reply({
                    body: {}
                });
            } else if (workflowError?.find((e) => e === WorkflowError.BROKER_QUERY_RESPONSE_DATA_FIORDERSUMMARY_NULL)) {
                req.reply({ fixture: "emptyDataResponse" });
            } else if (
                workflowError?.find((e) => e === WorkflowError.BROKER_QUERY_RESPONSE_DATA_BROKERALLOCATIONS_NULL)
            ) {
                req.reply({ fixture: "brokerEntities/nullBrokerEntity" });
            } else if (workflowError?.find((e) => e === WorkflowError.BROKER_QUERY_RESPONSE_HAS_GQL_ERRORS)) {
                req.reply({ fixture: "brokerEntities/gqlErrors" });
            } else {
                req.reply({ fixture: "brokerEntities/success" });
            }
        } else if (query.includes(ApiQuery.ORDER_A2A_QUERY)) {
            req.alias = ApiAliases[ApiQuery.ORDER_A2A_QUERY];

            const ordNum = req.body.variables.ordNum;
            req.reply({ fixture: `orders/${ordNum}` });
        } else if (query.includes(ApiQuery.ORDER_CARE_QUERY)) {
            req.alias = ApiAliases[ApiQuery.ORDER_CARE_QUERY];
            if (workflowError?.find((e) => e === WorkflowError.ORDER_CARE_QUERY_RESPONSE_NULL)) {
                req.reply({
                    body: null
                });
            } else if (workflowError?.find((e) => e === WorkflowError.ORDER_CARE_QUERY_RESPONSE_DATA_NULL)) {
                req.reply({
                    body: {}
                });
            } else if (
                workflowError?.find((e) => e === WorkflowError.ORDER_CARE_QUERY_RESPONSE_DATA_FIORDERSUMMARY_NULL)
            ) {
                req.reply({ fixture: "emptyDataResponse" });
            } else {
                const ordNum = req.body.variables.ordNum;
                req.reply({ fixture: `care/${ordNum}` });
            }
        } else if (query.includes(ApiQuery.ORDER_QUERY)) {
            req.alias = ApiAliases[ApiQuery.ORDER_QUERY];
            if (workflowError?.find((e) => e === WorkflowError.ORDER_QUERY_RESPONSE_NULL)) {
                req.reply({
                    body: null
                });
            } else if (workflowError?.find((e) => e === WorkflowError.ORDER_QUERY_RESPONSE_DATA_NULL)) {
                req.reply({
                    body: {}
                });
            } else if (workflowError?.find((e) => e === WorkflowError.ORDER_QUERY_RESPONSE_DATA_FIORDERSUMMARY_NULL)) {
                req.reply({ fixture: "emptyDataResponse" });
            } else if (workflowError?.find((e) => e === WorkflowError.ORDER_QUERY_RESPONSE_HAS_GQL_ERRORS)) {
                req.reply({ fixture: `order/gqlErrors` });
            } else if (editedFixtures) {
                req.reply(editedFixtures.order);
            } else {
                const ordNum = req.body.variables.ordNum;
                req.reply({ fixture: `orders/${ordNum}` });
            }
        } else if (query.includes(ApiQuery.PRICES_QUERY)) {
            req.alias = ApiAliases[ApiQuery.PRICES_QUERY];
            if (workflowError?.find((e) => e === WorkflowError.PRICES_RESPONSE_NULL)) {
                req.reply({
                    body: null
                });
            } else if (workflowError?.find((e) => e === WorkflowError.PRICES_RESPONSE_DATA_NULL)) {
                req.reply({
                    body: {}
                });
            } else if (workflowError?.find((e) => e === WorkflowError.PRICES_RESPONSE_DATA_PRICES_NULL)) {
                req.reply({ fixture: "emptyDataResponse" });
            } else if (workflowError?.find((e) => e === WorkflowError.PRICES_RESPONSE_DATA_PRICES_EMPTY)) {
                req.reply({ fixture: "prices/pricesEmpty" });
            } else if (workflowError?.find((e) => e === WorkflowError.PRICES_RESPONSE_DATA_INDEX_NAME_NULL)) {
                req.reply({ fixture: "prices/indexNameNull" });
            } else {
                const cusip = req.body.variables.cusips[0];
                req.reply({ fixture: `prices/${cusip}` });
            }
        } else if (query.includes(ApiQuery.BENCHMARK_QUERY)) {
            req.alias = ApiAliases[ApiQuery.BENCHMARK_QUERY];
            if (workflowError?.find((e) => e === WorkflowError.BENCHMARK_RESPONSE_NULL)) {
                req.reply({
                    body: null
                });
            } else if (workflowError?.find((e) => e === WorkflowError.BENCHMARK_RESPONSE_DATA_NULL)) {
                req.reply({
                    body: {}
                });
            } else if (workflowError?.find((e) => e === WorkflowError.BENCHMARK_RESPONSE_DATA_FIASSET_NULL)) {
                req.reply({ fixture: "emptyDataResponse" });
            } else if (workflowError?.find((e) => e === WorkflowError.BENCHMARK_RESPONSE_DATA_BASSET_NULL)) {
                req.reply({ fixture: "bond-benchmark/bAssetNull" });
            } else {
                const secId = req.body.variables.secId;
                req.reply({
                    fixture: `bond-benchmark/${secId}`
                });
            }
        } else if (query.includes(ApiQuery.ORDERLEAVES_QUERY)) {
            req.alias = ApiAliases[ApiQuery.ORDERLEAVES_QUERY];
            if (workflowError?.find((e) => e === WorkflowError.ORDERLEAVES_QUERY_RESPONSE_NULL)) {
                req.reply({
                    body: null
                });
            } else if (workflowError?.find((e) => e === WorkflowError.ORDERLEAVES_QUERY_RESPONSE_DATA_NULL)) {
                const orderNumber = req.body.variables.ordNum;
                req.reply({ fixture: `newOrderLeaves/${orderNumber}-null-data` });
            } else if (workflowError?.find((e) => e === WorkflowError.ORDERLEAVES_QUERY_RESPONSE_CHANGED_ORDERLEAVES)) {
                const orderNumber = req.body.variables.ordNum;
                req.reply({ fixture: `newOrderLeaves/${orderNumber}` });
            } else {
                const orderNumber = req.body.variables.ordNum;
                const folderName = Cypress.env().workflow === "CARES" ? "care" : "orders";
                req.reply({ fixture: `${folderName}/${orderNumber}` });
            }
        }
        {
            executionIntercepts({ req, workflowError, editedFixtures });
        }
    });
}

export function setupSecuritySearchIntercept() {
    cy.intercept("POST", "/bms/request/app/explore/securitySearch", (req) => {
        req.reply({
            fixture: "security-search/default"
        });
    });
}

export function setupTelemetryIntercept() {
    cy.intercept("POST", "/statcollector/v1/eventlogger/execution-ui", {
        statusCode: 200
    });
}

export function setupPrefIntercept() {
    cy.intercept("POST", "/weblications/etc/setPrefs.epl*", {
        statusCode: 200
    });
    cy.intercept("GET", "/weblications/etc/getPrefs.epl*", {
        statusCode: 200
    });
}

export function setupFilesDatIntercept(datFileName: string = "AT_benchmark_date") {
    cy.intercept("GET", "/std/files.dat", (req) => {
        req.reply({
            fixture: `filesDat/${datFileName}`,
            headers: { "last-modified": "Wed, 30 Nov 2022 18:34:55 GMT" }
        });
    }).as("filesDat");
}

export function setupDecodesIntercept(decodeFileName: string) {
    cy.intercept("GET", `/api/reference-data/decodes/v1/decode*`, (req) => {
        req.reply({
            fixture: `decodes/${decodeFileName}`
        });
    }).as("getDecodes");
}

type CommonIntercepts = {
    filesDat: string;
};

export function setupCommonIntercepts(commonIntercepts: CommonIntercepts) {
    setupFilesDatIntercept(commonIntercepts.filesDat);
    setupTelemetryIntercept();
    setupPrefIntercept();
    setupSecuritySearchIntercept();
}

type executionInterceptsConfig = {
    req: CyHttpMessages.IncomingHttpRequest;
    workflowError?: WorkflowError[];
    editedFixtures?: gqlFixtures;
};

export function executionIntercepts({ req, workflowError, editedFixtures }: executionInterceptsConfig) {
    const query = stripAllWhitespace(req.body.query);
    if (workflowError && workflowError.length > 0) {
        workflowError = workflowError.map((error) => WorkflowError[error]);
    }
    if (query.includes(ApiQuery.VALIDATE_PLACEMENTS_MUTATION)) {
        req.alias = ApiAliases[ApiQuery.VALIDATE_PLACEMENTS_MUTATION];
        if (workflowError?.find((e) => e === WorkflowError.VALIDATE_PLACEMENTS_MUTATION_MIN_AMOUNT)) {
            req.reply({
                fixture: "validation/minSizeError"
            });
        } else if (workflowError?.find((e) => e === WorkflowError.VALIDATE_PLACEMENTS_MUTATION_GENERIC_ERROR)) {
            req.reply({
                fixture: "validation/genericError"
            });
        } else if (
            workflowError?.find((e) => e === WorkflowError.VALIDATE_PLACEMENTS_MUTATION_UNSPECIFIED_RESPONSE_TYPE)
        ) {
            req.reply({
                fixture: "validation/unspecifiedResponseType"
            });
        } else if (workflowError?.find((e) => e === WorkflowError.VALIDATE_PLACEMENTS_MUTATION_RESPONSE_NULL)) {
            req.reply({
                body: null
            });
        } else {
            req.reply({
                fixture: "validation/success"
            });
        }
    } else if (query.includes(ApiQuery.VALIDATE_PLACEMENTS_COUNTERING_MUTATION)) {
        req.alias = ApiAliases[ApiQuery.VALIDATE_PLACEMENTS_COUNTERING_MUTATION];
        if (workflowError?.find((e) => e === WorkflowError.VALIDATE_PLACEMENTS_COUNTERING_MUTATION_MIN_AMOUNT)) {
            req.reply({
                fixture: "validation/minSizeError"
            });
        } else if (
            workflowError?.find((e) => e === WorkflowError.VALIDATE_PLACEMENTS_COUNTERING_MUTATION_GENERIC_ERROR)
        ) {
            req.reply({
                fixture: "validation/genericError"
            });
        } else if (
            workflowError?.find(
                (e) => e === WorkflowError.VALIDATE_PLACEMENTS_COUNTERING_MUTATION_UNSPECIFIED_RESPONSE_TYPE
            )
        ) {
            req.reply({
                fixture: "validation/unspecifiedResponseType"
            });
        } else if (
            workflowError?.find((e) => e === WorkflowError.VALIDATE_PLACEMENTS_COUNTERING_MUTATION_RESPONSE_NULL)
        ) {
            req.reply({
                body: null
            });
        } else {
            req.reply({
                fixture: "validation/success-countering"
            });
        }
    } else if (query.includes(ApiQuery.VALIDATE_PLACEMENTS_EXECUTION_MUTATION)) {
        req.alias = ApiAliases[ApiQuery.VALIDATE_PLACEMENTS_EXECUTION_MUTATION];
        if (workflowError?.find((e) => e === WorkflowError.VALIDATE_PLACEMENTS_EXECUTION_MUTATION_RESPONSE_ERROR)) {
            req.reply({
                fixture: "validation/genericError"
            });
        } else if (
            workflowError?.find((e) => e === WorkflowError.VALIDATE_PLACEMENTS_EXECUTION_MUTATION_RESPONSE_WARNING)
        ) {
            req.reply({
                fixture: "validation/genericWarning"
            });
        } else if (
            workflowError?.find((e) => e === WorkflowError.VALIDATE_PLACEMENTS_EXECUTION_MUTATION_RESPONSE_NULL)
        ) {
            req.reply({
                body: null
            });
        } else {
            req.reply({
                fixture: "validation/success"
            });
        }
    } else if (query.includes(ApiQuery.QUICK_PLACE_QUERY)) {
        req.alias = ApiAliases[ApiQuery.QUICK_PLACE_QUERY];
        if (workflowError?.find((e) => e === WorkflowError.QUICK_PLACE_ERROR)) {
            req.reply({
                fixture: "emptyDataResponse"
            });
        } else if (workflowError?.find((e) => e === WorkflowError.QUICK_PLACE_RESPONSE_NULL)) {
            req.reply({
                body: null
            });
        } else {
            req.reply({
                fixture: "quickPlace/success"
            });
        }
    } else if (query.includes(ApiQuery.REQUEST_PLACEMENT_QUOTE_QUERY)) {
        Cypress.env().api.count.requestplacementquote++;
        req.alias = ApiAliases[ApiQuery.REQUEST_PLACEMENT_QUOTE_QUERY];
        if (workflowError?.find((e) => e === WorkflowError.REQUEST_PLACEMENT_QUOTE_ERROR)) {
            req.reply({
                fixture: "emptyDataResponse"
            });
        } else if (workflowError?.find((e) => e === WorkflowError.REQUEST_PLACEMENT_QUOTE_RESPONSE_NULL)) {
            req.reply({
                body: null
            });
        } else if (workflowError?.find((e) => e === WorkflowError.REQUEST_PLACEMENT_QUOTE_RESPONSE_HAS_GQL_ERRORS)) {
            req.reply({ fixture: `order/gqlErrors` });
        } else if (editedFixtures) {
            req.reply(editedFixtures.requestPlacementQuote);
        } else {
            req.reply({ fixture: `requestPlacementQuote/success` });
        }
    } else if (query.includes(ApiQuery.COUNTER_ACCEPT_QUERY)) {
        req.alias = ApiAliases[ApiQuery.COUNTER_ACCEPT_QUERY];
        if (workflowError?.find((e) => e === WorkflowError.COUNTER_ACCEPT_ERROR)) {
            req.reply({
                fixture: "emptyDataResponse"
            });
        } else if (workflowError?.find((e) => e === WorkflowError.COUNTER_ACCEPT_RESPONSE_NULL)) {
            req.reply({
                body: null
            });
        } else {
            req.reply({
                fixture: "counterAccept/success"
            });
        }
    } else if (query.includes(ApiQuery.COUNTER_COUNTER_QUERY)) {
        req.alias = ApiAliases[ApiQuery.COUNTER_COUNTER_QUERY];
        if (workflowError?.find((e) => e === WorkflowError.COUNTER_COUNTER_ERROR)) {
            req.reply({
                fixture: "emptyDataResponse"
            });
        } else if (workflowError?.find((e) => e === WorkflowError.COUNTER_COUNTER_RESPONSE_NULL)) {
            req.reply({
                body: null
            });
        } else {
            req.reply({
                fixture: "counterCounter/success"
            });
        }
    } else if (query.includes(ApiQuery.COUNTER_PASS_QUERY)) {
        req.alias = ApiAliases[ApiQuery.COUNTER_PASS_QUERY];
        if (workflowError?.find((e) => e === WorkflowError.COUNTER_PASS_ERROR)) {
            req.reply({
                fixture: "emptyDataResponse"
            });
        } else if (workflowError?.find((e) => e === WorkflowError.COUNTER_PASS_RESPONSE_NULL)) {
            req.reply({
                body: null
            });
        } else {
            req.reply({
                fixture: "counterPass/success"
            });
        }
    } else if (query.includes(ApiQuery.CANCEL_ERROR_PLACEMENTS_MUTATION)) {
        req.alias = ApiAliases[ApiQuery.CANCEL_ERROR_PLACEMENTS_MUTATION];
        if (workflowError?.find((e) => e === WorkflowError.CANCEL_ERROR_PLACEMENTS_MUTATION_RESPONSE_ERROR)) {
            req.reply({
                fixture: "emptyDataResponse"
            });
        } else {
            req.reply({
                fixture: "cancelErrorPlacements/success"
            });
        }
    }
}

type setupExecutionInterceptsConfig = {
    req?: CyHttpMessages.IncomingHttpRequest;
    workflowError?: WorkflowError[];
    editedFixtures?: gqlFixtures;
};

export function setupExecutionIntercepts({ workflowError, editedFixtures }: setupExecutionInterceptsConfig) {
    cy.intercept("POST", "/oemsgqlserver/graphql", (req) => {
        executionIntercepts({ req, workflowError, editedFixtures });
    });
}

export function assertTable(tableName: string, table: TableDefinition) {
    const list: any = [];
    table.hashes().forEach((elem) => {
        const key = (removeSpace(tableName) + "-" + removeSpace(elem["key"])).toLowerCase();
        const value = elem["value"];
        list.push({ key, value });
    });
    cy.wrap(list).each((item: any) => {
        if (item.key === "axe-extcounterpartyrating") {
            cy.get(`[${DATA_TEST_ID_PREFIX}"${item.key}"] aux-icon[type="favorite-bold"]`).should(
                "have.length",
                parseInt(item.value, 10)
            );
        } else {
            cy.get(`[${DATA_TEST_ID_PREFIX}"${item.key}"]`).should("have.text", item.value);
        }
    });
}

export function assertPopup(popupName: string, table: TableDefinition) {
    // TODO: improve assertion call here for the table.
    const selector = `[${DATA_TEST_ID_PREFIX}"${removeSpace(popupName)}"]`;
    cy.get(selector).should(($div) => {
        table.hashes().forEach((elem) => {
            expect($div)
                .prop("innerText")
                .to.contain(elem["value"]);
        });
    });
}

export function assertDialog(dialogName: string, table: TableDefinition) {
    const selector = `[${DATA_TEST_ID_PREFIX}"alert-dialog-message"]`;
    const headerEl = `[${DATA_TEST_ID_PREFIX}"alert-dialog"]`;
    const header = table.hashes().find((elem) => elem["key"] === "Header");
    const error = table.hashes().find((elem) => elem["key"] === "Error");

    if (header) cy.get(headerEl).should("have.attr", "header", header["value"]);

    if (error) {
        cy.get(`${selector}`)
            .find("div")
            .should("have.prop", "innerText", error["value"]);
    }
}

export function assertForm(formName: string, table: TableDefinition) {
    const list = convertTableDefinitionToList(table);
    let formTitle = removeSpace(formName);
    let segmentedButtonTitle = formTitle;
    const parts = formTitle.split("[");
    if (parts.length > 1) {
        formTitle = parts[0];
        segmentedButtonTitle = parts[1].substring(0, parts[1].length - 1);
    }

    //Assert form title for execution
    if (formTitle === "lift" || formTitle === "hit") {
        cy.get(`[${DATA_TEST_ID_PREFIX}"${formTitle}"]`).then((dom) => {
            if (dom[0].localName === "aux-segmented-control") {
                // iterate and find which segemented control is 'checked'
                const found = (dom[0] as any).data.find((f) => f.label.toLowerCase() === segmentedButtonTitle);
                assert.isNotNull(found);
                assert(found.checked === true);
            } else {
                const el = (dom as any)[0];
                assert(el.outerText === formName);
            }
        });
    }
    cy.wrap(list).each((item: any) => {
        const selector = `[${DATA_TEST_ID_PREFIX}"${formTitle + "-control-" + item.key}"]`;
        switch (item.type) {
            case "radio":
                assertAuxRadioGroup(selector, item.value, item.mode, item.visible);
                break;
            case "select":
                assertAuxSelect(selector, item.value, item.mode, item.visible);
                break;
            case "date":
                assertAuxDatePicker(selector, item.value, item.mode, item.visible);
            case "input":
                assertAuxInput(selector, item.value, item.mode, item.visible);
                break;
            case "securitylookup":
                assertAuxInput(selector, item.value, item.mode, item.visible);
                break;
            case "time":
                // aux time component add an extra space in it's value before AM/PM
                item.value = item.value.replace(" PM", "  PM").replace(" AM", "  AM");
                assertAuxInput(selector, item.value, item.mode, item.visible);
                break;
            default:
                assertAuxInput(selector, item.value, item.mode, item.visible);
                break;
        }
        if (item.label) {
            const labelSelector = `[${DATA_TEST_ID_PREFIX}"${formTitle + "-" + item.key}"]`;
            cy.get(labelSelector).find("label").first().should("have.text", item.label);
        }
    });
}

export function assertFormError(formName: string, table: TableDefinition, type: "show" | "not show") {
    const list = convertTableDefinitionToList(table);
    const formTitle = removeSpace(formName);

    cy.wrap(list).each((item: any) => {
        const selector = `[${DATA_TEST_ID_PREFIX}"${formTitle + "-" + item.key}"]`;
        switch (item.type) {
            case "type ahead input":
            case "securitylookup":
                assertAuxTypeAheadError(selector, item.error, type);
                break;
            case "date":
                assertAuxDateError(selector, item.error, type);
                break;
            case "select":
                assertAuxSelectError(selector, item.error, type);
                break;
            case "multiselect":
                assertMultiSelectError(selector, item.error, type);
                break;
            case "input":
            case "time":
            default:
                assertAuxInputError(selector, item.error, type);
                break;
        }
    });
}

export function assertFormFieldsMode(formName: string, table: TableDefinition, enabled: boolean) {
    const list = convertTableDefinitionToList(table);
    const formTitle = removeSpace(formName);

    cy.wrap(list).each((item: any) => {
        const control = formTitle + "-control-" + item.key;
        verifyElementState(control, enabled ? "enabled" : "disabled");
    });
}

export function assertAuxStepper(numOptions: number, table: TableDefinition) {
    cy.get('[data-test-id="axe-stepper"]').within(() => {
        cy.get("button").should("have.length", numOptions);
        table.hashes().forEach((elem) => {
            let innerText = elem["value"];
            switch (elem["state"]) {
                case "active":
                    innerText += "- active";
                    break;
                case "completed":
                    innerText += "- complete";
                    break;
                case "disabled":
                default:
                    break;
            }
            const index = parseInt(elem["num"]);
            cy.get("button").eq(index).should("have.text", innerText);
        });
    });
}

export function populateForm(formName: string, table: TableDefinition) {
    const list = convertTableDefinitionToList(table);
    let formTitle = removeSpace(formName);
    const parts = formTitle.split("[");
    if (parts.length > 1) {
        formTitle = parts[0];
    }
    // NOTE: some component have to execute setTimeout/setInterval functions to fully render (Like AuxSelect's dropdown). try using cy.wait or cy.tick
    cy.tick(1000);

    cy.wrap(list).each((item: any) => {
        const key = item.key;
        const type = item.type;
        const value = item.value;
        const selector = `[${DATA_TEST_ID_PREFIX}"${formTitle + "-control-" + key}"]`;
        let fn = (selector, value) => {};

        switch (type) {
            case "select":
                fn = setAuxSelect;
                break;
            case "date":
                fn = setAuxDateInput;
                break;
            case "securitylookup":
                fn = setSecurityLookup;
                break;
            case "time":
                fn = setTimeInput;
                break;
            case "input":
            default:
                fn = setAuxInput;
                break;
        }

        return new Cypress.Promise((resolve) => {
            setTimeout(() => {
                fn(selector, value);
                resolve();
            }, 0);
        });
    });
}

export function assertElementContainsText(element: string, text: string) {
    cy.get(`[${DATA_TEST_ID_PREFIX}"${removeSpace(element)}"]`).contains(text);
}

export function assertElementHasText(element: string, text: string) {
    cy.get(`[${DATA_TEST_ID_PREFIX}"${removeSpace(element)}"]`).should(($div) => {
        expect($div.text().trim()).equal(text);
    });
}

export function assertElementHasLabel(element: string, text: string) {
    cy.get(`[${DATA_TEST_ID_PREFIX}"${removeSpace(element)}"]`)
        .invoke("attr", "label")
        .should("equal", text);
}

export function assertElementExists(element: string) {
    cy.get(`[${DATA_TEST_ID_PREFIX}"${removeSpace(element)}"]`).should("be.visible");
}

export function assertElementNotExists(element: string) {
    cy.get(`[${DATA_TEST_ID_PREFIX}"${removeSpace(element)}"]`).should("not.exist");
}

export function assertNumElements(numElements: number, selector: string, element?: string) {
    // if we pass element - then first find the particular subnode ...then find the selector in question
    if (element) {
        cy.get(`[${DATA_TEST_ID_PREFIX}"${element}"]`).within(() => {
            cy.get(selector).should("have.length", numElements);
        });
    } else {
        cy.get(selector).should("have.length", numElements);
    }
}

export function verifyElementState(control: string, command: string, not?: boolean) {
    control = removeSpace(control);
    const element = cy.get(`[${DATA_TEST_ID_PREFIX}"${control}"]`);
    switch (command) {
        case "checked":
            if (not) {
                element.should("have.prop", "isChecked", false);
            } else {
                element.should("have.prop", "isChecked", true);
            }
            break;
        case "enabled":
            element.should("have.prop", "isDisabled", false);
            break;
        case "disabled":
            expect;
            element.should("have.prop", "isDisabled", true);
            break;
        case "visible":
            if (not) {
                element.should("not.exist");
            } else {
                element.should("be.visible");
            }
            break;
        case "isondualstate":
            element.invoke("prop", "isOnDualState").should("equal", not ? false : true);
            break;
        default: {
            // verify equality
            element.should("have.text", command);
        }
    }
}

export function assertAuxInput(selector: string, value: string, mode?: string, visible?: boolean) {
    if (visible !== undefined) {
        if (!visible) cy.get(selector).should("not.exist");
        return;
    }
    cy.get(selector).within(() => {
        cy.get("input").should("have.value", value);
        if (mode !== undefined) cy.get("input").should("be." + mode);
    });
}

export function assertAuxDatePicker(selector: string, value: string, mode?: string, visible?: boolean) {
    cy.get(selector).should("have.attr", "value", value);
}

export function assertAuxDateError(selector: string, errorMessage: string, type: "show" | "not show") {
    let assertion = {
        show: "contain",
        "not show": "not.contain"
    };
    cy.get(selector).within(() => {
        cy.get('[data-test="aux-date-input"]').should(assertion[type], errorMessage);
    });
}

export function assertAuxSelectError(selector: string, errorMessage: string, type: "show" | "not show") {
    let assertion = {
        show: "contain",
        "not show": "not.contain"
    };
    cy.get(selector).within(() => {
        cy.get('[data-test="aux-select"]').should(assertion[type], errorMessage);
    });
}

export function assertMultiSelectError(selector: string, errorMessage: string, type: "show" | "not show") {
    let assertion = {
        show: "contain",
        "not show": "not.contain"
    };
    cy.get(selector).should(assertion[type], errorMessage);
}

export function assertAuxInputError(selector: string, errorMessage: string, type: "show" | "not show") {
    let assertion = {
        show: "contain",
        "not show": "not.contain"
    };
    cy.get(selector).within(() => {
        cy.get('[data-test="aux-input-mask"]').should(assertion[type], errorMessage);
    });
}

export function assertAuxTypeAheadError(selector: string, errorMessage: string, type: "show" | "not show") {
    let assertion = {
        show: "contain",
        "not show": "not.contain"
    };
    cy.get(selector).within(() => {
        cy.get('[data-test="aux-type-ahead"]').should(assertion[type], errorMessage);
    });
}
export function assertAuxNotification(
    config: { type: "restrictions" | "alert" | "message bar"; style: string },
    message?: string,
    not?: boolean
) {
    const typeMap = {
        restrictions: "restrictions-notification-group",
        alert: "alerts-notification-group",
        "message bar": "message-bar"
    };
    const selector = `[${DATA_TEST_ID_PREFIX}"${typeMap[config.type]}"]`;
    // needed to force showing of aux notification when cy.clock freezes setTimeout since aux notification uses setTimeout.....
    // TODO: find a way to fine grain control on when cy.clock can control setTimeout....
    cy.wait(1000);
    cy.tick(500);

    if (not) {
        try {
            cy.get(selector).should("not.exist");
        } catch (_) {
            // in this case - there is a notification ...but are these the droids we are looking for?
            cy.get("aux-notification-group")
                .find("aux-notification")
                .should(($notification) => {
                    expect($notification).attr("message").to.not.contain(message);
                });
        }
    } else {
        cy.get(selector).find("aux-notification").should("be.visible");
        cy.get(selector).find("aux-notification").should("have.attr", "notification-style", removeSpace(config.style));
        if (message) {
            cy.get(selector).find("aux-notification").invoke("attr", "message").should("contain", message);
        }
    }
}

export function closeAuxNotification(config: { type: "restrictions" | "alert" | "message bar"; style: string }) {
    const typeMap = {
        restrictions: "restrictions-notification-group",
        alert: "alerts-notification-group",
        "message bar": "message-bar"
    };
    const selector = `[${DATA_TEST_ID_PREFIX}"${typeMap[config.type]}"]`;
    cy.get(selector).find("aux-notification").find("button").click();
}

export function assertAuxCard(selector: string, table: TableDefinition, num: number) {
    const list = convertTableDefinitionToList(table).filter((elem) => elem.num === num + 1);

    cy.get(selector).should(($card) => {
        list.forEach((elem) => {
            expect($card).prop("innerText").to.contain(elem.value);
        });
    });
}

export function assertAuxSelectText(control: string, value: string) {
    const selector = `[${DATA_TEST_ID_PREFIX}"${removeSpace(control)}"]`;
    assertAuxSelect(selector, value);
}

export function assertAuxSelect(selector: string, value: string, mode?: string, visible?: boolean) {
    if (visible === true) {
        return cy.get(selector).should("exist");
    }
    if (visible == false) {
        return cy.get(selector).should("not.exist");
    }

    cy.get(selector).within((dom) => {
        if (mode !== undefined) {
            if (mode === "enabled") {
                assert((dom[0] as any).isDisabled === false);
            } else assert((dom[0] as any).isDisabled === true);
        }
        cy.get("input")
            .invoke("prop", "title")
            .should(($res) => {
                expect($res).to.equal(value);
            });
    });
}

export function assertAuxRadioGroup(selector: string, value: string, mode?: string, visible?: boolean) {
    if (visible === true) {
        return cy.get(selector).should("exist");
    }
    if (visible == false) {
        return cy.get(selector).should("not.exist");
    }

    cy.get(selector).within((dom) => {
        if (mode !== undefined) {
            if (mode === "enabled") {
                assert((dom[0]["data"][0] as any).disabled === false);
            } else assert((dom[0]["data"][0] as any).disabled === true);
        }
        cy.get(`aux-radio[label=${value}]`)
            .invoke("prop", "isChecked")
            .should(($res) => {
                expect($res).to.equal(true);
            });
    });
}

export function assertAuxSelectDropdownOptions(control: string, options: string[]) {
    const selector = `[${DATA_TEST_ID_PREFIX}"${removeSpace(control)}"]`;
    cy.get(`.aux-overlay__dropdown-container`).within(() => {
        cy.get('[data-aux-node-name="aux-option"]').should("have.length", options.length);
        options.forEach((option) => {
            cy.get(`[data-aux-node-name="aux-option"][data-aux-display-value="${option}"]`).should("contain", option);
        });
    });
}

export function setAuxSelect(selector: string, value: string) {
    cy.get(selector).find(`div[data-aux-display-value="${value}"]`).click({ force: true });
}

export function setAuxInput(selector: string, value: string) {
    // neeed to sometimes delete the 0 that gets set after clearing an input, which happens in spread and size input, type(`{del}${value}`)
    // Issue pops up when setTimeout is frozen with cypress cy.clock. cy.tick(1000) &&  cy.get("body").click(0, 0) work for size, but not spread....these have Imasks as part of the aux input
    // which use setTimeout.....
    cy.get(selector)
        // possibly due to aux input mask issues, when you focus on input, it actually focuses on the aux input mask element itself which is why we have to do force: true here
        .find("input")
        .click()
        .clear({ force: true })
        // needed to warm up cypress because sometimes the first character dissappears
        .type(`{del}${value}`, { force: true })
        .clear({ force: true })
        .type(`{del}${value}`, { force: true })
        .blur({ force: true });
}

export function setTimeInput(selector: string, value: string) {
    cy.get(selector).find("input").click().clear({ force: true }).type(value, { force: true });
    // finding and blurring it again to ensure blur is actually occuring
    cy.get(selector).find("input").click().blur({ force: true });
}

export function setSecurityLookup(selector: string, value: string) {
    cy.get(selector).find("aux-text-input").find("input").clear({ force: true }).type(value, { force: true });
    cy.wait(1000);
    cy.get(`.aux-overlay__dropdown-container`).then(($cell) => {
        const dropdownRow = $cell.find(`div[title="${value}"]`);
        if (dropdownRow.length) {
            return dropdownRow.trigger("click");
        } else {
            // if no result, click away to show error
            cy.get(selector).blur();
        }
    });
}

export function setAuxDateInput(selector: string, value: string) {
    cy.get(selector)
        .within(() => {
            cy.wait(1500);
            cy.get("input").type(value, { force: true });
        })
        .then((dom) => {
            cy.get("body").click(0, 0);
            (dom[0] as any).validate();
            cy.get("body").click(0, 0);
        });
}

export function setAuxStepper(num: number) {
    cy.get('[data-test-id="axe-stepper"]').within(() => {
        cy.get("button").eq(num).click({ force: true });
    });
}

export function toggleExpandOnAuxCard(selector: string, num: number) {
    cy.get(selector).within(() => {
        cy.get(`[${DATA_TEST_ID_PREFIX}"expander"]`).click({ force: true });
    });
}
export function pressButtonAuxDialog(dialogName: string, buttonValue: string) {
    const selector = `[data-test="aux-dialog"]`;
    cy.get(selector).within(() => {
        cy.get("aux-button[label=" + buttonValue + "]").click({ force: true });
    });
}

export function selectOption(value: string) {
    const selector = `[data-aux-id="${value}"]`;
    cy.get(selector).click({ force: true, multiple: true });
}

export function assertSelectOptionState(value: string, state: string) {
    const selector = `[data-aux-id="${value}"]`;
    switch (state) {
        case "disabled":
            cy.get(selector).should("have.attr", "aria-disabled", "true");
            break;
    }
}

export function performCommand(control: string, command: string) {
    if (control.includes("dialog")) {
        const split = control.split("dialog");
        const dialogName = split[0].trim();
        const buttonLabel = split[1].split("button")[0].trim();
        pressButtonAuxDialog(dialogName, buttonLabel);
    } else {
        let splitButtonIndex = -1;
        if (control.includes("splitbutton")) {
            const parts = control.split(" ");
            control = parts[0];
            splitButtonIndex = parseInt(parts[1].split("-")[1]);
        }
        control = removeSpace(control);
        const selector = getTestSelector(control);
        switch (command) {
            case "clicked element":
                cy.get(selector).click();
                break;
            case "clicked":
                if (splitButtonIndex !== -1) {
                    cy.get(selector).within(() => {
                        cy.get("input").eq(splitButtonIndex).click({ force: true });
                    });
                } else {
                    cy.get(selector).within(() => {
                        cy.get("button").click();
                    });
                }
                break;
            case "clicked into":
                if (splitButtonIndex !== -1) {
                    cy.get(selector).within(() => {
                        cy.get("input").eq(splitButtonIndex).click({ force: true });
                    });
                } else {
                    cy.get(selector).click({ force: true });
                }
                break;
            case "checked":
                cy.get(selector).find("input").click({ force: true });
                break;
            case "opened select":
                cy.get(selector).within(() => {
                    cy.get("button").click({ force: true });
                });
                break;
            case "hovered":
                cy.get(selector).trigger("mouseover");
                break;
            case "disabled":
                if (splitButtonIndex !== -1) {
                    cy.get(selector).within(() => {
                        cy.get("input").eq(splitButtonIndex).should("be.disabled");
                    });
                } else cy.get(selector).should("be.disabled");
                break;
            case "enabled":
                if (splitButtonIndex !== -1) {
                    cy.get(selector).within(() => {
                        cy.get("input").eq(splitButtonIndex).should("be.enabled");
                    });
                } else cy.get(selector).should("be.enabled");
                break;
            default:
                break;
        }
    }
}

export function verifyStyle(control: string, styles: string) {
    const styleList = JSON.parse(styles);
    control = removeSpace(control);
    const selector = getTestSelector(control);
    cy.get(selector).then((dom) => {
        const node = dom[0];
        styleList.forEach((style) => {
            const key = Object.keys(style)[0];
            const val = style[key];
            assert(node[key].toString() === val);
        });
    });
}

export function dispatchStore(json: any) {
    cy.window().then((win: any) => {
        if (typeof json === "string") {
            let cleanedJSON = cleanJSON(json);
            const action = JSON.parse(cleanedJSON);
            return win.store.dispatch(action);
        }
        return win.store.dispatch(json);
    });
}

export function verifyStore(slicePath: string, jsonValue: string) {
    cy.window().then((win: any) => {
        let cleanedJSON = cleanJSON(jsonValue);
        let state = win.store.getState();
        const subSlice = slicePath.split(".");
        for (let entry of subSlice) {
            state = state[entry];
        }
        // at this point state is what we want to look for ... stringify and match
        const jsonState = JSON.stringify(state);
        assert(jsonState === cleanedJSON);
    });
}

export function verifyLocalStorage(jsonValue: string) {
    cy.window().then((win: any) => {
        const localStorage = JSON.stringify(window.localStorage);
        assert(localStorage === jsonValue);
    });
}

export function performCtrlShift(key: string, release: boolean) {
    if (release) {
        cy.get("body").focus().type("{esc}", { force: true, release: true });
    } else {
        cy.get("body").focus().type(`{ctrl+${key}}`, { force: true, release: false });
    }
}

export function calledAtMostOnce(control: string) {
    return cy.window().then(() => {
        control = removeSpace(control);
        if (Cypress.env().api.count[control] !== undefined) {
            expect(Cypress.env().api.count[control]).to.be.lessThan(2);
        }
    });
}

export function waitFor(control?: string, table?: TableDefinition, timeout: number = 5000) {
    control = control ? removeSpace(control) : "";
    if (!table) {
        return cy.wait(getWaitString(lib[control]), { timeout });
    }

    let req = {};
    table.hashes().forEach((elem) => {
        req[elem["key"]] = elem["value"];
    });

    return cy
        .wait(getWaitString(lib[control]), { timeout })
        .its("request.body.variables.request")
        .should("contain", req);
}
