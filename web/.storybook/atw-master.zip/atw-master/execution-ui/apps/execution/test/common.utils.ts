import { TableDefinition } from "cypress-cucumber-preprocessor";
import { genericUtils } from "../src/common/utils/genericUtils";

// API / INTERCEPT UTILS
export enum ApiQuery {
    BROKER_QUERY = "queryfiOrderSummary($ordNum:Int!){fiOrderSummary(ordNum:$ordNum){brokerEntity{",
    ORDER_QUERY = "queryfiOrderSummary($ordNum:Int!,$user:String!,$brokerList:[Int!]){fiOrderSummary(ordNum:$ordNum,user:$user,brokerList:$brokerList){order{",
    ORDERLEAVES_QUERY = "queryfiOrderSummary($ordNum:Int!){fiOrderSummary(ordNum:$ordNum){order{orderLeaves}}}",
    ORDER_CARE_QUERY = "queryfiOrderSummary($ordNum:Int!,$user:String!,$care:Boolean!){fiOrderSummary(ordNum:$ordNum,user:$user,care:$care){",
    ORDER_A2A_QUERY = "queryfiOrderSummary($ordNum:Int!,$user:String!,$brokerList:[Int!],$a2a:Boolean!){fiOrderSummary(ordNum:$ordNum,user:$user,brokerList:$brokerList,a2a:$a2a){",
    VALIDATE_PLACEMENTS_MUTATION = "mutationvalidatePlacements($request:MultiQuickPlaceRequest,$user:String){validatePlacements(request:$request,user:$user){",
    VALIDATE_PLACEMENTS_COUNTERING_MUTATION = "mutationvalidatePlacementsCountering($request:PlacementQuoteRequest!,$warnings:String,$user:String){validatePlacementsCountering(request:$request,warnings:$warnings,user:$user){",
    VALIDATE_PLACEMENTS_EXECUTION_MUTATION = "mutationvalidatePlacementsExecution($request:PlacementQuoteExecute!,$user:String){validatePlacementsExecution(request:$request,user:$user){",
    QUICK_PLACE_QUERY = "mutationmultiQuickPlace($request:MultiQuickPlaceRequest,$user:String){multiQuickPlace(request:$request,user:$user){",
    REQUEST_PLACEMENT_QUOTE_QUERY = "mutationrequestPlacementQuote($request:PlacementQuoteRequest!,$user:String){requestPlacementQuote(request:$request,user:$user){",
    COUNTER_ACCEPT_QUERY = "mutationexecutePlacementQuote($request:PlacementQuoteExecute!,$user:String){executePlacementQuote(request:$request,user:$user){order{ordNum},placements{placementNum,statusquotes{quoteID,price,quantitycounterparty{ticker}}}}}",
    COUNTER_COUNTER_QUERY = "mutationcounterPlacementQuote($request:PlacementQuoteExecute!,$user:String){counterPlacementQuote(request:$request,user:$user){",
    COUNTER_PASS_QUERY = "mutationpassPlacementQuotes($placementNumList:[Int!],$user:String!){passPlacementQuotes(placementNumList:$placementNumList,user:$user){",
    PRICES_QUERY = "queryprices($cusips:[String!],$startInclusive:BFMTimestamp){prices(cusips:$cusips,startInclusive:$startInclusive){",
    BENCHMARK_QUERY = "queryfiAsset($secId:String){fiAsset(secId:$secId){",
    GET_FILES_DAT = "/std/files.dat",
    GET_DECODES = "/api/reference-data/decodes/v1/decode?sets=",
    CANCEL_ERROR_PLACEMENTS_MUTATION = "mutationcancelErrorPlacements($placementNumList:[Int!],$user:String!){"
}
export const ApiAliases = {
    [ApiQuery.BROKER_QUERY]: "gqlBrokers",
    [ApiQuery.ORDER_QUERY]: "gqlOrder",
    [ApiQuery.ORDERLEAVES_QUERY]: "gqlOrderLeaves",
    [ApiQuery.ORDER_CARE_QUERY]: "gqlOrderCare",
    [ApiQuery.ORDER_A2A_QUERY]: "gqlOrderA2A",
    [ApiQuery.VALIDATE_PLACEMENTS_MUTATION]: "gqlValidatePlacements",
    [ApiQuery.VALIDATE_PLACEMENTS_COUNTERING_MUTATION]: "gqlValidatePlacementsCountering",
    [ApiQuery.QUICK_PLACE_QUERY]: "gqlQuickPlace",
    [ApiQuery.REQUEST_PLACEMENT_QUOTE_QUERY]: "gqlRequestPlacementQuote",
    [ApiQuery.PRICES_QUERY]: "gqlPrices",
    [ApiQuery.BENCHMARK_QUERY]: "gqlBenchmark",
    [ApiQuery.COUNTER_ACCEPT_QUERY]: "gqlCounterAccept",
    [ApiQuery.COUNTER_PASS_QUERY]: "gqlCounterPass",
    [ApiQuery.COUNTER_COUNTER_QUERY]: "gqlCounterCounter",
    [ApiQuery.VALIDATE_PLACEMENTS_EXECUTION_MUTATION]: "gqlValidatePlacementsExecution",
    [ApiQuery.GET_FILES_DAT]: "getFilesDat",
    [ApiQuery.GET_DECODES]: "getDecodes",
    [ApiQuery.CANCEL_ERROR_PLACEMENTS_MUTATION]: "gqlCancelErrorPlacements"
};

export const DATA_TEST_ID_PREFIX = "data-test-id=";

export const getTestSelector = (key: string) => `[${DATA_TEST_ID_PREFIX}"${key}"]`;

export function getWaitString(query: ApiQuery): string {
    return "@" + [ApiAliases[query]];
}

// FORM UTILS
export interface AuxFormDefinition {
    type?: string;
    key?: string;
    label?: string;
    mode?: string;
    value?: any;
    error?: any;
    num?: number;
    visible?: boolean;
}

export function convertTableDefinitionToList(table: TableDefinition): AuxFormDefinition[] {
    const list: AuxFormDefinition[] = [];
    table.hashes().forEach((elem) => {
        const type = elem["type"];
        const key = genericUtils.removeSpace(elem["key"]);
        const label = elem["label"];
        const value = elem["value"];
        const error = elem["error"];
        const num = parseInt(elem["num"]);
        const mode = elem["mode"];
        const visible = elem["visible"] ? elem["visible"] === "true" : undefined;
        list.push({ key, label, value, type, error, num, mode, visible });
    });
    return list;
}

// ERROR UTILS
export enum WorkflowError {
    BROKER_QUERY_RESPONSE_NULL = "BROKER_QUERY_RESPONSE_NULL",
    BROKER_QUERY_RESPONSE_DATA_NULL = "BROKER_QUERY_RESPONSE_DATA_NULL",
    BROKER_QUERY_RESPONSE_DATA_FIORDERSUMMARY_NULL = "BROKER_QUERY_RESPONSE_DATA_FIORDERSUMMARY_NULL",
    BROKER_QUERY_RESPONSE_DATA_BROKERALLOCATIONS_NULL = "BROKER_QUERY_RESPONSE_DATA_BROKERALLOCATIONS_NULL",
    BROKER_QUERY_RESPONSE_HAS_GQL_ERRORS = "BROKER_QUERY_RESPONSE_HAS_GQL_ERRORS",

    ORDER_QUERY_RESPONSE_NULL = "ORDER_QUERY_RESPONSE_NULL",
    ORDER_QUERY_RESPONSE_DATA_NULL = "ORDER_QUERY_RESPONSE_DATA_NULL",
    ORDER_QUERY_RESPONSE_DATA_FIORDERSUMMARY_NULL = "ORDER_QUERY_RESPONSE_DATA_FIORDERSUMMARY_NULL",
    ORDER_QUERY_RESPONSE_HAS_GQL_ERRORS = "ORDER_QUERY_RESPONSE_HAS_GQL_ERRORS",

    ORDER_CARE_QUERY_RESPONSE_NULL = "ORDER_CARE_QUERY_RESPONSE_NULL",
    ORDER_CARE_QUERY_RESPONSE_DATA_NULL = "ORDER_CARE_QUERY_RESPONSE_DATA_NULL",
    ORDER_CARE_QUERY_RESPONSE_DATA_FIORDERSUMMARY_NULL = "ORDER_CARE_QUERY_RESPONSE_DATA_FIORDERSUMMARY_NULL",

    PRICES_RESPONSE_NULL = "PRICES_RESPONSE_NULL",
    PRICES_RESPONSE_DATA_NULL = "PRICES_RESPONSE_DATA_NULL",
    PRICES_RESPONSE_DATA_PRICES_NULL = "PRICES_RESPONSE_DATA_PRICES_NULL",
    PRICES_RESPONSE_DATA_PRICES_EMPTY = "PRICES_RESPONSE_DATA_PRICES_EMPTY",
    PRICES_RESPONSE_DATA_INDEX_NAME_NULL = "PRICES_RESPONSE_DATA_INDEX_NAME_NULL",

    BENCHMARK_RESPONSE_NULL = "BENCHMARK_RESPONSE_NULL",
    BENCHMARK_RESPONSE_DATA_NULL = "BENCHMARK_RESPONSE_DATA_NULL",
    BENCHMARK_RESPONSE_DATA_FIASSET_NULL = "BENCHMARK_RESPONSE_DATA_FIASSET_NULL",
    BENCHMARK_RESPONSE_DATA_BASSET_NULL = "BENCHMARK_RESPONSE_DATA_BASSET_NULL",

    VALIDATE_PLACEMENTS_MUTATION_RESPONSE_NULL = "VALIDATE_PLACEMENTS_MUTATION_RESPONSE_NULL",
    VALIDATE_PLACEMENTS_MUTATION_MIN_AMOUNT = "VALIDATE_PLACEMENTS_MUTATION_MIN_AMOUNT",
    VALIDATE_PLACEMENTS_MUTATION_GENERIC_ERROR = "VALIDATE_PLACEMENTS_MUTATION_GENERIC_ERROR",
    VALIDATE_PLACEMENTS_MUTATION_UNSPECIFIED_RESPONSE_TYPE = "VALIDATE_PLACEMENTS_MUTATION_UNSPECIFIED_RESPONSE_TYPE",

    VALIDATE_QUICK_PLACE_RESPONSE_NULL = VALIDATE_PLACEMENTS_MUTATION_RESPONSE_NULL,
    VALIDATE_QUICK_PLACE_MIN_AMOUNT = VALIDATE_PLACEMENTS_MUTATION_MIN_AMOUNT,
    VALIDATE_QUICK_PLACE_GENERIC_ERROR = VALIDATE_PLACEMENTS_MUTATION_GENERIC_ERROR,
    VALIDATE_QUICK_PLACE_UNSPECIFIED_RESPONSE_TYPE = VALIDATE_PLACEMENTS_MUTATION_UNSPECIFIED_RESPONSE_TYPE,

    VALIDATE_PLACEMENTS_COUNTERING_MUTATION_RESPONSE_NULL = "VALIDATE_PLACEMENTS_COUNTERING_MUTATION_RESPONSE_NULL",
    VALIDATE_PLACEMENTS_COUNTERING_MUTATION_MIN_AMOUNT = "VALIDATE_PLACEMENTS_COUNTERING_MUTATIOL_MIN_AMOUNT",
    VALIDATE_PLACEMENTS_COUNTERING_MUTATION_GENERIC_ERROR = "VALIDATE_PLACEMENTS_COUNTERING_MUTATION_GENERIC_ERROR",
    VALIDATE_PLACEMENTS_COUNTERING_MUTATION_UNSPECIFIED_RESPONSE_TYPE = "VALIDATE_PLACEMENTS_COUNTERING_MUTATION_UNSPECIFIED_RESPONSE_TYPE",

    VALIDATE_PLACEMENTS_EXECUTION_MUTATION_RESPONSE_NULL = "VALIDATE_PLACEMENTS_EXECUTION_MUTATION_RESPONSE_NULL",
    VALIDATE_PLACEMENTS_EXECUTION_MUTATION_RESPONSE_WARNING = "VALIDATE_PLACEMENTS_EXECUTION_MUTATION_RESPONSE_WARNING",
    VALIDATE_PLACEMENTS_EXECUTION_MUTATION_RESPONSE_ERROR = "VALIDATE_PLACEMENTS_EXECUTION_MUTATION_RESPONSE_ERROR",

    VALIDATE_REQUEST_PLACEMENT_QUOTE_RESPONSE_NULL = VALIDATE_PLACEMENTS_COUNTERING_MUTATION_RESPONSE_NULL,
    VALIDATE_REQUEST_PLACEMENT_QUOTE_MIN_AMOUNT = VALIDATE_PLACEMENTS_COUNTERING_MUTATION_MIN_AMOUNT,
    VALIDATE_REQUEST_PLACEMENT_QUOTE_GENERIC_ERROR = VALIDATE_PLACEMENTS_COUNTERING_MUTATION_GENERIC_ERROR,
    VALIDATE_REQUEST_PLACEMENT_QUOTEN_UNSPECIFIED_RESPONSE_TYPE = VALIDATE_PLACEMENTS_COUNTERING_MUTATION_UNSPECIFIED_RESPONSE_TYPE,

    VALIDATE_COUNTER_ACCEPT_RESPONSE_NULL = "VALIDATE_PLACEMENTS_EXECUTION_MUTATION_RESPONSE_NULL",
    VALIDATE_COUNTER_ACCEPT_RESPONSE_WARNING = "VALIDATE_PLACEMENTS_EXECUTION_MUTATION_RESPONSE_WARNING",
    VALIDATE_COUNTER_ACCEPT_RESPONSE_ERROR = "VALIDATE_PLACEMENTS_EXECUTION_MUTATION_RESPONSE_ERROR",

    QUICK_PLACE_ERROR = "QUICK_PLACE_ERROR",
    QUICK_PLACE_RESPONSE_NULL = "QUICK_PLACE_RESPONSE_NULL",

    REQUEST_PLACEMENT_QUOTE_ERROR = "REQUEST_PLACEMENT_QUOTE_ERROR",
    REQUEST_PLACEMENT_QUOTE_RESPONSE_NULL = "REQUEST_PLACEMENT_QUOTE_RESPONSE_NULL",
    REQUEST_PLACEMENT_QUOTE_RESPONSE_HAS_GQL_ERRORS = "REQUEST_PLACEMENT_QUOTE_RESPONSE_HAS_GQL_ERRORS",

    COUNTER_ACCEPT_ERROR = "COUNTER_ACCEPT_ERROR",
    COUNTER_ACCEPT_RESPONSE_NULL = "COUNTER_ACCEPT_RESPONSE_NULL",

    COUNTER_COUNTER_ERROR = "COUNTER_COUNTER_ERROR",
    COUNTER_COUNTER_RESPONSE_NULL = "COUNTER_COUNTER_RESPONSE_NULL",

    COUNTER_PASS_ERROR = "COUNTER_PASS_ERROR",
    COUNTER_PASS_RESPONSE_NULL = "COUNTER_PASS_RESPONSE_NULL",

    BASKET_QUERY_RESPONSE_NULL = "ORDER_QUERY_RESPONSE_NULL",
    BASKET_QUERY_RESPONSE_DATA_NULL = "ORDER_QUERY_RESPONSE_DATA_NULL",
    BASKET_QUERY_RESPONSE_DATA_FIBASKETSUMMARY_NULL = "ORDER_QUERY_RESPONSE_DATA_FIORDERSUMMARY_NULL",

    ORDERLEAVES_QUERY_RESPONSE_NULL = "ORDERLEAVES_QUERY_RESPONSE_NULL",
    ORDERLEAVES_QUERY_RESPONSE_DATA_NULL = "ORDERLEAVES_QUERY_RESPONSE_DATA_NULL",
    ORDERLEAVES_QUERY_RESPONSE_CHANGED_ORDERLEAVES = "ORDERLEAVES_QUERY_RESPONSE_CHANGED_ORDERLEAVES",

    CANCEL_ERROR_PLACEMENTS_MUTATION_RESPONSE_ERROR = "CANCEL_PLACEMENTS_MUTATION_RESPONSE_ERROR"
}

export function convertToWorkflowEnum(...words: string[]): WorkflowError {
    let result = "";
    words.forEach((word) => {
        result += "_" + word.replace(/ /g, "_").toUpperCase();
    });
    result = result.substring(1);
    return result as WorkflowError;
}

// Removes all whitespace, i.e. new line, carriage return, spaces
export function stripAllWhitespace(input: string): string {
    return input.replace(/\n|\r|\ /g, "");
}

// Converts first = 0, second = 1, third = 2
export function convertNumberStringToNumber(n: string): number {
    let num = 0;
    if (n === "second") {
        num = 1;
    } else if (n === "third") {
        num = 2;
    }
    return num;
}

export function mockSuccessfulApiResponse(body = {}): Promise<Response> {
    return Promise.resolve(
        new window.Response(JSON.stringify(body), {
            status: 200,
            headers: { "Content-type": "application/json" }
        })
    );
}

export function mockFailedApiResponse(statusText, body = {}): Promise<Response> {
    return Promise.resolve(
        new window.Response(JSON.stringify(body), {
            status: 400,
            headers: { "Content-type": "application/json" },
            statusText
        })
    );
}

export function cleanJSON(someJson: string) {
    let cleanJSON = someJson
        .replace(/\\n/g, "\\n")
        .replace(/\\'/g, "\\'")
        .replace(/\\"/g, '\\"')
        .replace(/\\&/g, "\\&")
        .replace(/\\r/g, "\\r")
        .replace(/\\t/g, "\\t")
        .replace(/\\b/g, "\\b")
        .replace(/\\f/g, "\\f");
    return cleanJSON;
}
