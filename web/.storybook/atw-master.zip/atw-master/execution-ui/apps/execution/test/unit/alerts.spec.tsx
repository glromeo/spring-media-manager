/// <reference types="cypress" />
import { mount } from "@cypress/react";
import App from "../../src/app/app";
import { windowUtils } from "../../src/common/utils";
import { Alerts } from "../../src/components/common/alerts";
import { Footer } from "../../src/components/execution/footer";
import { Alert, AlertType } from "../../src/features/alerts/alert";
import { setAlert } from "../../src/features/alerts/alertsActions";
import { getTestSelector } from "../common.utils";

// this link gave great insight on what mocking is hard (and why things just don't work ...as you expect) - https://javascript.plainenglish.io/unit-testing-challenges-with-modular-javascript-patterns-22cc22397362
const mountIt = (childComponent: JSX.Element) => {
    return mount(<App>{childComponent}</App>);
};

context("Alert tests", () => {
    const createInitialAlert = (type: AlertType, message: string) => {
        const alert: Alert = {
            type,
            message
        };
        return { type: "INIT", key: "alerts", value: [alert] };
    };

    beforeEach(() => {
        cy.window().its("store").invoke("dispatch", createInitialAlert("MESSAGE", "Initial"));
    });

    it("generic notification should display", () => {
        mountIt(<Alerts></Alerts>)
            .window()
            .its("store")
            .invoke("dispatch", setAlert([{ type: "MESSAGE", message: "message" }]))
            .window()
            .get(getTestSelector("alerts-notification-group"))
            .should("exist");
    });

    it("PROMPT notification should trigger closeWindow on close", () => {
        const closeWindowSpy = cy.spy(windowUtils, "closeWindow");
        mountIt(<Alerts></Alerts>)
            .window()
            .its("store")
            .invoke("dispatch", setAlert([{ type: "PROMPT", message: "prompt message" }]))
            .window()
            .get(getTestSelector("promptpopupnobutton"))
            .click({ force: true })
            .then(() => {
                expect(closeWindowSpy).to.have.been.called;
            });
    });
});

context("Footer tests", () => {
    it("#onCancel should call closeWindow()", () => {
        const closeWindowSpy = cy.spy(windowUtils, "closeWindow");
        mountIt(<Footer></Footer>)
            .get(getTestSelector("cancelbutton"))
            .click({ force: true })
            .then(() => {
                expect(closeWindowSpy).to.have.been.called;
            });
    });
});
