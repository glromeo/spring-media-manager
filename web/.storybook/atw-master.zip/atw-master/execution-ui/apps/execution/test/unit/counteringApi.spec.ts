/// <reference types="cypress" />
/// <reference types="chai-as-promised" />

import { benchmarkApi } from "@atx/commons/benchmark/useBenchmark";
import {
    cancelErrorPlacementsMutation,
    counterPlacementQuoteMutation,
    executePlacementQuoteMutation,
    GraphQlCancelErrorPlacementsResponse,
    GraphQLPlacementCreationVariables,
    passPlacementQuoteMutation,
    requestPlacementQuoteMutation
} from "../../src/api/types";
import { apiUtils, configUtils, counteringUtils } from "../../src/common/utils";
import { Countering, performCounteringActionConfig } from "../../src/features/countering/countering";
import {
    counterAxe,
    CounteringApi,
    createPlacement,
    getCounteringPopupSize,
    getNextCounteringState
} from "../../src/features/countering/counteringApi";
import { reconcilePlacements } from "../../src/features/order/orderApi";
import { TradeForm } from "../../src/features/tradeForm/tradeForm";
import {
    mockAxe_HY,
    mockAxe_IG,
    mockConfig_HY,
    mockConfig_IG,
    mockCountering,
    mockGQLPlacement,
    mockLastHistory,
    mockOrder,
    mockOrder_Buy_HY,
    mockOrder_Buy_IG,
    mockOrderWithPlacements,
    mockPlacements,
    mockTradeForm_HY_JPMSL,
    mockTradeForm_IG_JPM,
    responsePlacementQuote
} from "./mockData";

context("Counter API Tests", () => {
    const testUser = "tstUser";
    const dueInTime = "00:05:00|America/New_York"; // corresponds to what we set in cy.clock
    const gqlPlacements = [mockGQLPlacement];
    const placements = reconcilePlacements(gqlPlacements);
    const placement = placements[0];
    const HY_placement_request: GraphQLPlacementCreationVariables = {
        request: {
            ordNum: 20000,
            brokers: [{ broker: "JPMSL", subBrokerId: 1000 }],
            placementAllocationStrategy: {
                strategy: "EXACT_AMOUNT",
                value: 3000000
            },
            limitType: "P",
            dueInTime: dueInTime,
            limitValue: 124.56,
            externRefID: "mock-3001",
            axeLevel: 124.56,
            settleDate: "08/30/2021",
            axeID: "123",
            axeQty: 3000000
        },
        user: testUser
    };

    const IG_placement_request: GraphQLPlacementCreationVariables = {
        request: {
            ordNum: 20002,
            brokers: [{ broker: "JPM", subBrokerId: 1001 }],
            placementAllocationStrategy: {
                strategy: "EXACT_AMOUNT",
                value: 3000000
            },
            limitType: "S",
            dueInTime: dueInTime,
            limitValue: 86,
            externRefID: "mock-3000",
            axeLevel: 86,
            axeID: "123",
            settleDate: "08/30/2021",
            spreadIndex: "91282CCB5",
            spotType: 'A',
            axeQty: 3000000
        },
        user: testUser
    };
    const twebPrice = 10.01;

    beforeEach(() => {
        cy.stub(configUtils, "getUser").returns(testUser);
        cy.clock(new Date(Date.UTC(2022, 0, 18)).setHours(0));
        cy.stub(counteringUtils, "getMostRecentPlacementNumber").returns(placement);
    });
    afterEach(() => {
        cy.tick(0).invoke("restore");
    });

    context("#getNextCounteringState", () => {
        it("...should correctly infer next countering state", () => {
            const countering: Countering = {
                hasValidData: true,
                state: "ACCEPT_BROKER",
                placementNum: 0,
                prevState: "BROKER_ACCEPTED",
                action: "ACCEPT"
            };

            expect(getNextCounteringState(countering, "SEND")).to.equal("CLOSE");
            expect(getNextCounteringState(countering, "ACKSEND")).to.equal("CLOSE");
            expect(getNextCounteringState(countering, "CANCEL")).to.equal("BROKER_ACCEPTED");
            expect(getNextCounteringState(countering, "CLOSE")).to.be.undefined;
        });

        it("...should correctly handle cancelling the form", () => {
            const countering: Countering = {
                hasValidData: true,
                state: "FORM",
                placementNum: 0,
                prevState: "BROKER_ACCEPTED",
                action: "ACCEPT"
            };
            expect(getNextCounteringState(countering, "CANCEL")).to.equal(countering.prevState);
            expect(getNextCounteringState(countering, "CLOSE")).to.be.undefined;
        });
    });

    context("#getCounteringPopupSize", () => {
        it("...should correctly return the associated size as a dimension", () => {
            expect(getCounteringPopupSize("BROKER_ACCEPTED")).to.deep.equal({ width: 700, height: 455 });
            expect(getCounteringPopupSize("CLOSE")).to.be.undefined;
            expect(getCounteringPopupSize("FORM")).to.deep.equal({ width: 640, height: 885 });
            expect(getCounteringPopupSize("NOT_SET")).to.deep.equal({ width: 640, height: 885 });
            expect(getCounteringPopupSize("PASSING_NEW")).to.deep.equal({ width: 700, height: 365 });
        });
    });

    context("#performCounteringAction", () => {
        context("action: ACCEPT, nextState: CLOSE", () => {
            it("should accept payment quote", () => {
                const config: performCounteringActionConfig = {
                    action: "SEND",
                    nextState: "CLOSE",
                    currentState: "ACCEPT_BROKER",
                    order: mockOrder,
                    placementNumber: 5
                };
                cy.stub(CounteringApi, "acceptPlacementQuote");
                CounteringApi.performCounteringAction(config);
                expect(CounteringApi.acceptPlacementQuote).to.be.calledWith(mockOrder);
            });
        });
        context("action: SEND, nextState: CLOSE", () => {
            it("should accept payment quote", () => {
                const config: performCounteringActionConfig = {
                    action: "SEND",
                    nextState: "CLOSE",
                    currentState: "ACCEPT_BROKER",
                    order: mockOrder,
                    placementNumber: 5
                };
                cy.stub(CounteringApi, "acceptPlacementQuote");
                CounteringApi.performCounteringAction(config);
                expect(CounteringApi.acceptPlacementQuote).to.be.calledWith(mockOrder);
            });
            it("should accept payment quote for acknowledge & send", () => {
                const config: performCounteringActionConfig = {
                    action: "ACKSEND",
                    nextState: "CLOSE",
                    currentState: "ACCEPT_BROKER",
                    order: mockOrder,
                    placementNumber: 5
                };
                cy.stub(CounteringApi, "acceptPlacementQuote");
                CounteringApi.performCounteringAction(config);
                expect(CounteringApi.acceptPlacementQuote).to.be.calledWith(mockOrder);
            });
        });
    });

    context("#createPlacement", () => {
        it("...should create price-based placementCreationVariables for a HY counter", () => {
            cy.stub(configUtils, "isCares").returns(false);
            const order = mockOrder_Buy_HY;
            const lift = mockTradeForm_HY_JPMSL;
            const axe = mockAxe_HY;
            const settings = mockConfig_HY;

            const result = createPlacement(order, lift, axe, settings, mockCountering);
            expect(result).to.deep.eq(HY_placement_request);
        });
        it("...should create spread-based placementCreationVariables for an IG counter", () => {
            cy.stub(configUtils, "isCares").returns(false);
            const order = mockOrder_Buy_IG;
            const lift = mockTradeForm_IG_JPM;
            const axe = mockAxe_IG;
            const settings = mockConfig_IG;

            const result = createPlacement(order, lift, axe, settings);

            expect(result).to.deep.eq(IG_placement_request);
        });
    });

    context("#counterAxe", () => {
        const IG_fixture = {
            fixture: `placement-creation/${mockOrder_Buy_IG.id}`,
            telemetry: ["requestCounteringPlacement", "request countering placement"]
        };
        it("...should send a request to requestPlacementQuote (HY)", async () => {
            const fixture = {
                fixture: `placement-creation/${mockOrder.id}`,
                telemetry: ["requestCounteringPlacement", "request countering placement"]
            };
            const counterAxeCall = cy.stub(apiUtils, "apiQuery").resolves(responsePlacementQuote);
            const response = await counterAxe(
                mockOrder,
                mockTradeForm_HY_JPMSL,
                mockAxe_HY,
                mockConfig_HY,
                mockCountering
            );
            expect(counterAxeCall).to.be.calledWith(requestPlacementQuoteMutation, HY_placement_request, fixture);
            expect(response).to.be.true;
        });
        it("...should send a request with benchPrice to requestPlacementQuote (IG, Spot Now, valid TWEB price)", async () => {
            const request_benchPrice = {
                ...IG_placement_request,
                request: {
                    ...IG_placement_request.request,
                    benchPrice: twebPrice
                }
            };

            const benchmarkCall = cy.stub(benchmarkApi, "getTWEBPrice").returns(twebPrice);
            const counterAxeCall = cy.stub(apiUtils, "apiQuery").resolves(responsePlacementQuote);
            const response = await counterAxe(
                mockOrder_Buy_IG,
                mockTradeForm_IG_JPM,
                mockAxe_IG,
                mockConfig_IG,
                mockCountering
            );
            expect(counterAxeCall).to.be.calledWith(requestPlacementQuoteMutation, request_benchPrice, IG_fixture);
            expect(benchmarkCall).to.be.calledWith(mockAxe_IG.axeBmkId, mockOrder_Buy_IG.side);
            expect(response).to.be.true;
        });
        it("...should send a request without benchPrice to requestPlacementQuote (IG, Spot Now, invalid TWEB price)", async () => {
            const benchmarkCall = cy.stub(benchmarkApi, "getTWEBPrice").returns(null);
            const counterAxeCall = cy.stub(apiUtils, "apiQuery").resolves(responsePlacementQuote);
            const response = await counterAxe(
                mockOrder_Buy_IG,
                mockTradeForm_IG_JPM,
                mockAxe_IG,
                mockConfig_IG,
                mockCountering
            );
            expect(counterAxeCall).to.be.calledWith(requestPlacementQuoteMutation, IG_placement_request, IG_fixture);
            expect(benchmarkCall).to.be.calledWith(mockAxe_IG.axeBmkId, mockOrder_Buy_IG.side);
            expect(response).to.be.true;
        });
        it("...should send a request without benchPrice to requestPlacementQuote (IG, Delayed Spot, valid TWEB price)", async () => {
            const tradeForm_IG_delayed: TradeForm = {
                ...mockTradeForm_IG_JPM,
                spotTimeSelected: "11 AM ET"
            };
            const request_delayedSpot: GraphQLPlacementCreationVariables = {
                ...IG_placement_request,
                request: {
                    ...IG_placement_request.request,
                    spotType: "11 AM ET"
                }
            };
            const benchmarkCall = cy.stub(benchmarkApi, "getTWEBPrice").returns(twebPrice);
            const counterAxeCall = cy.stub(apiUtils, "apiQuery").resolves(responsePlacementQuote);
            const response = await counterAxe(
                mockOrder_Buy_IG,
                tradeForm_IG_delayed,
                mockAxe_IG,
                mockConfig_IG,
                mockCountering
            );
            expect(counterAxeCall).to.be.calledWith(requestPlacementQuoteMutation, request_delayedSpot, IG_fixture);
            expect(benchmarkCall).not.to.be.called;
            expect(response).to.be.true;
        });
        it("...should return an error on apiQuery error", async () => {
            cy.stub(benchmarkApi, "getTWEBPrice").returns(twebPrice);
            cy.stub(apiUtils, "apiQuery").throws({
                errors: [
                    {
                        errorType: "DataFetchingException",
                        message: "Could not create the placement, because the whole order is on hold",
                        locations: [],
                        path: null,
                        extensions: null
                    }
                ]
            });
            await expect(
                counterAxe(mockOrder_Buy_IG, mockTradeForm_IG_JPM, mockAxe_IG, mockConfig_IG, mockCountering)
            ).to.be.rejectedWith("Could not create the placement, because the whole order is on hold");
        });
    });
    context("#counterPlacementQuote", () => {
        const counterPlacementQuoteSuccessRes = {
            counterPlacementQuote: [{ order: {}, placements: {} }]
        };
        const counterPlacementQuoteErrorRes = {
            errors: [{ message: "error" }]
        };
        mockPlacements[0].placementNum = 123;
        mockOrder.placements = mockPlacements;
        const placementNum = 123;
        const counterPlacementQuoteVars = {
            ...apiUtils.createUpdatePlacementQuoteVars(mockOrder.placements[0], {
                tradeValue: mockTradeForm_HY_JPMSL.price!,
                quantity: mockTradeForm_HY_JPMSL.size!,
                dueInTime: "00:05:00|America/New_York"
            }),
            user: testUser
        };
        it("should make counterPlacementQuote request", () => {
            cy.stub(apiUtils, "apiQuery").resolves(counterPlacementQuoteSuccessRes);
            CounteringApi.counterPlacementQuote(mockOrder, placementNum, mockTradeForm_HY_JPMSL);
            expect(apiUtils.apiQuery).to.be.calledWith(counterPlacementQuoteMutation, counterPlacementQuoteVars);
        });
        it("should return true if success response", async () => {
            cy.stub(apiUtils, "apiQuery").resolves(counterPlacementQuoteSuccessRes);
            expect(await CounteringApi.counterPlacementQuote(mockOrder, placementNum, mockTradeForm_HY_JPMSL)).to.equal(
                true
            );
        });
        it("should throw error if error response", async () => {
            cy.stub(apiUtils, "apiQuery").resolves(counterPlacementQuoteErrorRes);
            await expect(
                CounteringApi.counterPlacementQuote(mockOrder, placementNum, mockTradeForm_HY_JPMSL)
            ).to.be.rejectedWith("Unable to counter placement quote for order: " + mockOrder.id);
        });
        it("should throw error if invalid response", async () => {
            mockOrder.id = 1;
            cy.stub(apiUtils, "apiQuery").resolves(1);
            await expect(
                CounteringApi.counterPlacementQuote(mockOrder, placementNum, mockTradeForm_HY_JPMSL)
            ).to.be.rejectedWith("Unable to counter placement quote for order: " + mockOrder.id);
        });
    });
    context("#cancelPlacements", () => {
        const placementNum = 123;
        const cancelErrorPlacementsVars = {
            placementNumList: [placementNum],
            user: testUser
        };
        const successfulResult: GraphQlCancelErrorPlacementsResponse = {
            cancelErrorPlacements: [
                {
                    placementNum,
                    status: "foo",
                    modifyReason: "foo"
                }
            ]
        };
        it("should return if successful response", () => {
            cy.stub(apiUtils, "apiQuery").resolves(successfulResult);
            CounteringApi.cancelPlacements(mockOrderWithPlacements, [placementNum]);
            expect(apiUtils.apiQuery).to.be.calledWith(cancelErrorPlacementsMutation, cancelErrorPlacementsVars);
        });
        it("should throw error if error response", async () => {
            const errorResult = {
                errors: [
                    {
                        locations: [],
                        message: "issue:error,505125984,Generic error message.",
                        errorType: "DataFetchingException",
                        extensions: null,
                        path: null
                    }
                ]
            };
            const validateCall = cy.stub(apiUtils, "apiQuery").resolves(errorResult);
            expect(CounteringApi.cancelPlacements(mockOrderWithPlacements, [placementNum])).to.be.rejectedWith(
                "Unable to cancel placements: 123"
            );
            validateCall.restore();
        });
    });
    context("#acceptPlacementQuote", () => {
        afterEach(() => {});
        const executePlacementQuoteSuccessRes = {
            executePlacementQuote: [{ order: {}, placements: {} }]
        };
        const executePlacementQuoteErrorRes = {
            errors: [{ message: "error" }]
        };
        mockPlacements[0].placementNum = 123;
        mockOrder.placements = mockPlacements;
        const placementNum = 123;
        const vars = {
            tradeValue: mockLastHistory.value!,
            quantity: mockLastHistory.size!
        };
        const executePlacementQuoteVars = {
            ...apiUtils.createUpdatePlacementQuoteVars(mockOrder.placements[0], vars),
            user: testUser
        };

        it("should make executePlacementQuote request", () => {
            cy.stub(apiUtils, "apiQuery").resolves(executePlacementQuoteSuccessRes);
            CounteringApi.acceptPlacementQuote(mockOrder, placementNum);
            expect(apiUtils.apiQuery).to.be.calledWith(executePlacementQuoteMutation, executePlacementQuoteVars);
        });
        it("should return true if success response", async () => {
            cy.stub(apiUtils, "apiQuery").resolves(executePlacementQuoteSuccessRes);
            expect(await CounteringApi.acceptPlacementQuote(mockOrder, placementNum)).to.equal(true);
        });
        it("should throw error if error response", async () => {
            cy.stub(apiUtils, "apiQuery").resolves(executePlacementQuoteErrorRes);
            await expect(CounteringApi.acceptPlacementQuote(mockOrder, placementNum)).to.be.rejectedWith(
                "Unable to accept placement quote for order: " + mockOrder.id
            );
        });
        it("should throw error if invalid response", async () => {
            mockOrder.id = 1;
            cy.stub(apiUtils, "apiQuery").resolves(1);
            await expect(CounteringApi.acceptPlacementQuote(mockOrder, placementNum)).to.be.rejectedWith(
                "Unable to accept placement quote for order: " + mockOrder.id
            );
        });
    });

    context("#passPlacementQuote", () => {
        const placementNum = 123;
        const passPlacementQuoteSuccessRes = {
            passPlacementQuotes: [
                {
                    placementNum
                }
            ]
        };
        const passPlacementQuoteErrorRes = {
            errors: [{ message: "error" }]
        };

        mockPlacements[0].placementNum = placementNum;
        mockOrder.placements = mockPlacements;

        const passPlacementQuoteReq = {
            placementNumList: [placementNum],
            user: testUser
        };

        it("should make passPlacementQuote request", () => {
            cy.stub(apiUtils, "apiQuery").resolves(passPlacementQuoteSuccessRes);
            CounteringApi.passPlacementQuotes(placementNum);
            expect(apiUtils.apiQuery).to.be.calledWith(passPlacementQuoteMutation, passPlacementQuoteReq);
        });
        it("should return true if success response", async () => {
            cy.stub(apiUtils, "apiQuery").resolves(passPlacementQuoteSuccessRes);
            expect(await CounteringApi.passPlacementQuotes(placementNum)).to.equal(true);
        });
        it("should not throw error if error response", async () => {
            cy.stub(apiUtils, "apiQuery").resolves(passPlacementQuoteErrorRes);
            expect(await CounteringApi.passPlacementQuotes(placementNum)).to.equal(false);
        });
    });
});
