/// <reference types="cypress" />
import { counteringUtils, orderUtils } from "../../src/common/utils";
import { CounteringHistory } from "../../src/features/countering/countering";
import { Placement, Quote } from "../../src/features/order/order";
import { HIGH_YIELD, INVESTMENT_GRADE, STRING_PLACE_HOLDER } from "../../src/models/common";
import { mockLastHistory, mockPlacement, mockQuote, mockOrder, mockCountering } from "./mockData";

context("counteringUtils tests", () => {
    context("#getLastHistoryFromPlacement", () => {
        it("...should return correct history from placementQuote", () => {
            const history: CounteringHistory = {
                value: 123.45,
                size: 100,
                status: "Test",
                quality: STRING_PLACE_HOLDER
            };
            const placementNullQuotes: Placement = {
                ...mockPlacement,
                quotes: []
            };
            expect(counteringUtils.getLastHistoryFromPlacement(placementNullQuotes)).to.be.null;
            const placementEmptyQuotes: Placement = {
                ...mockPlacement,
                quotes: []
            };
            expect(counteringUtils.getLastHistoryFromPlacement(placementEmptyQuotes)).to.be.null;
            const placementMismatch: Placement = {
                ...mockPlacement,
                quotes: [
                    {
                        ...mockPlacement.quotes[0],
                        spread: 80,
                        type: "SPREAD"
                    }
                ]
            };
            expect(counteringUtils.getLastHistoryFromPlacement(placementMismatch, true)).to.deep.equal(mockLastHistory);
            expect(counteringUtils.getLastHistoryFromPlacement(placementMismatch, false)).to.not.equal(mockLastHistory);
        });
    });
    context("#formatHistoryPriceBasedOnQuality", () => {
        it("...should return correct value from placementQuote", () => {
            const history: CounteringHistory = {
                size: 100,
                status: "Test",
                quality: STRING_PLACE_HOLDER
            };
            history.value = undefined;
            expect(counteringUtils.formatHistoryPriceBasedOnQuality(history, HIGH_YIELD)).to.equal(STRING_PLACE_HOLDER);
            history.value = 123.45;
            expect(counteringUtils.formatHistoryPriceBasedOnQuality(history, HIGH_YIELD)).to.equal("$123.450");
            expect(counteringUtils.formatHistoryPriceBasedOnQuality(history, INVESTMENT_GRADE)).to.equal("+123.450");
        });
    });
    context("#getCounteringNotifications", () => {
        it("should return notification if quote quantity is greater than order leaves", () => {
            const quote: Quote = {
                ...mockQuote,
                quantity: 9999999999
            };
            cy.stub(counteringUtils, "getValidQuote").returns(quote);
            expect(counteringUtils.getCounteringNotifications(mockOrder, mockCountering)).to.deep.equal([
                {
                    id: 1,
                    name: "Errors - Please Reach out to Aladdin Support",
                    message: "Broker SIMEQ countered with size greater than order leaves: 9,999,999,999 > 3,000,000",
                    type: "ERROR"
                }
            ]);
        });
        it("should return empty array if no countering issues", () => {
            cy.stub(counteringUtils, "getValidQuote").returns(mockQuote);
            expect(counteringUtils.getCounteringNotifications(mockOrder, mockCountering)).to.deep.equal([]);
        });
    });
    context("#getValidQuote", () => {
        it("should return a valid quote", () => {
            expect(counteringUtils.getValidQuote(mockPlacement, "BUY")).to.equal(mockQuote);
        });
        it("should return undefined if no broker match", () => {
            const placementWithNoBrokerMatch: Placement = {
                ...mockPlacement,
                broker: {
                    shortName: "SIMEQ",
                    code: 1,
                    ticker: "SIMEQ"
                }
            };
            expect(counteringUtils.getValidQuote(placementWithNoBrokerMatch, "BUY")).to.equal(undefined);
        });
        it("should return undefined if no order side match", () => {
            expect(counteringUtils.getValidQuote(mockPlacement, "SELL")).to.equal(undefined);
        });
    });
    context("#checkQuoteValidity", () => {
        it("throw error if no placement", () => {
            cy.stub(orderUtils, "getPlacement").returns(undefined);
            expect(() => counteringUtils.checkQuoteValidity(mockOrder, 1)).to.throw(`No Placement Found`);
        });
        it("throw error if no placement quote", () => {
            const { quotes, ...placementWithNoQuotes } = mockPlacement;
            cy.stub(orderUtils, "getPlacement").returns(placementWithNoQuotes);
            expect(() => counteringUtils.checkQuoteValidity(mockOrder, 1)).to.throw(`No Quote Found`);
        });
        it("throw error if no broker code on quote", () => {
            const placement: Placement = {
                ...mockPlacement
            };
            // @ts-ignore 
            placement.quotes[0].counterparty.code = null;
            cy.stub(orderUtils, "getPlacement").returns(placement);
            expect(() => counteringUtils.checkQuoteValidity(mockOrder, 1)).to.throw(
                `Broker code mapping not configured. Please contact Aladdin Support.`
            );
        });
        it("throw error if no broker code on placement", () => {
            const placement: Placement = {
                ...mockPlacement
            };
            // @ts-ignore 
            placement.broker.code = null;
            cy.stub(orderUtils, "getPlacement").returns(placement);
            expect(() => counteringUtils.checkQuoteValidity(mockOrder, 1)).to.throw(
                `Broker code mapping not configured. Please contact Aladdin Support.`
            );
        });
        it("throw error if broker mismatch", () => {
            const placement: Placement = {
                ...mockPlacement
            };
            placement.broker.code = 2;
            placement.quotes[0].counterparty.code = 1;
            cy.stub(orderUtils, "getPlacement").returns(placement);
            expect(() => counteringUtils.checkQuoteValidity(mockOrder, 1)).to.throw(
                "There is a broker mismatch. Please contact Aladdin Support."
            );
        });
        it("throw error if order side mismatch", () => {
            const placement: Placement = {
                ...mockPlacement
            };
            placement.broker.code = 2;
            placement.quotes[0].counterparty.code = 2;
            placement.quotes[0].side = "BID";
            cy.stub(orderUtils, "getPlacement").returns(placement);
            expect(() => counteringUtils.checkQuoteValidity(mockOrder, 1)).to.throw(
                "There are no matching quotes for the order side. Please contact Aladdin Support."
            );
        });
        it("not throw anything if quote valid", () => {
            const placement: Placement = {
                ...mockPlacement
            };
            placement.broker.code = 2;
            placement.quotes[0].counterparty.code = 2;
            placement.quotes[0].side = "ASK";
            cy.stub(orderUtils, "getPlacement").returns(placement);
            expect(() => counteringUtils.checkQuoteValidity(mockOrder, 1)).to.not.throw();
        });
        it("not throw anything if at least one is quote valid", () => {
            const placement: Placement = {
                ...mockPlacement
            };
            placement.broker.code = 1234567;
            placement.quotes[0].counterparty.code = 1234567;
            placement.quotes[0].side = "BID";
            placement.quotes[1] = mockQuote;
            placement.quotes[1].side = "ASK";
            cy.stub(orderUtils, "getPlacement").returns(placement);
            expect(() => counteringUtils.checkQuoteValidity(mockOrder, 1)).to.not.throw();
        });
    });
});
