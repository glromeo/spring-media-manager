/// <reference types="cypress" />
import { mount } from "@cypress/react";
import App from "../../../src/app/app";

// this link gave great insight on what mocking is hard (and why things just don't work ...as you expect) - https://javascript.plainenglish.io/unit-testing-challenges-with-modular-javascript-patterns-22cc22397362
const mountIt = (childComponent: JSX.Element) => {
    return mount(<App>{childComponent}</App>);
};

context("Header tests", () => {
    const orderInfo = {
        order: {
            placements: {
                placementNum: 215273685,
                limitValue: null,
                limitType: "PRICE",
                quantity: 2000,
                status: "CANCELLED",
                modifyReason: "Quote Lost",
                externRefID: null,
                settleDate: "09/28/2022",
                axeID: null,
                trader: null,
                broker: {
                    ticker: "SIMGS",
                    type: "BROKER",
                    shortName: "SIMGS",
                    code: 140479
                },
                desk: {
                    salesman: "",
                    brokerType: "GEN",
                    subBrokerID: 292516
                }
            }
        }
    };
});
