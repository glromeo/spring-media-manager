/// <reference types="cypress" />
import { mount } from "@cypress/react";
import { GraphQLOrderCreationResponse, GraphQLResult } from "../../../src/api/types";
import App from "../../../src/app/app";
import { CONFIG } from "../../../src/common/constants";
import { apiUtils } from "../../../src/common/utils/apiUtils";
import { windowUtils } from "../../../src/common/utils/windowUtils";
import { TradeConfirmationModal } from "../../../src/components/execution/trade-confirmation-modal";
import { setWorkflow } from "../../../src/features/config/configActions";
import { DEFAULT_STEPPER } from "../../../src/features/stepper/stepper";
import { sendOrder } from "../../../src/features/stepper/stepperActions";
import {
    mockAxe_HY,
    mockConfig_HY,
    mockCountering,
    mockOrder_Buy_HY,
    mockTradeForm_HY_JPM,
    mockGQLOrder_placements
} from "../mockData";
// this link gave great insight on what mocking is hard (and why things just don't work ...as you expect) - https://javascript.plainenglish.io/unit-testing-challenges-with-modular-javascript-patterns-22cc22397362
const mountIt = (childComponent: JSX.Element) => {
    return mount(<App>{childComponent}</App>);
};

context("Auto close tests", () => {
    beforeEach(() => {
        cy.stub(apiUtils, "apiGet").returns({});
    });
    it("Sending an order should auto-close the confirmation popup", () => {
        const closeWindowSpy = cy.spy(windowUtils, "closeWindow");

        const orderCreationResponse: GraphQLOrderCreationResponse = {
            multiQuickPlace: [
                {
                    ...mockGQLOrder_placements.placements![0]
                }
            ]
        };

        cy.stub(apiUtils, "createOrder").returns({});
        cy.stub(apiUtils, "apiQuery").resolves(orderCreationResponse);

        cy.clock().then((clock) => {
            clock.restore();

            mountIt(<TradeConfirmationModal></TradeConfirmationModal>)
                .window()
                .its("store")
                .invoke("dispatch", setWorkflow({ wf: "EXECUTION" }))
                .window()
                .its("store")
                .invoke(
                    "dispatch",
                    sendOrder({
                        order: mockOrder_Buy_HY,
                        tradeForm: mockTradeForm_HY_JPM,
                        axe: mockAxe_HY,
                        config: mockConfig_HY,
                        stepper: DEFAULT_STEPPER,
                        countering: mockCountering
                    })
                )
                .window()
                .wait((CONFIG.COUNTER_REQUEST_AUTO_CLOSE_SECS + 1) * 1000)
                .then(() => {
                    expect(closeWindowSpy).to.have.been.called;
                });
        });
    });
});
