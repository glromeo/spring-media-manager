/// <reference types="cypress" />
import { mount } from "@cypress/react";
import App from "../../../src/app/app";
import { TradeForm } from "../../../src/components/execution/trade/trade-form";
import { getTestSelector } from "../../common.utils";
import { mockOrderInfo_Buy_HY_Restrictions, mockTradeFormInfo_HY } from "../mockData";
import { genericUtils } from "../../../src/common/utils/genericUtils";

// this link gave great insight on what mocking is hard (and why things just don't work ...as you expect) - https://javascript.plainenglish.io/unit-testing-challenges-with-modular-javascript-patterns-22cc22397362
const mountIt = (childComponent: JSX.Element) => {
    return mount(<App>{childComponent}</App>);
};

const getOrderAction = () => {
    return { type: "INIT", key: "orderInfo", value: mockOrderInfo_Buy_HY_Restrictions };
};

const getTradeFormAction = () => {
    return { type: "INIT", key: "tradeFormInfo", value: mockTradeFormInfo_HY };
};

context("TradeForm Tests", () => {
    it.skip("settle date - do not allow before today", () => {
        cy.clock().then((clock) => {
            clock.restore();

            mountIt(<TradeForm></TradeForm>)
                .window()
                .its("store")
                .invoke("dispatch", getTradeFormAction())
                .window()
                .its("store")
                .invoke("dispatch", getOrderAction())
                .get(getTestSelector("hit-settledate"))
                .invoke("attr", "min-date")
                .should("contain", genericUtils.getTodaysDate(true));
        });
    });

    it.skip("broker - alphabetical order", () => {
        mountIt(<TradeForm></TradeForm>)
            .window()
            .its("store")
            .invoke("dispatch", getTradeFormAction())
            .window()
            .its("store")
            .invoke("dispatch", getOrderAction())
            .get(getTestSelector("tradeform-broker"))
            .then((dom: any) => {
                const list = dom[0].data[0].values.map((v) => v.value).join(",");
                assert.deepEqual(list, "ABC,JPM,JPMSL");
            });
    });
    it.skip("desk - alphabetical order", () => {
        mountIt(<TradeForm></TradeForm>)
            .window()
            .its("store")
            .invoke("dispatch", getTradeFormAction())
            .window()
            .its("store")
            .invoke("dispatch", getOrderAction())
            .get(getTestSelector("tradeform-desk"))
            .then((dom: any) => {
                const list = dom[0].data[0].values.map((v) => v.value).join(",");
                assert.deepEqual(list, "AA,FX,G2");
            });
    });
});
