// Mock data to be used in unit tests
// @ts-nocheck

import { GraphQLOrderSummary, GraphQLPlacement } from "../../src/api/types";
import { CODE } from "../../src/common/constants";
import { Axe, AxeInfo, DEFAULT_AXE_SCHEMA } from "../../src/features/axe/axe";
import { Config } from "../../src/features/config/config";
import { Countering, CounteringHistory } from "../../src/features/countering/countering";
import {
    Broker,
    BrokerEntity,
    BrokerRestriction,
    BrokerRestrictionAllocation,
    DEFAULT_ORDER_DETAIL_SCHEMA,
    Desk,
    Order,
    OrderInfo,
    Placement,
    Quote
} from "../../src/features/order/order";
import { Stepper } from "../../src/features/stepper/stepper";
import { DEFAULT_TRADEFORM_SCHEMA, TradeForm, TradeFormInfo } from "../../src/features/tradeForm/tradeForm";
import { HIGH_YIELD, INVESTMENT_GRADE, NUM_PLACE_HOLDER, STRING_PLACE_HOLDER } from "../../src/models/common";

// Desk IDs start at 1000
export const mockFXDesk: Desk = {
    brokerType: "FX",
    salesman: "FX Salesman",
    subBrokerID: 1000
};

export const mockFutDesk: Desk = {
    brokerType: "FUT-ALGO",
    salesman: "Salesman",
    subBrokerID: 1001
};

// Portfolio codes start at 100
export const TSTTRD1 = {
    name: "TSTTRD1",
    code: 101
};

export interface TestPortfolio {
    name: string;
    code: number;
}
export const TSTTRD2: TestPortfolio = {
    name: "TSTTRD2",
    code: 102
};

export const TSTTRD3: TestPortfolio = {
    name: "TSTTRD3",
    code: 103
};

export const TSTTRD4: TestPortfolio = {
    name: "TSTTRD4",
    code: 104
};

export const TSTTRD5: TestPortfolio = {
    name: "TSTTRD5",
    code: 105
};

export const TSTTRD6: TestPortfolio = {
    name: "TSTTRD6",
    code: 106
};

export const mockRestrictionAllocation_TSTTRD1_2P5er: BrokerRestrictionAllocation = {
    isRestricted: true,
    name: TSTTRD1.name,
    code: TSTTRD1.code,
    quantity: 500_000,
    percent: 25
};

export const mockRestrictionAllocation_TSTTRD1_50Per: BrokerRestrictionAllocation = {
    isRestricted: true,
    name: TSTTRD1.name,
    code: TSTTRD1.code,
    quantity: 1_000_000,
    percent: 50
};

export const mockRestrictionAllocation_TSTTRD1_100Per: BrokerRestrictionAllocation = {
    isRestricted: true,
    name: TSTTRD1.name,
    code: TSTTRD1.code,
    quantity: 3_000_000,
    percent: 100
};

export const mockBrokerRestriction_0Per: BrokerRestriction = {
    quantity: 0,
    percent: 0,
    allocation: []
};

export const mockBrokerRestriction_66Per: BrokerRestriction = {
    quantity: 2_000_000,
    percent: 66.66667,
    allocation: [mockRestrictionAllocation_TSTTRD1_2P5er, mockRestrictionAllocation_TSTTRD1_50Per]
};

export const mockBrokerRestriction_100Per: BrokerRestriction = {
    quantity: 3_000_000,
    percent: 100,
    allocation: [mockRestrictionAllocation_TSTTRD1_100Per]
};

export function createMockRestrictionAllocation(
    portfolio: TestPortfolio,
    quantity: number,
    percent: number
): BrokerRestrictionAllocation {
    return {
        isRestricted: percent !== 100,
        name: portfolio.name,
        code: portfolio.code,
        quantity,
        percent
    };
}

// Broker Entity codes start at 20
export const mockJPMSLBrokerEntity: BrokerEntity = {
    name: "JPMSL",
    code: 20,
    desk: [mockFXDesk, mockFutDesk],
    isDelayedSpot: false,
    restriction: undefined,
    isCounteringEnabled: false
};

export const mockJPMSLBrokerEntityWithRestrictions: BrokerEntity = {
    name: "JPMSL",
    code: 21,
    desk: [mockFXDesk, mockFutDesk],
    isDelayedSpot: false,
    restriction: mockBrokerRestriction_66Per,
    isCounteringEnabled: false
};

export const mockABCrokerEntity: BrokerEntity = {
    name: "ABC",
    code: 21,
    desk: [mockFXDesk, mockFutDesk],
    isDelayedSpot: false,
    restriction: undefined,
    isCounteringEnabled: false
};

export const mockJPMBrokerEntity: BrokerEntity = {
    name: "JPM",
    code: 21,
    desk: [mockFXDesk, mockFutDesk],
    isDelayedSpot: false,
    restriction: undefined,
    isCounteringEnabled: false
};

export const mockJPMBroker: Broker = {
    rollup: "JPM",
    entity: [mockJPMSLBrokerEntity, mockJPMBrokerEntity]
};

export const mockJPMBrokerWithRestrictions: Broker = {
    rollup: "JPM",
    entity: [mockJPMSLBrokerEntityWithRestrictions]
};

// Order Ids start at 20000
export const mockOrder_Buy_HY: Order = {
    id: 20000,
    side: "BUY",
    bond: "ALLY 4.7 12/31/79",
    orderBmk: STRING_PLACE_HOLDER,
    orderBmkId: STRING_PLACE_HOLDER,
    cusip: "02005NBM1",
    isin: "US02005NBM11",
    origSize: 3_000_000,
    unbookedAmt: 3_000_000,
    orderLeaves: 3_000_000,
    limit: undefined,
    limitType: undefined,
    instructions: STRING_PLACE_HOLDER,
    settleDate: "08/31/2021",
    tradingBmk: STRING_PLACE_HOLDER,
    broker: mockJPMBroker,
    currency: "USD",
    minTrdSize: 1_000,
    quality: "HY",
    price: 104.848672,
    hasValidData: true
};

export const mockOrderWithPlacements: Order = {
    id: 20000,
    side: "BUY",
    bond: "ALLY 4.7 12/31/79",
    orderBmk: STRING_PLACE_HOLDER,
    orderBmkId: STRING_PLACE_HOLDER,
    cusip: "02005NBM1",
    isin: "US02005NBM11",
    origSize: 3_000_000,
    unbookedAmt: 3_000_000,
    orderLeaves: 3_000_000,
    limit: undefined,
    limitType: undefined,
    instructions: STRING_PLACE_HOLDER,
    settleDate: "08/31/2021",
    tradingBmk: STRING_PLACE_HOLDER,
    broker: mockJPMBroker,
    currency: "USD",
    minTrdSize: 1_000,
    quality: "HY",
    price: 104.848672,
    hasValidData: true,
    broker: {
        entity: [mockJPMBrokerEntity, mockJPMSLBrokerEntity]
    },
    placements: [
        {
            placementNum: 1245678,
            limitValue: 45.78,
            limitType: "PRICE",
            quantity: 125000,
            status: "QUOTED",
            modifyReason: "QUOTED",
            externRefID: "ABC1234512397",
            broker: {
                code: 1
            },
            quotes: [
                {
                    requestID: "ABC1234512397",
                    spread: null,
                    price: 46.12,
                    quoteID: "ABC1234512397",
                    expTime: "02/10/2022 19:42:18.223",
                    counterparty: {
                        code: 1
                    }
                }
            ],
        },
        {
            placementNum: 196021185,
            limitValue: 111.0,
            quantity: 100.0,
            status: "QUOTED",
            modifyReason: "Quoted",
            externRefID: "DemoData-qauser44-1644477853870",
            quotes: [
                {
                    requestID: "214853185",
                    spread: null,
                    price: 111.0,
                    quoteID: "4734928972322029268",
                    expTime: "02/10/2022 19:42:18.223",
                    quantity: 100.0
                }
            ]
        }
    ]
};

export const mockGQLOrder_placements: GraphQLOrderSummary = {
    counteringEnabled: [25],
    actionableCounteringEnabled: [40],
    userMifidEligibility: "true",
    placements: [
        {
            placementNum: 196021185,
            limitValue: 111.0,
            quantity: 100.0,
            status: "QUOTED",
            modifyReason: "Quoted",
            externRefID: "DemoData-qauser44-1644477853870",
            quotes: [
                {
                    requestID: "214853185",
                    spread: null,
                    price: 111.0,
                    quoteID: "4734928972322029268",
                    expTime: "02/10/2022 19:42:18.223",
                    quantity: 100.0
                }
            ]
        },
        {
            placementNum: 196021186,
            limitValue: 111.0,
            quantity: 100.0,
            status: "QUOTED",
            modifyReason: "Quoted",
            externRefID: "DemoData-qauser44-1644477853870",
            quotes: [
                {
                    requestID: "214853185",
                    spread: null,
                    price: 111.0,
                    quoteID: "4734928972322029268",
                    expTime: "02/10/2022 19:42:18.223",
                    quantity: 100.0
                }
            ]
        },
        {
            placementNum: 196021187,
            limitValue: 111.0,
            quantity: 100.0,
            status: "QUOTED",
            modifyReason: "Quoted",
            externRefID: "DemoData-qauser44-1644477853870",
            quotes: [
                {
                    requestID: "214853185",
                    spread: null,
                    price: 111.0,
                    quoteID: "4734928972322029268",
                    expTime: "02/10/2022 19:42:18.223",
                    quantity: 100.0
                }
            ]
        },
        {
            placementNum: 196021188,
            limitValue: 111.0,
            quantity: 100.0,
            status: "QUOTED",
            modifyReason: "Quoted",
            externRefID: "DemoData-qauser44-1644477853870",
            quotes: [
                {
                    requestID: "214853185",
                    spread: null,
                    price: 111.0,
                    quoteID: "4734928972322029268",
                    expTime: "02/10/2022 19:42:18.223",
                    quantity: 100.0
                }
            ]
        },
        {
            placementNum: 196021189,
            limitValue: 111.0,
            quantity: 100.0,
            status: "QUOTED",
            modifyReason: "Quoted",
            externRefID: "DemoData-qauser44-1644477853870",
            quotes: [
                {
                    requestID: "214853185",
                    spread: null,
                    price: 111.0,
                    quoteID: "4734928972322029268",
                    expTime: "02/10/2022 19:42:18.223",
                    quantity: 100.0
                }
            ]
        },
        {
            placementNum: 196021190,
            limitValue: 111.0,
            quantity: 100.0,
            status: "QUOTED",
            modifyReason: "Quoted",
            externRefID: "DemoData-qauser44-1644477853870",
            quotes: [
                {
                    requestID: "214853185",
                    spread: null,
                    price: 111.0,
                    quoteID: "4734928972322029268",
                    expTime: "02/10/2022 19:42:18.223",
                    quantity: 100.0
                }
            ]
        }
    ]
};

export const mockOrderInfo_Buy_HY: OrderInfo = {
    order: mockOrder_Buy_HY,
    schema: DEFAULT_ORDER_DETAIL_SCHEMA
};

export const mockOrder_Buy_HY_Restrictions: Order = {
    id: 20001,
    side: "BUY",
    bond: "ALLY 4.7 12/31/79",
    orderBmk: STRING_PLACE_HOLDER,
    orderBmkId: STRING_PLACE_HOLDER,
    cusip: "02005NBM1",
    isin: "US02005NBM11",
    origSize: 3_000_000,
    unbookedAmt: 3_000_000,
    orderLeaves: 3_000_000,
    limit: undefined,
    limitType: undefined,
    instructions: STRING_PLACE_HOLDER,
    settleDate: "08/31/2021",
    tradingBmk: STRING_PLACE_HOLDER,
    broker: mockJPMBrokerWithRestrictions,
    currency: "USD",
    minTrdSize: 1_000,
    quality: "HY",
    price: 104.848672,
    hasValidData: true
};

export const mockOrderInfo_Buy_HY_Restrictions: OrderInfo = {
    order: mockOrder_Buy_HY_Restrictions,
    schema: DEFAULT_ORDER_DETAIL_SCHEMA
};

export const mockOrder_Buy_IG: Order = {
    bond: "VZ 2.55 03/21/31",
    broker: mockJPMBroker,
    currency: "USD",
    cusip: "92343VGJ7",
    hasValidData: true,
    id: 20002,
    instructions: "-",
    isin: "US92343VGJ70",
    limit: undefined,
    limitType: "-",
    minTrdSize: 2000,
    orderBmk: "TNOTE 1.625 05/15/31",
    orderBmkId: "91282CCB5",
    orderLeaves: 3000000,
    origSize: 3000000,
    price: 103.277304,
    quality: "IG",
    settleDate: "08/30/2021",
    side: "BUY",
    tradingBmk: "-",
    unbookedAmt: 3000000
};

export const mockOrder_Buy_HY_limit: Order = {
    id: 200003,
    side: "BUY",
    bond: "ALLY 4.7 12/31/79",
    orderBmk: STRING_PLACE_HOLDER,
    orderBmkId: STRING_PLACE_HOLDER,
    cusip: "02005NBM1",
    isin: "US02005NBM11",
    origSize: 3_000_000,
    unbookedAmt: 3_000_000,
    orderLeaves: 3_000_000,
    limit: 12345,
    limitType: undefined,
    instructions: STRING_PLACE_HOLDER,
    settleDate: "08/31/2021",
    tradingBmk: STRING_PLACE_HOLDER,
    broker: mockJPMBroker,
    currency: "USD",
    minTrdSize: 1_000,
    quality: "HY",
    price: 104.848672,
    hasValidData: true
};

export const mockOrder_Buy_IG_limit: Order = {
    bond: "VZ 2.55 03/21/31",
    broker: mockJPMBroker,
    currency: "USD",
    cusip: "92343VGJ7",
    hasValidData: true,
    id: 20004,
    instructions: "-",
    isin: "US92343VGJ70",
    limit: 23456,
    limitType: "-",
    minTrdSize: 2000,
    orderBmk: "TNOTE 1.625 05/15/31",
    orderBmkId: "91282CCB5",
    orderLeaves: 3000000,
    origSize: 3000000,
    price: 103.277304,
    quality: "IG",
    settleDate: "08/30/2021",
    side: "BUY",
    tradingBmk: "-",
    unbookedAmt: 3000000
};

// axe Ids start at 3000
export const mockAxe_IG: Axe = {
    id: "mock-3000",
    aid: "123",
    code: 3000,
    price: 0,
    spread: 86.0,
    yield: 0,
    yieldType: "-",
    quality: "IG",
    size: 3_000_000,
    time: new Date("08/30/2021").getTime(),
    broker: "JPM",
    axeBmk: "TNOTE 1.625 05/15/31",
    axeBmkId: "91282CCB5",
    hasValidData: true
};

export const mockAxeInfo_IG: AxeInfo = {
    axe: mockAxe_IG,
    schema: DEFAULT_AXE_SCHEMA
};

export const mockAxe_HY: Axe = {
    id: "mock-3001",
    aid: "123",
    code: 3001,
    price: 124.56,
    spread: 0,
    yield: 0,
    yieldType: "0Type",
    quality: "HY",
    size: 3_000_000,
    time: new Date("08/30/2021").getTime(),
    broker: "JPM",
    axeBmk: STRING_PLACE_HOLDER,
    axeBmkId: STRING_PLACE_HOLDER,
    hasValidData: true
};

export const mockAxeInfo_HY: AxeInfo = {
    axe: mockAxe_HY,
    schema: DEFAULT_AXE_SCHEMA
};

// TradeForm Ids start at 4000
export const mockTradeForm_HY_JPMSL: TradeForm = {
    spread: 0,
    price: 124.56,
    size: 3_000_000,
    broker: ["JPM", "JPMSL"],
    desk: ["FX"],
    settleDate: "08/30/2021",
    brokerSelected: "JPMSL",
    deskSelected: "FX - FX Salesman",
    hasValidData: true,
    dueInSelected: "5 minutes"
};

export const mockTradeForm_HY_JPM: TradeForm = {
    spread: 0,
    price: 124.56,
    size: 3_000_000,
    broker: ["JPM", "JPMSL", "ABC"],
    desk: ["FX", "AA", "G2"],
    settleDate: "08/30/2021",
    brokerSelected: "JPMSL",
    deskSelected: "FX - ",
    hasValidData: true,
    dueInSelected: "5 minutes"
};

export const mockTradeForm_IG_JPM: TradeForm = {
    spread: 86,
    price: 0,
    size: 3_000_000,
    broker: ["JPM", "JPMSL"],
    desk: ["FUT-ALGO"],
    settleDate: "08/30/2021",
    brokerSelected: "JPM",
    deskSelected: "FUT-ALGO - Salesman",
    spotTime: [CODE.SPOT_NOW],
    spotTimeSelected: CODE.SPOT_NOW,
    hasValidData: true,
    dueInSelected: "5 minutes"
};

export const mockTradeFormInfo_HY: TradeFormInfo = {
    tradeForm: mockTradeForm_HY_JPM,
    schema: DEFAULT_TRADEFORM_SCHEMA
};

export const mockTradeFormInfo_IG: TradeFormInfo = {
    tradeForm: mockTradeForm_IG_JPM,
    schema: DEFAULT_TRADEFORM_SCHEMA
};

export const mockConfig_HY: Config = {
    side: "BUY",
    cusip: "",
    axeId: "",
    axePrice: 0.0,
    axeSpread: 0.0,
    axeYield: 0.0,
    axeYieldType: "",
    axeQuality: HIGH_YIELD,
    axeSize: 0,
    axeCode: 0,
    axeBroker: "",
    axeBmkId: "",
    axeTime: 0,
    user: "",
    workflow: "NOTSET",
    theme: "light",
    embedded: false,
    env: null,
    mode: "NORMAL"
};

export const mockConfig_IG: Config = {
    side: "BUY",
    cusip: "",
    axeId: "",
    axePrice: 0.0,
    axeSpread: 0.0,
    axeYield: 0.0,
    axeYieldType: "",
    axeQuality: INVESTMENT_GRADE,
    axeSize: 0,
    axeCode: 0,
    axeBroker: "",
    axeBmkId: "",
    axeTime: 0,
    user: "",
    workflow: "NOTSET",
    theme: "light",
    embedded: false,
    env: null,
    mode: "NORMAL"
};

export const mockConfig_A2A_IG_PRICE: Config = {
    side: "BUY",
    cusip: "",
    axeId: "",
    axePrice: 0.0,
    axeSpread: 0.0,
    axeYield: 0.0,
    axeYieldType: "",
    axeQuality: INVESTMENT_GRADE,
    axePriceType: "AXE_PRICE_TYPE_PRICE",
    axeSize: 0,
    axeCode: 0,
    axeBroker: "",
    axeBmkId: "",
    axeTime: 0,
    user: "",
    workflow: "NOTSET",
    theme: "light",
    embedded: false,
    env: null,
    mode: "AXE_A2A"
};

export const mockConfig_A2A_HY_SPREAD: Config = {
    side: "BUY",
    cusip: "",
    axeId: "",
    axePrice: 0.0,
    axeSpread: 0.0,
    axeYield: 0.0,
    axeYieldType: "",
    axeQuality: HIGH_YIELD,
    axePriceType: "AXE_PRICE_TYPE_SPREAD",
    axeSize: 0,
    axeCode: 0,
    axeBroker: "",
    axeBmkId: "",
    axeTime: 0,
    user: "",
    workflow: "NOTSET",
    theme: "light",
    embedded: false,
    env: null,
    mode: "AXE_A2A"
};

export const mockOrder: Order = {
    id: 20000,
    side: "BUY",
    bond: "ALLY 4.7 12/31/79",
    orderBmk: STRING_PLACE_HOLDER,
    orderBmkId: STRING_PLACE_HOLDER,
    cusip: "02005NBM1",
    isin: "US02005NBM11",
    origSize: 3_000_000,
    unbookedAmt: 3_000_000,
    orderLeaves: 3_000_000,
    limit: undefined,
    limitType: undefined,
    instructions: STRING_PLACE_HOLDER,
    settleDate: "08/31/2021",
    tradingBmk: STRING_PLACE_HOLDER,
    broker: mockJPMBroker,
    currency: "USD",
    minTrdSize: 1_000,
    quality: "HY",
    price: 104.848672,
    hasValidData: true
};

export const mockQuote: Quote = {
    requestID: "214803485",
    spread: null,
    price: 23.49876594543457,
    quoteID: "777551721467657808",
    expTime: "02/28/2022 17:14:58.061",
    quantity: 100,
    counterparty: {
        shortName: "SIMEQ",
        code: 1234567,
        ticker: "SIMEQ"
    },
    side: "ASK"
};
export const mockPlacements: Placement[] = [
    {
        placementNum: 195821485,
        limitValue: 23.49876594543457,
        limitType: "PRICE",
        quantity: 100,
        status: "QUOTED",
        modifyReason: "Quoted",
        externRefID: "DemoData-qauser44-1646024347948",
        quotes: [mockQuote]
    }
];

export const mockPlacement: Placement = {
    placementNum: 195821485,
    limitValue: 23.49876594543457,
    settleDate: "09/10/2022",
    limitType: "PRICE",
    quantity: 100,
    status: "QUOTED",
    modifyReason: "Quoted",
    externRefID: "DemoData-qauser44-1646024347948",
    broker: {
        code: 1234567
    },
    quotes: [mockQuote]
};

export const mockGQLPlacement: GraphQLPlacement = {
    placementNum: 195821485,
    limitValue: 23.49876594543457,
    settleDate: "09/10/2022",
    limitType: "Price",
    quantity: 100,
    status: "QUOTED",
    modifyReason: "Quoted",
    externRefID: "DemoData-qauser44-1646024347948",
    quotes: [mockQuote],
    desk: {
        brokerType: "BROKER",
        salesman: "A",
        subBrokerID: 1
    },
    broker: {
        ticker: "a",
        shortName: "a",
        code: 1
    }
};

export const mockLastHistory: CounteringHistory = {
    value: mockPlacement.quotes[0].price,
    size: mockPlacement.quotes[0].quantity,
    quality: HIGH_YIELD,
    status: ""
};

export const mockCountering: Countering = {
    placementNum: NUM_PLACE_HOLDER,
    prevState: "NOT_SET",
    action: "NOT_SET",
    state: "NOT_SET",
    hasValidData: false
};

export const mockStepper: Stepper = {
    stepIdx: 0,
    status: "STEPS",
    subStatus: "DEFAULT_ACTION",
    fatal: false
};

export const responsePlacementQuote = {
    requestPlacementQuote: [
        {
            order: {
                ordNum: 674091585
            },
            placements: [
                {
                    placementNum: 222124985,
                    basketID: "222124685~1669696571806",
                    type: "RFQ",
                    axeID: null,
                    modifiedBy: "kbeyan"
                },
                {
                    placementNum: 222123985,
                    basketID: "222123885~1669685497296",
                    type: "RFQ",
                    axeID: null,
                    modifiedBy: "kbeyan"
                }
            ]
        }
    ]
};

export const MODIFY_REASONS = {
    RQCS: "Quote Color Sent",
    RQDT: "Quote Color Sent DNT",
    RQLA: "Lift Accepted",
    F: "Fill",
    QCR: "Quote Confirmed",
    TCRT: "Trade Correct",
    C: "Cancelation",
    MC: "Manual Cancelation",
    CR: "Cancel Request",
    RQQP: "Quote Passed",
    RQQC: "Quote Cancelled",
    SF: "Sending Failure",
    QSUB: "Quote Subjected",
    RQQA: "Quoted",
    RQCR: "Quote Counter",
    NOS: "New Order Single",
    RQDA: "Quote Done Away",
    PE: "Placement Expired"
};
