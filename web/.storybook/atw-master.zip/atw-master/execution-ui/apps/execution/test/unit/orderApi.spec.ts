/// <reference types="cypress" />
/// <reference types="chai-as-promised" />

import { benchmarkApi } from "@atx/commons/benchmark/useBenchmark";
import {
    GraphQLError,
    GraphQLOrderCreationResponse,
    GraphQLOrderCreationVariables,
    GraphQLPlacements,
    orderMutation
} from "../../src/api/types";
import { apiUtils, configUtils, windowUtils } from "../../src/common/utils";
import { placeOrder, reconcilePlacements } from "../../src/features/order/orderApi";
import { TradeForm } from "../../src/features/tradeForm/tradeForm";
import {
    mockAxe_HY,
    mockAxe_IG,
    mockConfig_HY,
    mockConfig_IG,
    mockCountering,
    mockGQLPlacement,
    mockOrderWithPlacements,
    mockOrder_Buy_HY,
    mockTradeForm_HY_JPMSL,
    mockTradeForm_IG_JPM
} from "./mockData";

context("Order API Tests", () => {
    const testUser = "testUser";
    context("#placeOrder", () => {
        const multiQuickPlaceResponse: GraphQLOrderCreationResponse = {
            multiQuickPlace: [mockGQLPlacement]
        };
        const twebPrice = 10.01;
        const request_HY: GraphQLOrderCreationVariables = {
            request: {
                orderData: {
                    orderNumber: mockOrderWithPlacements.id,
                    quantity: mockTradeForm_HY_JPMSL.size!,
                    limitValue: mockTradeForm_HY_JPMSL.price,
                    lastPrice: mockOrderWithPlacements.price,
                    ordType: "L",
                    timeInForce: "0"
                },
                externRefID: mockAxe_HY.id,
                broker: mockTradeForm_HY_JPMSL.brokerSelected!,
                subBrokerID: 1000,
                percentToPlace: mockTradeForm_HY_JPMSL.size!,
                user: testUser,
                allocationStrategy: "E",
                strategy: "E",
                settleDate: mockTradeForm_HY_JPMSL.settleDate,
                limitType: "P"
            },
            user: testUser
        };

        const request_IG: GraphQLOrderCreationVariables = {
            request: {
                orderData: {
                    orderNumber: mockOrderWithPlacements.id,
                    quantity: mockTradeForm_IG_JPM.size!,
                    limitValue: mockTradeForm_IG_JPM.spread,
                    ordType: "L",
                    timeInForce: "0"
                },
                externRefID: mockAxe_IG.id,
                broker: mockTradeForm_IG_JPM.brokerSelected!,
                subBrokerID: 1001,
                percentToPlace: mockTradeForm_IG_JPM.size!,
                user: testUser,
                allocationStrategy: "E",
                strategy: "E",
                settleDate: mockTradeForm_IG_JPM.settleDate,
                spotType: "A",
                limitType: "S",
                spreadIndex: mockAxe_IG.axeBmkId
            },
            user: testUser
        };

        beforeEach(() => {
            cy.stub(configUtils, "getUser").returns(testUser);
            cy.clock(new Date(Date.UTC(2022, 0, 18)).setHours(0));
            cy.stub(windowUtils, "registerPlacementForUrl");
        });
        afterEach(() => {
            cy.tick(0).invoke("restore");
        });

        const fixture = {
            fixture: `order-creation/${mockOrderWithPlacements.id}`,
            telemetry: ["placeOrder", "place order"]
        };
        it("...should send a request to multiQuickPlace (HY)", async () => {
            const placeOrderCall = cy.stub(apiUtils, "apiQuery").resolves(multiQuickPlaceResponse);
            const response = await placeOrder(
                mockOrderWithPlacements,
                mockTradeForm_HY_JPMSL,
                mockAxe_HY,
                mockConfig_HY,
                mockCountering
            );
            expect(placeOrderCall).to.be.calledWith(orderMutation, request_HY, fixture);
            expect(response).to.be.true;
        });
        it("...should send a request with benchPrice to requestPlacementQuote (IG, Spot Now, valid TWEB price)", async () => {
            const request_benchPrice = {
                ...request_IG,
                request: {
                    ...request_IG.request,
                    benchPrice: twebPrice
                }
            };

            const benchmarkCall = cy.stub(benchmarkApi, "getTWEBPrice").returns(twebPrice);
            const placeOrderCall = cy.stub(apiUtils, "apiQuery").resolves(multiQuickPlaceResponse);
            const response = await placeOrder(
                mockOrderWithPlacements,
                mockTradeForm_IG_JPM,
                mockAxe_IG,
                mockConfig_IG,
                mockCountering
            );
            expect(placeOrderCall).to.be.calledWith(orderMutation, request_benchPrice, fixture);
            expect(benchmarkCall).to.be.calledWith(mockAxe_IG.axeBmkId, mockOrderWithPlacements.side);
            expect(response).to.be.true;
        });
        it("...should send a request without benchPrice to requestPlacementQuote (IG, Spot Now, invalid TWEB price)", async () => {
            const benchmarkCall = cy.stub(benchmarkApi, "getTWEBPrice").returns(null);
            const placeOrderCall = cy.stub(apiUtils, "apiQuery").resolves(multiQuickPlaceResponse);
            const response = await placeOrder(
                mockOrderWithPlacements,
                mockTradeForm_IG_JPM,
                mockAxe_IG,
                mockConfig_IG,
                mockCountering
            );
            expect(placeOrderCall).to.be.calledWith(orderMutation, request_IG, fixture);
            expect(benchmarkCall).to.be.calledWith(mockAxe_IG.axeBmkId, mockOrderWithPlacements.side);
            expect(response).to.be.true;
        });
        it("...should send a request without benchPrice to requestPlacementQuote (IG, Delayed Spot, valid TWEB price)", async () => {
            const tradeForm_IG_delayed: TradeForm = {
                ...mockTradeForm_IG_JPM,
                spotTimeSelected: "11 AM ET"
            };
            const request_delayedSpot: GraphQLOrderCreationVariables = {
                ...request_IG,
                request: {
                    ...request_IG.request,
                    spotType: "11 AM ET"
                }
            };
            const benchmarkCall = cy.stub(benchmarkApi, "getTWEBPrice").returns(twebPrice);
            const placeOrderCall = cy.stub(apiUtils, "apiQuery").resolves(multiQuickPlaceResponse);
            const response = await placeOrder(
                mockOrderWithPlacements,
                tradeForm_IG_delayed,
                mockAxe_IG,
                mockConfig_IG,
                mockCountering
            );
            expect(placeOrderCall).to.be.calledWith(orderMutation, request_delayedSpot, fixture);
            expect(benchmarkCall).not.to.be.called;
            expect(response).to.be.true;
        });
        it("PlaceOrderExceptionTest", async () => {
            const orderCreationResponse: { errors: GraphQLError[] } = {
                errors: [
                    {
                        errorType: "DataFetchingException",
                        message: "Could not create the placement, because the whole order is on hold",
                        locations: [],
                        path: null,
                        extensions: null
                    }
                ]
            };
            cy.stub(apiUtils, "apiQuery").throws(orderCreationResponse);
            await expect(
                placeOrder(mockOrder_Buy_HY, mockTradeForm_HY_JPMSL, mockAxe_HY, mockConfig_HY, mockCountering)
            ).to.be.rejectedWith("Could not create the placement, because the whole order is on hold");
        });
        it("...should throw exception - bad placement - with no placement num", async () => {
            const orderCreationResponse: GraphQLOrderCreationResponse = {
                multiQuickPlace: []
            };
            cy.stub(apiUtils, "apiQuery").resolves(orderCreationResponse);

            await expect(
                placeOrder(mockOrder_Buy_HY, mockTradeForm_HY_JPMSL, mockAxe_HY, mockConfig_HY, mockCountering)
            ).to.be.rejectedWith("Unable to place out order on order: 20000");
        });
    });

    context("#reconcilePlacements", () => {
        it("should return empty array if it is null or empty", async () => {
            let placements: GraphQLPlacements = undefined;
            expect(reconcilePlacements([])).to.deep.eq([]);
            placements = [];
            expect(reconcilePlacements(placements)).to.deep.eq([]);
        });
        it("should return normalized axe", () => {
            let placements: GraphQLPlacements = [mockGQLPlacement];
            mockGQLPlacement.axeID = "1";
            mockGQLPlacement.placementGenFields = [
                {
                    "key": "numOfCompetitors",
                    "value": "1"
                },
                {
                    "key": "axeLevel",
                    "value": "5"
                },
                {
                    "key": "axeQty",
                    "value": "5"
                }
            ];
            const { placementGenFields, ...filteredmockGQLPlacement } = mockGQLPlacement;

            let reconciledPlacements = [
                {
                    ...filteredmockGQLPlacement,
                    limitType: "PRICE",
                    settleDate: "09/10/2022",
                    axe: { axeID: 1, axeLevel: 5, axeQty: 5},
                }
            ];
            console.log(reconcilePlacements(placements));
            console.log(reconciledPlacements);
            expect(reconcilePlacements(placements)).to.deep.eq(reconciledPlacements);
        });
    });
});
