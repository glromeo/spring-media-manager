import { orderUtils } from "../../src/common/utils";
import { BrokerEntity, BrokerRestriction } from "../../src/features/order/order";
import {
    mockBrokerRestriction_0Per,
    mockBrokerRestriction_100Per,
    mockBrokerRestriction_66Per,
    mockJPMBroker,
    mockOrder_Buy_HY,
    mockOrder_Buy_HY_Restrictions,
    mockRestrictionAllocation_TSTTRD1_100Per,
    mockRestrictionAllocation_TSTTRD1_2P5er,
    mockRestrictionAllocation_TSTTRD1_50Per,
    TSTTRD1
} from "./mockData";

context("orderUtils tests", () => {
    context("#hasBrokerRestrictions", () => {
        it("...should return true if at least one broker entity has a restriction allocation", () => {
            expect(orderUtils.hasBrokerRestrictions(mockOrder_Buy_HY)).to.be.false;
            expect(orderUtils.hasBrokerRestrictions(mockOrder_Buy_HY_Restrictions)).to.be.true;
        });
    });
    context("#isFullyRestricted", () => {
        it("#...should return true if restriction quantity is 0", () => {
            const fullyRestricted: BrokerEntity = {
                name: "ABC",
                code: 1,
                desk: [],
                restriction: mockBrokerRestriction_0Per,
                isDelayedSpot: false,
                isCounteringEnabled: false
            };
            expect(orderUtils.isFullyRestricted(fullyRestricted)).to.be.true;

            const noRestricted: BrokerEntity = {
                ...fullyRestricted,
                restriction: undefined
            };

            expect(orderUtils.isFullyRestricted(noRestricted)).to.be.false;

            const partiallyRestricted: BrokerEntity = {
                ...fullyRestricted,
                restriction: mockBrokerRestriction_66Per
            };
            expect(orderUtils.isFullyRestricted(partiallyRestricted)).to.be.false;
        });
    });
    context("#isFullyAvailable", () => {
        it("...should return true if none of the allocations are marked isRestricted", () => {
            const isRestricted: BrokerRestriction = {
                ...mockBrokerRestriction_66Per,
                allocation: [mockRestrictionAllocation_TSTTRD1_50Per]
            };

            const isNotRestricted: BrokerRestriction = {
                ...mockBrokerRestriction_100Per,
                allocation: [
                    {
                        ...mockRestrictionAllocation_TSTTRD1_100Per,
                        isRestricted: false
                    }
                ]
            };

            const restrictedBroker: BrokerEntity = {
                name: "ABC",
                code: 1,
                desk: [],
                restriction: isRestricted,
                isDelayedSpot: false,
                isCounteringEnabled: true
            };
            expect(orderUtils.isFullyAvailable(restrictedBroker)).to.be.false;

            const nonRestrictedBroker: BrokerEntity = {
                ...restrictedBroker,
                restriction: isNotRestricted
            };

            expect(orderUtils.isFullyAvailable(nonRestrictedBroker)).to.be.true;
        });
    });
    context("#getSelectedBrokerEntity", () => {
        it("...should return the broker that matches the selectedBroker input", () => {
            expect(orderUtils.getSelectedBrokerEntity(mockJPMBroker, mockJPMBroker.entity[0].name)).to.eq(
                mockJPMBroker.entity[0]
            );
            expect(orderUtils.getSelectedBrokerEntity(mockJPMBroker, "INVALID")).to.eq(undefined);
        });
    });
    context("#isAllocated", () => {
        it("...should return whether the allocation matches the provided code", () => {
            expect(orderUtils.isAllocated([mockRestrictionAllocation_TSTTRD1_2P5er], TSTTRD1.code)).to.be.true;
            expect(orderUtils.isAllocated([mockRestrictionAllocation_TSTTRD1_2P5er], -9)).to.be.false;
        });
    });
    context("#isBrokerCounterEnabled", () => {
        it("...should return whether the broker is counter eligible for the order", () => {
            mockOrder_Buy_HY.broker.entity[0].isCounteringEnabled = true;
            expect(orderUtils.isBrokerCounterEnabled(mockOrder_Buy_HY.broker.entity, "JPMSL")).to.be.true;
            mockOrder_Buy_HY.broker.entity[0].isCounteringEnabled = false;
            expect(orderUtils.isBrokerCounterEnabled(mockOrder_Buy_HY.broker.entity, "JPMSL")).to.be.false;
        });
    });
    context("#formatSecLookupDesc", () => {
        it("should format desc that has ticker, coupon value, and date", () => {
            const security = {
                "desc1": "TREASURY NOTE 1.625 15-MAY-2031",
                "desc2": "",
                "cusip": "91282CCB5",
                "ticker": "TNOTE",
                "desc3": "",
                "secGroup": "BND",
                "secType": "GOVT",
                "sedol": "",
                "CLASS_TYPE": "com.bfm.prism.data.SecuritySearchRecord",
                "isin": ""
            };
            expect(orderUtils.formatSecLookupDesc(security)).to.eq("TNOTE 1.625 05/15/31");
        });
        it("should format desc that has ticker and date, no coupon value, with 0.0", () => {
            const security = {
                "desc1": "CASHFLOW STREAM LIABCUSP 28-FEB-2068 Private",
                "desc2": "",
                "cusip": "BLK805531",
                "ticker": "LCS",
                "desc3": "",
                "secGroup": "BND",
                "bbTicker": "",
                "secType": "CORP",
                "sedol": "",
                "CLASS_TYPE": "com.bfm.prism.data.SecuritySearchRecord",
                "isin": ""
            };
            expect(orderUtils.formatSecLookupDesc(security)).to.eq("LCS 0.0 02/28/68");
        });
        it.only("should return original desc if has date and coupon value, no ticker", () => {
            const security = {
                "desc1": "CASHFLOW STREAM LIABCUSP 28-FEB-2068 Private",
                "desc2": "",
                "cusip": "BLK805531",
                "ticker": "",
                "desc3": "",
                "secGroup": "BND",
                "bbTicker": "",
                "secType": "CORP",
                "sedol": "",
                "CLASS_TYPE": "com.bfm.prism.data.SecuritySearchRecord",
                "isin": ""
            };
            expect(orderUtils.formatSecLookupDesc(security)).to.eq("CASHFLOW STREAM LIABCUSP 28-FEB-2068 Private");
        });
    });
});
