/// <reference types="cypress" />
import { CODE } from "../../src/common/constants";
import {
    apiUtils,
    configUtils,
    counteringUtils,
    genericUtils,
    orderUtils,
    pricingTypeUtils,
    tradeFormUtils,
    windowUtils
} from "../../src/common/utils";
import { Config } from "../../src/features/config/config";
import { TradeForm } from "../../src/features/tradeForm/tradeForm";
import { Dimension, HIGH_YIELD, INVESTMENT_GRADE, PRICE, SPREAD, STRING_PLACE_HOLDER } from "../../src/models/common";
import {
    mockAxeInfo_HY,
    mockAxeInfo_IG,
    mockAxe_HY,
    mockAxe_IG,
    mockConfig_A2A_HY_SPREAD,
    mockConfig_A2A_IG_PRICE,
    mockConfig_HY,
    mockConfig_IG,
    mockCountering,
    mockFXDesk,
    mockJPMSLBrokerEntity,
    mockOrderInfo_Buy_HY_Restrictions,
    mockOrderWithPlacements,
    mockOrder_Buy_HY,
    mockOrder_Buy_HY_limit,
    mockOrder_Buy_IG,
    mockOrder_Buy_IG_limit,
    mockPlacement,
    mockTradeForm_HY_JPMSL,
    mockTradeForm_IG_JPM
} from "./mockData";

context("Utils Tests", () => {
    context("API Utils", () => {
        const testUrl = "testURL";
        it("#getUnableToFetchMessage should return a standardized error message", () => {
            expect(apiUtils.getUnableToFetchMessage("order", "1234", "orderId")).to.eq(
                "Unable to fetch order for orderId: 1234"
            );
            expect(apiUtils.getUnableToFetchMessage("order", "1234")).to.eq("Unable to fetch order: 1234");
            expect(apiUtils.getUnableToFetchMessage("order")).to.eq("Unable to fetch order");
        });
        context("#parseFetchResponse", () => {
            it("should parse json", async () => {
                const result = await apiUtils.parseFetchResponse(
                    new window.Response(JSON.stringify({ a: 123 }), {
                        status: 200,
                        headers: { "Content-type": "application/json" }
                    })
                );
                expect(result).not.to.be.null;
                expect(result).to.deep.equal({ a: 123 });
            });
            it("should parse text", async () => {
                const result = await apiUtils.parseFetchResponse(
                    new window.Response("abcde", {
                        status: 200
                    })
                );
                expect(result).not.to.be.null;
                expect(result).to.equal("abcde");
            });
        });
    });

    context("Data Utils", () => {
        context("#getPlacement", () => {
            it("...should return parsed placement from order if exists", () => {
                const placementNum = 1245678;
                expect(orderUtils.getPlacement(mockOrderWithPlacements, placementNum)).to.deep.equal(
                    mockOrderWithPlacements.placements![0]
                );
                expect(orderUtils.getPlacement(mockOrderWithPlacements, 9999999)).to.be.undefined;
            });
        });

        context("#getCurrentPricingType", () => {
            before(() => {
                cy.stub(orderUtils, "getPlacement");
                cy.stub(pricingTypeUtils, "getQualityFromPlacement").returns("IG");
                cy.stub(pricingTypeUtils, "getQualityFromAxeOrUser").returns("HY");
            });
            it("...should return spread if placement quality is IG and live negotiation", () => {
                cy.stub(counteringUtils, "isLiveNegotiationState").returns(true);

                expect(
                    pricingTypeUtils.getCurrentPricingType({
                        axeInfo: mockAxeInfo_IG,
                        orderInfo: mockOrderInfo_Buy_HY_Restrictions,
                        config: mockConfig_HY,
                        countering: mockCountering
                    })
                ).to.eq(SPREAD);
            });
            it("...should return price if quality from axe is HY and no live or dead negotiation", () => {
                cy.stub(counteringUtils, "isLiveNegotiationState").returns(false);

                expect(
                    pricingTypeUtils.getCurrentPricingType({
                        axeInfo: mockAxeInfo_IG,
                        orderInfo: mockOrderInfo_Buy_HY_Restrictions,
                        config: mockConfig_HY,
                        countering: mockCountering
                    })
                ).to.eq(PRICE);
            });
            it("...should return price if in A2A mode and the axe price type is PRICE", () => {
                cy.stub(configUtils, "isAxeA2AMode").returns(true);

                expect(
                    pricingTypeUtils.getCurrentPricingType({
                        axeInfo: mockAxeInfo_IG,
                        orderInfo: { order: mockOrder_Buy_IG, schema: [] },
                        config: mockConfig_A2A_IG_PRICE,
                        countering: mockCountering
                    })
                ).to.eq(PRICE);
            });
            it("...should return spread if in A2A mode and the axe price type is SPREAD", () => {
                cy.stub(configUtils, "isAxeA2AMode").returns(true);

                expect(
                    pricingTypeUtils.getCurrentPricingType({
                        axeInfo: mockAxeInfo_HY,
                        orderInfo: mockOrderInfo_Buy_HY_Restrictions,
                        config: mockConfig_A2A_HY_SPREAD,
                        countering: mockCountering
                    })
                ).to.eq(SPREAD);
            });
        });

        context("#getQualityFromAxeOrUser", () => {
            it("...should return order quality if isCares() is true", () => {
                cy.stub(configUtils, "isCares").returns(true);
                expect(
                    pricingTypeUtils.getQualityFromAxeOrUser(
                        mockAxeInfo_IG,
                        mockOrderInfo_Buy_HY_Restrictions,
                        mockConfig_HY
                    )
                ).to.eq(mockOrderInfo_Buy_HY_Restrictions.order.quality);
            });

            it("#...should return axe quality if isCares() is false", () => {
                cy.stub(configUtils, "isCares").returns(false);
                expect(
                    pricingTypeUtils.getQualityFromAxeOrUser(
                        mockAxeInfo_IG,
                        mockOrderInfo_Buy_HY_Restrictions,
                        mockConfig_IG
                    )
                ).to.eq(mockAxeInfo_IG.axe.quality);
            });
        });

        context("#getQualityFromPlacement", () => {
            it("...should return correct BondQuality from placement", () => {
                const pricePlacement = {
                    ...mockPlacement,
                    limitType: "PRICE" as "PRICE"
                };
                expect(pricingTypeUtils.getQualityFromPlacement(pricePlacement)).to.equal(HIGH_YIELD);
                const spreadPlacement = {
                    ...mockPlacement,
                    limitType: "SPREAD" as "SPREAD"
                };
                expect(pricingTypeUtils.getQualityFromPlacement(spreadPlacement)).to.equal(INVESTMENT_GRADE);
            });
        });

        context("#getQualityFromPlacementQuote", () => {
            it("...should return correct BondQuality from placementQuote", () => {
                expect(pricingTypeUtils.getQualityFromPlacementQuote(mockPlacement.quotes[0])).to.be.null;
                const priceQuote = {
                    ...mockPlacement.quotes[0],
                    type: "PRICE" as "PRICE"
                };
                expect(pricingTypeUtils.getQualityFromPlacementQuote(priceQuote)).to.equal(HIGH_YIELD);
                const spreadQuote = {
                    ...mockPlacement.quotes[0],
                    type: "SPREAD" as "SPREAD"
                };
                expect(pricingTypeUtils.getQualityFromPlacementQuote(spreadQuote)).to.equal(INVESTMENT_GRADE);
            });
        });

        context("#createUpdatePlacementQuoteVars", () => {
            beforeEach(() => {
                cy.stub(configUtils, "getUser").returns("testUser");
            });
            it("should return executePlacementQuote variables", () => {
                const createUpdatePlacementQuoteVarsRes = {
                    request: {
                        placementNum: 195821485,
                        externId: "777551721467657808",
                        quantity: 100,
                        askPrice: 23.49876594543457,
                        bidPrice: 23.49876594543457,
                        counterparty: "SIMEQ",
                        dueInTime: "time"
                    },
                    user: "testUser"
                };

                expect(
                    apiUtils.createUpdatePlacementQuoteVars(mockPlacement, {
                        tradeValue: 23.49876594543457,
                        quantity: 100,
                        dueInTime: "time"
                    })
                ).to.deep.equal(createUpdatePlacementQuoteVarsRes);
            });
        });

        context("#isSpread", () => {
            it("...should return order quality === IG if isCares() is true", () => {
                cy.stub(configUtils, "isCares").returns(true);
                expect(
                    pricingTypeUtils.isSpread(mockOrder_Buy_HY, mockAxe_IG, mockConfig_HY, mockCountering)
                ).to.be.false;
            });

            it("#...should return axe quality === IG if isCares() is false", () => {
                cy.stub(configUtils, "isCares").returns(false);
                expect(
                    pricingTypeUtils.isSpread(mockOrder_Buy_HY, mockAxe_IG, mockConfig_IG, mockCountering)
                ).to.be.true;
            });
        });

        context("#getSelectedBroker", () => {
            it("...should return the broker that matches the trade form", () => {
                const invalid: TradeForm = {
                    spread: 0,
                    price: 124.56,
                    size: 3_000_000,
                    broker: ["ABC", "DEF"],
                    desk: ["XYZ"],
                    settleDate: "08/30/2021",
                    brokerSelected: "ABC",
                    deskSelected: "FX-",
                    hasValidData: true
                };

                expect(tradeFormUtils.getSelectedBrokerEntity(mockOrder_Buy_HY, mockTradeForm_HY_JPMSL)).to.eq(
                    mockJPMSLBrokerEntity
                );
                expect(tradeFormUtils.getSelectedBrokerEntity(mockOrder_Buy_HY, invalid)).to.be.undefined;
            });
        });
        context("#getSelectedDesk", () => {
            it("...should return the desk that matches the trade form", () => {
                const invalid: TradeForm = {
                    spread: 0,
                    price: 124.56,
                    size: 3_000_000,
                    broker: ["ABC", "DEF"],
                    desk: ["XYZ"],
                    settleDate: "08/30/2021",
                    brokerSelected: "ABC",
                    deskSelected: "FX-",
                    hasValidData: true
                };
                expect(tradeFormUtils.getSelectedDesk(mockJPMSLBrokerEntity, mockTradeForm_HY_JPMSL)).to.eq(mockFXDesk);
                expect(tradeFormUtils.getSelectedDesk(mockJPMSLBrokerEntity, invalid)).to.be.undefined;
            });
        });
        const testUser = "testUser";
        context("#createOrder", () => {
            beforeEach(() => {
                cy.stub(configUtils, "getUser").returns(testUser);
            });
            it("...should create price-based orderCreationVariables for a HY order that is NOT cares or limit", () => {
                cy.stub(configUtils, "isCares").returns(false);
                const order = mockOrder_Buy_HY;
                const tradeForm = mockTradeForm_HY_JPMSL;
                const axe = mockAxe_HY;
                const settings = mockConfig_HY;

                const result = apiUtils.createOrder(order, tradeForm, axe, settings, mockCountering);
                const expected = {
                    request: {
                        orderData: {
                            orderNumber: 20000,
                            quantity: 3000000,
                            lastPrice: 104.848672,
                            ordType: "L",
                            timeInForce: "0",
                            limitValue: 124.56
                        },
                        broker: "JPMSL",
                        subBrokerID: 1000,
                        user: "testUser",
                        allocationStrategy: "E",
                        strategy: "E",
                        percentToPlace: 3000000,
                        limitType: "P",
                        settleDate: "08/30/2021",
                        externRefID: "mock-3001"
                    },
                    user: "testUser"
                };
                expect(result).to.deep.eq(expected);
            });
            it("...should create spread-based orderCreationVariables for a IG order that is NOT cares or limit", () => {
                cy.stub(configUtils, "isCares").returns(false);
                const order = mockOrder_Buy_IG;
                const tradeForm = mockTradeForm_IG_JPM;
                const axe = mockAxe_IG;
                const settings = mockConfig_IG;

                const result = apiUtils.createOrder(order, tradeForm, axe, settings, mockCountering);
                const expected = {
                    request: {
                        orderData: {
                            orderNumber: 20002,
                            quantity: 3000000,
                            ordType: "L",
                            timeInForce: "0",
                            limitValue: 86
                        },
                        broker: "JPM",
                        subBrokerID: 1001,
                        user: "testUser",
                        allocationStrategy: "E",
                        strategy: "E",
                        percentToPlace: 3000000,
                        limitType: "S",
                        externRefID: "mock-3000",
                        settleDate: "08/30/2021",
                        spotType: CODE.SPOT_NOW,
                        spreadIndex: "91282CCB5"
                    },
                    user: "testUser"
                };
                expect(result).to.deep.eq(expected);
            });
            it("...should create price-based orderCreationVariables for a HY order that is cares but NOT limit", () => {
                cy.stub(configUtils, "isCares").returns(true);

                const order = mockOrder_Buy_HY;
                const tradeForm = mockTradeForm_HY_JPMSL;
                const axe = mockAxe_HY;
                const settings = mockConfig_HY;

                const result = apiUtils.createOrder(order, tradeForm, axe, settings, mockCountering);

                const expected = {
                    request: {
                        orderData: {
                            orderNumber: 20000,
                            quantity: 3000000,
                            lastPrice: 104.848672,
                            ordType: "L",
                            timeInForce: "0",
                            limitValue: 124.56
                        },
                        broker: "JPMSL",
                        subBrokerID: 1000,
                        user: "testUser",
                        allocationStrategy: "E",
                        strategy: "E",
                        percentToPlace: 3000000,
                        limitType: "P",
                        settleDate: "08/30/2021"
                    },
                    user: "testUser"
                };
                expect(result).to.deep.eq(expected);
            });
            it("...should create spread-based orderCreationVariables for a IG order that is cares but NOT limit", () => {
                cy.stub(configUtils, "isCares").returns(true);

                const order = mockOrder_Buy_IG;
                const tradeForm = mockTradeForm_IG_JPM;
                const axe = mockAxe_IG;
                const settings = mockConfig_IG;

                const result = apiUtils.createOrder(order, tradeForm, axe, settings, mockCountering);

                const expected = {
                    request: {
                        orderData: {
                            orderNumber: 20002,
                            quantity: 3000000,
                            ordType: "L",
                            timeInForce: "0",
                            limitValue: 86
                        },
                        broker: "JPM",
                        subBrokerID: 1001,
                        user: "testUser",
                        allocationStrategy: "E",
                        strategy: "E",
                        percentToPlace: 3000000,
                        limitType: "S",
                        settleDate: "08/30/2021",
                        spotType: CODE.SPOT_NOW,
                        spreadIndex: "91282CCB5"
                    },
                    user: "testUser"
                };
                expect(result).to.deep.eq(expected);
            });
            it("...should create price-based orderCreationVariables for a HY order that is cares and limit", () => {
                cy.stub(configUtils, "isCares").returns(true);

                const order = mockOrder_Buy_HY_limit;
                const tradeForm = mockTradeForm_HY_JPMSL;
                const axe = mockAxe_HY;
                const settings = mockConfig_HY;

                const result = apiUtils.createOrder(order, tradeForm, axe, settings, mockCountering);

                const expected = {
                    request: {
                        orderData: {
                            orderNumber: 200003,
                            quantity: 3000000,
                            lastPrice: 104.848672,
                            ordType: "L",
                            timeInForce: "0",
                            limitValue: 124.56
                        },
                        broker: "JPMSL",
                        subBrokerID: 1000,
                        user: "testUser",
                        allocationStrategy: "E",
                        strategy: "E",
                        percentToPlace: 3000000,
                        limitType: "P",
                        settleDate: "08/30/2021"
                    },
                    user: "testUser"
                };
                expect(result).to.deep.eq(expected);
            });
            it("...should create spread-based orderCreationVariables for a IG order that is cares and limit", () => {
                cy.stub(configUtils, "isCares").returns(true);
                const order = mockOrder_Buy_IG_limit;
                const tradeForm = mockTradeForm_IG_JPM;
                const axe = mockAxe_IG;
                const settings = mockConfig_IG;

                const result = apiUtils.createOrder(order, tradeForm, axe, settings, mockCountering);

                const expected = {
                    request: {
                        orderData: {
                            orderNumber: 20004,
                            quantity: 3000000,
                            ordType: "L",
                            timeInForce: "0",
                            limitValue: 86
                        },
                        broker: "JPM",
                        subBrokerID: 1001,
                        user: "testUser",
                        allocationStrategy: "E",
                        strategy: "E",
                        percentToPlace: 3000000,
                        limitType: "S",
                        settleDate: "08/30/2021",
                        spotType: CODE.SPOT_NOW,
                        spreadIndex: "91282CCB5"
                    },
                    user: "testUser"
                };
                expect(result).to.deep.eq(expected);
            });
        });
    });

    context("Generic Utils", () => {
        it("#countering only mode should return true", () => {
            const config: Partial<Config> = {
                mode: "COUNTERING_ONLY"
            };
            expect(configUtils.isCounteringModeOnly(config as Config)).to.eq(true);
        });
        it("#countering mode should return true", () => {
            const config: Partial<Config> = {
                mode: "COUNTERING"
            };
            expect(configUtils.isCounteringMode(config as Config)).to.eq(true);
        });
        it("#getYesterdaysDateAsEpoch should return yesterdays date as epoch time", () => {
            const epochYesterday = genericUtils.getYesterdaysDateAsEpoch();
            const yesterdayDate = new Date(epochYesterday).getDate();
            const todaysDate = new Date().getDate();
            expect(yesterdayDate).to.not.eq(todaysDate);
        });
        it("#nextNumber should increment the number", () => {
            expect(genericUtils.nextNumber()).to.eq(1);
            expect(genericUtils.nextNumber()).to.eq(2);
        });
        it("#formatSize should add decimals and commas", () => {
            expect(genericUtils.formatSize(100, 2)).to.eq("100.00");
            expect(genericUtils.formatSize(100000, 0)).to.eq("100,000");
            expect(genericUtils.formatSize(100000, 1)).to.eq("100,000.0");
        });
        it("#removeCommas should remove commas from numeric inputs", () => {
            expect(genericUtils.removeCommas("nocommas")).to.eq("");
            expect(genericUtils.removeCommas("1234")).to.eq("1234");
            expect(genericUtils.removeCommas("one,comma")).to.eq("");
            expect(genericUtils.removeCommas("1,234")).to.eq("1234");
            expect(genericUtils.removeCommas("-1,234")).to.eq("-1234");
            expect(genericUtils.removeCommas("-1,234.456")).to.eq("-1234.456");
        });
        it("#removeSpace should remove all spaces from input and convert to lowercase if specified", () => {
            expect(genericUtils.removeSpace("nospaces")).to.eq("nospaces");
            expect(genericUtils.removeSpace("some spaces ")).to.eq("somespaces");
            expect(genericUtils.removeSpace(" 12 3 4 5")).to.eq("12345");
            expect(genericUtils.removeSpace(" SOME UPPERCASE words", false)).to.eq("SOMEUPPERCASEwords");
        });
        it("#titleCase should convert sentences to title case", () => {
            expect(genericUtils.titleCase("my lowercase string here")).to.eq("My Lowercase String Here");
            expect(genericUtils.titleCase("my mixed Case String here")).to.eq("My Mixed Case String Here");
            expect(genericUtils.titleCase("MY UPPERCASE STRING HERE")).to.eq("My Uppercase String Here");
            expect(genericUtils.titleCase("My String with numbers 1234")).to.eq("My String With Numbers 1234");
            expect(genericUtils.titleCase("")).to.eq("");
            expect(genericUtils.titleCase(null!)).to.eq("");
        });
        it("#formatDate should format dates to MM/DD/YYYY or MM/DD/YY OR DD-MMM-YYYY", () => {
            expect(genericUtils.formatDate("31-AUG-2021", { fullYear: true })).to.eq("08/31/2021");
            expect(genericUtils.formatDate("02-DEC-2020", { fullYear: false, separator: "slash" })).to.eq("12/02/20");
            expect(genericUtils.formatDate("January 1, 2022", { fullYear: true })).to.eq("01/01/2022");
            expect(genericUtils.formatDate("04/12/2021", { fullYear: false, month: "number" })).to.eq("04/12/21");
            expect(genericUtils.formatDate("04/12/21", { fullYear: false, month: "number", separator: "slash" })).to.eq(
                "04/12/21"
            );
            expect(genericUtils.formatDate("31-AUG-2021", { fullYear: true, month: "short", separator: "dash" })).to.eq(
                "31-AUG-2021"
            );
            expect(genericUtils.formatDate("02-DEC-2020", { fullYear: true, month: "short", separator: "dash" })).to.eq(
                "02-DEC-2020"
            );
            expect(
                genericUtils.formatDate("January 1, 2022", { fullYear: true, month: "short", separator: "dash" })
            ).to.eq("01-JAN-2022");
            expect(genericUtils.formatDate("04/12/2021", { fullYear: true, month: "short", separator: "dash" })).to.eq(
                "12-APR-2021"
            );
            expect(genericUtils.formatDate("04/12/2021", { fullYear: false })).to.eq("04/12/21");
            expect(
                genericUtils.formatDate("January 1, 2022", { fullYear: true, month: "short", separator: "dash" })
            ).to.eq("01-JAN-2022");
            expect(genericUtils.formatDate("January 3, 2022")).to.eq("01/03/2022");
        });
        it("#formatPrice should format prices and handle zero / null cases", () => {
            expect(genericUtils.formatPrice(10)).to.eq("10.000");
            expect(genericUtils.formatPrice(10.1)).to.eq("10.100");
            expect(genericUtils.formatPrice(10.12)).to.eq("10.120");
            expect(genericUtils.formatPrice(10.12345)).to.eq("10.12345");
            expect(genericUtils.formatPrice(0)).to.eq("0.000");
            expect(genericUtils.formatPrice(null!)).to.eq(STRING_PLACE_HOLDER);
        });
        it("#formatSpread should format Spread and handle positive / negative / zero / null cases", () => {
            expect(genericUtils.formatSpread(10)).to.eq("+10.000");
            expect(genericUtils.formatSpread(10.1)).to.eq("+10.100");
            expect(genericUtils.formatSpread(10.12)).to.eq("+10.120");
            expect(genericUtils.formatSpread(-10.12)).to.eq("-10.120");
            expect(genericUtils.formatSpread(10.123456)).to.eq("+10.123456");
            expect(genericUtils.formatSpread(-10.123456)).to.eq("-10.123456");
            expect(genericUtils.formatSpread(0)).to.eq("0.000");
            expect(genericUtils.formatSpread(null!)).to.eq(STRING_PLACE_HOLDER);
        });
        it("#convertToMinPrecision should format a number with a given min and optional max precision value", () => {
            expect(genericUtils.convertToMinPrecision(10, 3)).to.eq("10.000");
            expect(genericUtils.convertToMinPrecision(-10, 3)).to.eq("-10.000");
            expect(genericUtils.convertToMinPrecision(10.1234567, 1, 3)).to.eq("10.123");
            expect(genericUtils.convertToMinPrecision(10.56, 1, 1)).to.eq("10.6");
            expect(genericUtils.convertToMinPrecision(10.56, 5, 10)).to.eq("10.56000");
        });
        it("#getSideTitle should return Lift or Hit the Axe", () => {
            expect(genericUtils.getSideTitle("BUY")).to.eq("Lift");
            expect(genericUtils.getSideTitle("SELL")).to.eq("Hit");
            expect(genericUtils.getSideTitle("NOTSET")).to.eq("Hit");
        });
        it("#sortSpotTimes should sort by time", () => {
            expect(
                genericUtils.sortSpotTimes(["Spot Now", "11am ET", "3am ET", "6:30pm ET", "4pm ET", "5:30am ET"])
            ).to.eql(["Spot Now", "3am ET", "5:30am ET", "11am ET", "4pm ET", "6:30pm ET"]);
        });
        it("#isValidNumber should determine if an input is numeric", () => {
            expect(genericUtils.isValidNumber(1234.56)).to.be.true;
            expect(genericUtils.isValidNumber(1234)).to.be.true;
            expect(genericUtils.isValidNumber(0.56)).to.be.true;
            expect(genericUtils.isValidNumber(0.56)).to.be.true;
            expect(genericUtils.isValidNumber(0)).to.be.true;
            expect(genericUtils.isValidNumber("1234.56")).to.be.true;
            expect(genericUtils.isValidNumber("0")).to.be.true;
            expect(genericUtils.isValidNumber("invalid")).to.be.false;
            expect(genericUtils.isValidNumber("")).to.be.false;
            expect(genericUtils.isValidNumber(null)).to.be.false;
            expect(genericUtils.isValidNumber(undefined)).to.be.false;
            expect(genericUtils.isValidNumber(NaN)).to.be.false;
            expect(genericUtils.isValidNumber({})).to.be.false;
            expect(genericUtils.isValidNumber([])).to.be.false;
        });
        context("#getConvertedDueTime", () => {
            beforeEach(() => {
                cy.clock(new Date("2023-02-16T05:30:00.000Z"), ["Date"]);
            });
            it("should set new york time properly to 00:00:00 hour instead of 24:00:00 with offSet mins", () => {
                // you have to use {hourCycle: "h23"} instead of {hour12: false}
                expect(genericUtils.getConvertedDueTime(2)).equal("00:32:00|America/New_York");
            });
            it("should set new york time properly to 00:00:00 hour instead of 24:00:00 with no offSet mins", () => {
                expect(genericUtils.getConvertedDueTime()).equal("00:30:00|America/New_York");
            });
        });
    });
    context("#resizeWindow", () => {
        it("...should resize the window", () => {
            const dim: Dimension = { width: 700, height: 800 };
            (window as any)["bfmCefQuery"] = (args) => {
                expect(args.request).to.eq('resizeWindow:{"width":700,"height":800}');
            };
            windowUtils.resizeWindow(dim);
        });
    });
    context("#foregroundWindow", () => {
        it("...should request to be foregrounded", () => {
            (window as any)["bfmCefQuery"] = (args) => {
                expect(args.request).to.eq(`foregroundWindow`);
            };
            windowUtils.foregroundWindow();
        });
    });
    context("#convertTimeToDate", () => {
        it("should convert the timestamp to toLocaleString date and time", async () => {
            const result = genericUtils.convertTimeToDate(1659005421413, "America/New_York")?.toUTCString();
            const expected = new Date("Thu Jul 28 2022 06:50:21 GMT-0400 (Eastern Daylight Time)").toUTCString();
            expect(result).to.eq(expected);
        });
        it("should return null if the timestamp is null", async () => {
            const result = genericUtils.convertTimeToDate(null, "America/New_York");
            const expected = null;
            expect(result).to.eq(expected);
        });
    });
    context("#convertHHmmToDate", () => {
        it("should handle null inputs", () => {
            const nullString = genericUtils.convertHHmmToDate(null, new Date());
            expect(nullString).to.be.null;
            const nullDate = genericUtils.convertHHmmToDate("12:00  AM", null);
            expect(nullDate).not.to.be.null;
            const empty = genericUtils.convertHHmmToDate(STRING_PLACE_HOLDER, new Date());
            expect(empty).to.be.null;
        });
        it("should return a correctly formatted date", () => {
            const amString = "08:12  AM";
            const pmString = "05:15 PM";
            const noonString = "12:00  PM";
            const midnightString = "12:00  AM";
            const date = new Date("Thu Jul 28 2022 06:50:21 GMT-0400 (Eastern Daylight Time)");
            const amResult = genericUtils.convertHHmmToDate(amString, date);
            expect(amResult!.getDay()).eq(date.getDay());
            expect(amResult!.getHours()).eq(8);
            expect(amResult!.getMinutes()).eq(12);
            expect(amResult!.getSeconds()).eq(0);

            const pmResult = genericUtils.convertHHmmToDate(pmString, date);
            expect(pmResult!.getDay()).eq(date.getDay());
            expect(pmResult!.getHours()).eq(17);
            expect(pmResult!.getMinutes()).eq(15);
            expect(pmResult!.getSeconds()).eq(0);

            const noonResult = genericUtils.convertHHmmToDate(noonString, date);
            expect(noonResult!.getDay()).eq(date.getDay());
            expect(noonResult!.getHours()).eq(12);
            expect(noonResult!.getMinutes()).eq(0);
            expect(noonResult!.getSeconds()).eq(0);

            const midnightResult = genericUtils.convertHHmmToDate(midnightString, date);
            expect(midnightResult!.getDay()).eq(date.getDay());
            expect(midnightResult!.getHours()).eq(0);
            expect(midnightResult!.getMinutes()).eq(0);
            expect(midnightResult!.getSeconds()).eq(0);
        });
    });
});
