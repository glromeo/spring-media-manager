/// <reference types="cypress" />
import {
    GraphQLCounteringValidationResponse,
    GraphQLError,
    GraphQLOrderValidationResponse,
    GraphQLResult,
    GraphQLValidationResponse
} from "../../src/api/types";
import { configUtils } from "../../src/common/utils";
import { apiUtils } from "../../src/common/utils/apiUtils";
import { genericUtils } from "../../src/common/utils/genericUtils";
import {
    parseAlertsFromGraphQLError,
    performCounteringValidation,
    performOrderValidation,
    validateBeforeUpdatingPlacementQuote
} from "../../src/features/alerts/validate/validateApi";
import {
    mockAxe_HY,
    mockConfig_HY,
    mockCountering,
    mockOrderWithPlacements,
    mockOrder_Buy_HY,
    mockStepper,
    mockTradeForm_HY_JPMSL
} from "./mockData";

context("Validation API Tests", () => {
    const testUser = "testUser";
    const placementNum = mockOrderWithPlacements.placements![0].placementNum;
    const placement = mockOrderWithPlacements.placements![0];
    const successfulResult: GraphQLResult<GraphQLValidationResponse> = {
        data: {
            placementNum,
            placementValidations: [],
            executionValidations: []
        },
        errors: []
    };

    const error: GraphQLError = {
        locations: [],
        message: "issue:error,505125984,Generic error message.",
        errorType: "DataFetchingException",
        extensions: null,
        path: null
    };

    const warning: GraphQLError = {
        locations: [],
        message: "issue:warning,505125984,Generic warning message.",
        errorType: "DataFetchingException",
        extensions: null,
        path: null
    };

    beforeEach(() => {
        cy.stub(configUtils, "getUser").returns(testUser);
        cy.stub(genericUtils, "nextNumber").returns(1);
    });
    context("#performValidation", () => {
        const successfulOrderValidationResponse: GraphQLResult<GraphQLOrderValidationResponse> = {
            data: {},
            errors: []
        };
        it("should call the performValidation endpoint and return true on success", async () => {
            const validateCall = cy.stub(apiUtils, "apiQuery").resolves(successfulOrderValidationResponse);
            expect(
                await performOrderValidation(
                    mockOrderWithPlacements,
                    mockTradeForm_HY_JPMSL,
                    mockAxe_HY,
                    mockConfig_HY,
                    mockCountering
                )
            ).to.be.true;
            validateCall.restore();
        });
        it("should call the performValidation endpoint and return true on success if errors array is null", async () => {
            const resultWithoutErrors: GraphQLResult<GraphQLOrderValidationResponse> = {
                data: successfulOrderValidationResponse.data
            };
            const validateCall = cy.stub(apiUtils, "apiQuery").resolves(resultWithoutErrors);
            expect(
                await performOrderValidation(
                    mockOrderWithPlacements,
                    mockTradeForm_HY_JPMSL,
                    mockAxe_HY,
                    mockConfig_HY,
                    mockCountering
                )
            ).to.be.true;
            validateCall.restore();
        });
        it("should call the performValidation endpoint and throw apiErrors on warnings", async () => {
            const warningResult: GraphQLOrderValidationResponse = {
                errors: [warning]
            };
            const validateCall = cy.stub(apiUtils, "apiQuery").throws(warningResult);
            await expect(
                performOrderValidation(
                    mockOrderWithPlacements,
                    mockTradeForm_HY_JPMSL,
                    mockAxe_HY,
                    mockConfig_HY,
                    mockCountering
                )
            ).to.be.rejectedWith(
                '[{"name":"Error Validating Order Execution","message":"issue:warning,505125984,Generic warning message.","type":"ERROR","id":1,"timeout":3600000}]'
            );
            validateCall.restore();
        });
        it("should call the performValidation endpoint and throw apiErrors on errors", async () => {
            const errorResult: GraphQLOrderValidationResponse = {
                errors: [warning, error]
            };
            const validateCall = cy.stub(apiUtils, "apiQuery").throws(errorResult);
            await expect(
                performOrderValidation(
                    mockOrderWithPlacements,
                    mockTradeForm_HY_JPMSL,
                    mockAxe_HY,
                    mockConfig_HY,
                    mockCountering
                )
            ).to.be.rejectedWith(
                '[{"name":"Error Validating Order Execution","message":"issue:warning,505125984,Generic warning message.\\n,issue:error,505125984,Generic error message.","type":"ERROR","id":1,"timeout":3600000}]'
            );
            validateCall.restore();
        });
    });
    context("#validateBeforeUpdatingPlacementQuote", () => {
        beforeEach(() => {
            cy.clock(new Date(Date.UTC(2022, 0, 18)).setHours(0));
        });
        afterEach(() => {
            cy.tick(0).invoke("restore");
        });
        it("should call the validatePlacements endpoint and return true on success", async () => {
            const validateCall = cy.stub(apiUtils, "apiQuery").resolves(successfulResult);
            expect(await validateBeforeUpdatingPlacementQuote(mockOrderWithPlacements, placementNum)).to.be.true;
            validateCall.restore();
        });
        it("should use trade form info variables if passed in as argument", async () => {
            const validateCall = cy.stub(apiUtils, "apiQuery").resolves(successfulResult);
            cy.stub(apiUtils, "createUpdatePlacementQuoteVars");
            await validateBeforeUpdatingPlacementQuote(mockOrderWithPlacements, placementNum, mockTradeForm_HY_JPMSL);
            expect(apiUtils.createUpdatePlacementQuoteVars).to.be.calledWith(placement, {
                quantity: mockTradeForm_HY_JPMSL.size,
                tradeValue: mockTradeForm_HY_JPMSL.price,
                dueInTime: "00:05:00|America/New_York"
            });
            validateCall.restore();
        });
        it("should call the validatePlacements endpoint and return true on success if errors array is null", async () => {
            const resultWithoutErrors = {
                data: successfulResult.data
            };
            const validateCall = cy.stub(apiUtils, "apiQuery").resolves(resultWithoutErrors);
            expect(await validateBeforeUpdatingPlacementQuote(mockOrderWithPlacements, placementNum)).to.be.true;
            validateCall.restore();
        });
        it("should call the validatePlacements endpoint and throw apiErrors on warnings", async () => {
            const warningResult: { errors: GraphQLError[] } = {
                errors: [warning]
            };
            const validateCall = cy.stub(apiUtils, "apiQuery").throws(warningResult);
            await expect(
                validateBeforeUpdatingPlacementQuote(mockOrderWithPlacements, placementNum)
            ).to.be.rejectedWith(
                '[{"name":"Error Validating Quote Update","message":"issue:warning,505125984,Generic warning message.","type":"ERROR","id":1,"timeout":3600000}]'
            );
            validateCall.restore();
        });
        it("should call the validatePlacements endpoint and throw apiErrors on errors", async () => {
            const errorResult: { errors: GraphQLError[] } = {
                errors: [warning, error]
            };
            const validateCall = cy.stub(apiUtils, "apiQuery").throws(errorResult);
            await expect(
                validateBeforeUpdatingPlacementQuote(mockOrderWithPlacements, placementNum)
            ).to.be.rejectedWith(
                '[{"name":"Error Validating Quote Update","message":"issue:warning,505125984,Generic warning message.\\n,issue:error,505125984,Generic error message.","type":"ERROR","id":1,"timeout":3600000}]'
            );
            validateCall.restore();
        });
    });
    context("#parseAlertsFromGraphQLError", () => {
        const action = "validation action";
        it("should return an empty alert list for empty array", async () => {
            expect(parseAlertsFromGraphQLError([], action)).to.deep.equal([]);
        });
        it("should return an error alert for a result without errors message", async () => {
            const errors = [
                {
                    errorType: "ERROR"
                }
            ];

            expect(parseAlertsFromGraphQLError(errors, action)).to.deep.equal([
                {
                    message: "When running validation for " + action + ", received ERROR type error without a message",
                    type: "ERROR"
                }
            ]);
        });
        it("should return an error alert for a result with invalid errors message", async () => {
            const errors = [
                {
                    message: "invalid error message"
                }
            ];
            expect(parseAlertsFromGraphQLError(errors, action)).to.deep.equal([
                {
                    message: `When running validation for ${action}, received error message "invalid error message"`,
                    type: "ERROR"
                }
            ]);
        });
        it("should return an error alert for a result with errors returned", async () => {
            const errors = [error];

            expect(parseAlertsFromGraphQLError(errors, action)).to.deep.equal([
                {
                    message: "Generic error message.",
                    type: "ERROR"
                }
            ]);
        });
        it("should return an warning alert for a result with warnings returned", async () => {
            const errors = [warning];

            expect(parseAlertsFromGraphQLError(errors, action)).to.deep.equal([
                {
                    message: "Generic warning message.",
                    type: "WARNING"
                }
            ]);
        });
    });
    context("#performCounteringValidation", () => {
        it("should return true if no validation errors", async () => {
            const counteringValidationResponse: GraphQLResult<GraphQLCounteringValidationResponse> = {
                data: { validatePlacementsCountering: [] }
            };
            cy.stub(apiUtils, "apiQuery").resolves(counteringValidationResponse);
            await expect(
                performCounteringValidation(
                    mockOrder_Buy_HY,
                    mockTradeForm_HY_JPMSL,
                    mockAxe_HY,
                    mockConfig_HY,
                    mockCountering
                )
            ).to.eventually.be.true;
        });
        it("should throw errors if validation errors", async () => {
            const counteringValidationResponse: GraphQLResult<GraphQLCounteringValidationResponse> = {
                data: { validatePlacementsCountering: [] },
                errors: [
                    {
                        errorType: "DataFetchingException",
                        message: "issue:warning,584934985,Trade execution is below minTrdSize 2000 of security.",
                        locations: [],
                        path: null,
                        extensions: null
                    }
                ]
            };
            cy.stub(apiUtils, "apiQuery").throws(counteringValidationResponse);
            await expect(
                performCounteringValidation(
                    mockOrder_Buy_HY,
                    mockTradeForm_HY_JPMSL,
                    mockAxe_HY,
                    mockConfig_HY,
                    mockCountering
                )
            ).to.be.rejectedWith("Trade execution is below minTrdSize 2000 of security.");
        });
    });
});