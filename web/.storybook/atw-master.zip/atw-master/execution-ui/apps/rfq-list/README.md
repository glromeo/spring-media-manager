# Make sure you have an environment like this

```bash
$ cat ./.bashrc
export PROXY=http://application-proxy.blackrock.com:9443/
export HTTP_PROXY=http://application-proxy.blackrock.com:9443/
export HTTPS_PROXY=http://application-proxy.blackrock.com:9443/
export NO_PROXY=bfm.com,blackrock.com
export YARN_PROXY=""
export YARN_HTTPS_PROXY=""
export NODE_TLS_REJECT_UNAUTHORIZED="0"
export PLAYWRIGHT_DOWNLOAD_HOST=https://developer.blackrock.com/artifactory/blk-npm/playwright/-

$ cat .yarnrc
registry "https://registry.npmjs.org/"
"@atw:registry" "http://artifactory.blackrock.com:9000/artifactory/api/npm/npm-releases-local-ewd/"
"@blk:registry" "http://artifactory.blackrock.com:9000/artifactory/api/npm/npm-releases-local-ewd/"
"@playwright:registry" "https://developer.blackrock.com/artifactory/api/npm/npm-third-party/"
email gianluca.romeo@blackrock.com
proxy ""
https_proxy ""
lastUpdateCheck 1677510176395
strict-ssl false
username gromeo

$ cat .npmrc
registry=https://registry.npmjs.org/
@blk:registry=http://artifactory.blackrock.com:8081/artifactory/api/npm/npm-releases-local-ewd/
@atw:registry=http://artifactory.blackrock.com:8081/artifactory/api/npm/npm-releases-local-ewd/
@meta:registry=http://artifactory.blackrock.com:8081/artifactory/api/npm/npm-releases-local-ewd/
@playwright:registry=https://developer.blackrock.com/artifactory/api/npm/npm-third-party/
prefix=C:\BLKDeveloper\.npm
cache=C:\BLKDeveloper\.npm-cache
loglevel=warn
proxy=http://application-proxy.blackrock.com:9443
https-proxy=http://application-proxy.blackrock.com:9443
no-proxy=bfm.com,blackrock.com
fetch-retry-maxtimeout=120000
strict-ssl=false
```

### VSCODE settings
given your workspace is based on execution-ui

Install the following extensions:
* Cucumber
* CucumberJS Test Runner

```json
{
    "workbench.colorTheme": "GitHub Dark",
    "testExplorer.useNativeTesting": true,
    "cucumber.features": [
        "apps/rfq-list/test/bdd/**/*.feature",
    ],
    "terminal.integrated.defaultProfile.windows": "Git Bash",
    "cucumber.glue": [
        "apps/rfq-list/test/bdd/**/*.steps.ts"
   ],
   "files.autoSave": "onFocusChange"
}
```