/** @type {import("@graphql-codegen/cli").CodegenConfig} */
const config = {
    schema: "schema.graphql",
    documents: ["src/**/*.graphql"],
    emitLegacyCommonJSImports: false,
    generates: {
        "./src/gql/": {
            preset: "client-preset"
        }
    }
};

module.exports = config;
