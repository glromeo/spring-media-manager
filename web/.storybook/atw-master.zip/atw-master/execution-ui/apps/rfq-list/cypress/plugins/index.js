const {
    baseUrl,
    coverage,
    requireConfig
} = require("@atx/scripts/config");

const {
    nativeCoveragePlugin,
    cucumberPlugin,
    recordingPlugin,
    expressDevServer
} = require("@atw/testing").cypress;

const nativeCoverage = nativeCoveragePlugin({
    prefix: baseUrl.pathname,
    reports: coverage?.reports,
    include: coverage?.include,
    exclude: coverage?.exclude,
    coverageDirectory: coverage?.coverageDirectory,
    clean: false
});

const buildOptions = require("@atx/template/scripts/esbuild.config");
const cucumber = cucumberPlugin({
    preserveSymlinks: true,
    treeShaking: true,
    define: buildOptions.define
});
const recording = recordingPlugin({});
const devServer = expressDevServer(buildOptions, [requireConfig("scripts/proxy.config.js")]);

module.exports = (on, config) => {
    require("cypress-terminal-report/src/installLogsPrinter")(on);

    nativeCoverage(on, config);
    cucumber(on, config);
    recording(on, config);
    devServer(on, config);

    return config;
};
