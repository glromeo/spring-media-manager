import "@atw/testing/coverage-hooks";
import "cypress-real-events";
require('cypress-terminal-report/src/installLogsCollector')();