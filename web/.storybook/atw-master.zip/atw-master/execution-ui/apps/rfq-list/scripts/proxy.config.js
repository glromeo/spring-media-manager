const { createProxyMiddleware } = require("http-proxy-middleware");
const fs = require("fs");
const url = require("url");

const log = process.env.CI ? () => void null : (...args) => console.log("[atx]", ...args);

const createDashboardRedirect =
    ({ target }) =>
    (req, res, next) => {
        if (req.header("User-Agent").endsWith("AWC/3.4")) {
            log(`redirect: ${req.method} ${req.originalUrl} -> ${target}`);
            res.redirect(308, `${target}${req.originalUrl}`);
        } else {
            return next();
        }
    };

module.exports = (app) => {
    app.use(require("@atx/template/middleware/prefs"));
    app.use(require("@atx/template/middleware/recording"));
    app.use(require("express").json()); // The new fixtures middleware needs json to look at the body
    app.use(require("@atx/template/middleware/fixtures"));

    if (!process.env.CI) {
        const target = "https://tst.blackrock.com";

        const dashboardRedirect = createDashboardRedirect({ target });
        const proxyMiddleware = createProxyMiddleware({
            target,
            changeOrigin: true,
            logLevel: "debug",
            onProxyReq(proxyReq, req) {
                proxyReq.setHeader("Cookie", "X-Session-Token=user&gromeo&mode&SSO&token&AAEAAAGLYUGCRWwljACQFxZ1lMhNT6mMhmAr8u0TVFNUICAgICAgIAEepxPbI0udpDi2c4Z48SksWGwG1HpCxkdnr1cwNkSpDg==; Path=/; SameSite=Strict;Secure;HttpOnly;");
            }
        });

        app.use("/weblications", dashboardRedirect, proxyMiddleware);
        app.use("/oemsgqlserver", dashboardRedirect, proxyMiddleware);
        app.use("/oemsgqlserver_beta", dashboardRedirect, proxyMiddleware);
        app.use("/api", dashboardRedirect, proxyMiddleware);
        app.use("/std", proxyMiddleware);
        app.use("/bms/request/app/explore/securitySearch", createDashboardRedirect({ target }), proxyMiddleware);

        app.use("/apps/execution", createDashboardRedirect({ target: "http://localhost:3001" }));
        app.use("/apps/historical-liquidity", createDashboardRedirect({ target: "http://localhost:3030" }));
        app.use("/apps/market-depth", createDashboardRedirect({ target: "https://tst.blackrock.com" }));
        app.use("/apps/market-depth-beta", createDashboardRedirect({ target: "https://tst.blackrock.com" }));
        app.use("/apps/atw-atlas", createDashboardRedirect({ target: "http://localhost:3060" }));
        app.use("/apps/at-rfq-single", createDashboardRedirect({ target: "http://localhost:3001" }));
        app.use("/apps/at-rfq-single-beta", createDashboardRedirect({ target: "http://localhost:3001" }));
    }
};
