import {useRef} from "react";
import {Order} from "@atx/commons/model";
import {SecurityLookup} from "@atx/commons/components";
import {RFQ} from "../../../../state/rfqs";
import {AtxTextField} from "@atx/toolkit/components";
import {classNames} from "@atx/toolkit";
import {formatMaturity} from "@atx/commons";
import {useSetRfqField} from "../../../../hooks/set-rfq-field";

export function BenchmarkCell({order, priceType, benchmark}: Order & RFQ) {
    const setBenchmark = useSetRfqField(order, "benchmark");
    const ref = useRef<HTMLDivElement>(null);
    return priceType === "spread" ? (
        <div ref={ref} className={classNames("benchmark-cell", !benchmark && "error")} data-price={benchmark?.price} data-source={benchmark?.source} >
            <SecurityLookup testId="benchmark"
                            cusip={benchmark?.cusip ?? null}
                            description={benchmark?.description ?? null}
                            placeholder="-"
                            error={!benchmark && "Please enter a security benchmark"}
                            filter={({type}) => type === "GOVT"}
                            onChange={(security) => {
                                if (security) {
                                    const {cusip} = security;
                                    const parts = security.description.split(" ");
                                    const maturity = parts.pop();
                                    const coupon = parts.pop();
                                    const ticker = parts.join(" ");
                                    setBenchmark({
                                        description: `${ticker} ${coupon} ${formatMaturity(maturity)}`,
                                        cusip,
                                        price: null,
                                        source: null
                                    });
                                } else {
                                    setBenchmark(null)
                                }
                            }}
            />
        </div>
    ) : (
        <AtxTextField placeholder="N/A" disabled={true}/>
    );
}
