import React from "react";
import { useAtomValue } from "jotai";
import { Order } from "@atx/commons";
import { eligibleBrokersAtom, requestedBrokersByOrderAtom } from "../../../../state/brokers";

export function BrokersCell({order}: { order: Order }) {
    return (
        <div className="brokers-cell flex-row" data-test-id="brk-req">
            <RequestedBrokersCount order={order}/>
        </div>
    );
}

function RequestedBrokersCount({order}: { order: Order }) {
    const requested = useAtomValue(requestedBrokersByOrderAtom).get(order)!;
    const eligible = useAtomValue(eligibleBrokersAtom).get(order)!;
    try {
        const title = `This RFQ will go to ${requested.length} / ${eligible.size} eligible brokers for ${order.ordNum}`;
        return (
            <div className="count" data-test-id="count" title={title}>
                {requested.length}
            </div>
        );
    } catch (ignored) {
        return null;
    }
}
