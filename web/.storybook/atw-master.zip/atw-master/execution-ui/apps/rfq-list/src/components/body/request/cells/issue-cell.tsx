import React from "react";
import {AtxAlert, AtxIcon} from "@atx/toolkit";
import {useAtomValue, useSetAtom} from "jotai";
import {Order} from "@atx/commons";
import {RfqBrokerDetails} from "../../tabs/brokers";
import {rfqIssuesAtom} from "../../../../state/validation";
import {rfqsAtom} from "../../../../state/rfqs";

export function IssueCell({order}: { order: Order }) {
    const level = useAtomValue(rfqIssuesAtom).get(order)?.[0].level;
    const setRfqs = useSetAtom(rfqsAtom);
    return (
        <div className="brokers-cell flex-row" data-test-id="brk-req">
            {level && <AtxIcon name={level === "error" ? "error-bold" : "alert-bold"}
                               type={level === "error" ? "danger" : level === "warning" ? "warning" : "info"}
                               title={{placement: "bottom", title: () => <IssueTooltip order={order}/>}}/>
            }
            <AtxIcon
                className="delete-row"
                name="widget-delete"
                onClick={(e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    setRfqs(order, "delete");
                }}
            />
        </div>
    );
}

function IssueTooltip({order}: { order: Order }) {
    const issues = useAtomValue(rfqIssuesAtom).get(order);
    const alerts = [];
    if (issues) {
        for (const {level, type, message} of issues) {
            const key = alerts.length;
            if (type === "broker") {
                alerts.push(<RfqBrokerDetails key={key} order={order}/>);
            } else {
                const type = level === "error" ? "danger" : "warning";
                const [title, details] = message.split(":");
                if (details) {
                    alerts.push(<AtxAlert key={key} type={type} title={title}>{details}</AtxAlert>);
                } else {
                    alerts.push(<AtxAlert key={key} type={type}>{message}</AtxAlert>);
                }
            }
        }
    }
    return <>{alerts}</>;
}