import React from "react";
import {PricingTypeToggle} from "@atx/commons/components";
import {RFQ} from "../../../../state/rfqs";
import {Order} from "@atx/commons";
import {useSetRfqField} from "../../../../hooks/set-rfq-field";

export function ProtocolCell({ order, priceType }: Order & RFQ) {
    const setPriceType = useSetRfqField(order, "priceType");
    return (
        <PricingTypeToggle
            testId="protocol"
            value={priceType}
            onChange={setPriceType}
        />
    );
}
