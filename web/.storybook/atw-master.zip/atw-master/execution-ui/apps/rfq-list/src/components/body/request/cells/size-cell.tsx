import React from "react";
import {AtxTextField, formatQuantity, parseQuantity} from "@atx/toolkit";
import {RFQ} from "../../../../state/rfqs";
import {Order} from "@atx/commons";
import {useSetRfqField} from "../../../../hooks/set-rfq-field";
import {useAtomValue} from "jotai";
import {orderIssuesAtom} from "../../../../state/validation";


export function SizeCell({order, size, eligibleQty}: Order & RFQ) {
    const setSize = useSetRfqField(order, "size");
    const issue = useAtomValue(orderIssuesAtom).get(order)?.find(issue => issue.field === "size");
    return (
        <AtxTextField
            testId="size"
            className="quantity"
            value={size}
            defaultValue={eligibleQty}
            validate={() => issue?.message}
            format={formatQuantity}
            parse={parseQuantity}
            onChange={setSize}
        />
    );
}
