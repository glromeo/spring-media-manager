import React from "react";
import {Order} from "@atx/commons/model";
import {SpotTimeSelect} from "@atx/commons";
import {useAtomValue} from "jotai";
import {RFQ} from "../../../../state/rfqs";
import {availableSpotTimeOptionsAtom} from "../../../../state/time";
import {useSetRfqField} from "../../../../hooks/set-rfq-field";

export function SpotTimeCell({order, priceType, spotTime}: Order & RFQ) {
    const setSpotTime = useSetRfqField(order, "spotTime");
    const options = useAtomValue(availableSpotTimeOptionsAtom);
    const disabled = priceType !== "spread";
    return (
        <SpotTimeSelect
            testId="spot-time"
            className="spot-time-select"
            disabled={disabled}
            required={true}
            value={disabled ? undefined : spotTime}
            options={options}
            onChange={setSpotTime}
        />
    );
}
