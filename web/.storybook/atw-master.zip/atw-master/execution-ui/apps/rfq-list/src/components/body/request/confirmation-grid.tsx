import React, { useMemo } from "react";
import { SecurityWidget } from "@atx/commons/components";
import { useAtomValue } from "jotai";
import { AtxGrid, AtxGridColumnDef } from "@atx/toolkit/components/grid";
import { requestedBrokersByOrderAtom } from "../../../state/brokers";
import { Security } from "@atx/commons";
import { DataItem } from "@atx/toolkit/components/grid/atx-grid";
import { rfqsAtom, rfqTimeAtom } from "../../../state/rfqs";

import "./orders-grid.scss";
import { spotTimeLabelsAtom } from "../../../state/time";

export type ConfirmationGridProps = {};

type ConfirmationData = DataItem & {
    id: number;
    side: string;
    asset: Security;
    size: number;
    priceType: string;
    spotTime: string | null;
    benchmark: string | null;
    brokers: string;
};

export function ConfirmationGrid({}: ConfirmationGridProps) {
    const rfqs = useAtomValue(rfqsAtom);
    const rfqTime = useAtomValue(rfqTimeAtom);
    const requestedBrokersByOrder = useAtomValue(requestedBrokersByOrderAtom);
    const spotTimeLabels = useAtomValue(spotTimeLabelsAtom);

    const rowData = useMemo<Array<ConfirmationData>>(() => {
        return (
            rfqs
                ?.map((rfq) => {
                    const brokers = requestedBrokersByOrder.get(rfq.order) ?? [];
                    return {
                        id: rfq.order.ordNum,
                        side: rfq.order.side,
                        asset: rfq.order.asset,
                        size: rfq.size ?? 0,
                        priceType: rfq.priceType === "spread" ? "Spread" : "Price",
                        spotTime: spotTimeLabels.get(rfq.spotTime) ?? "N/A",
                        benchmark: rfq.benchmark?.description ?? "N/A",
                        brokers: `(${brokers.length}) ${brokers.map((broker) => broker.shortName).join(" ")}`
                    };
                })
                .sort((l, r) => (l.asset.ticker! < r.asset.ticker! ? -1 : 1)) ?? []
        );
    }, [rfqs, rfqTime]);

    const columnDefs = useMemo(
        (): Array<AtxGridColumnDef<ConfirmationData>> => [
            {
                label: "Side",
                field: "side",
                type: "string",
                width: 50
            },
            {
                label: "Security",
                field: "asset",
                type: "string",
                width: 150,
                render: ({ data }) => <SecurityWidget security={data.asset} />
            },
            {
                label: "Size",
                field: "size",
                type: "quantity",
                width: 100
            },
            {
                label: "Pricing Pr.",
                field: "priceType",
                type: "string",
                width: 80
            },
            {
                label: "Spot Time",
                field: "spotTime",
                type: "string",
                width: 80
            },
            {
                label: "Brokers",
                field: "brokers",
                type: "string",
                width: 200
            }
        ],
        []
    );

    return (
        <div data-test-id="confirmation-grid" className="confirmation-grid">
            <AtxGrid rowData={rowData} rowHeight={24} headerHeight={32} columnDefs={columnDefs} />
        </div>
    );
}
