import React, {useCallback, useMemo} from 'react'
import {useAtomValue, useStore} from 'jotai'
import {ProtocolCell} from './cells/protocol-cell'
import {SpotTimeCell} from './cells/spot-time-cell'
import {BenchmarkCell} from './cells/benchmark-cell'
import {BrokersCell} from './cells/brokers-cell'
import {SizeCell} from './cells/size-cell'
import {AtxGrid, AtxGridColumnDef} from '@atx/toolkit/components/grid'
import {focusedOrderAtom, RFQ, rfqsAtom} from '../../../state/rfqs'
import {formatSecurity, Order} from '@atx/commons'
import {RfqIssue, rfqIssuesAtom} from '../../../state/validation'
import {IssueCell} from './cells/issue-cell'
import {atom} from 'jotai'
import {AtxGridSelection} from '@atx/toolkit/components/grid/atx-grid'

import './orders-grid.scss'
import {data} from 'jquery'

type RowType = Order & RFQ & { issue: RfqIssue | undefined };

const rowDataAtom = atom<RowType[]>(get => {
    const rfqIssues = get(rfqIssuesAtom)
    return get(rfqsAtom).map(rfq => ({
        ...rfq.order,
        ...rfq,
        issue: rfqIssues.get(rfq.order)?.[0]
    } as RowType))
})

const selectionAtom: AtxGridSelection<RowType> = atom(
    (get) => {
        const ordNum = get(focusedOrderAtom)?.ordNum
        return (data) => data.ordNum === ordNum
    },
    (get, set, selected: RowType | null) => {
        set(focusedOrderAtom, selected?.ordNum ?? null)
    }
)

/**
 * This component uses atoms so it should render only ONCE
 * DO NOT use hooks in it... if anything add more features with other atoms!!!
 *
 * @constructor
 */
export function OrdersGrid() {

    const bgClass = (rfqIssue: RfqIssue) => {
        if (rfqIssue.level === 'error') {
            return 'danger'
        }
        if (rfqIssue.level === 'warning' && rfqIssue.type !== 'broker') {
            return 'warning'
        }
    }

    return (
        <div data-test-id="orders-grid" className="orders-grid">
            <AtxGrid
                sort="auto"
                selection={selectionAtom}
                resizable={true}
                rowData={rowDataAtom}
                rowId={(rfq: RFQ) => rfq.order.ordNum}
                rowClassName={({issue}) => issue ? `rfq ${bgClass(issue)}` : 'rfq'}
                rowHeight={32}
                headerHeight={32}
                columnDefs={[
                    {
                        label: 'Ord. Num.',
                        field: 'ordNum',
                        width: 90
                    },
                    {
                        label: 'Bond',
                        field: 'asset',
                        type: 'security',
                        formatter: (data, field) => formatSecurity(data[field]),
                        width: 170
                    },
                    {
                        label: 'Side',
                        field: 'side',
                        type: 'string',
                        width: 60
                    },
                    {
                        label: 'Size (M/MM)',
                        width: 150,
                        field: 'size',
                        render: ({data}) => <SizeCell {...data} />
                    },
                    {
                        label: 'Protocol',
                        width: 150,
                        field: 'priceType',
                        render: ({data}) => <ProtocolCell {...data} />
                    },
                    {
                        label: 'Spot Time',
                        width: 110,
                        field: 'spotTime',
                        render: ({data}) => <SpotTimeCell {...data} />
                    },
                    {
                        label: 'Benchmark',
                        width: 185,
                        field: 'benchmark',
                        render: ({data}) => <BenchmarkCell {...data} />
                    },
                    {
                        label: 'Brk Req.',
                        width: 75,
                        sortable: false,
                        render: ({data}) => <BrokersCell {...data} />
                    },
                    {
                        label: 'Issues',
                        field: 'issue',
                        width: 60,
                        formatter: issue => issue?.level,
                        render: ({data}) => <IssueCell order={data.order}/>
                    }
                ]}
            />
        </div>
    )
}
