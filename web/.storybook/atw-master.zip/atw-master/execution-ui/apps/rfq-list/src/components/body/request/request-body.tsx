import React from "react";
import { RequestSummary } from "./request-summary";
import { OrdersGrid } from "./orders-grid";
import { AtxResizablePane, AtxTabbedPane } from "@atx/toolkit";
import { BrokersTab } from "../tabs/brokers-tab";
import { OrderDetailsTab } from "../tabs/order-details-tab";
import { SendConfirmation } from "./send-confirmation";

import "./request-body.scss";
import { useRequestWorkflow } from "../../../hooks/request-workflow";

export function RequestBody() {
    useRequestWorkflow();
    return (
        <div className="main-section request-section">
            <div className="orders-section">
                <RequestSummary />
                <OrdersGrid />
            </div>
            <AtxResizablePane className="details-section" resizer="left">
                <AtxTabbedPane testId="request-tabs">
                    <BrokersTab tab-title="Brokers" />
                    <OrderDetailsTab tab-title="Order Details" />
                </AtxTabbedPane>
            </AtxResizablePane>
            <SendConfirmation />
        </div>
    );
}
