import React from "react";
import { SummaryPricingType } from "./summary/summary-pricing-type";
import { SummarySpotTime } from "./summary/summary-spot-time";
import { TimerParameters } from "./summary/timer-parameters";

export function RequestSummary() {
    return (
        <div className="request-summary">
            <SummaryPricingType />
            <SummarySpotTime />
            <TimerParameters />
        </div>
    );
}
