import React from "react";
import { AtxDialog, statusOverlayAtom, useAtxTimeFieldUtils, useErrorNotification } from "@atx/toolkit";
import { useAtom, useAtomValue, useSetAtom } from "jotai";
import { ConfirmationGrid } from "./confirmation-grid";
import { createPlacementQuotesMutation } from "../../../query/placement-quotes-creation";
import { TIME_OFFSET } from "../../../state/time";
import { stepAtom } from "../../../state/workflow";
import { rfqTimeAtom } from "../../../state/rfqs";

import "./send-confirmation.scss";

export function SendConfirmation() {
    const [step, setStep] = useAtom(stepAtom);
    const {dueProtocol, dueIn, dueAt} = useAtomValue(rfqTimeAtom);
    const [formatTime] = useAtxTimeFieldUtils();
    const withOverlay = useSetAtom(statusOverlayAtom);
    const createPlacementQuotes = useSetAtom(createPlacementQuotesMutation);
    const errorNotification = useErrorNotification();

    return step === "Confirmation" ? (
        <AtxDialog
            title="Confirm Send"
            testId="confirmation-dialog"
            open={true}
            modal={true}
            onOK={() => {
                withOverlay(
                    "performing validation...",
                    createPlacementQuotes()
                        .then(() => {
                            setStep("Response");
                        })
                        .catch((error) => {
                            errorNotification("Failed to perform validation", error);
                            setStep("Validation");
                        })
                );
            }}
            onCancel={() => {
                setStep("Validation");
            }}
            labels={{OK: "Send"}}
        >
            {dueProtocol === "Due In" ? (
                <div className="timer">Due in {dueIn?.as("minutes") ?? 0} minutes</div>
            ) : (
                <div className="timer">
                    Due at {formatTime(dueAt)} - {TIME_OFFSET}
                </div>
            )}
            <ConfirmationGrid/>
            <div className="confirm-message" data-test-id="confirm-message">Would you like to proceed?</div>
        </AtxDialog>
    ) : null;
}
