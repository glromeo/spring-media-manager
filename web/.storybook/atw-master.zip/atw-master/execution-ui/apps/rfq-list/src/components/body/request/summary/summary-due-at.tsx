import { atom, useAtom, useAtomValue } from "jotai";
import { DueAtField } from "@atx/commons";
import { dueAtValidationAtom } from "../../../../state/validation";
import { rfqTimeAtom } from "../../../../state/rfqs";

const dueAtTimeZoneAtom = atom<string | null>("America/New_York");

export function SummaryDueAt() {
    const [time, setTime] = useAtom(rfqTimeAtom);
    const [dueAtTimeZone, setDueAtTimeZone] = useAtom(dueAtTimeZoneAtom);
    const validation = useAtomValue(dueAtValidationAtom);
    return (
        <DueAtField
            testId="summary-due-at"
            value={time.dueAt}
            timeZone={dueAtTimeZone}
            disabled={time.timer === "ASAP"}
            validate={() => validation}
            onChange={(value, timeZone) => {
                if (value) {
                    setTime({ ...time, dueAt: value });
                }
                setDueAtTimeZone(timeZone ?? null);
            }}
        />
    );
}
