import { useAtom, useAtomValue } from "jotai";
import { DueInSelect } from "@atx/commons";
import { dueInDurationsAtom } from "@atx/commons/atoms/timers";
import { rfqTimeAtom } from "../../../../state/rfqs";

export function SummaryDueIn() {
    const [time, setTime] = useAtom(rfqTimeAtom);
    const dueInDurations = useAtomValue(dueInDurationsAtom);
    return (
        <DueInSelect
            testId="summary-due-in"
            value={time.dueIn}
            durations={dueInDurations[time.timer]}
            onChange={(value) => setTime({...time, dueIn: value})}
            disabled={time.timer === "ASAP"}
        />
    );
}
