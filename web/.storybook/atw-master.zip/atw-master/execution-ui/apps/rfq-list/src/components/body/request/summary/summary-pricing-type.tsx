import {useAtomValue, useSetAtom} from "jotai";
import {useCallback} from "react";
import {PricingType} from "@atx/commons/model/bond";
import {PricingTypeToggle} from "@atx/commons/components";
import {rfqsAtom, rfqSummaryAtom} from "../../../../state/rfqs";

export function SummaryPricingType() {
    const {priceType} = useAtomValue(rfqSummaryAtom);
    const setRfqs = useSetAtom(rfqsAtom);
    return (
        <div data-test-id="summary-price-type" className="summary-item pricing-type toggle">
            <div className="label">Pricing Protocol</div>
            <PricingTypeToggle
                value={priceType}
                onChange={useCallback((value: PricingType | null) => {
                    console.log("changed default price type to:", value);
                    if (value) {
                        setRfqs({ priceType: value });
                    }
                }, [])}
            />
        </div>
    );
}
