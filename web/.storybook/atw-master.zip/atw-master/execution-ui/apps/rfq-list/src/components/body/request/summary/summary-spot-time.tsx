import {useAtom, useAtomValue, useSetAtom} from "jotai";
import { availableSpotTimeOptionsAtom } from "../../../../state/time";
import { SpotTimeSelect } from "@atx/commons";
import {rfqsAtom, rfqSummaryAtom} from "../../../../state/rfqs";

export function SummarySpotTime() {
    const {spotTime, priceType} = useAtomValue(rfqSummaryAtom);
    const setRfqs = useSetAtom(rfqsAtom)
    const options = useAtomValue(availableSpotTimeOptionsAtom);
    const disabled = priceType === "price";
    return (
        <div data-test-id="summary-spot-time" className="summary-item spot-time">
            <div className="label">Spot Time</div>
            <div>
                <SpotTimeSelect
                    className="spot-time-select"
                    size="small"
                    disabled={disabled}
                    value={disabled ? undefined : spotTime}
                    options={options}
                    onChange={(value) => {
                        console.log("changed spot time to:", value);
                        if (value) {
                            setRfqs({spotTime: value});
                        }
                    }}
                />
            </div>
        </div>
    );
}
