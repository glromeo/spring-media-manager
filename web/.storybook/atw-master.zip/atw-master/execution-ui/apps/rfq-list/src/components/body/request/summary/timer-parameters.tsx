import { AtxRadioGroup } from "@atx/toolkit";
import { useAtom, useAtomValue } from "jotai";
import { DueProtocol, Timer } from "@atx/commons/model";
import { SummaryDueIn } from "./summary-due-in";
import { SummaryDueAt } from "./summary-due-at";
import { dueInDurationsAtom } from "@atx/commons/atoms/timers";
import { rfqTimeAtom } from "../../../../state/rfqs";

const TIMER_OPTIONS: Timer[] = ["ASAP", "Bin"];
const DUE_PROTOCOL_OPTIONS: DueProtocol[] = ["Due In", "Due At"];

export function TimerParameters() {
    const [time, setTime] = useAtom(rfqTimeAtom);
    const dueInDurations = useAtomValue(dueInDurationsAtom);
    return (
        <div className="summary-item timer-parameters">
            <div className="label">Timer</div>
            <div className="parameters">
                <AtxRadioGroup
                    testId="summary-timer"
                    className="summary-item timer-toggle"
                    value={time.timer}
                    options={TIMER_OPTIONS}
                    onChange={(value: Timer | null) => {
                        if (value) {
                            console.log("changed default timer to:", value);
                            const durations = dueInDurations[value];
                            const dueIn = durations[Math.floor(durations.length / 2)];
                            setTime({ ...time, timer: value, dueProtocol: "Due In", dueIn });
                        }
                    }}
                />
                <AtxRadioGroup
                    testId="summary-due-protocol"
                    className="summary-item due-protocol-toggle"
                    value={time.dueProtocol}
                    options={DUE_PROTOCOL_OPTIONS}
                    disabled={time.timer === "ASAP"}
                    onChange={(value: DueProtocol | null) => {
                        if (value) {
                            console.log("changed default due protocol to:", value);
                            const dueAt = new Date(Date.now() + 30 * 60 * 1000);
                            setTime({ ...time, dueProtocol: value, dueAt });
                        }
                    }}
                />
                {time.dueProtocol === "Due In" ? <SummaryDueIn /> : <SummaryDueAt />}
            </div>
        </div>
    );
}
