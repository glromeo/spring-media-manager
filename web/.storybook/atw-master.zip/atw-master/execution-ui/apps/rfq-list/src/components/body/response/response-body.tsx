import React from "react";
import { useResponseWorkflow } from "../../../hooks/response-workflow";
import { ResponseSummaryGrid } from "./response-summary-grid";
import { OrderDetailsTab } from "../tabs/order-details-tab";
import { AtxResizablePane, AtxTabbedPane } from "@atx/toolkit/components";
import { ResponseDetailsGrid } from "./response-details-grid";
import { OrderTotals } from "../../ribbon/order-totals";

import "./response-body.scss";
import { OrderSpotTime } from "../../ribbon/order-spot-time";

export function ResponseBody() {
    useResponseWorkflow();
    return (
        <div className="main-section response-section">
            <div className="summary-section">
                <ResponseSummaryGrid />
            </div>
            <AtxResizablePane className="details-section" resizer="top" style={{ height: 350 }}>
                <div className="ribbon-section secondary">
                    <OrderTotals />
                    <div className="flex-fill" />
                    <div className="vertical-separator" />
                    <OrderSpotTime />
                </div>
                <AtxTabbedPane>
                    <ResponseDetailsGrid tab-title="Brokers" />
                    <OrderDetailsTab tab-title="Order Details" />
                </AtxTabbedPane>
            </AtxResizablePane>
        </div>
    );
}
