import React, { useCallback, useMemo } from "react";
import { SecurityWidget } from "@atx/commons/components";
import { useAtomValue, useStore } from "jotai";
import { AtxGrid, AtxGridColumnDef } from "@atx/toolkit/components/grid";
import { Order } from "@atx/commons";
import { basketAtom, PlacementSummary } from "../../../state/basket";
import {atom} from 'jotai'
import {focusedOrderAtom} from '../../../state/rfqs'
import { AtxGridSelection } from "@atx/toolkit/components/grid/atx-grid";

import "./response-details-grid.scss";

type RowType = Order & PlacementSummary;

const selectionAtom: AtxGridSelection<RowType> = atom(
    (get) => {
        const ordNum = get(focusedOrderAtom)?.ordNum
        return (data) => data.ordNum === ordNum
    },
    (get, set, selected: RowType | null) => {
        set(focusedOrderAtom, selected?.ordNum ?? null)
    }
)

export function ResponseDetailsGrid() {
    const basket = useAtomValue(basketAtom);
    const {get} = useStore();

    const data = basket.map((quote) => {
        return {
            ...quote.order,
            ...quote
        } as RowType;
    });

    return (
        <div data-test-id="response-details-grid" className="response-details-grid">
            <AtxGrid
                sort="auto"
                selection={selectionAtom}
                resizable={true}
                rowData={data}
                rowId={useCallback((quote: PlacementSummary) => quote.order.ordNum, [])}
                rowHeight={32}
                headerHeight={32}
                columnDefs={useMemo(
                    (): Array<AtxGridColumnDef<typeof data[number]>> => [
                        {
                            label: "Ord. Num.",
                            field: "ordNum",
                            width: 90
                        },
                        {
                            label: "Bond",
                            field: "asset",
                            type: "text",
                            width: 170,
                            render: ({data}) => <SecurityWidget security={data.asset}/>
                        },
                        {
                            label: "Side",
                            field: "side",
                            type: "text",
                            width: 55
                        },
                        {
                            label: "Size (M/MM)",
                            field: "size",
                            type: "quantity",
                            width: 100
                        },
                        {
                            label: "Top Level",
                            field: "topLevel",
                            type: "text",
                            width: 80
                        },
                        {
                            label: "Top Brk.",
                            field: "topBroker",
                            type: "text",
                            width: 80
                        },
                        {
                            label: "Ref. Level",
                            field: "referenceLevel",
                            type: "text",
                            width: 85
                        },
                        {
                            label: "Spot Time",
                            field: "spotTime",
                            type: "text",
                            width: 85
                        },
                        {
                            label: "Bk.Req.",
                            field: "requested",
                            type: "number",
                            width: 65
                        }
                    ],
                    []
                )}
            />
        </div>
    );
}
