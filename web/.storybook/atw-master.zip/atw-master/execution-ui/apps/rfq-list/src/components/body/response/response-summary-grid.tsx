import React, {useMemo} from 'react'
import {SecurityWidget} from '@atx/commons/components'
import {atom} from 'jotai'
import {AtxGrid, AtxGridColumnDef} from '@atx/toolkit/components/grid'
import {Order} from '@atx/commons/model'
import {basketAtom, PlacementSummary} from '../../../state/basket'
import {focusedOrderAtom} from '../../../state/rfqs'
import {AtxGridSelection} from '@atx/toolkit/components/grid/atx-grid'
import {LivePrice} from '@atx/commons/hooks/live-prices'
import {bondPricesAtom} from '../../../state/bond-prices'
import {formatPrice, formatSpread} from '@atx/toolkit/utils'

import './response-summary-grid.scss'

type BondReferenceLevel = {
    referenceLevel: LivePrice
}

type ResponseSummary = Order & PlacementSummary & BondReferenceLevel;

const selectionAtom: AtxGridSelection<ResponseSummary> = atom(
    (get) => {
        const ordNum = get(focusedOrderAtom)?.ordNum
        return (data) => data.ordNum === ordNum
    },
    (get, set, selected: ResponseSummary | null) => {
        set(focusedOrderAtom, selected?.ordNum ?? null)
    }
)

const responseSummaryAtom = atom<ResponseSummary[]>(get => {
    const prices = get(bondPricesAtom)
    return get(basketAtom).map(quote => {
        const {order} = quote;
        const {asset} = order;
        return {
            ...order,
            ...quote,
            referenceLevel: prices[asset.cusip] // referenceLevel(asset.cusip, side, priceType)
        } as ResponseSummary
    });
})

export function ResponseSummaryGrid() {
    return (
        <div data-test-id="response-summary-grid" className="response-summary-grid">
            <AtxGrid
                sort="auto"
                selection={selectionAtom}
                resizable={true}
                rowData={responseSummaryAtom}
                rowId="ordNum"
                rowHeight={32}
                headerHeight={32}
                columnDefs={useMemo(
                    (): Array<AtxGridColumnDef<ResponseSummary>> => [
                        {
                            label: "Ord. Num.",
                            field: "ordNum",
                            width: 90
                        },
                        {
                            label: "Bond",
                            field: "asset",
                            type: "text",
                            width: 170,
                            render: ({ data }) => <SecurityWidget security={data.asset} />
                        },
                        {
                            label: "Side",
                            field: "side",
                            type: "text",
                            width: 55
                        },
                        {
                            label: "Size (M/MM)",
                            field: "size",
                            type: "quantity",
                            width: 100
                        },
                        {
                            label: "Top Level",
                            field: "topLevel",
                            type: "text",
                            width: 80
                        },
                        {
                            label: "Top Brk.",
                            field: "topBroker",
                            type: "text",
                            width: 80
                        },
                        {
                            label: "Ref. Level",
                            field: "referenceLevel",
                            type: "number",
                            formatter: ({referenceLevel: livePrice, side, priceType}) => {
                                if (livePrice) {
                                    if (priceType === "spread") {
                                        return formatSpread(side === "BUY" ? livePrice.askSpread : livePrice.bidSpread, "N/A")
                                    } else {
                                        return formatPrice(side === "BUY" ? livePrice.askPrice : livePrice.bidPrice, "N/A")
                                    }
                                } else {
                                    return "N/A"
                                }
                            },
                            width: 85
                        },
                        {
                            label: "Spot Time",
                            field: "spotTime",
                            type: "text",
                            width: 85
                        },
                        {
                            label: "Bk.Req.",
                            field: "requested",
                            type: "number",
                            width: 65
                        }
                    ],
                    []
                )}
            />
        </div>
    );
}
