import { AtxTabProps } from "@atx/toolkit";
import { BrokerSelection } from "./brokers";
import { useAtomValue, useSetAtom } from "jotai";
import { brokerAllocationsAtom, brokersAtom, selectBrokersAtom } from "../../../state/brokers";

import "./brokers-tab.scss";

/**
 * NOTE: brokers and allocations have a different (pretty much static) lifecycle than restrictions and selections
 *       that's why I moved them here and I pass them down to the <BrokerSelection> component as props!
 *
 * @constructor
 */
export function BrokersTab({}: AtxTabProps) {
    const brokers = useAtomValue(brokersAtom);
    const allocations = useAtomValue(brokerAllocationsAtom);
    const selectBrokers = useSetAtom(selectBrokersAtom);
    return (
        <div className="brokers-tab">
            <BrokerSelection required={true} brokers={brokers} allocations={allocations} />
        </div>
    );
}
