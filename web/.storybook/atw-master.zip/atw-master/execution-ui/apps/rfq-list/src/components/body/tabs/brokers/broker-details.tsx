import React, { useMemo } from "react";
import { AtxAlert, AtxCard } from "@atx/toolkit/components";
import { classNames, discardSyntheticEvent, formatPercentage, formatQuantity } from "@atx/toolkit/utils";
import { SecurityWidget } from "@atx/commons/components/widgets";
import {
    Broker,
    BrokerAllocation,
    isFullyRestricted,
    isRestricted,
    Order,
    PortfolioAllocation
} from "@atx/commons/model";
import { formatSecurity } from "@atx/commons/utils";
import "./broker-details.scss";
import { useAtomValue } from "jotai";
import { rfqRestrictionsAtom } from "../../../../state/restrictions";

export type BrokerDetailsProps = { broker: Broker; allocations: BrokerAllocation[] };

export function BrokerDetails(props: BrokerDetailsProps) {
    const {broker, allocations} = props;
    const restricted = allocations.filter(isRestricted);
    const level = restricted.every(isFullyRestricted) ? "fully" : "partially";
    return restricted.length ? (
        <div className="broker-details" onClick={discardSyntheticEvent}>
            <AtxAlert type={level === "fully" ? "danger" : "warning"}>
                {restricted.length > 1 ? (
                    <span>
                        There are <b>{restricted.length}</b> orders restricted with broker <b>{broker.shortName}</b>
                    </span>
                ) : (
                    <span>
                        The broker <b>{broker.shortName}</b> is <b>{level}</b> restricted
                    </span>
                )}
            </AtxAlert>
            <BrokerAllocationList restricted={restricted}/>
        </div>
    ) : null;
}

export type RfqBrokerDetailsProps = {
    order: Order;
};

export function RfqBrokerDetails({order}: RfqBrokerDetailsProps) {
    const {exclusions, allocations} = useAtomValue(rfqRestrictionsAtom).get(order)!;
    const restricted = useMemo(() => allocations.filter(isRestricted), [allocations]);
    const level = restricted.every(isFullyRestricted) ? "fully" : "partially";
    const alert =
        restricted.length && level === "fully"
            ? "danger"
            : (restricted.length && level === "fully") || exclusions.size
                ? "warning"
                : "info";
    return (
        <div className="broker-details">
            <AtxAlert type={alert}>
                {restricted.length > 1 ? (
                    <span>
                        <b>{formatSecurity(order.asset)}</b> is partially restricted with multiple brokers
                    </span>
                ) : restricted.length ? (
                    <span>
                        <b>{formatSecurity(order.asset)}</b> is partially restricted with
                        {restricted[0].broker.shortName}
                    </span>
                ) : exclusions.size ? (
                    <span>
                        <b>{formatSecurity(order.asset)}</b> has some brokers excluded
                    </span>
                ) : (
                    <span>
                        <b>{formatSecurity(order.asset)}</b> has no restrictions
                    </span>
                )}
            </AtxAlert>
            <BrokerAllocationList restricted={restricted}/>
            <BrokerExclusionCard exclusions={exclusions} allocations={allocations}/>
        </div>
    );
}

function BrokerAllocationList({restricted}: { restricted: BrokerAllocation[] }) {
    return (
        <div className="broker-allocations">
            {restricted.map(({order: {asset}, quantity, percent, details, restrictionLevel}, index) => (
                <AtxCard
                    key={index}
                    title={
                        <div className="flex-row">
                            <SecurityWidget security={asset}/>
                            <div className="flex-fill"/>
                            <div className={classNames("ratio", percent > 0 && restrictionLevel)}>
                                {formatQuantity(quantity)} / {formatPercentage(percent)}{" "}
                            </div>
                            <div> of available quantity</div>
                        </div>
                    }
                    contents={(isOpen) => <AllocationsDetails allocations={details} full={isOpen}/>}
                />
            ))}
        </div>
    );
}

function AllocationsDetails({allocations, full}: { allocations: PortfolioAllocation[]; full: boolean }) {
    const restricted = allocations.filter(({isRestricted}) => isRestricted);
    return (
        <div className="allocation-details">
            {full ? (
                <div className="portfolio-details">
                    <PortfolioRow
                        restriction="Restriction"
                        portfolio="Portfolio"
                        quantity="Quantity"
                        available="% of available"
                    />
                    {allocations.map(({code, isRestricted, name, quantity, percent}) => (
                        <PortfolioRow
                            key={code}
                            restriction={isRestricted ? "Restricted" : "Eligible"}
                            portfolio={name}
                            quantity={formatQuantity(quantity)}
                            available={formatPercentage(percent)}
                        />
                    ))}
                </div>
            ) : null}
            <div className="portfolio-summary">
                {restricted.length} of {allocations.length} portfolios restricted
            </div>
        </div>
    );
}

function PortfolioRow({
                          restriction,
                          portfolio,
                          quantity,
                          available
                      }: {
    restriction: string;
    portfolio: string;
    quantity: string;
    available: string;
}) {
    return (
        <div className="portfolio-row">
            <div className={"restriction portfolio-column " + restriction}>{restriction}</div>
            <div className="portfolio portfolio-column">{portfolio}</div>
            <div className="quantity portfolio-column">{quantity}</div>
            <div className="available portfolio-column">{available}</div>
        </div>
    );
}

function BrokerExclusionCard(props: { exclusions: Map<Broker, string>; allocations: BrokerAllocation[] }) {
    const {exclusions, allocations} = props;
    const total = exclusions.size + allocations.length;
    const title = `${exclusions.size} of ${total} brokers excluded`;
    return exclusions.size ? (
        <AtxCard
            className="broker-exclusion-card"
            title={title}
            contents={(isOpen) =>
                isOpen ? (
                    <div className="broker-exclusion-list">
                        {[...exclusions].map(([broker, reason]) => (
                            <div key={broker.code} className="broker-exclusion-item">
                                <div>{reason}</div>
                            </div>
                        ))}
                    </div>
                ) : null
            }
        />
    ) : null;
}
