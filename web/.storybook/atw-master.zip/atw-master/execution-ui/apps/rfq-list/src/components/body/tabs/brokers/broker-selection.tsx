import React, { useMemo, useState } from "react";
import { BrokerToggle } from "./broker-toggle";
import { Broker, BrokerAllocation, isRestricted } from "@atx/commons/model";
import { logClick } from "@atw/toolkit/telemetry";
import { AtxButton, AtxCheckbox, AtxDropdown, classNames } from "@atx/toolkit";
import { useAtomValue, useSetAtom } from "jotai";
import { brokersByVenueAtom, requestedByVenueAtom, selectBrokersAtom, Venue } from "../../../../state/brokers";
import { TipIcon } from "./broker-tips";
import { DeskSelectionDialog } from "./desk-selection";

import "./broker-selection.scss";

export type BrokerSelectionProps = {
    required?: boolean;
    brokers: Broker[];
    allocations: { [code: number]: BrokerAllocation[] };
};

export const BrokerSelection = (props: BrokerSelectionProps) => {
    const {required = true, brokers, allocations} = props;

    const requestedByVenue = useAtomValue(requestedByVenueAtom);
    const selectBrokers = useSetAtom(selectBrokersAtom);

    const [hideRestricted, setHideRestricted] = useState<boolean>(false);
    const [selectAxed, setSelectAxed] = useState<boolean>(false);
    const [allToAllNetwork, setAllToAllNetwork] = useState<boolean>(false);

    const restricted = useMemo(
        () => new Set(brokers.filter(({code}) => allocations[code]?.every(isRestricted)) ?? []),
        [brokers]
    );

    const brokersByVenue = useAtomValue(brokersByVenueAtom);

    const eligible = useMemo(() => {
        const eligible = hideRestricted ? brokers.filter((broker) => !restricted.has(broker)) : brokers;
        return Object.fromEntries(
            Object.entries(brokersByVenue).map(([venue, brokers]) => {
                return [venue, eligible.filter((broker) => brokers.has(broker))];
            })
        ) as Record<Venue, Broker[]>;
    }, [hideRestricted, restricted, brokers, brokersByVenue]);

    const multipleDesk = useMemo(() => brokers.filter(({desks}) => desks.length > 1), [brokers]);
    const shouldShowDesks = multipleDesk.length > 0;

    const requestedTotal = Object.values(requestedByVenue).reduce((total, {length}) => total + length, 0);

    const [deskSelection, setDeskSelection] = useState<Broker[]>([]);

    const venues = useMemo<Venue[]>(() => {
        return Object.keys(brokersByVenue).filter(venue => venue !== "DIRECT") as any;
    }, [brokersByVenue]);
    const [venueIndex, setVenueIndex] = useState<number>(0);
    const venue = venues[venueIndex];

    const eligibleDirect = eligible.DIRECT ?? [];
    const eligibleVenue = eligible[venue] ?? [];
    const requestedDirect = requestedByVenue.DIRECT ?? [];
    const requestedVenue = requestedByVenue[venue] ?? [];

    return (
        <div
            data-test-id="broker-selection"
            className={classNames("broker-selection", required && requestedTotal === 0 ? "invalid" : "valid")}
        >
            {restricted.size > 0 && (
                <div className="header">
                    <div data-test-id="hide-restricted-checkbox" className="hide-restricted">
                        <AtxCheckbox
                            checked={hideRestricted}
                            disabled={true}
                            onChange={() => {
                                setHideRestricted(!hideRestricted);
                                logClick("Hide Restricted Brokers", {hideRestricted});
                            }}
                        >
                            Hide Restricted ({String(restricted.size)})
                        </AtxCheckbox>
                    </div>
                    <div className="flex-fill"/>
                    <div data-test-id="select-axed-checkbox" className="select-axed">
                        <AtxCheckbox
                            checked={selectAxed}
                            disabled={true}
                            onChange={() => {
                                setSelectAxed(!selectAxed);
                                logClick("Select Axe'd Brokers", {selectAxed});
                            }}
                        >
                            Select Axe'd Brokers
                        </AtxCheckbox>
                    </div>
                </div>
            )}

            <div className="presets">
                <AtxDropdown className="preset-select" disabled={true}/>
                <AtxButton className="more" type="secondary" disabled={true}>
                    ...
                </AtxButton>
            </div>

            <div className="direct-brokers-heading">
                <div data-test-id="direct-brokers-title" className="title">
                    Direct Brokers <span className="em">{requestedDirect.length}</span>
                </div>
                {shouldShowDesks && (
                    <TipIcon
                        testId={"brokers-desks-tip"}
                        level="info"
                        onClick={() => setDeskSelection(multipleDesk)}
                        popup={() => `There are ${multipleDesk.length} brokers with multiple desks`}
                    />
                )}
            </div>

            <div className="direct-brokers-selection">
                {eligibleDirect.map((broker) => (
                    <BrokerToggle
                        key={broker.code}
                        broker={broker}
                        selected={requestedDirect.includes(broker)}
                        onChange={(selected) => {
                            if (selected) {
                                selectBrokers({DIRECT: [...requestedDirect, broker]});
                            } else {
                                selectBrokers({DIRECT: [...requestedDirect].filter((b) => b !== broker)});
                            }
                        }}
                        onDeskSelection={setDeskSelection}
                    />
                ))}
            </div>

            <div className="venue-brokers-heading">
                {venues.length === 1 ? (
                    <div data-test-id="venue-brokers-title" className="title">
                        TradeWeb <span className="em">{requestedVenue.length}</span>
                    </div>
                ) : (
                    <AtxDropdown data-test-id="venue-brokers-title" className="title" options={venues} value={venue}
                                 onChange={venue => {
                                     setVenueIndex(Math.max(0, venue ? venues.indexOf(venue) : 0));
                                 }}/>
                )}
                <div className="flex-fill"/>
                <div data-test-id="all-to-all-toggle" className="all-to-all-toggle">
                    <AtxCheckbox
                        checked={allToAllNetwork}
                        onChange={() => {
                            setAllToAllNetwork(!allToAllNetwork);
                            logClick("All to All Network", {allToAllNetwork});
                        }}
                    >
                        All to All Network
                    </AtxCheckbox>
                </div>
            </div>

            <div className="flex-column flex-fill">
                <div className="venue-brokers-selection">
                    <div data-test-id="venue-select-all" className="venue-select-all">
                        <AtxCheckbox
                            checked={eligibleVenue.length === requestedVenue.length}
                            onChange={() => {
                                if (requestedVenue.length) {
                                    selectBrokers({[venue]: []});
                                } else {
                                    selectBrokers({[venue]: eligibleVenue});
                                }
                                logClick("Venue Select All");
                            }}
                        >
                            Select All
                        </AtxCheckbox>
                    </div>
                    {eligibleVenue.map((broker) => (
                        <BrokerToggle
                            key={broker.code}
                            broker={broker}
                            selected={requestedVenue.includes(broker)}
                            venue={true}
                            onChange={(selected) => {
                                const updateVenue = new Set(requestedVenue);
                                if (selected) {
                                    selectBrokers({[venue]: [...updateVenue, broker]});
                                } else {
                                    selectBrokers({[venue]: [...updateVenue].filter((b) => b !== broker)});
                                }
                            }}
                            onDeskSelection={setDeskSelection}
                        />
                    ))}
                </div>

                {required && !requestedTotal && <div className="text-error">Must select at least 1 broker.</div>}
            </div>

            <DeskSelectionDialog required={deskSelection} onClose={() => setDeskSelection([])}/>
        </div>
    );
};
