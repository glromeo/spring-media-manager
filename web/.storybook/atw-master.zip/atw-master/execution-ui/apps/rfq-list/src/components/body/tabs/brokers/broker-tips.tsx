import React, { ReactNode } from "react";
import { AtxIconProps, Level, WidgetProps } from "@atx/toolkit";
import { AtxIcon } from "@atx/toolkit/components";

export type TipLevel = Exclude<Level, "success"> | "help" | "direct";

const TIP_PROPS: Record<TipLevel, Pick<AtxIconProps, "type" | "name">> = {
    danger: { name: "alert", type: "primary" },
    warning: { name: "alert-bold", type: "warning" },
    info: { name: "info-bold", type: "info" },
    help: { name: "help", type: "warning" },
    direct: { name: "direct", type: "info" }
};

type TipIconProps = Omit<AtxIconProps & WidgetProps, "type" | "name" | "children"> & {
    level: TipLevel;
    popup: () => ReactNode;
};

export function TipIcon(props: TipIconProps) {
    return <AtxIcon {...props} title={{ placement: "bottom", title: props.popup }} {...TIP_PROPS[props.level]} />;
}
