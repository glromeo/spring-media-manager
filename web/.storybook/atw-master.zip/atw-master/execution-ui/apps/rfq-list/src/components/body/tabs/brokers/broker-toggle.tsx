import React from "react";
import { BrokerDetails } from "./broker-details";
import { AtxAlert, AtxButton, classNames, testId } from "@atx/toolkit";
import { Broker } from "@atx/commons/model";
import { TipIcon } from "./broker-tips";
import { useAtomValue } from "jotai";
import { brokerRestrictionsAtom } from "../../../../state/restrictions";
import { brokersByVenueAtom } from "../../../../state/brokers";

import "./broker-selection.scss";

type BrokerToggleProps = {
    broker: Broker;
    venue?: boolean;
    selected: boolean;
    onChange?: (selected: boolean, broker: Broker) => void;
    onDeskSelection: (brokers: Broker[]) => void;
};

export function BrokerToggle(props: BrokerToggleProps) {
    const { broker, venue, selected, onChange, onDeskSelection } = props;
    const { status, message, restrictions = [] } = useAtomValue(brokerRestrictionsAtom).get(broker) ?? {};
    const {DIRECT} = useAtomValue(brokersByVenueAtom);

    const isDisabled = status === "UNAVAILABLE" || status === "FULLY_RESTRICTED";
    const isDirect = venue && DIRECT.has(broker);
    const level = isDisabled
        ? "danger"
        : restrictions.length
        ? "warning"
        : broker.desks?.length > 1
        ? "info"
        : isDirect
        ? "direct"
        : null;

    const popup = () => (
        <div className="broker-toggle-popup">
            {isDisabled && (
                <AtxAlert className="disabled-message" type="danger">
                    {message}
                </AtxAlert>
            )}
            {broker.desks.length > 1 && (
                <AtxAlert className="multiple-desks" type="info">
                    {broker.shortName} has multiple desks
                    <AtxButton
                        className="choose-desk-button"
                        size={"small"}
                        type={"secondary"}
                        onClick={() => onDeskSelection([broker])}
                    >
                        Choose
                    </AtxButton>
                </AtxAlert>
            )}
            {restrictions.length ? <BrokerDetails broker={broker} allocations={restrictions} /> : null}
            {isDirect ? <span style={{ padding: "0.5rem" }}>{broker.name} is a direct broker.</span> : null}
        </div>
    );

    return (
        <div
            data-test-id={testId`broker-tile-${broker.shortName}`}
            className={classNames("broker-tile", selected && "selected", isDisabled && "disabled")}
            onClick={isDisabled || !onChange ? undefined : () => onChange(!selected, broker)}
        >
            <div className="short-name">{broker.shortName}</div>
            {level && (
                <TipIcon
                    level={level}
                    popup={popup}
                    onClick={() => {
                        if (!isDisabled && broker.desks.length > 1) {
                            onDeskSelection([broker]);
                        }
                    }}
                />
            )}
        </div>
    );
}
