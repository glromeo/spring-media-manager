import React, { useEffect, useState } from "react";
import { AtxCheckbox, AtxDialog, AtxDropdown } from "@atx/toolkit";
import { Broker, Desk } from "@atx/commons/model";
import { isDefaultSelectionAtom, selectedDesksAtom } from "../../../../state/brokers";
import { useAtom, useAtomValue } from "jotai";

import "./desk-selection.scss";

type DeskSelection = {
    broker: Broker;
    desk: Desk;
    isDefault: boolean;
};

export function DeskSelectionDialog({
    required,
    onClose
}: {
    required: Broker[];
    onClose: () => void;
}) {
    const [selectedDesks, setSelectedDesks] = useAtom(selectedDesksAtom);
    const [userSelections, setUserSelections] = useState<DeskSelection[]>([]);
    return required.length ? (
        <AtxDialog
            title="Please choose a desk"
            open={true}
            modal={true}
            disabled={userSelections.length === 0}
            onOK={() => {
                setSelectedDesks(userSelections);
                onClose();
            }}
            onCancel={() => {
                onClose();
            }}
        >
            <div className="desk-selection flex-column">
                {required.map((broker) => (
                    <DeskSelectionRow key={broker.code} broker={broker} selected={selectedDesks.get(broker)} />
                ))}
            </div>
        </AtxDialog>
    ) : null;
}

function DeskSelectionRow({ broker, selected }: { broker: Broker; selected: Desk | null | undefined }) {
    const [selectedDesk, setSelectedDesk] = useState(selected ?? broker.defaultDesk);
    const isDefaultSelection = selectedDesk ? useAtomValue(isDefaultSelectionAtom)(broker, selectedDesk) : false;
    const [makeDefault, setMakeDefault] = useState(isDefaultSelection);
    useEffect(() => {
        if (makeDefault !== isDefaultSelection) {
            setMakeDefault(isDefaultSelection);
        }
    }, [makeDefault, isDefaultSelection]);
    return (
        <div className="flex-row">
            <div className="broker">{broker.shortName}</div>
            <AtxDropdown
                className="desks"
                value={selectedDesk?.subBrokerID}
                options={broker.desks.map((desk) => ({
                    label: `${desk.brokerType} - ${desk.salesman}`,
                    value: desk.subBrokerID
                }))}
                onChange={(subBrokerID) => {
                    const desk = broker.desks.find((desk) => desk.subBrokerID === subBrokerID);
                    setSelectedDesk(desk ?? broker.defaultDesk);
                }}
            />
            <AtxCheckbox
                label="Make default"
                checked={makeDefault}
                title="Make this selection persistent"
                onChange={(checked) => setMakeDefault(checked || false)}
            />
        </div>
    );
}
