import React, { useCallback, useMemo } from "react";
import { useAtomValue } from "jotai";
import { OrderField, selectedOrderFieldsAtom } from "../../../state/details";
import { BenchmarkWidget, Quantity, SecurityWidget } from "@atx/commons/components";
import { AtxTabProps } from "@atx/toolkit";
import { ordersAtom } from "../../../state/orders";
import { Order } from "@atx/commons";
import {focusedOrderAtom, rfqsAtom} from "../../../state/rfqs";

import "./order-details-tab.scss";

type OrderDetails = Partial<Order> & { ordNum: number | null };

type FormWidgetProps = { order: OrderDetails };
type FormWidget = React.FC<FormWidgetProps>;

const WIDGETS: Record<OrderField, FormWidget> = {
    Side: Side,
    Bond: Bond,
    "Security Bmk": SecurityBmk,
    CCY: CCY,
    CUSIP: CUSIP,
    ISIN: ISIN,
    "Original Size": OriginalSize,
    "Unbooked Amt": UnbookedAmt,
    "Order Leaves": OrderLeaves,
    Limit: Limit,
    "Limit Type": LimitType,
    Instructions: Instructions,
    "Trading Bmk": TradingBmk
};

export function OrderDetailsTab({}: AtxTabProps) {
    const orders = useAtomValue(ordersAtom);
    const selectedOrderFields = useAtomValue(selectedOrderFieldsAtom);
    const focusedOrder = useAtomValue(focusedOrderAtom);

    const source = useMemo<OrderDetails>(() => {
        let summary = { ...orders[0] };
        for (const order of orders) {
            if (order === focusedOrder) {
                return order;
            } else
                for (const field of Object.keys(order) as (keyof Order)[]) {
                    if (summary[field] !== order[field]) {
                        summary[field] = undefined as never; // :D :D :D take this TS!!!
                    }
                }
        }
        return summary;
    }, [orders, focusedOrder]);

    return (
        <div className="order-details-tab" data-test-id="order-details">
            <div className="order-fields">
                {source &&
                    selectedOrderFields.map((label) => {
                        const Widget = WIDGETS[label];
                        return (
                            <div className="order-field" key={label} data-test-id={label}>
                                <div className="label">{label}</div>
                                <div className="value">
                                    {<Widget order={source}/>}
                                </div>
                            </div>
                        );
                    })}
            </div>
        </div>
    );
}

function Side({ order }: FormWidgetProps) {
    const { side } = order;
    return side ? <div className={`order-side ${side}`}>You {side}</div> : <DASH />;
}

function Bond({ order }: FormWidgetProps) {
    const { asset } = order;
    return asset ? <SecurityWidget className="order-bond" security={asset} /> : <DASH />;
}

function SecurityBmk({ order }: FormWidgetProps) {
    const rfq = useAtomValue(rfqsAtom).find((rfq) => rfq.order === order);
    if (rfq) {
        const { benchmark, priceType } = rfq;
        if (priceType === "spread") {
            return benchmark ? <BenchmarkWidget className="order-security-bmk" benchmark={benchmark} /> : <DASH />;
        }
    }
    return <NA />;
}

function CCY({ order }: FormWidgetProps) {
    const { ccy } = order;
    return ccy ? <div className="order-ccy">{ccy}</div> : <DASH />;
}

function CUSIP({ order }: FormWidgetProps) {
    const cusip = order.asset?.cusip;
    return cusip ? <div className="order-cusip">{cusip}</div> : <DASH />;
}

function ISIN({ order }: FormWidgetProps) {
    const isin = order.asset?.isin;
    return isin ? <div className="order-isin">{isin}</div> : <DASH />;
}

function OriginalSize({ order }: FormWidgetProps) {
    const { size } = order;
    return size ? <Quantity className="order-original-size" value={size} /> : <DASH />;
}

function UnbookedAmt({ order }: FormWidgetProps) {
    const { unbookedAmt } = order;
    return unbookedAmt ? <Quantity className="order-unbooked-amt" value={unbookedAmt} /> : <DASH />;
}

function OrderLeaves({ order }: FormWidgetProps) {
    const { orderLeaves } = order;
    return orderLeaves ? <Quantity className="order-order-leaves" value={orderLeaves} /> : <DASH />;
}

function Limit({ order }: FormWidgetProps) {
    const { limit } = order;
    return limit ? <div className="order-limit">{limit}</div> : <DASH />;
}

function LimitType({ order }: FormWidgetProps) {
    const { limitType } = order;
    return limitType ? <div className="order-limit-type">{limitType}</div> : <DASH />;
}

function Instructions({ order }: FormWidgetProps) {
    const { instructions } = order;
    return instructions ? <div className="order-instructions">{instructions}</div> : <DASH />;
}

function TradingBmk({ order }: FormWidgetProps) {
    const { tradingBmk } = order;
    return tradingBmk ? <div className="order-trading-bmk">{tradingBmk}</div> : <DASH />;
}

/**
 * We could probably do without this...
 *
 * @constructor
 */
function NA() {
    return <>{"N/A"}</>;
}
function DASH() {
    return <>{"-"}</>;
}