import { queryHost } from "@atx/toolkit/utils";
import { AtxButton } from "@atx/toolkit";
import { useAtomValue } from "jotai";
import { stageAtom } from "../../state/workflow";

const closeDashboard = () => queryHost("CLOSE");

export function CancelButton() {
    const stage = useAtomValue(stageAtom);
    return (
        <AtxButton testId="cancel-button" type="secondary" size="regular" onClick={closeDashboard}>
            {stage === "Request" ? "Cancel List RFQ" : "Cancel All Remaining"}
        </AtxButton>
    );
}
