import React, {useMemo} from "react";
import {AtxButton, statusOverlayAtom, useErrorNotification} from "@atx/toolkit";
import {useAtomValue, useSetAtom} from "jotai";
import {ValidationTooltip} from "./validation-tooltip";
import {validatePlacementQuotesMutation} from "../../query/placement-quotes-validation";
import {stepAtom} from "../../state/workflow";
import {requestValidationSummaryAtom} from "../../state/validation";

export function NextButton() {
    const setStep = useSetAtom(stepAtom);
    const {errors, warnings} = useAtomValue(requestValidationSummaryAtom);
    const disabled = errors.length > 0;
    const label = warnings.length > 0 ? "Acknowledge and Send" : "Next";

    const withOverlay = useSetAtom(statusOverlayAtom);
    const validatePlacementQuotes = useSetAtom(validatePlacementQuotesMutation);
    const errorNotification = useErrorNotification();

    return (
        <AtxButton
            testId="next-button"
            type="primary"
            size="regular"
            title={disabled ? () => <ValidationTooltip errors={errors}/> : null}
            disabled={disabled}
            onClick={() => {
                if (label === "Acknowledge and Send") {
                    setStep("Confirmation");
                } else {
                    setStep("Validation");
                    withOverlay(
                        "performing validation...",
                        validatePlacementQuotes()
                            .then(() => {
                                setStep("Confirmation");
                            })
                            .catch((error) => {
                                errorNotification("Failed to perform validation", error);
                                setStep("Validation");
                            })
                    );
                }
            }}
        >
            {label}
        </AtxButton>
    );
}
