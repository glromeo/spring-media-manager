import React from "react";
import { useSetAtom } from "jotai";
import {requestIssuesAtom, requestValidationSummaryAtom} from "../../state/validation";
import { AtxButton } from "@atx/toolkit";

import "./validation-tooltip.scss";

export function ValidationTooltip({ errors }: { errors: string[] }) {
    const dispatch = useSetAtom(requestValidationSummaryAtom);
    return errors.length ? (
        <div className="validation-tooltip flex-column">
            <div className="heading">You must address {errors.length} issue(s)</div>
            <ul className="issues">
                {errors.map((error, index) => (
                    <li
                        className="issue"
                        key={index}
                        style={{ padding: 4 }}
                        ref={(li) => {
                            if (li) {
                                li.innerHTML = error;
                            }
                        }}
                    />
                ))}
            </ul>
            <div className="quick-fix">
                or
                <AtxButton type="tertiary" onClick={() => dispatch("QuickFix")}>
                    remove problem items
                </AtxButton>
            </div>
        </div>
    ) : (
        <div>Request Quotes</div>
    );
}
