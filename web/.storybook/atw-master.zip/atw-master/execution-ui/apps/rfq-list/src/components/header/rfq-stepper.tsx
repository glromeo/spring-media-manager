import { useAtom } from "jotai";
import {
    AuxProgressStepper,
    AuxProgressStepperInterface,
    AuxProgressStepperStepClickedDetailInterface
} from "@blk/aladdin-react-components-es";
import { useMemo } from "react";
import { stageAtom, STAGES } from "../../state/workflow";

export function RfqStepper() {
    const [stage, setStage] = useAtom(stageAtom);

    const workflow = useMemo<AuxProgressStepperInterface[]>(
        () =>
            STAGES.map((label, index) => ({
                index,
                label,
                state: STAGES.indexOf(stage) === index ? "active" : "disabled",
                value: index + 1
            })),
        [stage]
    );

    return (
        <AuxProgressStepper
            data-test-id="rfq-stepper"
            isResponsive={false}
            onStepClicked={(event: CustomEvent<AuxProgressStepperStepClickedDetailInterface>) => {
                const step = event.detail.data[event.detail.index];
                setStage(step.index === 0 ? "Request" : "Response");
            }}
            steps={workflow}
            type="button"
        />
    );
}

