import { AtxDialog, AtxIcon, userAtom } from "@atx/toolkit";
import React, { useState } from "react";
import { useAtomValue } from "jotai";
import { isUserMifidEligibleAtom } from "../state/restrictions";
import { brokersAtom } from "../state/brokers";
import { ordersAtom } from "../state/orders";
import { formatSecurity } from "@atx/commons";

export function ListDebug() {
    const [isOpen, setOpen] = useState(false)
    return <>
        <AtxIcon name={"help"} onClick={() => setOpen(!isOpen)}/>
        {isOpen && <DebugDialog isOpen={isOpen} setOpen={setOpen}/>}
    </>;
}

function DebugDialog({isOpen, setOpen}: { isOpen: boolean, setOpen: (isOpen: boolean) => void }) {
    return (
        <AtxDialog modal={true}
                   title="List RFQ Debug"
                   open={isOpen}
                   onOK={() => setOpen(false)}
                   onCancel={() => setOpen(false)}
                   style={{width: "66vw"}}>
            <table cellPadding={8}>
                <tbody>
                <tr>
                    <td>User</td>
                    <td>{String(useAtomValue(userAtom))}</td>
                </tr>
                <tr>
                    <td>Mifid Eligible</td>
                    <td>{String(useAtomValue(isUserMifidEligibleAtom))}</td>
                </tr>
                <tr>
                    <td>Mifid Enabled Brokers</td>
                    <td>{useAtomValue(brokersAtom).filter(broker => broker.isMifidTagEnabled).map(broker => `${broker.shortName} (${broker.code})`).join(", ")}</td>
                </tr>
                <tr>
                    <td>Mifid Eligible Orders</td>
                    <td>
                        <table>
                            <tbody>{
                                Object.entries(
                                    useAtomValue(ordersAtom)
                                        .filter(order => order.asset.isMiFID2Eligible)
                                        .reduce((acc, order) => {
                                            let key = formatSecurity(order.asset);
                                            acc[key] = acc[key] ? [...acc[key], order.ordNum] : [order.ordNum];
                                            return acc;
                                        }, {} as Record<string, number[]>)
                                ).map(([key, values], index) => (
                                    <tr key={index}>
                                        <td>{key}</td>
                                        <td>
                                            <table>
                                                <tbody>{
                                                    values.map((ordNum, index) => (
                                                        <tr key={index}>
                                                            <td>{ordNum}</td>
                                                        </tr>
                                                    ))
                                                }</tbody>
                                            </table>
                                        </td>
                                    </tr>
                                ))
                            }</tbody>
                        </table>
                    </td>
                </tr>
                </tbody>
            </table>
        </AtxDialog>
    )
}