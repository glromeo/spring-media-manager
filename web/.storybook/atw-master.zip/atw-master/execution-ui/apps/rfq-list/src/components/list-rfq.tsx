import React from "react";
import { BrokersRequested } from "./ribbon/brokers-requested";
import { CancelButton } from "./footer/cancel-button";
import { NextButton } from "./footer/next-button";
import { OrdersTotals } from "./ribbon/orders-totals";
import { RfqStepper } from "./header/rfq-stepper";
import { useAtomValue } from "jotai";
import { tokensAtom } from "@atx/commons/atoms";
import { RequestBody } from "./body/request/request-body";
import { ResponseBody } from "./body/response/response-body";
import { ResponseDueIn } from "./ribbon/response-due-in";
import { FlexFill } from "@atx/commons/components";
import { stageAtom } from "../state/workflow";

import "./list-rfq.scss";

export function ListRFQ() {
    useAtomValue(tokensAtom); // TODO: move me into AtxApp

    return useAtomValue(stageAtom) === "Request" ? (
        <div className="list-rfq request-stage">
            <div className="header-section">
                <RfqStepper/>
            </div>
            <div className="ribbon-section primary">
                <OrdersTotals/>
                <FlexFill/>
                <BrokersRequested/>
            </div>
            <RequestBody/>
            <div className="footer-section">
                <FlexFill/>
                <NextButton/>
                <CancelButton/>
            </div>
        </div>
    ) : (
        <div className="list-rfq response-stage">
            <div className="header-section">
                <RfqStepper/>
            </div>
            <div className="ribbon-section primary">
                <OrdersTotals/>
                <FlexFill/>
                <ResponseDueIn/>
            </div>
            <ResponseBody/>
            <div className="footer-section">
                <FlexFill/>
                <CancelButton/>
            </div>
        </div>
    );
}
