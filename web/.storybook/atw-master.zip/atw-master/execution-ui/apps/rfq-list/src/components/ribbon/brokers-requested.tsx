import { useAtomValue } from "jotai";
import { brokersRequestedAtom, requestedVenuesAtom } from "../../state/brokers";

export function BrokersRequested() {
    const brokersRequested = useAtomValue(brokersRequestedAtom);
    return (
        <div className="ribbon-item flex-column" data-test-id="brokers-requested" data-requested-venues={useAtomValue(requestedVenuesAtom)}>
            <div className="ribbon-item-label">Brokers Requested</div>
            <div className="ribbon-item-value">{brokersRequested}</div>
        </div>
    );
}
