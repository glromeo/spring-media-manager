import React from "react";
import { useAtomValue } from "jotai";
import { selectedQuoteAtom } from "../../state/quote";

export function OrderSpotTime() {
    const quote = useAtomValue(selectedQuoteAtom);
    return quote ? (
        <div className="ribbon-item flex-row" data-test-id="order-spot-time">
            <div className="ribbon-item-label">Spot Time</div>
            <div className="ribbon-item-value">{quote.spotTime}</div>
        </div>
    ) : null;
}
