import React from "react";
import { useAtomValue } from "jotai";
import { AtxBadge, formatQuantity } from "@atx/toolkit";
import { SecurityWidget } from "@atx/commons/components";
import { selectedQuoteAtom } from "../../state/quote";

export function OrderTotals() {
    const quote = useAtomValue(selectedQuoteAtom);
    if (quote) {
        const { side, size, asset } = quote.order;
        return (
            <div className="ribbon-item flex-row row-spaced" data-test-id="order-totals">
                <AtxBadge type={side === "SELL" ? "danger" : "info"} size="large">
                    {side}
                </AtxBadge>
                <div className="ribbon-item-value flex-row">
                    <SecurityWidget security={asset} />
                    <div style={{ margin: "0 .5rem" }}>/</div>
                    <div>{formatQuantity(size)}</div>
                </div>
            </div>
        );
    } else {
        return null;
    }
}
