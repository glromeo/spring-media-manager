import React, { useMemo } from "react";
import { useAtomValue } from "jotai";
import { AtxBadge, formatQuantity } from "@atx/toolkit";
import { quotesAtom } from "../../state/quote";

export type OrdersTotalsProps = {};

function emptyTotal(): { count: number; size: number } {
    return { count: 0, size: 0 };
}

export function OrdersTotals({}: OrdersTotalsProps) {
    const quotes = useAtomValue(quotesAtom);
    const [buy, sell] = useMemo(() => {
        let buy = emptyTotal();
        let sell = emptyTotal();
        for (const {
            order: { side },
            size
        } of quotes) {
            if (side === "BUY") {
                buy.count++;
                buy.size += size ?? 0;
            } else {
                sell.count++;
                sell.size += size ?? 0;
            }
        }
        return [buy, sell];
    }, [quotes]);
    return (
        <div className="ribbon-item flex-row row-spaced">
            <div className="flex-row row-spaced">
                <AtxBadge type="info" size="large">
                    BUY
                </AtxBadge>
                <div className="ribbon-item-value" data-test-id="buy-order-totals">
                    {buy.count} / {formatQuantity(buy.size)}
                </div>
            </div>
            <div className="flex-row row-spaced">
                <AtxBadge type="danger" size="large">
                    SELL
                </AtxBadge>
                <div className="ribbon-item-value" data-test-id="sell-order-totals">
                    {sell.count} / {formatQuantity(sell.size)}
                </div>
            </div>
        </div>
    );
}
