import { useAtomValue } from "jotai";
import { responseDueInAtom } from "../../state/response";

export function ResponseDueIn() {
    const responseDueIn = useAtomValue(responseDueInAtom);
    return (
        <div className="ribbon-item flex-column" data-test-id="response-due-in">
            <div className="ribbon-item-label">Due In</div>
            <div className="ribbon-item-value">{responseDueIn.toFormat("mm:ss")}</div>
        </div>
    );
}
