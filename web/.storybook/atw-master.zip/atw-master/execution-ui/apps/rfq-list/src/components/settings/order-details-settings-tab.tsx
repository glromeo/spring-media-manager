import { SettingsTabProps } from "@atx/toolkit";
import { useCallback, useMemo, useState } from "react";
import { AuxPicklist, AuxPicklistDetailInterface } from "@blk/aladdin-react-components-es";
import { useAtomValue, useSetAtom } from "jotai";
import { availableOrderDetailsFields, OrderField, selectedOrderFieldsAtom } from "../../state/details";

/**
 * NOTE: This component is not used and it's deprecated
 *
 * @constructor
 */
export function OrderDetailsSettingsTab({}: SettingsTabProps) {
    const setSelectedOrderFields = useSetAtom(selectedOrderFieldsAtom);

    const availableFields = useAtomValue(availableOrderDetailsFields);
    const [selectedFields, setSelectedFields] = useState(() => availableFields.map((field) => field.label));
    const [checkedFields, setCheckedFields] = useState<string[]>([]);

    const [sourceData, targetData] = useMemo(() => {
        const selected = new Map(selectedFields.map((label, index) => [label, index]));
        const checked = new Set(checkedFields);
        const toOption = ({ label, tooltip, required }: typeof availableFields[number]) => ({
            label,
            tooltip,
            isDisabled: required,
            isChecked: checked.has(label)
        });
        return [
            availableFields
                .filter(({ label }) => !selected.has(label))
                .sort((l, r) => (selected.get(l.label)! < selected.get(r.label)! ? -1 : 1))
                .map(toOption),
            availableFields
                .filter(({ label }) => selected.has(label))
                .sort((l, r) => (selected.get(l.label)! < selected.get(r.label)! ? -1 : 1))
                .map(toOption)
                .sort((l, r) => (l.isDisabled ? (r.isDisabled ? 0 : -1) : 1))
        ];
    }, [availableFields, selectedFields, checkedFields]);

    const onSelectionChanged = useCallback(
        ({ detail }: { detail: AuxPicklistDetailInterface }) => {
            const selected: OrderField[] = [];
            const checked: string[] = [];
            for (const { label, isChecked } of detail.targetData.sort((l, r) =>
                l.isDisabled ? (r.isDisabled ? 0 : -1) : 1
            )) {
                selected.push(label! as OrderField);
                if (isChecked) {
                    checked.push(label!);
                }
            }
            setSelectedFields(selected);
            setCheckedFields(checked);

            setSelectedOrderFields(selected); // TODO: refactor me!!!
        },
        [availableFields]
    );

    return (
        <div className="order-details-settings-tab" style={{ height: "100%" }}>
            <AuxPicklist
                config={{ hasBoldLabel: true }}
                role="order-details-settings-tab"
                className="order-fields-picker"
                sourceLabel="Available Order Fields"
                targetLabel="Displayed Order Fields"
                hasAggregator
                hasDragAndDrop
                hasReorder
                allowDuplicates={false}
                hasSelectedOnly={false}
                sourceData={sourceData}
                targetData={targetData}
                onTargetListChanged={onSelectionChanged}
            />
        </div>
    );
}
