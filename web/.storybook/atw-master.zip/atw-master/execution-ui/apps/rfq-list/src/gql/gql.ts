/* eslint-disable */
import * as types from './graphql.js';
import { TypedDocumentNode as DocumentNode } from '@graphql-typed-document-node/core';

/**
 * Map of all GraphQL operations in the project.
 *
 * This map has several performance disadvantages:
 * 1. It is not tree-shakeable, so it will include all operations in the project.
 * 2. It is not minifiable, so the string of a GraphQL query will be multiple times inside the bundle.
 * 3. It does not support dead code elimination, so it will add unused operations.
 *
 * Therefore it is highly recommended to use the babel or swc plugin for production.
 */
const documents = {
    "query assetList($secIds: [String!]) {\n  fiAssetList(secIds: $secIds) {\n    isin\n    cusip\n    couponValue\n    bAsset {\n      maturity\n      ticker\n      minTrdSize\n      secGroup\n      secType\n    }\n    bondQuality\n    defaultSettleDate\n    isMiFID2Eligible\n  }\n}": types.AssetListDocument,
    "query asset($secId: String!) {\n  fiAsset(secId: $secId) {\n    isin\n    cusip\n    couponValue\n    bAsset {\n      maturity\n      ticker\n      minTrdSize\n      secGroup\n      secType\n    }\n    bondQuality\n    defaultSettleDate\n    isMiFID2Eligible\n  }\n}": types.AssetDocument,
    "query BasketListSummary($basketId: String!, $user: String!) {\n  fiBasketSummary(basketId: $basketId, user: $user) {\n    placements {\n      placementNum\n      basketID\n      axeID\n      limitValue\n      inquiryType\n      limitType\n      quantity\n      status\n      modifyReason\n      modifiedTime\n      placementGenFields {\n        key\n        value\n      }\n      externRefID\n      quotes {\n        spread\n        quoteStatus\n        price\n        type\n        side\n        quoteID\n        expTime\n        quantity\n        counterparty {\n          ticker\n          code\n          shortName\n        }\n      }\n      desk {\n        salesman\n        brokerType\n        subBrokerID\n      }\n      broker {\n        ticker\n        type\n        shortName\n        code\n      }\n      ordNum\n      dueInTime\n      spreadIndex\n      settleDate\n      modifiedBy\n      type\n    }\n  }\n}": types.BasketListSummaryDocument,
    "query benchmarkList($secIds: [String!]) {\n  fiAssetList(secIds: $secIds) {\n    cusip\n    bAsset {\n      secDesc1\n      maturity\n      ticker\n    }\n    couponValue\n  }\n}": types.BenchmarkListDocument,
    "query orderListSummary($ordNumList: [Int], $user: String!, $rfqExecution: Boolean!) {\n  fiOrderListSummary(\n    ordNumList: $ordNumList\n    user: $user\n    rfqExecution: $rfqExecution\n  ) {\n    fiOrderSummaries {\n      order {\n        cusip\n        ordNum\n        price\n        effectiveTranType\n        updateInstr\n        face\n        fillAmt\n        limitValue\n        limitType\n        orderLeaves\n        settleDate\n        tradingBenchmark\n        priceCurrency\n      }\n      orderDetails {\n        quantity\n        quantityBooked\n        portfolio {\n          portfolioCode\n          portfolioName\n        }\n      }\n      brokerAllocations {\n        broker {\n          code\n        }\n        availablePlacementQuantity\n        eligiblePlacementQuantity\n        eligiblePlacementQuantityAsPct\n        portfolioAllocations {\n          portfolioCode\n          quantityAvailable\n        }\n      }\n    }\n  }\n}": types.OrderListSummaryDocument,
    "query orderSummary($ordNum: Int, $user: String!, $rfqExecution: Boolean!) {\n  fiOrderSummary(ordNum: $ordNum, user: $user, rfqExecution: $rfqExecution) {\n    directBrokers\n    venueBrokers {\n      brokerName\n      brokerCode\n      executingBrokerCodes\n    }\n    delayedSpotEnabled\n    mifidTagEnabled\n    spreadFlowEnabled\n    counteringEnabled\n    brokerAllocations {\n      broker {\n        code\n        name\n        shortName\n        defaultDesk\n        desks {\n          brokerCode\n          brokerType\n          salesman\n          subBrokerID\n        }\n      }\n      availablePlacementQuantity\n      eligiblePlacementQuantity\n      eligiblePlacementQuantityAsPct\n      portfolioAllocations {\n        portfolioCode\n        quantityAvailable\n      }\n    }\n    brokerEntity {\n      key\n      value\n    }\n    spotTimes {\n      venue\n      spotTime {\n        code\n        displayName\n      }\n    }\n    userMifidEligibility\n  }\n}": types.OrderSummaryDocument,
    "mutation createPlacementQuotes($requests: [PlacementQuoteRequest!], $user: String) {\n  requestListPlacementQuotes(requests: $requests, user: $user) {\n    order {\n      ordNum\n    }\n    placements {\n      placementNum\n    }\n  }\n}": types.CreatePlacementQuotesDocument,
    "mutation validatePlacementQuotes($request: [PlacementQuoteRequest!], $warnings: String, $user: String) {\n  validateListPlacementsCountering(\n    request: $request\n    warnings: $warnings\n    user: $user\n  ) {\n    message\n  }\n}": types.ValidatePlacementQuotesDocument,
    "query prices($cusips: [String!], $startInclusive: BFMTimestamp) {\n  prices(cusips: $cusips, startInclusive: $startInclusive) {\n    cusip\n    indexName\n    price\n  }\n}": types.PricesDocument,
};

/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 *
 *
 * @example
 * ```ts
 * const query = graphql(`query GetUser($id: ID!) { user(id: $id) { name } }`);
 * ```
 *
 * The query argument is unknown!
 * Please regenerate the types.
 */
export function graphql(source: string): unknown;

/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(source: "query assetList($secIds: [String!]) {\n  fiAssetList(secIds: $secIds) {\n    isin\n    cusip\n    couponValue\n    bAsset {\n      maturity\n      ticker\n      minTrdSize\n      secGroup\n      secType\n    }\n    bondQuality\n    defaultSettleDate\n    isMiFID2Eligible\n  }\n}"): (typeof documents)["query assetList($secIds: [String!]) {\n  fiAssetList(secIds: $secIds) {\n    isin\n    cusip\n    couponValue\n    bAsset {\n      maturity\n      ticker\n      minTrdSize\n      secGroup\n      secType\n    }\n    bondQuality\n    defaultSettleDate\n    isMiFID2Eligible\n  }\n}"];
/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(source: "query asset($secId: String!) {\n  fiAsset(secId: $secId) {\n    isin\n    cusip\n    couponValue\n    bAsset {\n      maturity\n      ticker\n      minTrdSize\n      secGroup\n      secType\n    }\n    bondQuality\n    defaultSettleDate\n    isMiFID2Eligible\n  }\n}"): (typeof documents)["query asset($secId: String!) {\n  fiAsset(secId: $secId) {\n    isin\n    cusip\n    couponValue\n    bAsset {\n      maturity\n      ticker\n      minTrdSize\n      secGroup\n      secType\n    }\n    bondQuality\n    defaultSettleDate\n    isMiFID2Eligible\n  }\n}"];
/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(source: "query BasketListSummary($basketId: String!, $user: String!) {\n  fiBasketSummary(basketId: $basketId, user: $user) {\n    placements {\n      placementNum\n      basketID\n      axeID\n      limitValue\n      inquiryType\n      limitType\n      quantity\n      status\n      modifyReason\n      modifiedTime\n      placementGenFields {\n        key\n        value\n      }\n      externRefID\n      quotes {\n        spread\n        quoteStatus\n        price\n        type\n        side\n        quoteID\n        expTime\n        quantity\n        counterparty {\n          ticker\n          code\n          shortName\n        }\n      }\n      desk {\n        salesman\n        brokerType\n        subBrokerID\n      }\n      broker {\n        ticker\n        type\n        shortName\n        code\n      }\n      ordNum\n      dueInTime\n      spreadIndex\n      settleDate\n      modifiedBy\n      type\n    }\n  }\n}"): (typeof documents)["query BasketListSummary($basketId: String!, $user: String!) {\n  fiBasketSummary(basketId: $basketId, user: $user) {\n    placements {\n      placementNum\n      basketID\n      axeID\n      limitValue\n      inquiryType\n      limitType\n      quantity\n      status\n      modifyReason\n      modifiedTime\n      placementGenFields {\n        key\n        value\n      }\n      externRefID\n      quotes {\n        spread\n        quoteStatus\n        price\n        type\n        side\n        quoteID\n        expTime\n        quantity\n        counterparty {\n          ticker\n          code\n          shortName\n        }\n      }\n      desk {\n        salesman\n        brokerType\n        subBrokerID\n      }\n      broker {\n        ticker\n        type\n        shortName\n        code\n      }\n      ordNum\n      dueInTime\n      spreadIndex\n      settleDate\n      modifiedBy\n      type\n    }\n  }\n}"];
/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(source: "query benchmarkList($secIds: [String!]) {\n  fiAssetList(secIds: $secIds) {\n    cusip\n    bAsset {\n      secDesc1\n      maturity\n      ticker\n    }\n    couponValue\n  }\n}"): (typeof documents)["query benchmarkList($secIds: [String!]) {\n  fiAssetList(secIds: $secIds) {\n    cusip\n    bAsset {\n      secDesc1\n      maturity\n      ticker\n    }\n    couponValue\n  }\n}"];
/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(source: "query orderListSummary($ordNumList: [Int], $user: String!, $rfqExecution: Boolean!) {\n  fiOrderListSummary(\n    ordNumList: $ordNumList\n    user: $user\n    rfqExecution: $rfqExecution\n  ) {\n    fiOrderSummaries {\n      order {\n        cusip\n        ordNum\n        price\n        effectiveTranType\n        updateInstr\n        face\n        fillAmt\n        limitValue\n        limitType\n        orderLeaves\n        settleDate\n        tradingBenchmark\n        priceCurrency\n      }\n      orderDetails {\n        quantity\n        quantityBooked\n        portfolio {\n          portfolioCode\n          portfolioName\n        }\n      }\n      brokerAllocations {\n        broker {\n          code\n        }\n        availablePlacementQuantity\n        eligiblePlacementQuantity\n        eligiblePlacementQuantityAsPct\n        portfolioAllocations {\n          portfolioCode\n          quantityAvailable\n        }\n      }\n    }\n  }\n}"): (typeof documents)["query orderListSummary($ordNumList: [Int], $user: String!, $rfqExecution: Boolean!) {\n  fiOrderListSummary(\n    ordNumList: $ordNumList\n    user: $user\n    rfqExecution: $rfqExecution\n  ) {\n    fiOrderSummaries {\n      order {\n        cusip\n        ordNum\n        price\n        effectiveTranType\n        updateInstr\n        face\n        fillAmt\n        limitValue\n        limitType\n        orderLeaves\n        settleDate\n        tradingBenchmark\n        priceCurrency\n      }\n      orderDetails {\n        quantity\n        quantityBooked\n        portfolio {\n          portfolioCode\n          portfolioName\n        }\n      }\n      brokerAllocations {\n        broker {\n          code\n        }\n        availablePlacementQuantity\n        eligiblePlacementQuantity\n        eligiblePlacementQuantityAsPct\n        portfolioAllocations {\n          portfolioCode\n          quantityAvailable\n        }\n      }\n    }\n  }\n}"];
/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(source: "query orderSummary($ordNum: Int, $user: String!, $rfqExecution: Boolean!) {\n  fiOrderSummary(ordNum: $ordNum, user: $user, rfqExecution: $rfqExecution) {\n    directBrokers\n    venueBrokers {\n      brokerName\n      brokerCode\n      executingBrokerCodes\n    }\n    delayedSpotEnabled\n    mifidTagEnabled\n    spreadFlowEnabled\n    counteringEnabled\n    brokerAllocations {\n      broker {\n        code\n        name\n        shortName\n        defaultDesk\n        desks {\n          brokerCode\n          brokerType\n          salesman\n          subBrokerID\n        }\n      }\n      availablePlacementQuantity\n      eligiblePlacementQuantity\n      eligiblePlacementQuantityAsPct\n      portfolioAllocations {\n        portfolioCode\n        quantityAvailable\n      }\n    }\n    brokerEntity {\n      key\n      value\n    }\n    spotTimes {\n      venue\n      spotTime {\n        code\n        displayName\n      }\n    }\n    userMifidEligibility\n  }\n}"): (typeof documents)["query orderSummary($ordNum: Int, $user: String!, $rfqExecution: Boolean!) {\n  fiOrderSummary(ordNum: $ordNum, user: $user, rfqExecution: $rfqExecution) {\n    directBrokers\n    venueBrokers {\n      brokerName\n      brokerCode\n      executingBrokerCodes\n    }\n    delayedSpotEnabled\n    mifidTagEnabled\n    spreadFlowEnabled\n    counteringEnabled\n    brokerAllocations {\n      broker {\n        code\n        name\n        shortName\n        defaultDesk\n        desks {\n          brokerCode\n          brokerType\n          salesman\n          subBrokerID\n        }\n      }\n      availablePlacementQuantity\n      eligiblePlacementQuantity\n      eligiblePlacementQuantityAsPct\n      portfolioAllocations {\n        portfolioCode\n        quantityAvailable\n      }\n    }\n    brokerEntity {\n      key\n      value\n    }\n    spotTimes {\n      venue\n      spotTime {\n        code\n        displayName\n      }\n    }\n    userMifidEligibility\n  }\n}"];
/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(source: "mutation createPlacementQuotes($requests: [PlacementQuoteRequest!], $user: String) {\n  requestListPlacementQuotes(requests: $requests, user: $user) {\n    order {\n      ordNum\n    }\n    placements {\n      placementNum\n    }\n  }\n}"): (typeof documents)["mutation createPlacementQuotes($requests: [PlacementQuoteRequest!], $user: String) {\n  requestListPlacementQuotes(requests: $requests, user: $user) {\n    order {\n      ordNum\n    }\n    placements {\n      placementNum\n    }\n  }\n}"];
/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(source: "mutation validatePlacementQuotes($request: [PlacementQuoteRequest!], $warnings: String, $user: String) {\n  validateListPlacementsCountering(\n    request: $request\n    warnings: $warnings\n    user: $user\n  ) {\n    message\n  }\n}"): (typeof documents)["mutation validatePlacementQuotes($request: [PlacementQuoteRequest!], $warnings: String, $user: String) {\n  validateListPlacementsCountering(\n    request: $request\n    warnings: $warnings\n    user: $user\n  ) {\n    message\n  }\n}"];
/**
 * The graphql function is used to parse GraphQL queries into a document that can be used by GraphQL clients.
 */
export function graphql(source: "query prices($cusips: [String!], $startInclusive: BFMTimestamp) {\n  prices(cusips: $cusips, startInclusive: $startInclusive) {\n    cusip\n    indexName\n    price\n  }\n}"): (typeof documents)["query prices($cusips: [String!], $startInclusive: BFMTimestamp) {\n  prices(cusips: $cusips, startInclusive: $startInclusive) {\n    cusip\n    indexName\n    price\n  }\n}"];

export function graphql(source: string) {
  return (documents as any)[source] ?? {};
}

export type DocumentType<TDocumentNode extends DocumentNode<any, any>> = TDocumentNode extends DocumentNode<  infer TType,  any>  ? TType  : never;