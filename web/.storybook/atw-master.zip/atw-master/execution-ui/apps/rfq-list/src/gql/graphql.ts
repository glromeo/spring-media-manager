/* eslint-disable */
import { TypedDocumentNode as DocumentNode } from '@graphql-typed-document-node/core';
export type Maybe<T> = T | null;
export type InputMaybe<T> = Maybe<T>;
export type Exact<T extends { [key: string]: unknown }> = { [K in keyof T]: T[K] };
export type MakeOptional<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]?: Maybe<T[SubKey]> };
export type MakeMaybe<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]: Maybe<T[SubKey]> };
export type MakeEmpty<T extends { [key: string]: unknown }, K extends keyof T> = { [_ in K]?: never };
export type Incremental<T> = T | { [P in keyof T]?: P extends ' $fragmentName' | '__typename' ? T[P] : never };
/** All built-in and custom scalars, mapped to their actual values */
export type Scalars = {
  ID: { input: string; output: string; }
  String: { input: string; output: string; }
  Boolean: { input: boolean; output: boolean; }
  Int: { input: number; output: number; }
  Float: { input: number; output: number; }
  /** Decode Scalar for AssignedToStatus */
  AssignedToStatus: { input: any; output: any; }
  /** BFM scalar for BFMDate */
  BFMDate: { input: any; output: any; }
  /** BFM scalar for BFMDateTime */
  BFMDateTime: { input: any; output: any; }
  /** BFM Scalar for BFMDateTimeTZ */
  BFMDateTimeTZ: { input: any; output: any; }
  /** BFM Scalar for BFMTimestamp */
  BFMTimestamp: { input: any; output: any; }
  /** Char as Character */
  Char: { input: any; output: any; }
  /** Placement Scalar for ExecutionTimeSource */
  ExecutionTimeSource: { input: any; output: any; }
  /** BFM scalar for ExternCommand */
  ExternCommand: { input: any; output: any; }
  /** Long type */
  Long: { input: any; output: any; }
  /** Decode Scalar for OrderExecInst */
  OrderExecInst: { input: any; output: any; }
  /** Decode Scalar for OrderLimitType */
  OrderExpiryType: { input: any; output: any; }
  /** Decode Scalar for OrderFlags */
  OrderFlags: { input: any; output: any; }
  /** Custom scalar for OrderLimitType */
  OrderLimitType: { input: any; output: any; }
  /** Decode Scalar for OrderStatus */
  OrderStatus: { input: any; output: any; }
  /** Decode Scalar for OrderTranType */
  OrderTranType: { input: any; output: any; }
  /** Decode Scalar for OrderUnitFlagType */
  OrderUnitFlagType: { input: any; output: any; }
  /** Decode Scalar for OrderUrgency */
  OrderUrgency: { input: any; output: any; }
  /** Decode Scalar for OwnerType */
  OwnerType: { input: any; output: any; }
  /** Placement Scalar for PlacementStatus */
  PlacementStatus: { input: any; output: any; }
  /** Placement Scalar for PlacementType */
  PlacementType: { input: any; output: any; }
  /** Quote Decode for QuoteStatus */
  QuoteStatus: { input: any; output: any; }
  /** Quote Decode for Type */
  QuoteType: { input: any; output: any; }
  /** Quote Decode for RFQType */
  RFQType: { input: any; output: any; }
  /** Quote Decode for Side */
  Side: { input: any; output: any; }
  /** Placement Scalar for PlacementAllocationStrategy.Strategy */
  Strategy: { input: any; output: any; }
  /** Placement Scalar for Type */
  Type: { input: any; output: any; }
  /** Placement Scalar for ValidationSeverityType */
  ValidationSeverityType: { input: any; output: any; }
  /** Placement Scalar for ValidationState */
  ValidationState: { input: any; output: any; }
  /** Placement Scalar for ValidationID.ValidationType */
  ValidationType: { input: any; output: any; }
};

export type AccountInfo = {
  __typename?: 'AccountInfo';
  accountFullName?: Maybe<Scalars['String']['output']>;
  acctCode?: Maybe<Scalars['Long']['output']>;
  acctType?: Maybe<Scalars['Char']['output']>;
  shortname?: Maybe<Scalars['String']['output']>;
};

export type AllocationStrategy = {
  strategy: Scalars['Strategy']['input'];
  value: Scalars['Float']['input'];
};

export type AssetObject = {
  __typename?: 'AssetObject';
  bAsset?: Maybe<BAsset>;
  bondQuality?: Maybe<Scalars['String']['output']>;
  couponValue?: Maybe<Scalars['Float']['output']>;
  cusip?: Maybe<Scalars['String']['output']>;
  defaultSettleDate?: Maybe<Scalars['BFMDate']['output']>;
  isMiFID2Eligible?: Maybe<Scalars['Boolean']['output']>;
  isin?: Maybe<Scalars['String']['output']>;
  tradeOnPrice?: Maybe<Scalars['Boolean']['output']>;
};

export type Axe = {
  __typename?: 'Axe';
  actionableFlag?: Maybe<Scalars['String']['output']>;
  actualSize: Scalars['Float']['output'];
  aladdinId: Scalars['String']['output'];
  axeId: Scalars['Int']['output'];
  axeType?: Maybe<Scalars['String']['output']>;
  brokerCode?: Maybe<Scalars['String']['output']>;
  ecnAxeId?: Maybe<Scalars['String']['output']>;
  effectiveTime: Scalars['BFMTimestamp']['output'];
  expiryTime?: Maybe<Scalars['BFMTimestamp']['output']>;
  price?: Maybe<Scalars['Float']['output']>;
  priceCurrency?: Maybe<Scalars['String']['output']>;
  priceType?: Maybe<Scalars['String']['output']>;
  qualifier?: Maybe<Scalars['String']['output']>;
  securityID?: Maybe<Scalars['String']['output']>;
  shortName?: Maybe<Scalars['String']['output']>;
  source?: Maybe<Scalars['String']['output']>;
  sourceComment?: Maybe<Scalars['String']['output']>;
  spread?: Maybe<Scalars['Float']['output']>;
  status?: Maybe<Scalars['Char']['output']>;
  tranType: Scalars['String']['output'];
};

export type BAsset = {
  __typename?: 'BAsset';
  MTN?: Maybe<Scalars['Char']['output']>;
  accrualDate?: Maybe<Scalars['BFMDate']['output']>;
  /**     offeringData: OfferingData */
  amtIssued?: Maybe<Scalars['Float']['output']>;
  announceDate?: Maybe<Scalars['BFMDate']['output']>;
  assetId?: Maybe<Scalars['String']['output']>;
  assetStatus?: Maybe<Scalars['String']['output']>;
  barrierEnd?: Maybe<Scalars['BFMDate']['output']>;
  /**
   * ratingTable: HashMap
   * map: BRMap
   */
  barrierEvent?: Maybe<Scalars['String']['output']>;
  barrierLower?: Maybe<Scalars['Float']['output']>;
  barrierSource?: Maybe<Scalars['String']['output']>;
  barrierStart?: Maybe<Scalars['BFMDate']['output']>;
  barrierUpper?: Maybe<Scalars['Float']['output']>;
  basketCusip?: Maybe<Scalars['String']['output']>;
  benchmark?: Maybe<Scalars['String']['output']>;
  calcType?: Maybe<Scalars['Int']['output']>;
  callPut?: Maybe<Scalars['String']['output']>;
  cdsType?: Maybe<Scalars['String']['output']>;
  changeDate?: Maybe<Scalars['BFMDateTime']['output']>;
  collateralType?: Maybe<Scalars['String']['output']>;
  contractMonth?: Maybe<Scalars['Int']['output']>;
  contractYear?: Maybe<Scalars['Int']['output']>;
  country?: Maybe<Scalars['String']['output']>;
  coupFreq?: Maybe<Scalars['Int']['output']>;
  /**     coupon: Coupon */
  currency?: Maybe<Scalars['String']['output']>;
  cusip?: Maybe<Scalars['String']['output']>;
  dateConv?: Maybe<Scalars['String']['output']>;
  delFlag?: Maybe<Scalars['Char']['output']>;
  /**     splitAdjustments: List */
  deliveryDate?: Maybe<Scalars['BFMDate']['output']>;
  digitalFlag?: Maybe<Scalars['Char']['output']>;
  excerciseType?: Maybe<Scalars['Char']['output']>;
  exchange?: Maybe<Scalars['String']['output']>;
  executionSpread?: Maybe<Scalars['Float']['output']>;
  expDate?: Maybe<Scalars['BFMDate']['output']>;
  expectedMaturity?: Maybe<Scalars['BFMDate']['output']>;
  expiryTime?: Maybe<Scalars['String']['output']>;
  firstCpnDate?: Maybe<Scalars['BFMDate']['output']>;
  firstDeliveryDate?: Maybe<Scalars['BFMDate']['output']>;
  firstPmtDate?: Maybe<Scalars['BFMDate']['output']>;
  flag144a?: Maybe<Scalars['Char']['output']>;
  globalId?: Maybe<Scalars['String']['output']>;
  haircut?: Maybe<Scalars['Float']['output']>;
  issueDate?: Maybe<Scalars['BFMDate']['output']>;
  issuer?: Maybe<Scalars['String']['output']>;
  issuerPrice?: Maybe<Scalars['Float']['output']>;
  /**     factors: Vector<BRElem> */
  lastTouchTime?: Maybe<Scalars['BFMDateTime']['output']>;
  lastTouchTimeUTC?: Maybe<Scalars['BFMDateTime']['output']>;
  leadMgr?: Maybe<Scalars['String']['output']>;
  liquidity?: Maybe<Scalars['String']['output']>;
  market?: Maybe<Scalars['String']['output']>;
  marketIssue?: Maybe<Scalars['String']['output']>;
  maturity?: Maybe<Scalars['BFMDate']['output']>;
  mgmtFee?: Maybe<Scalars['Float']['output']>;
  minTrdIncrement?: Maybe<Scalars['Float']['output']>;
  minTrdSize?: Maybe<Scalars['Float']['output']>;
  modificationTime?: Maybe<Scalars['Int']['output']>;
  modifiedBy?: Maybe<Scalars['String']['output']>;
  notionalAmt?: Maybe<Scalars['Float']['output']>;
  notionalFlag?: Maybe<Scalars['Char']['output']>;
  optionsExchange?: Maybe<Scalars['String']['output']>;
  paymentCalendar?: Maybe<Scalars['String']['output']>;
  paymentCurrency?: Maybe<Scalars['String']['output']>;
  paymentFxReference?: Maybe<Scalars['String']['output']>;
  pricing?: Maybe<Scalars['Int']['output']>;
  prinFreq?: Maybe<Scalars['Int']['output']>;
  putCall?: Maybe<Scalars['Char']['output']>;
  redCode?: Maybe<Scalars['String']['output']>;
  referenceEntity?: Maybe<Scalars['String']['output']>;
  referenceName?: Maybe<Scalars['String']['output']>;
  referenceObligation?: Maybe<Scalars['String']['output']>;
  region?: Maybe<Scalars['String']['output']>;
  restructuringType?: Maybe<Scalars['Char']['output']>;
  reviewedBy?: Maybe<Scalars['String']['output']>;
  riskCountry?: Maybe<Scalars['String']['output']>;
  secDesc?: Maybe<Scalars['String']['output']>;
  secDesc1?: Maybe<Scalars['String']['output']>;
  secDesc2?: Maybe<Scalars['String']['output']>;
  secGroup?: Maybe<Scalars['String']['output']>;
  secLongName?: Maybe<Scalars['String']['output']>;
  secSource?: Maybe<Scalars['String']['output']>;
  secType?: Maybe<Scalars['String']['output']>;
  seniority?: Maybe<Scalars['String']['output']>;
  settleCal?: Maybe<Scalars['String']['output']>;
  settleLocation?: Maybe<Scalars['Char']['output']>;
  settleMeth?: Maybe<Scalars['Char']['output']>;
  shortSecDesc?: Maybe<Scalars['String']['output']>;
  standardAgreement?: Maybe<Scalars['Char']['output']>;
  standardContract?: Maybe<Scalars['Char']['output']>;
  stdSettleDays?: Maybe<Scalars['Int']['output']>;
  strikePrice?: Maybe<Scalars['Float']['output']>;
  structure?: Maybe<Scalars['String']['output']>;
  taxStatus?: Maybe<Scalars['Char']['output']>;
  ticker?: Maybe<Scalars['String']['output']>;
  underlyingCusip?: Maybe<Scalars['String']['output']>;
  underlyingIssuerType?: Maybe<Scalars['Char']['output']>;
  underlyingNotionalFace?: Maybe<Scalars['Float']['output']>;
  underlyingSecDesc?: Maybe<Scalars['String']['output']>;
  units?: Maybe<Scalars['String']['output']>;
  wiFlag?: Maybe<Scalars['Char']['output']>;
};

export type BrokerAllocation = {
  __typename?: 'BrokerAllocation';
  assetID: Scalars['String']['output'];
  availablePlacementQuantity?: Maybe<Scalars['Float']['output']>;
  broker: Counterparty;
  /** availablePlacementQuantity -> totalOrdQty (ord.face) - bookedQty (sum(orderDetail.qty_booked)) - placedQty (placement.qty where status not in (COMPLETED, CACNCELLED)) */
  eligiblePlacementQuantity?: Maybe<Scalars['Float']['output']>;
  eligiblePlacementQuantityAsPct?: Maybe<Scalars['Float']['output']>;
  fxQuotes?: Maybe<Array<FxQuote>>;
  /**  eligiblePlacementQuantity * 100/ availablePlacementQuantity | eligiblePlacementQuantity <= availablePlacementQuantity */
  portfolioAllocations?: Maybe<Array<PortfolioAllocation>>;
};

export type BrokerDeskPairing = {
  broker: Scalars['String']['input'];
  subBrokerId: Scalars['Long']['input'];
};

export type Contact = {
  __typename?: 'Contact';
  city?: Maybe<Scalars['String']['output']>;
  code?: Maybe<Scalars['Int']['output']>;
  country?: Maybe<Scalars['String']['output']>;
  email?: Maybe<Scalars['String']['output']>;
  fax?: Maybe<Scalars['String']['output']>;
  firstName?: Maybe<Scalars['String']['output']>;
  ftp?: Maybe<Scalars['String']['output']>;
  lastName?: Maybe<Scalars['String']['output']>;
  organization?: Maybe<AccountInfo>;
  phone?: Maybe<Scalars['String']['output']>;
  printer?: Maybe<Scalars['String']['output']>;
  state?: Maybe<Scalars['String']['output']>;
  streetAddress?: Maybe<Scalars['String']['output']>;
  streetAddress2?: Maybe<Scalars['String']['output']>;
  title?: Maybe<Scalars['String']['output']>;
  webPassword?: Maybe<Scalars['String']['output']>;
  webType?: Maybe<Scalars['String']['output']>;
  zip?: Maybe<Scalars['String']['output']>;
};

export type Counterparty = {
  __typename?: 'Counterparty';
  brokerPortCode?: Maybe<Scalars['Int']['output']>;
  code: Scalars['Int']['output'];
  defaultDesk?: Maybe<Scalars['String']['output']>;
  desks?: Maybe<Array<Desk>>;
  encodeOnlyCode?: Maybe<Scalars['Boolean']['output']>;
  isDefunc?: Maybe<Scalars['Boolean']['output']>;
  issuerValue?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  org?: Maybe<Scalars['Int']['output']>;
  parentCode?: Maybe<Scalars['Int']['output']>;
  shortName?: Maybe<Scalars['String']['output']>;
  ticker?: Maybe<Scalars['String']['output']>;
  type?: Maybe<Scalars['String']['output']>;
  ultimateParent?: Maybe<Scalars['String']['output']>;
};

export type Desk = {
  __typename?: 'Desk';
  /**     selectBQL: BQLExpression @depracated */
  brokerCode?: Maybe<Scalars['Int']['output']>;
  brokerType?: Maybe<Scalars['String']['output']>;
  defunc?: Maybe<Scalars['Boolean']['output']>;
  entity?: Maybe<Scalars['Int']['output']>;
  globalID?: Maybe<Scalars['Long']['output']>;
  salesman?: Maybe<Scalars['String']['output']>;
  salesmanContact?: Maybe<Contact>;
  subBrokerCode?: Maybe<Scalars['Int']['output']>;
  subBrokerDTC?: Maybe<Scalars['Int']['output']>;
  subBrokerID?: Maybe<Scalars['Long']['output']>;
};

export type EntityMapping = {
  __typename?: 'EntityMapping';
  key: Scalars['String']['output'];
  value?: Maybe<Array<Scalars['String']['output']>>;
};

export type FiBasketSummary = {
  __typename?: 'FIBasketSummary';
  brokerAllocations: Array<Maybe<BrokerAllocation>>;
  order: Order;
  placements?: Maybe<Array<Placement>>;
};

export type FiConfig = {
  __typename?: 'FIConfig';
  alldesks?: Maybe<Array<Desk>>;
  brokerEntity?: Maybe<Array<EntityMapping>>;
  counteringEnabled?: Maybe<Array<Scalars['Int']['output']>>;
  delayedSpotEnabled?: Maybe<Array<Scalars['Int']['output']>>;
  listRFQEnabled?: Maybe<Array<Scalars['Int']['output']>>;
  mifidTagEnabled?: Maybe<Array<Scalars['Int']['output']>>;
  spreadFlowEnabled?: Maybe<Array<Scalars['Int']['output']>>;
  userMifidEligibility?: Maybe<Scalars['String']['output']>;
};

export type FiOrderListSummary = {
  __typename?: 'FIOrderListSummary';
  basketId?: Maybe<Scalars['String']['output']>;
  configurations?: Maybe<FiConfig>;
  fiOrderSummaries?: Maybe<Array<Maybe<FiOrderSummary>>>;
};

export type FiOrderSummary = {
  __typename?: 'FIOrderSummary';
  actionableCounteringEnabled?: Maybe<Array<Scalars['Int']['output']>>;
  brokerAllocations: Array<Maybe<BrokerAllocation>>;
  brokerEntity?: Maybe<Array<EntityMapping>>;
  configurations?: Maybe<FiConfig>;
  counteringEnabled?: Maybe<Array<Scalars['Int']['output']>>;
  delayedSpotEnabled?: Maybe<Array<Scalars['Int']['output']>>;
  directBrokers?: Maybe<Array<Scalars['Int']['output']>>;
  directListBrokers?: Maybe<Array<Scalars['Int']['output']>>;
  fiAsset?: Maybe<AssetObject>;
  mifidTagEnabled?: Maybe<Array<Scalars['Int']['output']>>;
  order: Order;
  orderDetails?: Maybe<Array<OrderDetail>>;
  placements?: Maybe<Array<Placement>>;
  spotTimes?: Maybe<Array<VenueSpotTime>>;
  spreadFlowEnabled?: Maybe<Array<Scalars['Int']['output']>>;
  userMifidEligibility?: Maybe<Scalars['String']['output']>;
  venueBrokers?: Maybe<Array<VenueBroker>>;
};

export type FxQuote = {
  __typename?: 'FXQuote';
  askSide?: Maybe<Quote>;
  bidSide?: Maybe<Quote>;
  counterparty?: Maybe<Counterparty>;
  currency?: Maybe<Scalars['String']['output']>;
  expTime?: Maybe<Scalars['BFMDateTime']['output']>;
  quoteId?: Maybe<Scalars['String']['output']>;
  status?: Maybe<Scalars['QuoteStatus']['output']>;
  symbol?: Maybe<Scalars['String']['output']>;
};

export type Fill = {
  __typename?: 'Fill';
  agency?: Maybe<Scalars['Int']['output']>;
  algo?: Maybe<Scalars['String']['output']>;
  allocationPlacementNum?: Maybe<Scalars['Long']['output']>;
  avgPrice?: Maybe<Scalars['Float']['output']>;
  /**     executionValidations: PlacementValidation */
  commissionRate?: Maybe<Scalars['Float']['output']>;
  commissionRateType?: Maybe<Scalars['String']['output']>;
  exchange?: Maybe<Scalars['String']['output']>;
  execPrice?: Maybe<Scalars['Float']['output']>;
  execQuantity?: Maybe<Scalars['Float']['output']>;
  execTime?: Maybe<Scalars['BFMDateTimeTZ']['output']>;
  execTimeSource?: Maybe<Scalars['ExecutionTimeSource']['output']>;
  externID?: Maybe<Scalars['String']['output']>;
  fillNum?: Maybe<Scalars['Float']['output']>;
  /**     placement: Placement */
  hasBeenTouched?: Maybe<Scalars['Boolean']['output']>;
  lastLiquidity?: Maybe<Scalars['Int']['output']>;
  modifiedBy?: Maybe<Scalars['String']['output']>;
  modifiedTime?: Maybe<Scalars['BFMDateTime']['output']>;
  netMoney?: Maybe<Scalars['Float']['output']>;
  placementNum?: Maybe<Scalars['Long']['output']>;
  previousFill?: Maybe<Fill>;
  quantityFilled?: Maybe<Scalars['Float']['output']>;
  requestID?: Maybe<Scalars['String']['output']>;
  tradeDate?: Maybe<Scalars['BFMDate']['output']>;
  version?: Maybe<Scalars['Int']['output']>;
};

export type GenericFieldEntry = {
  __typename?: 'GenericFieldEntry';
  key: Scalars['String']['output'];
  value?: Maybe<Scalars['String']['output']>;
};

export type MultiQuickPlaceRequest = {
  algo?: InputMaybe<Scalars['String']['input']>;
  algoParams?: InputMaybe<Array<InputMaybe<MultiQuickPlaceRequestAlgoParam>>>;
  allocationStrategy?: InputMaybe<Scalars['Strategy']['input']>;
  auto?: InputMaybe<Scalars['Boolean']['input']>;
  basketID?: InputMaybe<Scalars['String']['input']>;
  benchPrice?: InputMaybe<Scalars['Float']['input']>;
  broker?: InputMaybe<Scalars['String']['input']>;
  brokerReason?: InputMaybe<Scalars['String']['input']>;
  brokerSelectionStrategy?: InputMaybe<Scalars['String']['input']>;
  comment?: InputMaybe<Scalars['String']['input']>;
  externRefID?: InputMaybe<Scalars['String']['input']>;
  limitType?: InputMaybe<Scalars['String']['input']>;
  openDate?: InputMaybe<Scalars['String']['input']>;
  orderData?: InputMaybe<Array<InputMaybe<MultiQuickPlaceRequestOrderData>>>;
  percentToPlace?: InputMaybe<Scalars['Float']['input']>;
  route?: InputMaybe<Scalars['String']['input']>;
  routing?: InputMaybe<Scalars['String']['input']>;
  saveRestrictedAllocations?: InputMaybe<Scalars['Boolean']['input']>;
  settleDate?: InputMaybe<Scalars['BFMDate']['input']>;
  spotTime?: InputMaybe<Scalars['BFMDateTime']['input']>;
  spotType?: InputMaybe<Scalars['String']['input']>;
  spreadIndex?: InputMaybe<Scalars['String']['input']>;
  stopValue?: InputMaybe<Scalars['Float']['input']>;
  strategy?: InputMaybe<Scalars['String']['input']>;
  subBrokerID?: InputMaybe<Scalars['Long']['input']>;
  user?: InputMaybe<Scalars['String']['input']>;
};

export type MultiQuickPlaceRequestAlgoParam = {
  enabled?: InputMaybe<Scalars['Boolean']['input']>;
  isTimestamp?: InputMaybe<Scalars['Boolean']['input']>;
  name?: InputMaybe<Scalars['String']['input']>;
  parameter?: InputMaybe<Scalars['String']['input']>;
  sequence?: InputMaybe<Scalars['Int']['input']>;
  tag?: InputMaybe<Scalars['Int']['input']>;
  value?: InputMaybe<Scalars['String']['input']>;
  visible?: InputMaybe<Scalars['Boolean']['input']>;
};

export type MultiQuickPlaceRequestOrderData = {
  basePrice?: InputMaybe<Scalars['Float']['input']>;
  commissionRate?: InputMaybe<Scalars['Float']['input']>;
  commissionRateType?: InputMaybe<Scalars['String']['input']>;
  expDate?: InputMaybe<Scalars['BFMDate']['input']>;
  lastPrice?: InputMaybe<Scalars['Float']['input']>;
  limitValue?: InputMaybe<Scalars['Float']['input']>;
  ordType?: InputMaybe<Scalars['String']['input']>;
  orderNumber?: InputMaybe<Scalars['Int']['input']>;
  price?: InputMaybe<Scalars['Float']['input']>;
  quantity?: InputMaybe<Scalars['Float']['input']>;
  stopType?: InputMaybe<Scalars['OrderLimitType']['input']>;
  stopValue?: InputMaybe<Scalars['Float']['input']>;
  timeInForce?: InputMaybe<Scalars['OrderExpiryType']['input']>;
  volAvg30d?: InputMaybe<Scalars['Float']['input']>;
};

export type Mutation = {
  __typename?: 'Mutation';
  cancelErrorPlacements?: Maybe<Array<Placement>>;
  cancelRFQPlacements?: Maybe<Array<Placement>>;
  counterPlacementQuote?: Maybe<Array<OrderSummary>>;
  executePlacementQuote?: Maybe<Array<OrderSummary>>;
  multiQuickPlace?: Maybe<Array<Maybe<Placement>>>;
  passPlacementQuotes?: Maybe<Array<Placement>>;
  requestListPlacementQuotes?: Maybe<Array<OrderSummary>>;
  requestListPlacementQuotesAsync?: Maybe<Array<OrderSummary>>;
  requestPlacementQuote?: Maybe<Array<OrderSummary>>;
  sendPlacementColorSent?: Maybe<Array<Placement>>;
  subjectPlacementQuote?: Maybe<Array<Placement>>;
  validateListPlacementsCountering?: Maybe<Array<Maybe<ValidationIssue>>>;
  validatePlacements?: Maybe<Array<Maybe<Placement>>>;
  validatePlacementsCountering?: Maybe<Array<Maybe<Placement>>>;
  validatePlacementsExecution?: Maybe<Array<Maybe<Placement>>>;
};


export type MutationCancelErrorPlacementsArgs = {
  placementNumList?: InputMaybe<Array<Scalars['Int']['input']>>;
  user?: InputMaybe<Scalars['String']['input']>;
};


export type MutationCancelRfqPlacementsArgs = {
  placementNumList?: InputMaybe<Array<Scalars['Int']['input']>>;
  user?: InputMaybe<Scalars['String']['input']>;
};


export type MutationCounterPlacementQuoteArgs = {
  quotes?: InputMaybe<Array<InputMaybe<PlacementQuotes>>>;
  request: PlacementQuoteExecute;
  user?: InputMaybe<Scalars['String']['input']>;
};


export type MutationExecutePlacementQuoteArgs = {
  quotes?: InputMaybe<Array<InputMaybe<PlacementQuotes>>>;
  request: PlacementQuoteExecute;
  user?: InputMaybe<Scalars['String']['input']>;
};


export type MutationMultiQuickPlaceArgs = {
  request?: InputMaybe<MultiQuickPlaceRequest>;
  user?: InputMaybe<Scalars['String']['input']>;
};


export type MutationPassPlacementQuotesArgs = {
  placementNumList?: InputMaybe<Array<Scalars['Int']['input']>>;
  user?: InputMaybe<Scalars['String']['input']>;
};


export type MutationRequestListPlacementQuotesArgs = {
  requests?: InputMaybe<Array<PlacementQuoteRequest>>;
  user?: InputMaybe<Scalars['String']['input']>;
};


export type MutationRequestListPlacementQuotesAsyncArgs = {
  basketId?: InputMaybe<Scalars['String']['input']>;
  requests?: InputMaybe<Array<PlacementQuoteRequest>>;
  user?: InputMaybe<Scalars['String']['input']>;
};


export type MutationRequestPlacementQuoteArgs = {
  request: PlacementQuoteRequest;
  user?: InputMaybe<Scalars['String']['input']>;
};


export type MutationSendPlacementColorSentArgs = {
  isDNT?: InputMaybe<Scalars['Boolean']['input']>;
  placementNumList?: InputMaybe<Array<Scalars['Int']['input']>>;
  user?: InputMaybe<Scalars['String']['input']>;
};


export type MutationSubjectPlacementQuoteArgs = {
  placementNumList?: InputMaybe<Array<Scalars['Int']['input']>>;
  user?: InputMaybe<Scalars['String']['input']>;
};


export type MutationValidateListPlacementsCounteringArgs = {
  request?: InputMaybe<Array<PlacementQuoteRequest>>;
  user?: InputMaybe<Scalars['String']['input']>;
  warnings?: InputMaybe<Scalars['String']['input']>;
};


export type MutationValidatePlacementsArgs = {
  request?: InputMaybe<MultiQuickPlaceRequest>;
  user?: InputMaybe<Scalars['String']['input']>;
  warnings?: InputMaybe<Scalars['String']['input']>;
};


export type MutationValidatePlacementsCounteringArgs = {
  request: PlacementQuoteRequest;
  user?: InputMaybe<Scalars['String']['input']>;
  warnings?: InputMaybe<Scalars['String']['input']>;
};


export type MutationValidatePlacementsExecutionArgs = {
  request: PlacementQuoteExecute;
  user?: InputMaybe<Scalars['String']['input']>;
  warnings?: InputMaybe<Scalars['String']['input']>;
};

export type Nav = {
  __typename?: 'Nav';
  navDate?: Maybe<Scalars['BFMDate']['output']>;
  navType?: Maybe<Scalars['String']['output']>;
  navValue?: Maybe<Scalars['Float']['output']>;
  portfolioCode?: Maybe<Scalars['Int']['output']>;
};

export type Order = {
  __typename?: 'Order';
  activeAmt?: Maybe<Scalars['Float']['output']>;
  activeFillAmt?: Maybe<Scalars['Float']['output']>;
  /**  Order activiation time */
  activeTime?: Maybe<Scalars['BFMDate']['output']>;
  assignToRule?: Maybe<Scalars['String']['output']>;
  /**  Order assigned to initials */
  assignedTo?: Maybe<Scalars['String']['output']>;
  /**  Assigned to status set to either "Hold" or "Do not Trade" */
  assignedToStatus?: Maybe<Scalars['AssignedToStatus']['output']>;
  /**  Authorized Timestamp */
  authTime?: Maybe<Scalars['BFMDate']['output']>;
  /**  Average price for order */
  avgPrice?: Maybe<Scalars['Float']['output']>;
  brokerCode?: Maybe<Scalars['Int']['output']>;
  /**  Convexity of the security at the time of trade. */
  convexity?: Maybe<Scalars['Float']['output']>;
  /**  Aladdin user name of the user who created this record */
  createdBy?: Maybe<Scalars['String']['output']>;
  /**  Security associated with the order */
  cusip?: Maybe<Scalars['String']['output']>;
  /**  Directed broker account for order */
  dirBrokerAcct?: Maybe<Scalars['String']['output']>;
  /**  Duration of the security */
  duration?: Maybe<Scalars['Float']['output']>;
  effectiveTranType?: Maybe<Scalars['String']['output']>;
  entryTime?: Maybe<Scalars['BFMDate']['output']>;
  /**  Execution instructions on order */
  execInst?: Maybe<Scalars['String']['output']>;
  executionType?: Maybe<Scalars['Char']['output']>;
  /**  Expiration date of order. */
  expDate?: Maybe<Scalars['BFMDate']['output']>;
  /**  Expiration type of order. Please refer to Aladdin Decode 'TIME_IN_FORCE' to get the list of valid values. */
  expiryType?: Maybe<Scalars['OrderExpiryType']['output']>;
  face?: Maybe<Scalars['Float']['output']>;
  /**  Factor to calculate the remaining unpaid amount for mortgage pools, ABS, or other amortizing securities, or the factor for TIPS securities. For securities that have no such factor, Aladdin by convention may assign a factor of 1 */
  factor?: Maybe<Scalars['Float']['output']>;
  factorDate?: Maybe<Scalars['BFMDate']['output']>;
  fillAmt?: Maybe<Scalars['Float']['output']>;
  fillTime?: Maybe<Scalars['BFMDate']['output']>;
  filledBy?: Maybe<Scalars['String']['output']>;
  /**  Total accrued interest on the transaction in the settle_ccy. Incoming money is negative, and outgoing money is positive. Note: There is no net money field; instead, net money = principal + interest + commission + fees */
  interest?: Maybe<Scalars['Float']['output']>;
  /**  Limit type of the order. Please refer to Aladdin Decode 'ORD_LIMIT_TYPE' to get the list of valid values. */
  limitType?: Maybe<Scalars['OrderLimitType']['output']>;
  /**  Order limit value */
  limitValue?: Maybe<Scalars['Float']['output']>;
  mergedInto?: Maybe<Scalars['Int']['output']>;
  /**  Login ID of the person or program that last modified this record. */
  modifiedBy?: Maybe<Scalars['String']['output']>;
  /**  Date and time when this record was modified */
  modifyTime?: Maybe<Scalars['BFMDate']['output']>;
  netMoney?: Maybe<Scalars['Float']['output']>;
  /**  Open date for the order */
  openDate?: Maybe<Scalars['BFMDate']['output']>;
  /**  Basket id associated with this order */
  ordGroup?: Maybe<Scalars['String']['output']>;
  /**  On an order, this is Aladdin's unique ID for the order. On a related transaction (e.g. placement, trade, capital flow), this is the order which is related to that transaction */
  ordNum: Scalars['Int']['output'];
  /**  Order type, e.g. M for Market, L = Limit, I = Funari, B = Limit on Close, 5 = Market on Close, X = Stop Limit, S = Stop. Full list in ORDER_TYPES decode The complete list of valid values can be found in the ORDER_TYPES decode. */
  ordType?: Maybe<OrderType>;
  orderFlags?: Maybe<Scalars['OrderFlags']['output']>;
  orderLeaves?: Maybe<Scalars['Float']['output']>;
  orderMarketNotional?: Maybe<Scalars['Float']['output']>;
  orderReason?: Maybe<Scalars['String']['output']>;
  /**  Order owner type */
  ownerType?: Maybe<Scalars['OwnerType']['output']>;
  /**  PM initials associated with the order */
  pm?: Maybe<Scalars['String']['output']>;
  /**  Market price of the security in the security local currency */
  price?: Maybe<Scalars['Float']['output']>;
  /**  Currency associated with the price */
  priceCurrency?: Maybe<Scalars['String']['output']>;
  /**  Principal money on the trade in the settle_ccy. Incoming money is negative, and outgoing is positive. e.g. sell 100 shares at $40/sh is -4000 principal. Note: There is no net money field; instead, net money = principal + interest + commission + fees */
  principal?: Maybe<Scalars['Float']['output']>;
  refCusip?: Maybe<Scalars['String']['output']>;
  refHaircut?: Maybe<Scalars['Float']['output']>;
  refPrice?: Maybe<Scalars['Float']['output']>;
  /**  Contractual settlement date */
  settleDate?: Maybe<Scalars['BFMDate']['output']>;
  /**  Settlement date offset when relative settle date is enabled */
  settleDateOffset?: Maybe<Scalars['Int']['output']>;
  /**  Order soft dollar */
  softDollar?: Maybe<Scalars['String']['output']>;
  source?: Maybe<Scalars['String']['output']>;
  splitFrom?: Maybe<Scalars['Int']['output']>;
  /**  Aladdin order status */
  status?: Maybe<Scalars['OrderStatus']['output']>;
  /**  Limit stop type of the order. Please refer to Aladdin Decode 'ORD_LIMIT_TYPE' to get the list of valid values. */
  stopType?: Maybe<Scalars['OrderLimitType']['output']>;
  /**  Stop value of order */
  stopValue?: Maybe<Scalars['Float']['output']>;
  /**  Number of times this record has been touched. */
  touchCount?: Maybe<Scalars['Int']['output']>;
  /**  Trade date */
  tradeDate?: Maybe<Scalars['BFMDate']['output']>;
  /**  Trader initials associated with the order */
  trader?: Maybe<Scalars['String']['output']>;
  traderLabel?: Maybe<Scalars['String']['output']>;
  /**  Order trading benchmark */
  tradingBenchmark?: Maybe<Scalars['String']['output']>;
  /**  Order trading benchmark date. */
  tradingBenchmarkDate?: Maybe<Scalars['BFMDate']['output']>;
  /**  Order trading benchmark price */
  tradingBenchmarkPrice?: Maybe<Scalars['Float']['output']>;
  /**  Transaction type of the order. Please refer to Aladdin Decode 'ORDERTRANTYPES' to get the list of valid values. */
  tranType?: Maybe<Scalars['OrderTranType']['output']>;
  /**  Unit type of order; e.g., V for Value. Refer to ORD_UNITFLG_TYP decode. */
  unitFlag?: Maybe<Scalars['String']['output']>;
  updateInstr?: Maybe<Scalars['String']['output']>;
  /**  Urgency of execution as defined in DECODE ORD_URGENCY */
  urgency?: Maybe<Scalars['OrderUrgency']['output']>;
  /**  Order version number */
  version: Scalars['Int']['output'];
  /**  Yield */
  yield?: Maybe<Scalars['Float']['output']>;
};

export type OrderDetail = {
  __typename?: 'OrderDetail';
  centralClearingParty?: Maybe<Scalars['Int']['output']>;
  fund: Scalars['Int']['output'];
  /**  Login ID of the person or program that last modified this record. */
  modifiedBy?: Maybe<Scalars['String']['output']>;
  /**  Date and time when this record was modified */
  modifiedTime?: Maybe<Scalars['BFMDate']['output']>;
  ordDetailId: Scalars['Int']['output'];
  /**    orderReservations: [OrderReservation] */
  orderReservationLoaded?: Maybe<Scalars['Boolean']['output']>;
  origOrdDetailId?: Maybe<Scalars['Int']['output']>;
  origOrdNum?: Maybe<Scalars['Int']['output']>;
  /**  PM initials associated with the order */
  pm?: Maybe<Scalars['String']['output']>;
  portfolio?: Maybe<Portfolio>;
  quantity: Scalars['Float']['output'];
  quantityBooked?: Maybe<Scalars['Float']['output']>;
  refFace?: Maybe<Scalars['Float']['output']>;
  refFillAmt?: Maybe<Scalars['Float']['output']>;
  requestStatus?: Maybe<Scalars['AssignedToStatus']['output']>;
  strategyId?: Maybe<Scalars['Int']['output']>;
  /**  Trader initials associated with the order */
  trader?: Maybe<Scalars['String']['output']>;
  version: Scalars['Int']['output'];
};

export type OrderSummary = {
  __typename?: 'OrderSummary';
  asset?: Maybe<BAsset>;
  /**     snapshots: [PriceSnapshot] */
  brokerAllocations: Array<Maybe<BrokerAllocation>>;
  crossable?: Maybe<Scalars['Boolean']['output']>;
  encodeAsset?: Maybe<Scalars['Boolean']['output']>;
  ioiId?: Maybe<Scalars['String']['output']>;
  mergeable?: Maybe<Scalars['Boolean']['output']>;
  order: Order;
  orderDetails?: Maybe<Array<OrderDetail>>;
  placements?: Maybe<Array<Placement>>;
  /**
   * externalOrder: ExternalOrder
   * orderRels: [OrderRels]
   */
  uniqueId?: Maybe<Scalars['Int']['output']>;
};

export type OrderType = {
  __typename?: 'OrderType';
  basic?: Maybe<Scalars['Boolean']['output']>;
  charValue?: Maybe<Scalars['String']['output']>;
  decodedValue?: Maybe<Scalars['String']['output']>;
  limit?: Maybe<Scalars['Boolean']['output']>;
  stop?: Maybe<Scalars['Boolean']['output']>;
  type?: Maybe<Scalars['String']['output']>;
  valid?: Maybe<Scalars['Boolean']['output']>;
  value?: Maybe<Scalars['String']['output']>;
};

export type Placement = {
  __typename?: 'Placement';
  agency?: Maybe<Scalars['Char']['output']>;
  algo?: Maybe<Scalars['String']['output']>;
  allocations?: Maybe<Array<Maybe<PlacementDetail>>>;
  /**     summary: OrderSummary @depracated */
  asset?: Maybe<BAsset>;
  auto?: Maybe<Scalars['Boolean']['output']>;
  autoRule?: Maybe<Scalars['String']['output']>;
  avgPrice?: Maybe<Scalars['Float']['output']>;
  axeID?: Maybe<Scalars['String']['output']>;
  basketID?: Maybe<Scalars['String']['output']>;
  benchmark?: Maybe<BAsset>;
  broker?: Maybe<Counterparty>;
  brokerAccount?: Maybe<Scalars['String']['output']>;
  brokerNote?: Maybe<Scalars['String']['output']>;
  brokerReason?: Maybe<Scalars['String']['output']>;
  children?: Maybe<Array<Maybe<PlacementRel>>>;
  comment?: Maybe<Scalars['String']['output']>;
  commissionRate?: Maybe<Scalars['Float']['output']>;
  commissionRateType?: Maybe<Scalars['String']['output']>;
  commissionScheduleId?: Maybe<Scalars['Float']['output']>;
  createTime?: Maybe<Scalars['BFMDateTime']['output']>;
  currency?: Maybe<Scalars['String']['output']>;
  cusip?: Maybe<Scalars['String']['output']>;
  desk?: Maybe<Desk>;
  directedExchange?: Maybe<Scalars['String']['output']>;
  discretionInst?: Maybe<Scalars['String']['output']>;
  discretionOffset?: Maybe<Scalars['Float']['output']>;
  dueInTime?: Maybe<Scalars['BFMDateTime']['output']>;
  effectiveTime?: Maybe<Scalars['BFMDateTime']['output']>;
  endTime?: Maybe<Scalars['BFMDateTime']['output']>;
  endTimeSource?: Maybe<Scalars['ExecutionTimeSource']['output']>;
  execInst?: Maybe<Scalars['OrderExecInst']['output']>;
  executedExchange?: Maybe<Scalars['String']['output']>;
  /**     calculator: PlacementCalculator @depracated */
  executionTime?: Maybe<Scalars['Int']['output']>;
  executionValidations?: Maybe<Array<Maybe<PlacementValidation>>>;
  expDate?: Maybe<Scalars['BFMDate']['output']>;
  externID?: Maybe<Scalars['String']['output']>;
  externRefID?: Maybe<Scalars['String']['output']>;
  /**     algoParams: [PlacementAlgoParam] @depracated */
  fills?: Maybe<Array<Maybe<Fill>>>;
  handlingInst?: Maybe<Scalars['String']['output']>;
  inquiryType?: Maybe<Scalars['Int']['output']>;
  isEstimatedFill?: Maybe<Scalars['Boolean']['output']>;
  limitType?: Maybe<Scalars['OrderLimitType']['output']>;
  limitValue?: Maybe<Scalars['Float']['output']>;
  maxFloor?: Maybe<Scalars['Float']['output']>;
  minQuantity?: Maybe<Scalars['Float']['output']>;
  modifiedBy?: Maybe<Scalars['String']['output']>;
  modifiedTime?: Maybe<Scalars['BFMDateTime']['output']>;
  modifyReason?: Maybe<Scalars['ExternCommand']['output']>;
  openDate?: Maybe<Scalars['BFMDate']['output']>;
  ordNum?: Maybe<Scalars['Int']['output']>;
  ordType?: Maybe<OrderType>;
  orderReservationSource?: Maybe<Scalars['Int']['output']>;
  /**     contractAsset: BAsset @depracated */
  parents?: Maybe<Array<Maybe<PlacementRel>>>;
  pegDifference?: Maybe<Scalars['Float']['output']>;
  placementAxe?: Maybe<Axe>;
  placementGenFields?: Maybe<Array<Maybe<GenericFieldEntry>>>;
  placementNum: Scalars['Long']['output'];
  placementValidations?: Maybe<Array<Maybe<PlacementValidation>>>;
  price?: Maybe<Scalars['Float']['output']>;
  priceDate?: Maybe<Scalars['BFMDate']['output']>;
  principal?: Maybe<Scalars['Float']['output']>;
  quantity?: Maybe<Scalars['Float']['output']>;
  quantityAllocated?: Maybe<Scalars['Float']['output']>;
  quantityByChildren?: Maybe<Scalars['Float']['output']>;
  quantityFilled?: Maybe<Scalars['Float']['output']>;
  quantityFilledByChildren?: Maybe<Scalars['Float']['output']>;
  quotes?: Maybe<Array<Maybe<Quote>>>;
  rate?: Maybe<Scalars['Float']['output']>;
  rawAvgPrice?: Maybe<Scalars['Float']['output']>;
  requestId?: Maybe<Scalars['String']['output']>;
  rfqType?: Maybe<Scalars['RFQType']['output']>;
  sendTime?: Maybe<Scalars['BFMDateTime']['output']>;
  setUSI?: Maybe<Scalars['String']['output']>;
  settleDate?: Maybe<Scalars['BFMDate']['output']>;
  settleDateOffset?: Maybe<Scalars['Int']['output']>;
  settleExchangeRate?: Maybe<Scalars['Float']['output']>;
  showTradeSide?: Maybe<Scalars['Boolean']['output']>;
  spotTime?: Maybe<Scalars['BFMDateTime']['output']>;
  spread?: Maybe<Scalars['Float']['output']>;
  spreadIndex?: Maybe<Scalars['String']['output']>;
  status?: Maybe<Scalars['PlacementStatus']['output']>;
  stopType?: Maybe<Scalars['OrderLimitType']['output']>;
  stopValue?: Maybe<Scalars['Float']['output']>;
  timeInForce?: Maybe<Scalars['OrderExpiryType']['output']>;
  touchCount?: Maybe<Scalars['Int']['output']>;
  tradeDate?: Maybe<Scalars['BFMDate']['output']>;
  trader?: Maybe<Scalars['String']['output']>;
  traderLEI?: Maybe<Scalars['String']['output']>;
  tranType?: Maybe<Scalars['OrderTranType']['output']>;
  type?: Maybe<Scalars['PlacementType']['output']>;
  /**     attributes: Attributes @depracated */
  unitFlag?: Maybe<Scalars['OrderUnitFlagType']['output']>;
  validationsLoaded?: Maybe<Scalars['Boolean']['output']>;
  venue?: Maybe<AccountInfo>;
  version?: Maybe<Scalars['Int']['output']>;
};

export type PlacementAlgoParam = {
  __typename?: 'PlacementAlgoParam';
  placement?: Maybe<Placement>;
  sequence?: Maybe<Scalars['Int']['output']>;
  tag?: Maybe<Scalars['Int']['output']>;
  value?: Maybe<Scalars['String']['output']>;
};

export type PlacementDetail = {
  __typename?: 'PlacementDetail';
  fund?: Maybe<Scalars['Int']['output']>;
  placementDetailID: Scalars['Long']['output'];
  quantity?: Maybe<Scalars['Float']['output']>;
  quantityAllocated?: Maybe<Scalars['Float']['output']>;
  quantityFilled?: Maybe<Scalars['Float']['output']>;
  quantityProposed?: Maybe<Scalars['Float']['output']>;
  strategyID?: Maybe<Scalars['Int']['output']>;
  version?: Maybe<Scalars['Int']['output']>;
};

export type PlacementQuoteExecute = {
  askPrice: Scalars['Float']['input'];
  bidPrice: Scalars['Float']['input'];
  counterparty: Scalars['String']['input'];
  dueInTime?: InputMaybe<Scalars['BFMDateTime']['input']>;
  externId: Scalars['String']['input'];
  lastPrice?: InputMaybe<Scalars['Float']['input']>;
  placementNum: Scalars['Int']['input'];
  quantity: Scalars['Float']['input'];
};

export type PlacementQuoteRequest = {
  axeID?: InputMaybe<Scalars['String']['input']>;
  axeLevel?: InputMaybe<Scalars['Float']['input']>;
  axeQty?: InputMaybe<Scalars['Int']['input']>;
  benchPrice?: InputMaybe<Scalars['Float']['input']>;
  brokers?: InputMaybe<Array<BrokerDeskPairing>>;
  dueInTime?: InputMaybe<Scalars['BFMDateTime']['input']>;
  externRefID?: InputMaybe<Scalars['String']['input']>;
  isBin?: InputMaybe<Scalars['Boolean']['input']>;
  lastPrice?: InputMaybe<Scalars['Float']['input']>;
  limitType?: InputMaybe<Scalars['String']['input']>;
  limitValue?: InputMaybe<Scalars['Float']['input']>;
  linkedOrdNum?: InputMaybe<Scalars['Int']['input']>;
  ordNum: Scalars['Int']['input'];
  placementAllocationStrategy: AllocationStrategy;
  settleDate?: InputMaybe<Scalars['BFMDate']['input']>;
  spotTime?: InputMaybe<Scalars['BFMDateTime']['input']>;
  spotType?: InputMaybe<Scalars['String']['input']>;
  spreadIndex?: InputMaybe<Scalars['String']['input']>;
  venueBrokers?: InputMaybe<Array<VenueBrokerInput>>;
};

export type PlacementQuotes = {
  broker: Scalars['String']['input'];
  price?: InputMaybe<Scalars['Float']['input']>;
  quantity?: InputMaybe<Scalars['Long']['input']>;
  quoteID?: InputMaybe<Scalars['String']['input']>;
};

export type PlacementRel = {
  __typename?: 'PlacementRel';
  child?: Maybe<Placement>;
  parent?: Maybe<Placement>;
  type?: Maybe<Scalars['Type']['output']>;
};

/**  This should be a com.bfm.order.placement.MultiQuickPlaceRequest */
export type PlacementRequest = {
  algo?: InputMaybe<Scalars['String']['input']>;
  algoParams?: InputMaybe<Array<InputMaybe<PlacementRequestAlgoParam>>>;
  /**
   * route: String
   * brokerSelectionStrategy: String
   */
  allocationStrategy?: InputMaybe<Scalars['String']['input']>;
  basePrice?: InputMaybe<Scalars['Float']['input']>;
  basketId?: InputMaybe<Scalars['String']['input']>;
  brokerCode?: InputMaybe<Scalars['String']['input']>;
  brokerReason?: InputMaybe<Scalars['String']['input']>;
  comment?: InputMaybe<Scalars['String']['input']>;
  commissionRate?: InputMaybe<Scalars['Float']['input']>;
  commissionRateType?: InputMaybe<Scalars['String']['input']>;
  expDate?: InputMaybe<Scalars['BFMDate']['input']>;
  externRefID?: InputMaybe<Scalars['String']['input']>;
  lastPrice?: InputMaybe<Scalars['Float']['input']>;
  limitType?: InputMaybe<Scalars['String']['input']>;
  limitValue?: InputMaybe<Scalars['Float']['input']>;
  modifiedBy?: InputMaybe<Scalars['String']['input']>;
  notional?: InputMaybe<Scalars['Float']['input']>;
  ordNum?: InputMaybe<Scalars['Int']['input']>;
  ordType?: InputMaybe<Scalars['String']['input']>;
  percentToPlace?: InputMaybe<Scalars['Float']['input']>;
  price?: InputMaybe<Scalars['Float']['input']>;
  quantity?: InputMaybe<Scalars['Float']['input']>;
  sendToFix?: InputMaybe<Scalars['Boolean']['input']>;
  stopType?: InputMaybe<Scalars['OrderLimitType']['input']>;
  stopValue?: InputMaybe<Scalars['Float']['input']>;
  subBrokerId?: InputMaybe<Scalars['Long']['input']>;
  timeInForce?: InputMaybe<Scalars['String']['input']>;
  volAvg30d?: InputMaybe<Scalars['Float']['input']>;
};

export type PlacementRequestAlgoParam = {
  enabled?: InputMaybe<Scalars['Boolean']['input']>;
  isTimestamp?: InputMaybe<Scalars['Boolean']['input']>;
  name?: InputMaybe<Scalars['String']['input']>;
  parameter?: InputMaybe<Scalars['String']['input']>;
  sequence?: InputMaybe<Scalars['Int']['input']>;
  tag?: InputMaybe<Scalars['Int']['input']>;
  value?: InputMaybe<Scalars['String']['input']>;
  visible?: InputMaybe<Scalars['Boolean']['input']>;
};

export type PlacementValidation = {
  __typename?: 'PlacementValidation';
  fillNums?: Maybe<Array<Maybe<Scalars['Long']['output']>>>;
  severityType?: Maybe<Scalars['ValidationSeverityType']['output']>;
  type?: Maybe<Scalars['String']['output']>;
  validationDate?: Maybe<Scalars['BFMDate']['output']>;
  validationID?: Maybe<ValidationId>;
  validationState?: Maybe<Scalars['ValidationState']['output']>;
  violation?: Maybe<Scalars['String']['output']>;
};

export type Portfolio = {
  __typename?: 'Portfolio';
  alphaStartDate?: Maybe<Scalars['BFMDate']['output']>;
  /**
   * externalAccounts: [ExternalAccount!]
   * assignment: Assignment
   */
  asset?: Maybe<BAsset>;
  benchmarkName?: Maybe<Scalars['String']['output']>;
  commodityPoolOperator?: Maybe<Scalars['String']['output']>;
  contractId?: Maybe<Scalars['Int']['output']>;
  country?: Maybe<Scalars['String']['output']>;
  currency?: Maybe<Scalars['String']['output']>;
  cusip?: Maybe<Scalars['String']['output']>;
  discretionary?: Maybe<Scalars['Char']['output']>;
  durationType?: Maybe<Scalars['String']['output']>;
  fullName?: Maybe<Scalars['String']['output']>;
  fundingType?: Maybe<Scalars['String']['output']>;
  inceptionDate?: Maybe<Scalars['BFMDate']['output']>;
  indexReturnType?: Maybe<Scalars['String']['output']>;
  investmentAdvisor?: Maybe<Scalars['String']['output']>;
  legalName?: Maybe<Scalars['String']['output']>;
  legalStructure?: Maybe<Scalars['String']['output']>;
  mgmtStyle?: Maybe<Scalars['String']['output']>;
  nav?: Maybe<Nav>;
  packageOrder?: Maybe<Scalars['String']['output']>;
  pme?: Maybe<Scalars['String']['output']>;
  portSource?: Maybe<Scalars['String']['output']>;
  /**
   * portfolioGroups: [PortfolioGroup!]
   * portFlags: [PortFlag!]
   */
  portfolioAccounting?: Maybe<PortfolioAccounting>;
  portfolioCode?: Maybe<Scalars['Int']['output']>;
  portfolioJoin?: Maybe<Scalars['String']['output']>;
  portfolioName?: Maybe<Scalars['String']['output']>;
  portfolioType?: Maybe<Scalars['String']['output']>;
  regDomicile?: Maybe<Scalars['String']['output']>;
  regulatoryStructure?: Maybe<Scalars['String']['output']>;
  /**     portRels: [PortRels!] */
  source?: Maybe<Scalars['String']['output']>;
  status?: Maybe<Scalars['String']['output']>;
  terminationDate?: Maybe<Scalars['BFMDate']['output']>;
  tradingDate?: Maybe<Scalars['BFMDate']['output']>;
  underwriter?: Maybe<Scalars['String']['output']>;
};

export type PortfolioAccounting = {
  __typename?: 'PortfolioAccounting';
  clientLot?: Maybe<Scalars['String']['output']>;
  custodianInvestorType?: Maybe<Scalars['String']['output']>;
  glConstraint?: Maybe<Scalars['Char']['output']>;
  portfolioCode?: Maybe<Scalars['Int']['output']>;
  primaryNAVSource?: Maybe<Scalars['String']['output']>;
  secondaryNAVSource?: Maybe<Scalars['String']['output']>;
};

export type PortfolioAllocation = {
  __typename?: 'PortfolioAllocation';
  portfolioCode: Scalars['Int']['output'];
  quantityAvailable: Scalars['Float']['output'];
  strategyID?: Maybe<Scalars['Int']['output']>;
};

export type Price = {
  __typename?: 'Price';
  allInRate?: Maybe<Scalars['Float']['output']>;
  ask?: Maybe<Scalars['Float']['output']>;
  askSize?: Maybe<Scalars['Float']['output']>;
  askSpread?: Maybe<Scalars['Float']['output']>;
  askYield?: Maybe<Scalars['Float']['output']>;
  bid?: Maybe<Scalars['Float']['output']>;
  bidSize?: Maybe<Scalars['Float']['output']>;
  bidSpread?: Maybe<Scalars['Float']['output']>;
  bidYield?: Maybe<Scalars['Float']['output']>;
  brokerCode?: Maybe<Scalars['Int']['output']>;
  close?: Maybe<Scalars['Float']['output']>;
  convexity?: Maybe<Scalars['Float']['output']>;
  currency?: Maybe<Scalars['String']['output']>;
  cusip?: Maybe<Scalars['String']['output']>;
  dirtyPrice?: Maybe<Scalars['Boolean']['output']>;
  discountMidPrice?: Maybe<Scalars['Float']['output']>;
  duration?: Maybe<Scalars['Float']['output']>;
  estimatedQuantity?: Maybe<Scalars['Float']['output']>;
  forwardPoints?: Maybe<Scalars['Float']['output']>;
  high?: Maybe<Scalars['Float']['output']>;
  high1y?: Maybe<Scalars['Float']['output']>;
  indexName?: Maybe<Scalars['String']['output']>;
  indexSpread?: Maybe<Scalars['Float']['output']>;
  lastPrice?: Maybe<Scalars['Float']['output']>;
  low?: Maybe<Scalars['Float']['output']>;
  low1y?: Maybe<Scalars['Float']['output']>;
  markDate?: Maybe<Scalars['BFMDate']['output']>;
  mid?: Maybe<Scalars['Float']['output']>;
  open?: Maybe<Scalars['Float']['output']>;
  origSource?: Maybe<Scalars['String']['output']>;
  price?: Maybe<Scalars['Float']['output']>;
  purpose?: Maybe<Scalars['String']['output']>;
  quantity?: Maybe<Scalars['Float']['output']>;
  quoteType?: Maybe<Scalars['String']['output']>;
  sharesOutstanding?: Maybe<Scalars['Float']['output']>;
  source?: Maybe<Scalars['String']['output']>;
  splitIndex?: Maybe<Scalars['Float']['output']>;
  spread?: Maybe<Scalars['Float']['output']>;
  timestamp?: Maybe<Scalars['BFMTimestamp']['output']>;
  totalMarketCap?: Maybe<Scalars['Float']['output']>;
  valid?: Maybe<Scalars['Boolean']['output']>;
  valueDate?: Maybe<Scalars['String']['output']>;
  volAvg10d?: Maybe<Scalars['Float']['output']>;
  volAvg30d?: Maybe<Scalars['Float']['output']>;
  volAvg90d?: Maybe<Scalars['Float']['output']>;
  volume?: Maybe<Scalars['Float']['output']>;
  vwap?: Maybe<Scalars['Float']['output']>;
  yield?: Maybe<Scalars['Float']['output']>;
};

export type PriceSnapshot = {
  __typename?: 'PriceSnapshot';
  price?: Maybe<Scalars['Float']['output']>;
  source?: Maybe<Scalars['String']['output']>;
  timestamp?: Maybe<Scalars['BFMTimestamp']['output']>;
  type?: Maybe<Scalars['String']['output']>;
  user?: Maybe<Scalars['String']['output']>;
  volume?: Maybe<Scalars['Float']['output']>;
  vwap?: Maybe<Scalars['Float']['output']>;
};

export type Query = {
  __typename?: 'Query';
  fiAsset: AssetObject;
  fiAssetList?: Maybe<Array<AssetObject>>;
  fiBasketSummary: FiBasketSummary;
  fiOrderListSummary: FiOrderListSummary;
  fiOrderSummary: FiOrderSummary;
  generateBasketIDForOrders?: Maybe<Scalars['String']['output']>;
  getPlacementsByPlacementNums?: Maybe<Array<Placement>>;
  prices?: Maybe<Array<Price>>;
};


export type QueryFiAssetArgs = {
  secId?: InputMaybe<Scalars['String']['input']>;
};


export type QueryFiAssetListArgs = {
  secIds?: InputMaybe<Array<Scalars['String']['input']>>;
};


export type QueryFiBasketSummaryArgs = {
  basketId?: InputMaybe<Scalars['String']['input']>;
  user?: InputMaybe<Scalars['String']['input']>;
};


export type QueryFiOrderListSummaryArgs = {
  ordNumList?: InputMaybe<Array<InputMaybe<Scalars['Int']['input']>>>;
  rfqExecution?: InputMaybe<Scalars['Boolean']['input']>;
  user?: InputMaybe<Scalars['String']['input']>;
};


export type QueryFiOrderSummaryArgs = {
  a2a?: InputMaybe<Scalars['Boolean']['input']>;
  brokerList?: InputMaybe<Array<InputMaybe<Scalars['Int']['input']>>>;
  care?: InputMaybe<Scalars['Boolean']['input']>;
  ltx?: InputMaybe<Scalars['Boolean']['input']>;
  ordNum?: InputMaybe<Scalars['Int']['input']>;
  rfqExecution?: InputMaybe<Scalars['Boolean']['input']>;
  user?: InputMaybe<Scalars['String']['input']>;
};


export type QueryGenerateBasketIdForOrdersArgs = {
  ordNum: Scalars['Int']['input'];
};


export type QueryGetPlacementsByPlacementNumsArgs = {
  placementNumList?: InputMaybe<Array<Scalars['Long']['input']>>;
  user?: InputMaybe<Scalars['String']['input']>;
};


export type QueryPricesArgs = {
  cusips?: InputMaybe<Array<Scalars['String']['input']>>;
  startInclusive?: InputMaybe<Scalars['BFMTimestamp']['input']>;
};

export type Quote = {
  __typename?: 'Quote';
  counterparty?: Maybe<Counterparty>;
  expTime?: Maybe<Scalars['BFMDateTime']['output']>;
  externID?: Maybe<Scalars['String']['output']>;
  placement?: Maybe<Placement>;
  price?: Maybe<Scalars['Float']['output']>;
  quantity?: Maybe<Scalars['Float']['output']>;
  quoteID?: Maybe<Scalars['String']['output']>;
  quoteStatus?: Maybe<Scalars['QuoteStatus']['output']>;
  rate?: Maybe<Scalars['Float']['output']>;
  requestID?: Maybe<Scalars['String']['output']>;
  side?: Maybe<Scalars['Side']['output']>;
  spread?: Maybe<Scalars['Float']['output']>;
  type?: Maybe<Scalars['QuoteType']['output']>;
  underlyingExchangeRate?: Maybe<Scalars['Float']['output']>;
  volatility?: Maybe<Scalars['Float']['output']>;
};

export type SpotTimePair = {
  __typename?: 'SpotTimePair';
  code?: Maybe<Scalars['String']['output']>;
  displayName?: Maybe<Scalars['String']['output']>;
};

export type ValidationId = {
  __typename?: 'ValidationID';
  id?: Maybe<Scalars['Long']['output']>;
  touchCount?: Maybe<Scalars['Int']['output']>;
  validationKey?: Maybe<Scalars['String']['output']>;
  validationType?: Maybe<Scalars['ValidationType']['output']>;
};

export type ValidationIssue = {
  __typename?: 'ValidationIssue';
  message?: Maybe<Scalars['String']['output']>;
};

export type VenueBroker = {
  __typename?: 'VenueBroker';
  brokerCode?: Maybe<Scalars['Int']['output']>;
  brokerName?: Maybe<Scalars['String']['output']>;
  executingBrokerCodes?: Maybe<Array<Scalars['Int']['output']>>;
};

export type VenueBrokerInput = {
  executingBrokers?: InputMaybe<Array<Scalars['String']['input']>>;
  subBrokerId: Scalars['Long']['input'];
  venueBroker: Scalars['String']['input'];
};

export type VenueSpotTime = {
  __typename?: 'VenueSpotTime';
  spotTime?: Maybe<Array<SpotTimePair>>;
  venue?: Maybe<Scalars['String']['output']>;
};

export type AssetListQueryVariables = Exact<{
  secIds?: InputMaybe<Array<Scalars['String']['input']> | Scalars['String']['input']>;
}>;


export type AssetListQuery = { __typename?: 'Query', fiAssetList?: Array<{ __typename?: 'AssetObject', isin?: string | null, cusip?: string | null, couponValue?: number | null, bondQuality?: string | null, defaultSettleDate?: any | null, isMiFID2Eligible?: boolean | null, bAsset?: { __typename?: 'BAsset', maturity?: any | null, ticker?: string | null, minTrdSize?: number | null, secGroup?: string | null, secType?: string | null } | null }> | null };

export type AssetQueryVariables = Exact<{
  secId: Scalars['String']['input'];
}>;


export type AssetQuery = { __typename?: 'Query', fiAsset: { __typename?: 'AssetObject', isin?: string | null, cusip?: string | null, couponValue?: number | null, bondQuality?: string | null, defaultSettleDate?: any | null, isMiFID2Eligible?: boolean | null, bAsset?: { __typename?: 'BAsset', maturity?: any | null, ticker?: string | null, minTrdSize?: number | null, secGroup?: string | null, secType?: string | null } | null } };

export type BasketListSummaryQueryVariables = Exact<{
  basketId: Scalars['String']['input'];
  user: Scalars['String']['input'];
}>;


export type BasketListSummaryQuery = { __typename?: 'Query', fiBasketSummary: { __typename?: 'FIBasketSummary', placements?: Array<{ __typename?: 'Placement', placementNum: any, basketID?: string | null, axeID?: string | null, limitValue?: number | null, inquiryType?: number | null, limitType?: any | null, quantity?: number | null, status?: any | null, modifyReason?: any | null, modifiedTime?: any | null, externRefID?: string | null, ordNum?: number | null, dueInTime?: any | null, spreadIndex?: string | null, settleDate?: any | null, modifiedBy?: string | null, type?: any | null, placementGenFields?: Array<{ __typename?: 'GenericFieldEntry', key: string, value?: string | null } | null> | null, quotes?: Array<{ __typename?: 'Quote', spread?: number | null, quoteStatus?: any | null, price?: number | null, type?: any | null, side?: any | null, quoteID?: string | null, expTime?: any | null, quantity?: number | null, counterparty?: { __typename?: 'Counterparty', ticker?: string | null, code: number, shortName?: string | null } | null } | null> | null, desk?: { __typename?: 'Desk', salesman?: string | null, brokerType?: string | null, subBrokerID?: any | null } | null, broker?: { __typename?: 'Counterparty', ticker?: string | null, type?: string | null, shortName?: string | null, code: number } | null }> | null } };

export type BenchmarkListQueryVariables = Exact<{
  secIds?: InputMaybe<Array<Scalars['String']['input']> | Scalars['String']['input']>;
}>;


export type BenchmarkListQuery = { __typename?: 'Query', fiAssetList?: Array<{ __typename?: 'AssetObject', cusip?: string | null, couponValue?: number | null, bAsset?: { __typename?: 'BAsset', secDesc1?: string | null, maturity?: any | null, ticker?: string | null } | null }> | null };

export type OrderListSummaryQueryVariables = Exact<{
  ordNumList?: InputMaybe<Array<InputMaybe<Scalars['Int']['input']>> | InputMaybe<Scalars['Int']['input']>>;
  user: Scalars['String']['input'];
  rfqExecution: Scalars['Boolean']['input'];
}>;


export type OrderListSummaryQuery = { __typename?: 'Query', fiOrderListSummary: { __typename?: 'FIOrderListSummary', fiOrderSummaries?: Array<{ __typename?: 'FIOrderSummary', order: { __typename?: 'Order', cusip?: string | null, ordNum: number, price?: number | null, effectiveTranType?: string | null, updateInstr?: string | null, face?: number | null, fillAmt?: number | null, limitValue?: number | null, limitType?: any | null, orderLeaves?: number | null, settleDate?: any | null, tradingBenchmark?: string | null, priceCurrency?: string | null }, orderDetails?: Array<{ __typename?: 'OrderDetail', quantity: number, quantityBooked?: number | null, portfolio?: { __typename?: 'Portfolio', portfolioCode?: number | null, portfolioName?: string | null } | null }> | null, brokerAllocations: Array<{ __typename?: 'BrokerAllocation', availablePlacementQuantity?: number | null, eligiblePlacementQuantity?: number | null, eligiblePlacementQuantityAsPct?: number | null, broker: { __typename?: 'Counterparty', code: number }, portfolioAllocations?: Array<{ __typename?: 'PortfolioAllocation', portfolioCode: number, quantityAvailable: number }> | null } | null> } | null> | null } };

export type OrderSummaryQueryVariables = Exact<{
  ordNum?: InputMaybe<Scalars['Int']['input']>;
  user: Scalars['String']['input'];
  rfqExecution: Scalars['Boolean']['input'];
}>;


export type OrderSummaryQuery = { __typename?: 'Query', fiOrderSummary: { __typename?: 'FIOrderSummary', directBrokers?: Array<number> | null, delayedSpotEnabled?: Array<number> | null, mifidTagEnabled?: Array<number> | null, spreadFlowEnabled?: Array<number> | null, counteringEnabled?: Array<number> | null, userMifidEligibility?: string | null, venueBrokers?: Array<{ __typename?: 'VenueBroker', brokerName?: string | null, brokerCode?: number | null, executingBrokerCodes?: Array<number> | null }> | null, brokerAllocations: Array<{ __typename?: 'BrokerAllocation', availablePlacementQuantity?: number | null, eligiblePlacementQuantity?: number | null, eligiblePlacementQuantityAsPct?: number | null, broker: { __typename?: 'Counterparty', code: number, name?: string | null, shortName?: string | null, defaultDesk?: string | null, desks?: Array<{ __typename?: 'Desk', brokerCode?: number | null, brokerType?: string | null, salesman?: string | null, subBrokerID?: any | null }> | null }, portfolioAllocations?: Array<{ __typename?: 'PortfolioAllocation', portfolioCode: number, quantityAvailable: number }> | null } | null>, brokerEntity?: Array<{ __typename?: 'EntityMapping', key: string, value?: Array<string> | null }> | null, spotTimes?: Array<{ __typename?: 'VenueSpotTime', venue?: string | null, spotTime?: Array<{ __typename?: 'SpotTimePair', code?: string | null, displayName?: string | null }> | null }> | null } };

export type CreatePlacementQuotesMutationVariables = Exact<{
  requests?: InputMaybe<Array<PlacementQuoteRequest> | PlacementQuoteRequest>;
  user?: InputMaybe<Scalars['String']['input']>;
}>;


export type CreatePlacementQuotesMutation = { __typename?: 'Mutation', requestListPlacementQuotes?: Array<{ __typename?: 'OrderSummary', order: { __typename?: 'Order', ordNum: number }, placements?: Array<{ __typename?: 'Placement', placementNum: any }> | null }> | null };

export type ValidatePlacementQuotesMutationVariables = Exact<{
  request?: InputMaybe<Array<PlacementQuoteRequest> | PlacementQuoteRequest>;
  warnings?: InputMaybe<Scalars['String']['input']>;
  user?: InputMaybe<Scalars['String']['input']>;
}>;


export type ValidatePlacementQuotesMutation = { __typename?: 'Mutation', validateListPlacementsCountering?: Array<{ __typename?: 'ValidationIssue', message?: string | null } | null> | null };

export type PricesQueryVariables = Exact<{
  cusips?: InputMaybe<Array<Scalars['String']['input']> | Scalars['String']['input']>;
  startInclusive?: InputMaybe<Scalars['BFMTimestamp']['input']>;
}>;


export type PricesQuery = { __typename?: 'Query', prices?: Array<{ __typename?: 'Price', cusip?: string | null, indexName?: string | null, price?: number | null }> | null };


export const AssetListDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"query","name":{"kind":"Name","value":"assetList"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"secIds"}},"type":{"kind":"ListType","type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"fiAssetList"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"secIds"},"value":{"kind":"Variable","name":{"kind":"Name","value":"secIds"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"isin"}},{"kind":"Field","name":{"kind":"Name","value":"cusip"}},{"kind":"Field","name":{"kind":"Name","value":"couponValue"}},{"kind":"Field","name":{"kind":"Name","value":"bAsset"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"maturity"}},{"kind":"Field","name":{"kind":"Name","value":"ticker"}},{"kind":"Field","name":{"kind":"Name","value":"minTrdSize"}},{"kind":"Field","name":{"kind":"Name","value":"secGroup"}},{"kind":"Field","name":{"kind":"Name","value":"secType"}}]}},{"kind":"Field","name":{"kind":"Name","value":"bondQuality"}},{"kind":"Field","name":{"kind":"Name","value":"defaultSettleDate"}},{"kind":"Field","name":{"kind":"Name","value":"isMiFID2Eligible"}}]}}]}}]} as unknown as DocumentNode<AssetListQuery, AssetListQueryVariables>;
export const AssetDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"query","name":{"kind":"Name","value":"asset"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"secId"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"fiAsset"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"secId"},"value":{"kind":"Variable","name":{"kind":"Name","value":"secId"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"isin"}},{"kind":"Field","name":{"kind":"Name","value":"cusip"}},{"kind":"Field","name":{"kind":"Name","value":"couponValue"}},{"kind":"Field","name":{"kind":"Name","value":"bAsset"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"maturity"}},{"kind":"Field","name":{"kind":"Name","value":"ticker"}},{"kind":"Field","name":{"kind":"Name","value":"minTrdSize"}},{"kind":"Field","name":{"kind":"Name","value":"secGroup"}},{"kind":"Field","name":{"kind":"Name","value":"secType"}}]}},{"kind":"Field","name":{"kind":"Name","value":"bondQuality"}},{"kind":"Field","name":{"kind":"Name","value":"defaultSettleDate"}},{"kind":"Field","name":{"kind":"Name","value":"isMiFID2Eligible"}}]}}]}}]} as unknown as DocumentNode<AssetQuery, AssetQueryVariables>;
export const BasketListSummaryDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"query","name":{"kind":"Name","value":"BasketListSummary"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"basketId"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}}},{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"user"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"fiBasketSummary"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"basketId"},"value":{"kind":"Variable","name":{"kind":"Name","value":"basketId"}}},{"kind":"Argument","name":{"kind":"Name","value":"user"},"value":{"kind":"Variable","name":{"kind":"Name","value":"user"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"placements"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"placementNum"}},{"kind":"Field","name":{"kind":"Name","value":"basketID"}},{"kind":"Field","name":{"kind":"Name","value":"axeID"}},{"kind":"Field","name":{"kind":"Name","value":"limitValue"}},{"kind":"Field","name":{"kind":"Name","value":"inquiryType"}},{"kind":"Field","name":{"kind":"Name","value":"limitType"}},{"kind":"Field","name":{"kind":"Name","value":"quantity"}},{"kind":"Field","name":{"kind":"Name","value":"status"}},{"kind":"Field","name":{"kind":"Name","value":"modifyReason"}},{"kind":"Field","name":{"kind":"Name","value":"modifiedTime"}},{"kind":"Field","name":{"kind":"Name","value":"placementGenFields"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"key"}},{"kind":"Field","name":{"kind":"Name","value":"value"}}]}},{"kind":"Field","name":{"kind":"Name","value":"externRefID"}},{"kind":"Field","name":{"kind":"Name","value":"quotes"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"spread"}},{"kind":"Field","name":{"kind":"Name","value":"quoteStatus"}},{"kind":"Field","name":{"kind":"Name","value":"price"}},{"kind":"Field","name":{"kind":"Name","value":"type"}},{"kind":"Field","name":{"kind":"Name","value":"side"}},{"kind":"Field","name":{"kind":"Name","value":"quoteID"}},{"kind":"Field","name":{"kind":"Name","value":"expTime"}},{"kind":"Field","name":{"kind":"Name","value":"quantity"}},{"kind":"Field","name":{"kind":"Name","value":"counterparty"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"ticker"}},{"kind":"Field","name":{"kind":"Name","value":"code"}},{"kind":"Field","name":{"kind":"Name","value":"shortName"}}]}}]}},{"kind":"Field","name":{"kind":"Name","value":"desk"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"salesman"}},{"kind":"Field","name":{"kind":"Name","value":"brokerType"}},{"kind":"Field","name":{"kind":"Name","value":"subBrokerID"}}]}},{"kind":"Field","name":{"kind":"Name","value":"broker"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"ticker"}},{"kind":"Field","name":{"kind":"Name","value":"type"}},{"kind":"Field","name":{"kind":"Name","value":"shortName"}},{"kind":"Field","name":{"kind":"Name","value":"code"}}]}},{"kind":"Field","name":{"kind":"Name","value":"ordNum"}},{"kind":"Field","name":{"kind":"Name","value":"dueInTime"}},{"kind":"Field","name":{"kind":"Name","value":"spreadIndex"}},{"kind":"Field","name":{"kind":"Name","value":"settleDate"}},{"kind":"Field","name":{"kind":"Name","value":"modifiedBy"}},{"kind":"Field","name":{"kind":"Name","value":"type"}}]}}]}}]}}]} as unknown as DocumentNode<BasketListSummaryQuery, BasketListSummaryQueryVariables>;
export const BenchmarkListDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"query","name":{"kind":"Name","value":"benchmarkList"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"secIds"}},"type":{"kind":"ListType","type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"fiAssetList"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"secIds"},"value":{"kind":"Variable","name":{"kind":"Name","value":"secIds"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"cusip"}},{"kind":"Field","name":{"kind":"Name","value":"bAsset"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"secDesc1"}},{"kind":"Field","name":{"kind":"Name","value":"maturity"}},{"kind":"Field","name":{"kind":"Name","value":"ticker"}}]}},{"kind":"Field","name":{"kind":"Name","value":"couponValue"}}]}}]}}]} as unknown as DocumentNode<BenchmarkListQuery, BenchmarkListQueryVariables>;
export const OrderListSummaryDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"query","name":{"kind":"Name","value":"orderListSummary"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"ordNumList"}},"type":{"kind":"ListType","type":{"kind":"NamedType","name":{"kind":"Name","value":"Int"}}}},{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"user"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}}},{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"rfqExecution"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"Boolean"}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"fiOrderListSummary"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"ordNumList"},"value":{"kind":"Variable","name":{"kind":"Name","value":"ordNumList"}}},{"kind":"Argument","name":{"kind":"Name","value":"user"},"value":{"kind":"Variable","name":{"kind":"Name","value":"user"}}},{"kind":"Argument","name":{"kind":"Name","value":"rfqExecution"},"value":{"kind":"Variable","name":{"kind":"Name","value":"rfqExecution"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"fiOrderSummaries"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"order"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"cusip"}},{"kind":"Field","name":{"kind":"Name","value":"ordNum"}},{"kind":"Field","name":{"kind":"Name","value":"price"}},{"kind":"Field","name":{"kind":"Name","value":"effectiveTranType"}},{"kind":"Field","name":{"kind":"Name","value":"updateInstr"}},{"kind":"Field","name":{"kind":"Name","value":"face"}},{"kind":"Field","name":{"kind":"Name","value":"fillAmt"}},{"kind":"Field","name":{"kind":"Name","value":"limitValue"}},{"kind":"Field","name":{"kind":"Name","value":"limitType"}},{"kind":"Field","name":{"kind":"Name","value":"orderLeaves"}},{"kind":"Field","name":{"kind":"Name","value":"settleDate"}},{"kind":"Field","name":{"kind":"Name","value":"tradingBenchmark"}},{"kind":"Field","name":{"kind":"Name","value":"priceCurrency"}}]}},{"kind":"Field","name":{"kind":"Name","value":"orderDetails"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"quantity"}},{"kind":"Field","name":{"kind":"Name","value":"quantityBooked"}},{"kind":"Field","name":{"kind":"Name","value":"portfolio"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"portfolioCode"}},{"kind":"Field","name":{"kind":"Name","value":"portfolioName"}}]}}]}},{"kind":"Field","name":{"kind":"Name","value":"brokerAllocations"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"broker"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"code"}}]}},{"kind":"Field","name":{"kind":"Name","value":"availablePlacementQuantity"}},{"kind":"Field","name":{"kind":"Name","value":"eligiblePlacementQuantity"}},{"kind":"Field","name":{"kind":"Name","value":"eligiblePlacementQuantityAsPct"}},{"kind":"Field","name":{"kind":"Name","value":"portfolioAllocations"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"portfolioCode"}},{"kind":"Field","name":{"kind":"Name","value":"quantityAvailable"}}]}}]}}]}}]}}]}}]} as unknown as DocumentNode<OrderListSummaryQuery, OrderListSummaryQueryVariables>;
export const OrderSummaryDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"query","name":{"kind":"Name","value":"orderSummary"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"ordNum"}},"type":{"kind":"NamedType","name":{"kind":"Name","value":"Int"}}},{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"user"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}}},{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"rfqExecution"}},"type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"Boolean"}}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"fiOrderSummary"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"ordNum"},"value":{"kind":"Variable","name":{"kind":"Name","value":"ordNum"}}},{"kind":"Argument","name":{"kind":"Name","value":"user"},"value":{"kind":"Variable","name":{"kind":"Name","value":"user"}}},{"kind":"Argument","name":{"kind":"Name","value":"rfqExecution"},"value":{"kind":"Variable","name":{"kind":"Name","value":"rfqExecution"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"directBrokers"}},{"kind":"Field","name":{"kind":"Name","value":"venueBrokers"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"brokerName"}},{"kind":"Field","name":{"kind":"Name","value":"brokerCode"}},{"kind":"Field","name":{"kind":"Name","value":"executingBrokerCodes"}}]}},{"kind":"Field","name":{"kind":"Name","value":"delayedSpotEnabled"}},{"kind":"Field","name":{"kind":"Name","value":"mifidTagEnabled"}},{"kind":"Field","name":{"kind":"Name","value":"spreadFlowEnabled"}},{"kind":"Field","name":{"kind":"Name","value":"counteringEnabled"}},{"kind":"Field","name":{"kind":"Name","value":"brokerAllocations"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"broker"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"code"}},{"kind":"Field","name":{"kind":"Name","value":"name"}},{"kind":"Field","name":{"kind":"Name","value":"shortName"}},{"kind":"Field","name":{"kind":"Name","value":"defaultDesk"}},{"kind":"Field","name":{"kind":"Name","value":"desks"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"brokerCode"}},{"kind":"Field","name":{"kind":"Name","value":"brokerType"}},{"kind":"Field","name":{"kind":"Name","value":"salesman"}},{"kind":"Field","name":{"kind":"Name","value":"subBrokerID"}}]}}]}},{"kind":"Field","name":{"kind":"Name","value":"availablePlacementQuantity"}},{"kind":"Field","name":{"kind":"Name","value":"eligiblePlacementQuantity"}},{"kind":"Field","name":{"kind":"Name","value":"eligiblePlacementQuantityAsPct"}},{"kind":"Field","name":{"kind":"Name","value":"portfolioAllocations"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"portfolioCode"}},{"kind":"Field","name":{"kind":"Name","value":"quantityAvailable"}}]}}]}},{"kind":"Field","name":{"kind":"Name","value":"brokerEntity"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"key"}},{"kind":"Field","name":{"kind":"Name","value":"value"}}]}},{"kind":"Field","name":{"kind":"Name","value":"spotTimes"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"venue"}},{"kind":"Field","name":{"kind":"Name","value":"spotTime"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"code"}},{"kind":"Field","name":{"kind":"Name","value":"displayName"}}]}}]}},{"kind":"Field","name":{"kind":"Name","value":"userMifidEligibility"}}]}}]}}]} as unknown as DocumentNode<OrderSummaryQuery, OrderSummaryQueryVariables>;
export const CreatePlacementQuotesDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"mutation","name":{"kind":"Name","value":"createPlacementQuotes"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"requests"}},"type":{"kind":"ListType","type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"PlacementQuoteRequest"}}}}},{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"user"}},"type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"requestListPlacementQuotes"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"requests"},"value":{"kind":"Variable","name":{"kind":"Name","value":"requests"}}},{"kind":"Argument","name":{"kind":"Name","value":"user"},"value":{"kind":"Variable","name":{"kind":"Name","value":"user"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"order"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"ordNum"}}]}},{"kind":"Field","name":{"kind":"Name","value":"placements"},"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"placementNum"}}]}}]}}]}}]} as unknown as DocumentNode<CreatePlacementQuotesMutation, CreatePlacementQuotesMutationVariables>;
export const ValidatePlacementQuotesDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"mutation","name":{"kind":"Name","value":"validatePlacementQuotes"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"request"}},"type":{"kind":"ListType","type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"PlacementQuoteRequest"}}}}},{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"warnings"}},"type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}},{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"user"}},"type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"validateListPlacementsCountering"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"request"},"value":{"kind":"Variable","name":{"kind":"Name","value":"request"}}},{"kind":"Argument","name":{"kind":"Name","value":"warnings"},"value":{"kind":"Variable","name":{"kind":"Name","value":"warnings"}}},{"kind":"Argument","name":{"kind":"Name","value":"user"},"value":{"kind":"Variable","name":{"kind":"Name","value":"user"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"message"}}]}}]}}]} as unknown as DocumentNode<ValidatePlacementQuotesMutation, ValidatePlacementQuotesMutationVariables>;
export const PricesDocument = {"kind":"Document","definitions":[{"kind":"OperationDefinition","operation":"query","name":{"kind":"Name","value":"prices"},"variableDefinitions":[{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"cusips"}},"type":{"kind":"ListType","type":{"kind":"NonNullType","type":{"kind":"NamedType","name":{"kind":"Name","value":"String"}}}}},{"kind":"VariableDefinition","variable":{"kind":"Variable","name":{"kind":"Name","value":"startInclusive"}},"type":{"kind":"NamedType","name":{"kind":"Name","value":"BFMTimestamp"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"prices"},"arguments":[{"kind":"Argument","name":{"kind":"Name","value":"cusips"},"value":{"kind":"Variable","name":{"kind":"Name","value":"cusips"}}},{"kind":"Argument","name":{"kind":"Name","value":"startInclusive"},"value":{"kind":"Variable","name":{"kind":"Name","value":"startInclusive"}}}],"selectionSet":{"kind":"SelectionSet","selections":[{"kind":"Field","name":{"kind":"Name","value":"cusip"}},{"kind":"Field","name":{"kind":"Name","value":"indexName"}},{"kind":"Field","name":{"kind":"Name","value":"price"}}]}}]}}]} as unknown as DocumentNode<PricesQuery, PricesQueryVariables>;