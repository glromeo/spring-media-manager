import { useAtom, useSetAtom } from "jotai";
import { useEffect } from "react";
import { hasSearchParam } from "@atw/toolkit/utility/index";
import { useErrorNotification } from "@atx/toolkit/utils/notifications";
import { queryHost } from "@atx/toolkit/utils/host";
import { orderNumbersAtom } from "../state/orders";
import { cusipsAtom } from "../state/assets";
import { statusOverlayAtom } from "@atx/toolkit";

export function useInitialContext() {
    const [orderNumbers, setOrderNumbers] = useAtom(orderNumbersAtom);
    const setCusips = useSetAtom(cusipsAtom);
    const notifyError = useErrorNotification();

    const withOverlay = useSetAtom(statusOverlayAtom);

    useEffect(() => {
        if (!orderNumbers.length) {
            withOverlay(
                "Initializing the application...",
                queryHost<void, { ordNum: number; cusip: string }[]>("READY")
                    .then((orders) => {
                        console.log("READY", orders);
                        const ordNums = [...new Set(orders?.map((order) => order.ordNum) ?? [])];
                        setOrderNumbers(ordNums);
                        const cusips = [...new Set(orders?.map((order) => order.cusip) ?? [])];
                        setCusips(cusips);
                    })
                    .catch((error) => {
                        console.error("READY", error);
                        if (hasSearchParam("embedded")) {
                            notifyError("List RFQ not ready!", error?.message ?? error);
                        }
                    })
            );
        }
    }, []);
}
