import { useAtom } from "jotai";
import { useEffect } from "react";
import { useErrorNotification } from "@atx/toolkit/utils/notifications";
import { priceIndicesQuery } from "../query/price-indices";

export function usePriceIndices(cusips: string[]) {
    const notifyError = useErrorNotification();

    const [queryPriceIndices, setPriceIndices] = useAtom(priceIndicesQuery);

    useEffect(() => {
        setPriceIndices({});
        if (cusips.length) {
            queryPriceIndices(cusips)
                .then(setPriceIndices)
                .catch((error) => {
                    notifyError("Failed to query Price Indices", error);
                });
        }
    }, [cusips]);
}
