import {useAtom, useAtomValue, useSetAtom} from "jotai";
import {useErrorNotification} from "@atx/toolkit/utils";
import {useEffect} from "react";
import {assetListQuery} from "../query/asset-list";
import {orderListSummaryQuery} from "../query/order-list-summary";
import {orderSummaryQuery} from "../query/order-summary";
import {useInitialContext} from "./initial-context";
import {usePriceIndices} from "./price-indices";
import {cusipsAtom} from "../state/assets";
import {statusOverlayAtom} from "@atx/toolkit";
import {orderNumbersAtom} from "../state/orders";
import {selectBrokersAtom} from "../state/brokers";
import {LivePrice, useLivePrices} from "@atx/commons/hooks/live-prices";
import {benchmarkCusipsAtom} from "../state/benchmarks";
import {rfqsAtom} from "../state/rfqs";

export function useRequestWorkflow() {
    const orderNumbers = useAtomValue(orderNumbersAtom);
    const cusips = useAtomValue(cusipsAtom);
    const notifyError = useErrorNotification();

    const withOverlay = useSetAtom(statusOverlayAtom);

    useInitialContext();
    usePriceIndices(cusips);

    const [queryOrderSummary, setOrderSummary] = useAtom(orderSummaryQuery);
    const [queryAssetList, setAssetList] = useAtom(assetListQuery);
    const [queryOrderListSummary, setOrderListSummary] = useAtom(orderListSummaryQuery);
    const selectBrokers = useSetAtom(selectBrokersAtom);

    const setRfqs = useSetAtom(rfqsAtom);
    useLivePrices("TWEB", useAtomValue(benchmarkCusipsAtom), (update: LivePrice[]) => {
        for (const price of update) {
            setRfqs({
                benchmark: (rfq) => {
                    const benchmark = rfq.benchmark;
                    if (benchmark?.cusip === price.assetId) {
                        benchmark.price = rfq.order.side === "BUY" ? price.askPrice : price.bidPrice
                    }
                    return benchmark
                }
            });
        }
    });

    useEffect(() => {
        if (orderNumbers.length && cusips.length) {
            withOverlay(
                "Loading Order Summary List",
                Promise.all([
                    queryOrderSummary(orderNumbers[0]),
                    queryAssetList(cusips),
                    queryOrderListSummary(orderNumbers)
                ])
                    .then(async ([orderSummary, assetList, orderListSummary]) => {
                        // NOTE: The order of execution of the setXXX is important, Assets have to be there before Orders

                        if (orderSummary.data) {
                            setOrderSummary(orderSummary.data);
                        }
                        if (orderSummary.errors) {
                            for (const error of orderSummary.errors) {
                                notifyError("Error querying Order Summary", error.message);
                            }
                        }

                        if (assetList.data) {
                            setAssetList(assetList.data);
                        }
                        if (assetList.errors) {
                            for (const error of assetList.errors) {
                                notifyError("Error querying Asset List", error.message);
                            }
                        }

                        if (orderListSummary.data) {
                            setOrderListSummary(orderListSummary.data);
                        }
                        if (orderListSummary.errors) {
                            for (const error of orderListSummary.errors) {
                                notifyError("Error querying Order List Summary", error.message);
                            }
                        }

                        selectBrokers("NONE");
                        requestAnimationFrame(() => selectBrokers("DIRECT"));
                    })
                    .catch((error) => {
                        notifyError("Failed to query Order Summary List", error);
                    })
            );
        }
    }, [orderNumbers, cusips]);
}
