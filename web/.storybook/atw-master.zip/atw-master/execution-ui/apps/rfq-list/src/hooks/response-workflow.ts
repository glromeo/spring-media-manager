import {useAtom, useAtomValue, useSetAtom} from 'jotai'
import {useErrorNotification} from '@atx/toolkit/utils'
import {useEffect} from 'react'
import {assetListQuery} from '../query/asset-list'
import {orderListSummaryQuery} from '../query/order-list-summary'
import {orderSummaryQuery} from '../query/order-summary'
import {useInitialContext} from './initial-context'
import {orderNumbersAtom, ordersAtom} from '../state/orders'
import {cusipsAtom} from '../state/assets'
import {statusOverlayAtom} from '@atx/toolkit'
import {useLivePrices} from '@atx/commons/hooks/live-prices'
import {bondPricesUpdate} from '../state/bond-prices'

export function useResponseWorkflow() {
    const orderNumbers = useAtomValue(orderNumbersAtom);
    const cusips = useAtomValue(cusipsAtom);
    const orders = useAtomValue(ordersAtom);
    const notifyError = useErrorNotification();
    const withOverlay = useSetAtom(statusOverlayAtom);

    useInitialContext();

    // TODO: replace what follows with something tailored for basket summary

    const [queryOrderSummary, setOrderSummary] = useAtom(orderSummaryQuery);
    const [queryAssetList, setAssetList] = useAtom(assetListQuery);
    const [queryOrderListSummary, setOrderListSummary] = useAtom(orderListSummaryQuery);

    useEffect(() => {
        if (!orders.length && orderNumbers.length && cusips.length) {
            withOverlay(
                "Loading Basket",
                Promise.all([
                    queryOrderSummary(orderNumbers[0]),
                    queryAssetList(cusips),
                    queryOrderListSummary(orderNumbers)
                ])
                    .then(async ([orderSummary, assetList, orderListSummary]) => {
                        // NOTE: The order of execution of the setXXX is important, Assets have to be there before Orders

                        if (orderSummary.data) {
                            setOrderSummary(orderSummary.data);
                        }
                        if (orderSummary.errors) {
                            for (const error of orderSummary.errors) {
                                notifyError("Error querying Order Summary", error.message);
                            }
                        }

                        if (assetList.data) {
                            setAssetList(assetList.data);
                        }
                        if (assetList.errors) {
                            for (const error of assetList.errors) {
                                notifyError("Error querying Asset List", error.message);
                            }
                        }

                        if (orderListSummary.data) {
                            setOrderListSummary(orderListSummary.data);
                        }
                        if (orderListSummary.errors) {
                            for (const error of orderListSummary.errors) {
                                notifyError("Error querying Order List Summary", error.message);
                            }
                        }
                    })
                    .catch((error) => {
                        notifyError("Failed to query Order Summary List", error);
                    })
            );
        }
    }, [orderNumbers, cusips]);

    const setBondPrices = useSetAtom(bondPricesUpdate);
    useLivePrices("COMPOSITE", useAtomValue(cusipsAtom), update => setBondPrices(update));
}
