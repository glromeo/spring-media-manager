import {useSetAtom} from "jotai";
import {Order} from "@atx/commons";
import {RFQ, rfqsAtom} from "../state/rfqs";

export function useSetRfqField<F extends keyof RFQ, V = RFQ[F]>(order: Order, field: F) {
    const updateRfqs = useSetAtom(rfqsAtom);
    return (value: V) => {
        updateRfqs(order, {[field]: value});
    };
}

