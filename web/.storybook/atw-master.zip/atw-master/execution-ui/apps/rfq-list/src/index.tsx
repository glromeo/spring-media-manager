import React from "react";
import { AtxApp, AtxTitleBar, renderApp } from "@atx/toolkit";
import { ListRFQ } from "./components/list-rfq";
import { ListDebug } from "./components/list-debug";
import { atoms } from "./state";

import "./index.scss";

renderApp(
    <AtxApp atoms={atoms}>
        <AtxTitleBar toolbar={
            <ListDebug/>
        }/>
        <ListRFQ/>
    </AtxApp>
);
