import { apiQuery } from "@atx/toolkit/utils";
import { BondQuality, Security } from "@atx/commons/model";
import { AssetListQuery, AssetListQueryVariables } from "../gql/graphql";
import { atom } from "jotai";
import { assetsAtom } from "../state/assets";

const ASSET_LIST_QUERY = require("./asset-list.graphql");

export const assetListQuery = atom(
    (get) => async (cusips: string[]) =>
        apiQuery<AssetListQueryVariables, AssetListQuery>(
            ASSET_LIST_QUERY,
            { secIds: cusips },
            {
                fixture: `asset-list`,
                telemetry: ["asset-list", `querying fiAssetList with ${cusips.length} cusips`]
            }
        ),
    (get, set, { fiAssetList }: AssetListQuery) => {
        const assetByCusip = {} as { [cusip: string]: Security };
        for (const {
            cusip,
            isin,
            couponValue,
            bAsset,
            bondQuality,
            defaultSettleDate,
            isMiFID2Eligible
        } of fiAssetList!) {
            if (cusip && bAsset) {
                const { maturity, ticker, minTrdSize, secGroup, secType } = bAsset;
                assetByCusip[cusip] = {
                    cusip,
                    isin: isin ?? null,
                    ticker: ticker ?? null,
                    coupon: couponValue ?? null,
                    maturity: maturity ?? null,
                    minTrdSize: minTrdSize ?? null,
                    secGroup: secGroup!,
                    secType: secType!,
                    quality: bondQuality ? (bondQuality as BondQuality) : null,
                    defaultSettleDate: defaultSettleDate ?? null,
                    isMiFID2Eligible: isMiFID2Eligible === true
                };
            }
        }
        set(assetsAtom, Object.values(assetByCusip));
    }
);
