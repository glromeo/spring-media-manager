import { apiQuery } from "@atx/toolkit/utils";
import { AssetQuery, AssetQueryVariables } from "../gql/graphql";
import { atom } from "jotai";
import { BondQuality } from "@atx/commons";

const ASSET_QUERY = require("./asset.graphql");

export const assetQuery = atom((get) => async (cusip: string) => {
    const {data, errors} = await apiQuery<AssetQueryVariables, AssetQuery>(
        ASSET_QUERY,
        {secId: cusip},
        {
            fixture: `asset/${cusip}`,
            telemetry: ["asset-list", `querying fiAsset with cusip ${cusip}`]
        }
    )
    if (errors) {
        const [{message}] = errors;
        throw new Error(`Unable to query asset ${cusip} due to ${message}`);
    }
    if (data) {
        const {
            cusip,
            isin,
            couponValue,
            bAsset,
            bondQuality,
            defaultSettleDate,
            isMiFID2Eligible
        } = data.fiAsset;
        const { maturity, ticker, minTrdSize, secGroup, secType } = bAsset!;
        return  {
            cusip,
            isin: isin ?? null,
            ticker: ticker ?? null,
            coupon: couponValue ?? null,
            maturity: maturity ?? null,
            minTrdSize: minTrdSize ?? null,
            secGroup: secGroup!,
            secType: secType!,
            quality: bondQuality ? (bondQuality as BondQuality) : null,
            defaultSettleDate: defaultSettleDate ?? null,
            isMiFID2Eligible: isMiFID2Eligible === true
        };
    }
});
