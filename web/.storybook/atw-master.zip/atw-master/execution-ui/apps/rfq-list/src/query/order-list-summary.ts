import { BrokerAllocation, Order, PortfolioAllocation, Side } from "@atx/commons/model";
import { apiQuery } from "@atx/toolkit/utils";
import { atom } from "jotai";
import { OrderDetail, OrderListSummaryQuery, OrderListSummaryQueryVariables, Portfolio } from "../gql/graphql";
import { userAtom } from "@atx/toolkit/atoms";
import { assetsAtom } from "../state/assets";
import { brokerAllocationsAtom, brokersAtom } from "../state/brokers";
import { ordersAtom } from "../state/orders";

const FI_ORDER_LIST_SUMMARY_QUERY = require("./order-list-summary.graphql");

// NOTE: There are few defaults in the destructuring assignments which wouldn't capture the case the value is null
// They are not there to patch the response but rather to cope with the case the request didn't had those fields at all

export const orderListSummaryQuery = atom(
    (get) => async (ordNumList: number[]) =>
        await apiQuery<OrderListSummaryQueryVariables, OrderListSummaryQuery>(
            FI_ORDER_LIST_SUMMARY_QUERY,
            {
                ordNumList,
                user: get(userAtom),
                rfqExecution: true
            },
            {
                fixture: "order-list-summary",
                telemetry: [
                    "order-list-summary",
                    `querying fiOrderListSummary withb ${ordNumList.length} order numbers`
                ]
            }
        ),
    (get, set, {fiOrderListSummary: {fiOrderSummaries}}: OrderListSummaryQuery) => {
        const assetByCusip = Object.fromEntries(get(assetsAtom).map((asset) => [asset.cusip, asset]));
        const brokerByCode = Object.fromEntries(get(brokersAtom).map((broker) => [broker.code, broker]));

        const orders = [] as Order[];

        const allocations = {} as { [code: number]: BrokerAllocation[] };
        for (const code of Object.keys(brokerByCode)) {
            allocations[code as any] = [];
        }

        for (const fiOrderSummary of fiOrderSummaries!) {
            const {
                order: {
                    ordNum,
                    cusip,
                    effectiveTranType,
                    priceCurrency,
                    face,
                    orderLeaves,
                    limitValue,
                    limitType,
                    updateInstr,
                    tradingBenchmark
                },
                orderDetails = [],
                brokerAllocations = []
            } = fiOrderSummary!;

            const size = Math.abs(face!);

            const order: Order = {
                ordNum,
                side: effectiveTranType as Side,
                asset: assetByCusip[cusip!],
                ccy: priceCurrency!,
                size: size,
                unbookedAmt: unbookedAmt(size, orderDetails),
                orderLeaves: orderLeaves!,
                limit: limitValue ?? null,
                limitType: limitType,
                instructions: updateInstr ?? null,
                tradingBmk: tradingBenchmark ?? null
            };

            orders.push(order);

            const portfolios = Object.fromEntries(
                orderDetails!.map(({portfolio, quantity, quantityBooked}) => {
                    const {portfolioCode, portfolioName} = portfolio!;
                    return [
                        portfolioCode,
                        {
                            portfolioCode,
                            portfolioName,
                            quantity,
                            quantityBooked
                        }
                    ];
                })
            ) as Record<number,
                Pick<Portfolio, "portfolioCode" | "portfolioName"> & Pick<OrderDetail, "quantity" | "quantityBooked">>;

            for (const counterpartyRestriction of brokerAllocations!) {
                const {
                    broker: {code},
                    availablePlacementQuantity,
                    eligiblePlacementQuantity,
                    eligiblePlacementQuantityAsPct,
                    portfolioAllocations
                } = counterpartyRestriction!;

                if (!brokerByCode[code]) {
                    continue;
                }

                const unrestricted: PortfolioAllocation[] = portfolioAllocations!
                    .filter((allocation) => {
                        const {portfolioCode} = allocation!;
                        if (portfolios[portfolioCode]) {
                            return true;
                        } else {
                            console.warn("no portfolio in order details for portfolio allocation code:", portfolioCode);
                            return false;
                        }
                    })
                    .map((allocation) => {
                        const {portfolioCode, quantityAvailable} = allocation!;
                        return ({
                            name: portfolios[portfolioCode].portfolioName,
                            code: portfolioCode,
                            quantity: Math.abs(quantityAvailable),
                            percent: availablePlacementQuantity
                                ? (Math.abs(quantityAvailable) / availablePlacementQuantity) * 100
                                : 0,
                            isRestricted: false
                        }) as PortfolioAllocation;
                    });

                const restricted: PortfolioAllocation[] = [];
                if (availablePlacementQuantity !== eligiblePlacementQuantity) {
                    const isAllocated = new Set(unrestricted.map(({code}) => code));
                    for (const {portfolioCode, portfolioName, quantity} of Object.values(portfolios)) {
                        if (!isAllocated.has(portfolioCode!)) {
                            restricted.push({
                                name: portfolioName!,
                                code: portfolioCode!,
                                quantity: Math.abs(quantity ?? 0),
                                percent: availablePlacementQuantity
                                    ? (Math.abs(quantity ?? 0) / availablePlacementQuantity) * 100
                                    : 0,
                                isRestricted: true
                            });
                        }
                    }
                    restricted.sort((a, b) => (a.percent < b.percent ? 1 : -1));
                }

                allocations[code].push({
                    broker: brokerByCode[code],
                    order,
                    quantity: eligiblePlacementQuantity!,
                    percent: eligiblePlacementQuantityAsPct!,
                    restrictionLevel: eligiblePlacementQuantity === 0 ? "FULL" : restricted.length ? "PARTIAL" : "NONE",
                    details: [...unrestricted, ...restricted]
                });
            }
        }

        set(ordersAtom, orders);
        set(brokerAllocationsAtom, allocations);
    }
);

function unbookedAmt(faceValue: number, orderDetails?: { quantityBooked?: number | null }[] | null) {
    return faceValue - (orderDetails?.reduce((t, {quantityBooked}) => t + Math.abs(quantityBooked ?? 0), 0) ?? 0);
}
