import { Broker } from "@atx/commons/model";
import { apiQuery } from "@atx/toolkit/utils";
import { atom } from "jotai";
import { OrderSummaryQuery, OrderSummaryQueryVariables } from "../gql/graphql";
import { userAtom } from "@atx/toolkit/atoms";
import { brokersAtom, brokersByVenueAtom, Venue } from "../state/brokers";
import { isUserMifidEligibleAtom } from "../state/restrictions";
import { SpotTimeCode, SpotTimeOption, spotTimeOptionsAtom, SpotTimes } from "../state/time";

const FI_ORDER_SUMMARY_QUERY = require("./order-summary.graphql");

export const orderSummaryQuery = atom(
    (get) => async (ordNum: number) =>
        await apiQuery<OrderSummaryQueryVariables, OrderSummaryQuery>(
            FI_ORDER_SUMMARY_QUERY,
            {
                ordNum,
                user: get(userAtom),
                rfqExecution: true
            },
            {
                fixture: "order-summary",
                telemetry: ["order-summary", `querying fiOrderSummary for order number ${ordNum}`]
            }
        ),
    (get, set, {fiOrderSummary}: OrderSummaryQuery) => {
        const isUserMifidEligible = fiOrderSummary.userMifidEligibility === "true";
        const {brokerByCode, excluded} = parseBrokerAllocations(fiOrderSummary);
        const brokers = Object.values(brokerByCode);
        const brokersByVenue = parseBrokersByVenue(fiOrderSummary, brokerByCode, excluded);
        const venues = Object.keys(brokersByVenue);
        const spotTimes = parseSpotTimes(fiOrderSummary, venues);

        set(isUserMifidEligibleAtom, isUserMifidEligible);
        set(brokersAtom, brokers);
        set(brokersByVenueAtom, brokersByVenue);
        set(spotTimeOptionsAtom, spotTimes);
    }
);

function parseBrokerAllocations(fiOrderSummary: OrderSummaryQuery["fiOrderSummary"]) {
    const delayedSpotEnabled = new Set(fiOrderSummary.delayedSpotEnabled);
    const mifidTagEnabled = new Set(fiOrderSummary.mifidTagEnabled);
    const spreadFlowEnabled = new Set(fiOrderSummary.spreadFlowEnabled);
    const counteringEnabled = new Set(fiOrderSummary.counteringEnabled);

    const brokerByCode = {} as { [code: number]: Broker };
    const excluded = new Set<number>();

    for (const brokerAllocation of fiOrderSummary.brokerAllocations) {
        const {broker} = brokerAllocation!;
        const {code, defaultDesk, name, shortName, desks} = broker!;
        if (desks?.length) {
            const defaultSubBrokerID = defaultDesk ? parseInt(defaultDesk) : null;
            const brokerDesks = desks.map((desk) => ({
                brokerCode: desk.brokerCode!,
                brokerType: desk.brokerType!,
                salesman: desk.salesman!,
                subBrokerID: desk.subBrokerID!
            }));
            brokerByCode[code] = {
                code: code,
                name: name ?? shortName!,
                shortName: shortName!,
                desks: brokerDesks,
                defaultDesk: brokerDesks.find((desk) => desk.subBrokerID === defaultSubBrokerID) ?? brokerDesks[0],
                isDelayedSpotEnabled: delayedSpotEnabled.has(code),
                isMifidTagEnabled: mifidTagEnabled.has(code),
                isSpreadFlowEnabled: spreadFlowEnabled.has(code),
                isCounteringEnabled: counteringEnabled.has(code)
            };
        } else {
            console.warn(`broker ${shortName} (${code}) has no associated desks`);
            excluded.add(code);
        }
    }
    return {brokerByCode, excluded};
}

function parseBrokersByVenue({
                                 directBrokers,
                                 venueBrokers
                             }: OrderSummaryQuery["fiOrderSummary"], brokerByCode: { [code: number]: Broker }, excluded: Set<number>) {
    const brokersByVenue = {
        DIRECT: new Set<Broker>()
    } as Record<Venue, Set<Broker>>;

    for (const code of directBrokers!) {
        const broker = brokerByCode[code];
        if (broker) {
            brokersByVenue.DIRECT.add(broker);
        } else if (!excluded.has(code)) {
            console.warn("no broker allocation for direct broker code:", code);
        }
    }

    for (const {brokerCode, executingBrokerCodes} of venueBrokers!) {
        const venueBroker = brokerByCode[brokerCode!];
        if (venueBroker) {
            const target = brokersByVenue[venueBroker.shortName as Venue] = new Set<Broker>();
            for (const code of executingBrokerCodes!) {
                const broker = brokerByCode[code];
                if (broker) {
                    target.add(broker);
                } else if (!excluded.has(code)) {
                    console.warn("no broker allocation for venue executing broker code:", code);
                }
            }
        } else {
            console.warn("no broker allocation for venue broker code:", brokerCode);
        }
    }
    return brokersByVenue;
}

function parseSpotTimes({spotTimes}: OrderSummaryQuery['fiOrderSummary'], venues: string[]) {
    const spotTimesByVenue = {
        DIRECT: [] as SpotTimeOption[]
    } as SpotTimes;
    const unmapped = new Set(venues);
    if (spotTimes) {
        for (const {venue, spotTime} of spotTimes) {
            let options = spotTimesByVenue[venue as Venue] = [] as SpotTimeOption[];
            if (!unmapped.delete(venue as Venue)) {
                console.error("unknown spot time venue:", venue);
            }
            if (spotTime) {
                for (const item of spotTime) {
                    if (item.code) {
                        options.push({
                            value: item.code as SpotTimeCode,
                            label: item.displayName ?? `(${item.code})`
                        })
                    }
                }
            }
            options.sort(({value: l}, {value: r}) => {
                if (l === r) {
                    return 0;
                } else {
                    switch (l) {
                        case "A":
                            return -1;
                        case "N":
                            return r === "A" ? 1 : -1
                        default:
                            switch (r) {
                                case "A":
                                case "N":
                                    return 1
                                default:
                                    return l < r ? -1 : +1;
                            }
                    }
                }
            });
        }
    }
    for (const venue of unmapped) {
        spotTimesByVenue[venue as Venue] = [] as SpotTimeOption[];
        console.error("venue", venue, "has no spot times");
    }
    return spotTimesByVenue;
}
