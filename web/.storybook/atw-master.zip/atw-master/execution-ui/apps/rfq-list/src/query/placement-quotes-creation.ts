import { atom } from "jotai";
import { userAtom } from "@atx/toolkit/atoms";
import { apiQuery, errorNotification, notificationSink, warningNotification } from "@atx/toolkit/utils";
import { CreatePlacementQuotesMutation, CreatePlacementQuotesMutationVariables } from "../gql/graphql";
import { placementQuotesRequest, rfqTimeAtom } from "../state/rfqs";
import { Order } from "@atx/commons/model";
import { ordersAtom } from "../state/orders";
import { DateTime } from "luxon";
import { TIME_ZONE } from "../state/time";

const CREATE_PLACEMENT_QUOTES_MUTATION = require("./placement-quotes-creation.graphql");

export const createPlacementQuotesMutation = atom(null, async (get, set) => {
    const {timer, dueProtocol, dueIn, dueAt} = get(rfqTimeAtom);

    const dueAtDateTime =
        dueProtocol === "Due In"
            ? DateTime.local({zone: TIME_ZONE}).plus(dueIn ?? 0)
            : DateTime.fromJSDate(dueAt!, {zone: TIME_ZONE});
    const dueInTime = `${dueAtDateTime.toFormat("HH:mm:ss")}|${TIME_ZONE}`;

    const requests = get(placementQuotesRequest).map((item) => ({
        ...item,
        dueInTime,
        isBin: timer === "Bin"
    }));
    const {data, errors} = await apiQuery<CreatePlacementQuotesMutationVariables, CreatePlacementQuotesMutation>(
        CREATE_PLACEMENT_QUOTES_MUTATION,
        {
            requests: requests,
            user: get(userAtom)
        },
        {
            gzip: true,
            fixture: `validate-placements`,
            telemetry: [
                "validateListPlacementsCountering",
                `querying validateListPlacementsCountering with ${requests.length} orders`
            ]
        }
    );
    const placementQuotesIssues = new Map<Order, { warnings: string[]; errors: string[] }>();
    const totals = {errors: 0, warnings: 0};
    if (errors) {
        const ordersByOrdNum = get(ordersAtom).reduce(
            (map, order) => map.set(order.ordNum, order),
            new Map<number, Order>()
        );
        for (const {ordNum, message, level} of parseErrors(errors)) {
            const order = ordersByOrdNum.get(ordNum);
            if (order) {
                let creations = placementQuotesIssues.get(order);
                if (!creations) {
                    placementQuotesIssues.set(order, (creations = {warnings: [], errors: []}));
                }
                if (level === "error") {
                    totals.errors++;
                    creations.errors.push(message);
                } else {
                    totals.warnings++;
                    creations.warnings.push(message);
                }
            } else {
                if (level === "error") {
                    set(notificationSink, errorNotification("Validation Error!", message));
                } else {
                    set(notificationSink, warningNotification("Validation Warning!", message));
                }
            }
        }
    }

    {
        const {errors = 0, warnings = 0} = totals;
        if (errors) {
            if (warnings) {
                set(
                    notificationSink,
                    errorNotification(
                        "Validation Error!",
                        `There are ${errors} errors and ${warnings} warnings resulting from backend validation.`
                    )
                );
            } else {
                set(
                    notificationSink,
                    errorNotification(
                        "Validation Error!",
                        `There are ${errors} errors resulting from backend validation.`
                    )
                );
            }
        } else if (warnings) {

            set(
                notificationSink,
                warningNotification(
                    "Validation Warning!",
                    `There are ${warnings} warnings resulting from backend validation.`
                )
            );
        }
    }

    if (errors?.length) {
        return Promise.reject();
    }
});

function parseErrors(errors: { message: string }[]) {
    return errors.map(({message}) => parseError(message));
}

function parseError(text: string): { ordNum: number; level: "warning" | "error"; message: string } {
    let from = 0,
        to = text.indexOf(",");
    const level = text.slice(from, to).endsWith(":error") ? "error" : "warning";
    from = to + 1;
    to = text.indexOf(",", from);
    const ordNum = parseInt(text.slice(from, to));
    from = to + 1;
    to = text.length;
    const message = text.slice(from, to);
    return {
        ordNum,
        level,
        message
    };
}
