import {atom} from "jotai";
import {userAtom} from "@atx/toolkit/atoms";
import {apiQuery, errorNotification, notificationSink, warningNotification} from "@atx/toolkit/utils";
import {ValidatePlacementQuotesMutation, ValidatePlacementQuotesMutationVariables} from "../gql/graphql";
import {placementQuotesRequest, RFQ, rfqTimeAtom} from "../state/rfqs";
import {Order} from "@atx/commons/model";
import {findOrderAtom} from "../state/orders";
import {DateTime} from "luxon";
import {TIME_ZONE} from "../state/time";
import {validationIssuesAtom, RfqIssue} from "../state/validation";

const VALIDATE_PLACEMENT_QUOTES_MUTATION = require("./placement-quotes-validation.graphql");

const messageParserAtom = atom((get) => {
    const findOrder = get(findOrderAtom);
    const findField = (message: string): keyof RFQ | undefined => {
        if (/quantity/i.test(message)) {
            return "size";
        }
    };
    return (text: string): RfqIssue & { order?: Order } => {
        let from = 0;
        let to = text.indexOf(",");
        const level = text.slice(from, to).endsWith(":error") ? "error" : "warning";
        from = to + 1;
        to = text.indexOf(",", from);
        const ordNum = parseInt(text.slice(from, to));
        from = to + 1;
        to = text.length;
        const message = text.slice(from, to);
        return {
            order: findOrder(ordNum),
            field: findField(message),
            level,
            message
        };
    };
});

export const validatePlacementQuotesMutation = atom(null, async (get, set) => {
    const {timer, dueProtocol, dueIn, dueAt} = get(rfqTimeAtom);

    const dueAtDateTime =
        dueProtocol === "Due In"
            ? DateTime.local({zone: TIME_ZONE}).plus(dueIn ?? 0)
            : DateTime.fromJSDate(dueAt!, {zone: TIME_ZONE});
    const dueInTime = `${dueAtDateTime.toFormat("HH:mm:ss")}|${TIME_ZONE}`;

    const request = get(placementQuotesRequest).map((item) => ({
        ...item,
        dueInTime,
        isBin: timer === "Bin"
    }));
    const {data} = await apiQuery<ValidatePlacementQuotesMutationVariables, ValidatePlacementQuotesMutation>(
        VALIDATE_PLACEMENT_QUOTES_MUTATION,
        {
            request: request,
            user: get(userAtom)
        },
        {
            gzip: true,
            fixture: `validate-placements`,
            telemetry: [
                "validateListPlacementsCountering",
                `querying validateListPlacementsCountering with ${request.length} orders`
            ]
        }
    );

    const backendIssues = new Map<Order, RfqIssue[]>();

    const issues = data?.validateListPlacementsCountering;
    let errors = 0;
    let warnings = 0;
    if (issues?.length) {
        const parseMessage = get(messageParserAtom);
        for (const issue of issues.filter(issue => issue?.message)) {
            const {order, field, message, level} = parseMessage(issue!.message!);
            if (order) {
                let orderIssues = backendIssues.get(order);
                if (!orderIssues) {
                    backendIssues.set(order, orderIssues = []);
                }
                if (level === "error") {
                    errors++;
                } else {
                    warnings++;
                }
                orderIssues.push({field, message, level});
            } else {
                if (level === "error") {
                    set(notificationSink, errorNotification("Validation Error!", message));
                } else {
                    set(notificationSink, warningNotification("Validation Warning!", message));
                }
            }
        }
    }

    set(validationIssuesAtom, backendIssues);

    if (errors) {
        set(notificationSink, errorNotification(
            "Validation Error!",
            warnings
                ? `There are ${errors} errors and ${warnings} warnings resulting from backend validation.`
                : `There are ${errors} errors resulting from backend validation.`
        ));
    } else if (warnings) {
        set(notificationSink, warningNotification(
            "Validation Warning!",
            `There are ${warnings} warnings resulting from backend validation.`
        ));
    }

    if (issues?.length) {
        return Promise.reject();
    }
});

