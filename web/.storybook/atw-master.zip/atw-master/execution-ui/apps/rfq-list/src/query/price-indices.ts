import { formatSecurity } from "@atx/commons/utils";
import { apiQuery, queryHost } from "@atx/toolkit/utils";
import { atom } from "jotai";
import { BenchmarkListQuery, BenchmarkListQueryVariables, PricesQuery, PricesQueryVariables } from "../gql/graphql";
import { Benchmark, benchmarkEpochAtom, bondBenchmarksAtom } from "../state/benchmarks";

const PRICES_QUERY = require("./price-indices.graphql");

type PriceIndices = Record<string, { index: string, price: number | null, source: "Market Axess" | "Aladdin" }>;

function queryPrices(cusips: string[], startInclusive: number): Promise<PriceIndices> {
    return apiQuery<PricesQueryVariables, PricesQuery>(
        PRICES_QUERY,
        {
            cusips: cusips,
            startInclusive: startInclusive
        },
        {
            fixture: "price-indices",
            telemetry: ["price-indices", `querying prices for benchmarks: ${JSON.stringify(cusips)}`]
        }
    )
        .then(({data, errors}) => {
            const indices = {} as PriceIndices;
            if (data?.prices) {
                for (const {cusip, indexName: index, price = null} of data.prices) {
                    if (cusip && index) {
                        indices[cusip] = {index, price, source: "Aladdin"};
                    }
                }
            }
            console.warn("errors querying price indices", errors);
            return indices;
        })
        .catch((error) => {
            console.warn("unable to query PriceServer benchmarks", error.message ?? error);
            return {};
        });
}

export const pricesQuery = atom(get => (cusips:string[]) => queryPrices(cusips, get(benchmarkEpochAtom)));

function queryMktxsService(cusips: string[]): Promise<PriceIndices> {
    return queryHost<string[], Record<string, string>>("MKTXS_BENCHMARKS", cusips)
        .then((result) => {
            console.log("MKTXS_BENCHMARKS", result);
            const indices = {} as PriceIndices;
            for (const [cusip, index] of Object.entries(result)) {
                indices[cusip] = {index, price: null, source: "Market Axess"};
            }
            return indices;
        })
        .catch((error) => {
            console.error("MKTXS_BENCHMARKS", error.message ?? error);
            return {};
        });
}

const BENCHMARK_DESC_QUERY = require("./benchmark-list.graphql");

export const priceIndicesQuery = atom(
    (get) => (cusips: string[]) => Promise.all([
        queryMktxsService(cusips),
        queryPrices(cusips, get(benchmarkEpochAtom))
    ]).then(async ([mktxsIndices, aladdinIndices]): Promise<Record<string, Benchmark>> => {
        const priceIndices: PriceIndices = {
            ...mktxsIndices,
            ...aladdinIndices
        }
        const {data} = await apiQuery<BenchmarkListQueryVariables, BenchmarkListQuery>(
            BENCHMARK_DESC_QUERY,
            {secIds: [...new Set(Object.values(priceIndices).map(({index}) => index))]},
            {
                fixture: `benchmark-list`,
                telemetry: ["benchmark-list", `querying fiAssetList with ${cusips.length} for benchmarks`]
            }
        );
        const descriptors = new Map(
            data?.fiAssetList?.map(({cusip, bAsset, couponValue}) => {
                return [cusip, bAsset ? formatSecurity({
                    maturity: bAsset.maturity,
                    coupon: couponValue ?? null,
                    ticker: bAsset.ticker ?? null
                }) : null];
            })
        );
        return Object.fromEntries(
            Object.entries(priceIndices).map(([cusip, {index, source, price}]) => [
                cusip,
                {
                    cusip: index,
                    description: descriptors.get(index) ?? "-",
                    source,
                    price
                }
            ])
        );
    }),
    (get, set, benchmarks: Record<string, Benchmark | null>) => {
        set(bondBenchmarksAtom, benchmarks);
    }
);
