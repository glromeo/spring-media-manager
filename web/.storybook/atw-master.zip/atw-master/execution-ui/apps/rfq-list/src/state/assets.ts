import { atom } from "jotai";
import { Security } from "@atx/commons/model";

export const cusipsAtom = atom<string[]>([]);

export const assetsAtom = atom([] as Security[]);

