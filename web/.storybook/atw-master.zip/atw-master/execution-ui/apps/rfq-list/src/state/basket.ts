import { atom } from "jotai";
import { searchParam } from "@atx/toolkit/utils/location";
import { Broker } from "@atx/commons/model/broker";
import { Quote } from "./quote";
import {ordersAtom} from "./orders";
import { PricingType } from "@atx/commons/model/bond";

export const basketIdAtom = atom<string | null>(searchParam("basketId"));

export type PlacementSummary = Quote & {
    requested: number | null;
    topLevel: number | null;
    topBroker: Broker | null;
    referenceLevel: number | null;
};

export type PlacementDetails = {
    broker: Broker | null;
    size: number | null;
    spotTime: string | null;
    requested: number | null;
    topLevel: number | null;
    topBroker: Broker | null;
    referenceLevel: number | null;
};

export const basketAtom = atom<PlacementSummary[]>(get => {
    return get(ordersAtom).map((order): PlacementSummary => {
        return {
            order,
            size: order.orderLeaves,
            spotTime: "A",
            priceType: ["price","spread"][Math.floor(Math.random()*2)] as PricingType,
            requested: null,
            topLevel: null,
            referenceLevel: null,
            topBroker: null
        };
    })
});
