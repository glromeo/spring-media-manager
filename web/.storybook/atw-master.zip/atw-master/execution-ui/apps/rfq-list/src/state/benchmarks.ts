import { atom } from "jotai";
import { tokensAtom } from "@atx/commons/atoms";
import { DateTime } from "luxon";
import { atomWithEffects } from "@atx/toolkit/atoms";
import {rfqsAtom} from "./rfqs";
import {LivePrice} from "@atx/commons/hooks/live-prices";

export const benchmarkEpochAtom = atom((get) => {
    const previousDayEpoch = () => {
        const localDate = DateTime.local();
        return DateTime.fromObject(
            {
                year: localDate.year,
                month: localDate.month,
                day: localDate.day,
                hour: 0,
                minute: 0,
                second: 0
            },
            {
                zone: "America/New_York"
            }
        ).toMillis();
    };

    let token = get(tokensAtom).AT_benchmark_date;
    if (!token) {
        console.warn("No value for token 'AT_benchmark_date', using yesterday date for benchmark.");
        return previousDayEpoch();
    } else {
        let epoch = DateTime.fromFormat(token, "dd/mm/yyyy", {
            zone: "America/New_York"
        }).toMillis();
        if (isNaN(epoch)) {
            console.error("Could not parse token 'AT_benchmark_date', using yesterday date for benchmark.");
            return previousDayEpoch();
        }
        return epoch;
    }
});

export type Benchmark = {
    cusip: string;
    description: string | null;
    price: number | null;
    source: "Market Axess" | "Aladdin" | null;
};

/**
 * These are the default benchmarks, fetched for each order bond upon initialization
 * the user can then choose a different benchmark and that's stored in the RFQ's benchmark field
 *
 * NOTE: the key of this record is the cusip of the bond, not the benchmark cusip
 */

export const bondBenchmarksAtom = atomWithEffects({} as Record<string, Benchmark | null>, (get, set, benchmarks) => {
    set(rfqsAtom, {
        benchmark: rfq => benchmarks[rfq.order.asset.cusip] ?? null
    })
});

export const benchmarkPricesAtom = atom({} as Record<string, LivePrice>)

export const benchmarkCusipsAtom = atom(get => {
    return [...new Set(Object.values(get(rfqsAtom)).map(rfq => rfq.benchmark?.cusip!).filter(c => c))]
})