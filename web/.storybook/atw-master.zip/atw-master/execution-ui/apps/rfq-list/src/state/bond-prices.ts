import { LivePrice } from "@atx/commons/hooks/live-prices";
import { atom } from "jotai";

export const bondPricesAtom = atom({} as Record<string, LivePrice>)

export const bondPricesLastUpdate = atom({} as Record<string, LivePrice>)

export const bondPricesUpdate = atom(get => get(bondPricesLastUpdate), (get, set, update:LivePrice[])=>{
    const record = {} as Record<string, LivePrice>;
    for (const price of update) {
        record[price.assetId] = price;
    }
    set(bondPricesLastUpdate, record)
    set(bondPricesAtom, {
        ...get(bondPricesAtom),
        ...record
    });
})
