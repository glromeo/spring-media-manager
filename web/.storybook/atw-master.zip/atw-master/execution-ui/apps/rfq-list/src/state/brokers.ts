import { atom } from "jotai";
import { Broker, BrokerAllocation, Desk, Order } from "@atx/commons/model";
import { brokerRestrictionsAtom, rfqRestrictionsAtom } from "./restrictions";
import { atomWithStorage } from "jotai/utils";
import { storeKey } from "@atx/toolkit/utils/storage";

export type Venue = "DIRECT" | "TWRFQUS" | "SIMTWEB";

export const brokersAtom = atom([] as Broker[]);

export const venueBrokersAtom = atom(new Set<Broker>());
export const brokersByVenueAtom = atom<Record<Venue, Set<Broker>>>({
    DIRECT: new Set<Broker>(),
    TWRFQUS: new Set<Broker>(),
    SIMTWEB: new Set<Broker>()
});

export const sortBrokersByName = (l: Broker, r: Broker) => (l.name < r.name ? -1 : l.name === r.name ? 0 : 1);

export const brokerAllocationsAtom = atom<{ [code: number]: BrokerAllocation[] }>({});

const defaultSubBrokerIdsAtom = atomWithStorage<Record<number, number>>(storeKey("desk-selection"), {});
const selectedSubBrokersIdsAtom = atom<Record<number, number>>({});

export const isDefaultSelectionAtom = atom((get) => {
    return ({code}: Broker, {subBrokerID}: Desk) => get(defaultSubBrokerIdsAtom)[code] === subBrokerID;
});

/**
 * Broker's default desk is used unless there are multiple desks available and one in particular is
 * selected for a broker in which case the selection is kept in this map
 */

export const selectedDesksAtom = atom(
    (get) => {
        const selectedDesks = new Map<Broker, Desk>();
        const brokers = get(brokersAtom);
        const defaultDesks = {...get(defaultSubBrokerIdsAtom), ...get(selectedSubBrokersIdsAtom)};
        for (const broker of brokers) {
            const subBrokerID = defaultDesks[broker.code];
            if (subBrokerID) {
                const desk = broker.desks.find((desk) => desk.subBrokerID === subBrokerID);
                if (desk) {
                    selectedDesks.set(broker, desk);
                }
            }
        }
        return selectedDesks;
    },
    (get, set, selections: { broker: Broker; desk: Desk; isDefault: boolean }[]) => {
        const defaultSubBrokerIds = {...get(defaultSubBrokerIdsAtom)};
        const selectedSubBrokersIds = {...get(selectedSubBrokersIdsAtom)};
        for (const {broker, desk, isDefault} of selections) {
            if (isDefault) {
                defaultSubBrokerIds[broker.code] = desk.subBrokerID;
            }
            selectedSubBrokersIds[broker.code] = desk.subBrokerID;
        }
        set(defaultSubBrokerIdsAtom, defaultSubBrokerIds);
        set(selectedSubBrokersIdsAtom, selectedSubBrokersIds);
    }
);

const selectedByVenueAtom = atom({} as Record<Venue, Set<Broker>>);

export const selectBrokersAtom = atom(null, (get, set, action: Partial<Record<Venue, Broker[]>> | "NONE" | Venue) => {
    const brokersByVenue = get(brokersByVenueAtom);
    if (action === "NONE") {
        set(selectedByVenueAtom, Object.fromEntries(
            Object.keys(brokersByVenue).map(venue => [venue, new Set()])
        ) as Record<Venue, Set<Broker>>);
    } else {
        const update = typeof action === "string" ? {[action as Venue]: brokersByVenue[action as Venue]} : action;

        const selectedByVenue = {...get(selectedByVenueAtom)}
        for (const venue of Object.keys(brokersByVenue)) {
            let selected: Set<Broker>;
            if (venue in update) {
                selected = new Set(update[venue as Venue])
            } else {
                selected = new Set(selectedByVenue[venue as Venue]);
                for (const brokers of Object.values(action)) {
                    for (const broker of brokers) {
                        selected.delete(broker);
                    }
                }
            }
            selectedByVenue[venue as Venue] = selected;
        }
        set(selectedByVenueAtom, selectedByVenue);
    }
});

export const requestedByVenueAtom = atom((get) => {
    const restrictions = get(brokerRestrictionsAtom);
    const selectedByVenue = Object.entries(get(selectedByVenueAtom));
    return Object.fromEntries(
        selectedByVenue.map(([venue, selected]) => [
            venue,
            [...selected].filter((broker: Broker) => {
                const {status} = restrictions.get(broker) ?? {};
                return status !== "UNAVAILABLE" && status !== "FULLY_RESTRICTED";
            })]
        )
    )
});

export const requestedVenuesAtom = atom((get) => {
    return Object.entries(get(requestedByVenueAtom))
        .filter(([venue, brokers]) => brokers.length > 0)
        .map(([venue]) => venue as Venue);
})

export const requestedBrokersAtom = atom((get) => {
    const requestedBrokers = [] as Broker[];
    for (const [venue, requested] of Object.entries(get(requestedByVenueAtom))) {
        for (const broker of requested) {
            requestedBrokers.push(broker);
        }
    }
    return requestedBrokers;
});

/**
 * why not just look at unrestricted ?
 * it is likely that eligible it's going to be a mix of unrestricted and restricted at some point
 * so I rather make this distinction explicit now
 */
export const eligibleBrokersAtom = atom((get) => {
    const eligibleBrokers = new Map<Order, Set<Broker>>();
    for (const [order, {unrestricted}] of get(rfqRestrictionsAtom)) {
        eligibleBrokers.set(order, unrestricted);
    }
    return eligibleBrokers;
});

export const requestedBrokersByOrderAtom = atom((get) => {
    const requestedBrokers = get(requestedBrokersAtom);
    const requestedBrokersByOrder = new Map<Order, Broker[]>();
    for (const [order, eligible] of get(eligibleBrokersAtom)) {
        requestedBrokersByOrder.set(
            order,
            requestedBrokers.filter((broker) => eligible.has(broker))
        );
    }
    return requestedBrokersByOrder;
});

export const hideRestrictedAtom = atom<boolean>(false);
export const selectAxedBrokersAtom = atom<boolean>(false);
export const brokersRequestedAtom = atom<number>((get) => get(requestedBrokersAtom).length);