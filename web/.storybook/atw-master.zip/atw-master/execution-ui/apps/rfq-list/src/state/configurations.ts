import { atom } from "jotai";

export const configurationsAtom = atom<any>({
    userMifidEligibility: "true",
    delayedSpotEnabled: [],
    mifidTagEnabled: [],
    spreadFlowEnabled: [],
    counteringEnabled: [],
    brokerEntity: [],
    alldesks: []
});
