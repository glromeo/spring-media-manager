import { atom } from "jotai";

export const availableOrderDetailsFields = atom<
    {
        label: string;
        tooltip?: string;
        required?: boolean;
    }[]
>([
    { label: "Side", required: true },
    { label: "Bond", required: true },
    { label: "Security Bmk" },
    { label: "CCY" },
    { label: "CUSIP" },
    { label: "ISIN" },
    { label: "Original Size" },
    { label: "Unbooked Amt" },
    { label: "Order Leaves" },
    { label: "Limit" },
    { label: "Limit Type" },
    { label: "Instructions" },
    { label: "Trading Bmk" }
]);

export type OrderField =
    | "Side"
    | "Bond"
    | "Security Bmk"
    | "CCY"
    | "CUSIP"
    | "ISIN"
    | "Original Size"
    | "Unbooked Amt"
    | "Order Leaves"
    | "Limit"
    | "Limit Type"
    | "Instructions"
    | "Trading Bmk";

export const selectedOrderFieldsAtom = atom<OrderField[]>([
    "Side",
    "Bond",
    "Security Bmk",
    "CCY",
    "CUSIP",
    "ISIN",
    "Original Size",
    "Unbooked Amt",
    "Order Leaves",
    "Limit",
    "Limit Type",
    "Instructions",
    "Trading Bmk"
]);
