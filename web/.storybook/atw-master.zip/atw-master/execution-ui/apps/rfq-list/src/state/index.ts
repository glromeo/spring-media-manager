import { assetsAtom, cusipsAtom } from "./assets"
import { basketAtom, basketIdAtom } from "./basket"
import { benchmarkEpochAtom, bondBenchmarksAtom } from "./benchmarks"
import {
    brokerAllocationsAtom,
    brokersAtom,
    brokersByVenueAtom,
    brokersRequestedAtom,
    eligibleBrokersAtom,
    hideRestrictedAtom,
    isDefaultSelectionAtom,
    requestedBrokersAtom,
    requestedBrokersByOrderAtom,
    requestedByVenueAtom,
    selectAxedBrokersAtom,
    selectBrokersAtom,
    selectedDesksAtom,
    venueBrokersAtom
} from "./brokers"
import { configurationsAtom } from "./configurations"
import { selectedOrderFieldsAtom } from "./details"
import { orderNumbersAtom, ordersAtom } from "./orders"
import { quotesAtom, selectedQuoteAtom } from "./quote"
import { responseDueInAtom } from "./response"
import {
    brokerRestrictionsAtom,
    isUserMifidEligibleAtom,
    mifidEligibleOrdersAtom,
    orderRestrictionsAtom,
    rfqRestrictionsAtom
} from "./restrictions"
import {focusedOrderAtom, rfqsAtom, rfqSummaryAtom, rfqTimeAtom} from "./rfqs";
import { availableSpotTimeOptionsAtom, spotTimeOptionsAtom } from "./time"
import { dueAtValidationAtom, requestIssuesAtom } from "./validation"
import { stageAtom, stepAtom, stepIndexAtom } from "./workflow"

import { userAtom } from "@atx/toolkit";
import { tokensAtom } from "@atx/commons";

// brokers.ts:       defaultSubBrokerIdsAtom
// brokers.ts:       selectedSubBrokersIdsAtom
// brokers.ts:       selectedDirectAtom
// brokers.ts:       selectedVenueAtom
// response.ts:      responseDurationAtom
// restrictions.ts:  isClientMifidEligibleAtom
// restrictions.ts:  isWorkflowMifidEligibleAtom
// validation.ts:    backendIssuesAtom
// validation.ts:    fieldIssuesAtom
// validation.ts:    brokerIssuesAtom

export const atoms = {
    user: userAtom,
    tokens: tokensAtom,
    cusips: cusipsAtom,
    assets: assetsAtom,
    basketId: basketIdAtom,
    basket: basketAtom,
    benchmarkEpoch: benchmarkEpochAtom,
    benchmarks: bondBenchmarksAtom,
    brokers: brokersAtom,
    venueBrokers: venueBrokersAtom,
    brokersByVenue: brokersByVenueAtom,
    requestedByVenue: requestedByVenueAtom,
    brokerAllocations: brokerAllocationsAtom,
    selectBrokers: selectBrokersAtom,
    isDefaultSelection: isDefaultSelectionAtom,
    selectedDesks: selectedDesksAtom,
    requestedBrokers: requestedBrokersAtom,
    eligibleBrokersByOrder: eligibleBrokersAtom,
    requestedBrokersByOrder: requestedBrokersByOrderAtom,
    hideRestricted: hideRestrictedAtom,
    selectAxedBrokers: selectAxedBrokersAtom,
    brokersRequested: brokersRequestedAtom,
    configurations: configurationsAtom,
    selectedOrderFields: selectedOrderFieldsAtom,
    orderNumbers: orderNumbersAtom,
    focusedOrder: focusedOrderAtom,
    orders: ordersAtom,
    quotes: quotesAtom,
    selectedQuote: selectedQuoteAtom,
    responseDueIn: responseDueInAtom,
    isUserMifidEligible: isUserMifidEligibleAtom,
    mifidEligibleOrders: mifidEligibleOrdersAtom,
    orderRestrictions: orderRestrictionsAtom,
    rfqRestrictions: rfqRestrictionsAtom,
    brokerRestrictions: brokerRestrictionsAtom,
    rfqTime: rfqTimeAtom,
    rfqs: rfqsAtom,
    rfqSummary: rfqSummaryAtom,
    spotTimes: spotTimeOptionsAtom,
    availableSpotTimes: availableSpotTimeOptionsAtom,
    dueAtValidation: dueAtValidationAtom,
    requestValidation: requestIssuesAtom,
    stepIndex: stepIndexAtom,
    step: stepAtom,
    stage: stageAtom,
}