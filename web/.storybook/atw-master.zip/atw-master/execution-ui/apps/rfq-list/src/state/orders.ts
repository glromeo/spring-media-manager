import {atom} from "jotai";
import {atomWithEffects} from "@atx/toolkit/atoms";
import {Order} from "@atx/commons/model";
import {stageAtom} from "./workflow";
import {createRfqsAtom} from "./rfqs";

export const orderNumbersAtom = atom<number[]>([]);

export const ordersAtom = atomWithEffects<Order[]>([], (get, set, orders) => {
    switch (get(stageAtom)) {
        case "Request":
            set(createRfqsAtom, orders);
            break;
        case "Response":
            break;
    }
});

export const findOrderAtom = atom(get => {
    const ordersByOrdNum = get(ordersAtom).reduce(
        (map, order) => map.set(order.ordNum, order),
        new Map<number, Order>()
    );
    return (ordNum: number) => ordersByOrdNum.get(ordNum);
});
