import { atom } from "jotai";
import {focusedOrderAtom, rfqsAtom} from "./rfqs";
import { stageAtom } from "./workflow";
import { basketAtom } from "./basket";
import { SpotTimeCode } from "./time";
import {Order, PricingType} from '@atx/commons'

export type Quote = {
    order: Order;
    size: number | null;
    spotTime: SpotTimeCode | null;
    priceType: PricingType | null;
};

export const quotesAtom = atom<Quote[]>((get) => {
    const stage = get(stageAtom);
    return stage === "Request" ? get(rfqsAtom) : get(basketAtom);
});

export const selectedQuoteAtom = atom<Quote | null>((get) => {
    let order = get(focusedOrderAtom);
    if (!order) {
        return null;
    } else {
        const { ordNum } = order;
        return get(quotesAtom).find((rfq) => rfq.order.ordNum === ordNum) ?? null;
    }
});
