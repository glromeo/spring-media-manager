import { atom } from "jotai";
import { DateTime, Duration } from "luxon";

const responseDurationAtom = atom<Duration>(DateTime.now().plus({ minutes: 5 }).diff(DateTime.now()));

export const responseDueInAtom = atom(
    (get) => get(responseDurationAtom),
    (get, set) => {
        set(responseDurationAtom, get(responseDurationAtom).minus({ second: 1 }));
    }
);

responseDueInAtom.onMount = (setAtom) => {
    setInterval(setAtom, 1000);
};
