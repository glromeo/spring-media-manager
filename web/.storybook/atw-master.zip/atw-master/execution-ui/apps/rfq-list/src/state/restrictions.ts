import { atom } from "jotai";
import { ordersAtom } from "./orders";
import { rfqsAtom, rfqSummaryAtom } from "./rfqs";
import { brokerAllocationsAtom, brokersAtom, requestedBrokersAtom } from "./brokers";
import { tokensAtom } from "@atx/commons/atoms";
import { Broker, BrokerAllocation, isRestricted, Order } from "@atx/commons/model";

export const isUserMifidEligibleAtom = atom<boolean>(false);

const isClientMifidEligibleAtom = atom((get) => get(tokensAtom).AladdinTraderMIFIDEligible === "true");
const isWorkflowMifidEligibleAtom = atom((get) => get(isClientMifidEligibleAtom) && get(isUserMifidEligibleAtom));

/**
 * https://webster.bfm.com/Wiki/pages/viewpage.action?pageId=689168553
 */
export const mifidEligibleOrdersAtom = atom((get) => {
    const orders = get(ordersAtom);
    if (get(isWorkflowMifidEligibleAtom)) {
        return new Set(orders.filter(({ asset }) => asset.isMiFID2Eligible));
    }
    return new Set(orders);
});

/**
 * Why allocation? The brokerAllocationsAtom is keyed by broker and meant to be used in rendering
 * the restrictions when the focus is a broker. These arrays are keyed by order, and they are meant
 * to render the restrictions when focusing on a rfq table row.
 */

export type OrderRestriction = {
    unrestricted: Set<Broker>;
    restricted: Set<Broker>;
    exclusions: Map<Broker, string>;
    allocations: BrokerAllocation[];
};

export const orderRestrictionsAtom = atom((get) => {
    const orderRestrictions = [] as OrderRestriction[];
    const mifidEligibleOrders = get(mifidEligibleOrdersAtom);
    const brokers = get(requestedBrokersAtom);
    const brokerAllocations = get(brokerAllocationsAtom);

    for (const order of get(ordersAtom)) {
        const isMifidEligible = mifidEligibleOrders.has(order);

        const unrestricted = new Set<Broker>();
        const restricted = new Set<Broker>();
        const excluded = new Map<Broker, string>();

        const allocations = [] as BrokerAllocation[];

        for (const broker of brokers) {
            if (isMifidEligible && !broker.isMifidTagEnabled) {
                excluded.set(broker, `${broker.shortName} is not MiFID enabled for ${order.asset.ticker}`);
                continue;
            }

            const allocation = brokerAllocations[broker.code]?.find((allocation) => allocation.order === order);
            if (!allocation) {
                excluded.set(broker, `${broker.shortName} has no allocations for order ${order.ordNum}`);
            } else {
                if (isRestricted(allocation)) {
                    restricted.add(broker);
                } else {
                    unrestricted.add(broker);
                }
                allocations.push(allocation);
            }
        }

        orderRestrictions.push({
            unrestricted,
            restricted,
            exclusions: excluded,
            allocations
        });
    }

    return orderRestrictions;
});

export const rfqRestrictionsAtom = atom((get) => {
    const orderRestrictions = get(orderRestrictionsAtom);
    const rfqs = get(rfqsAtom);

    const rfqRestrictions = new Map<Order, OrderRestriction>();

    orderRestrictions.forEach(({ unrestricted, restricted, exclusions, allocations }, index) => {
        exclusions = new Map(exclusions);

        const { order, priceType, spotTime } = rfqs[index];

        const predicate = (broker: Broker) => {
            if (priceType === "spread") {
                if (!broker.isSpreadFlowEnabled) {
                    exclusions.set(broker, `${broker.shortName} is not enabled for spread flow`);
                    return false;
                }
                if (spotTime !== "A" && !broker.isDelayedSpotEnabled) {
                    exclusions.set(broker, `${broker.shortName} is not enabled for delayed spot`);
                    return false;
                }
            }
            return true;
        };

        rfqRestrictions.set(order, {
            unrestricted: new Set([...unrestricted].filter(predicate)),
            restricted: new Set([...restricted].filter(predicate)),
            exclusions,
            allocations
        });
    });

    return rfqRestrictions;
});

export type BrokerSummary = {
    status: "UNRESTRICTED" | "PARTIALLY_RESTRICTED" | "FULLY_RESTRICTED" | "UNAVAILABLE";
    message: string;
    restrictions: BrokerAllocation[];
};

/**
 * rfqSummaryAtom is the result of intersecting all the rfqs e.g.
 * isMiFID2Eligible is true if all orders are true, false if all are false and null otherwise
 * this way we know that each property affects the broker selection/toggle
 * only if the value is not null... otherwise put, if isMiFID2Eligible is true
 * it means that all orders are eligible therefore the broker must have the tag to be enabled
 */

export const brokerRestrictionsAtom = atom((get) => {
    const brokerRestrictions = new Map<Broker, BrokerSummary>();
    const { isMiFID2Eligible, priceType, spotTime } = get(rfqSummaryAtom);
    const brokers = get(brokersAtom);
    const allocations = get(brokerAllocationsAtom);
    const isWorkflowMifidEligible = get(isWorkflowMifidEligibleAtom);
    for (const broker of brokers) {
        const noDesks = broker.desks.length < 1;
        const isDisabledMiFID2 = isWorkflowMifidEligible && isMiFID2Eligible && !broker.isMifidTagEnabled;
        const isDisabledPricingType = priceType === "spread" && !broker.isSpreadFlowEnabled;
        const isDisabledSpotTime = priceType === "spread" && spotTime !== "A" && !broker.isDelayedSpotEnabled;

        let message: string | undefined;
        if (noDesks) {
            message = `${broker.shortName} has no associated desks.`;
        } else if (isDisabledMiFID2) {
            message = `${broker.shortName} is not enabled for MiFID.`;
        } else if (isDisabledPricingType) {
            message = `${broker.shortName} is not enabled for spread trading.`;
        } else if (isDisabledSpotTime) {
            message = `${broker.shortName} is not enabled for delayed spotting.`;
        }

        const restrictions = allocations[broker.code]?.filter(isRestricted) ?? [];

        if (message) {
            brokerRestrictions.set(broker, {
                status: "UNAVAILABLE",
                message,
                restrictions
            });
        } else if (restrictions.length === allocations[broker.code]?.length) {
            brokerRestrictions.set(broker, {
                status: "FULLY_RESTRICTED",
                message: `${broker.shortName} is restricted across all orders.`,
                restrictions
            });
        } else {
            brokerRestrictions.set(broker, {
                status: restrictions.length ? "PARTIALLY_RESTRICTED" : "UNRESTRICTED",
                message: restrictions.length
                    ? `${broker.shortName} is restricted for ${restrictions.length} orders.`
                    : "",
                restrictions
            });
        }
    }
    return brokerRestrictions;
});
