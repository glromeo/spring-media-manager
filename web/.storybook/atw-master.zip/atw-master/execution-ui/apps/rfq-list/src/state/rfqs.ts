import {atom} from "jotai";
import {DueProtocol, Order, PricingType, Timer} from "@atx/commons/model";
import {Benchmark, bondBenchmarksAtom} from "./benchmarks";
import {BrokerDeskPairing, PlacementQuoteRequest} from "../gql/graphql";
import {brokersAtom, requestedBrokersByOrderAtom, requestedByVenueAtom, selectedDesksAtom,} from "./brokers";
import {dueAtValidationAtom, validateOrdersAtom} from "./validation";
import {pricingType} from "@atx/commons/utils/pricing-type";
import {Quote} from "./quote";
import {Duration} from "luxon";
import {atomWithEffects, matrixAtom} from "@atx/toolkit";
import {SpotTimeCode} from "./time";

export type RFQ = Quote & {
    eligibleQty: number;
    priceType: PricingType | null;
    benchmark: Benchmark | null;
};

export type RFQTime = {
    timer: Timer;
    dueAt: Date | null;
    dueIn: Duration | null;
    dueProtocol: DueProtocol;
};

export const rfqTimeAtom = atomWithEffects<RFQTime>({
    timer: "ASAP",
    dueProtocol: "Due In",
    dueAt: null,
    dueIn: Duration.fromObject({minutes: 3})
}, (get, set, current, previous) => {
    if (current.dueAt?.getTime() !== previous.dueAt?.getTime()) {
        set(dueAtValidationAtom, current.dueAt);
    }
});


export const rfqsAtom = matrixAtom([] as RFQ[], {
    key: "order",
    onChange: (get, set, changedRfqs, changedFields) => {
        const summary = get(rfqSummaryAtom);
        const benchmarks = get(bondBenchmarksAtom);
        for (const rfq of changedRfqs) {
            if (changedFields.has("priceType")) {
                if (rfq.priceType === "price") {
                    rfq.spotTime = null;
                    rfq.benchmark = null;
                } else {
                    rfq.spotTime = summary.spotTime ?? "A";
                    rfq.benchmark = benchmarks[rfq.order.asset.cusip] ?? null;
                }
            }
        }
        set(validateOrdersAtom, changedRfqs, changedFields);
    }
});

export const createRfqsAtom = atom(null, (get, set, orders: Order[]) => {
    const rfqs = new Map(get(rfqsAtom).map((rfq) => [rfq.order, rfq]));
    const benchmarks = get(bondBenchmarksAtom);
    set(
        rfqsAtom,
        orders.map((order) => {
            const existingRfq = rfqs.get(order);
            if (existingRfq) {
                return existingRfq;
            } else {
                let priceType = pricingType(order.asset.quality);
                const newRfq: RFQ = {
                    benchmark: priceType === "spread" ? benchmarks[order.asset.cusip] ?? null : null,
                    order,
                    priceType: priceType,
                    size: order.orderLeaves,
                    eligibleQty: order.orderLeaves ?? 0,
                    spotTime: priceType === "spread" ? "A" : null
                };
                return newRfq;
            }
        })
    );
});

export type RFQSummary = {
    priceType: PricingType | null,
    spotTime: SpotTimeCode | null,
    isMiFID2Eligible: boolean
};

export const rfqSummaryAtom = atom<RFQSummary>((get) => {
    const rfqs = get(rfqsAtom);
    let summary: RFQSummary = {
        priceType: rfqs[0]?.priceType ?? null,
        spotTime: rfqs[0]?.spotTime ?? null,
        isMiFID2Eligible: rfqs[0]?.order.asset.isMiFID2Eligible ?? null
    };
    for (const rfq of rfqs) {
        summary = {
            priceType: rfq.priceType === summary.priceType ? summary.priceType : null,
            spotTime: rfq.spotTime === summary.spotTime ? summary.spotTime : null,
            isMiFID2Eligible: rfq.order.asset.isMiFID2Eligible && summary.isMiFID2Eligible
        };
    }
    return summary;
});

export const placementQuotesRequest = atom<Array<PlacementQuoteRequest>>((get) => {
    const brokers = get(brokersAtom);
    const requestedBrokersByOrder = get(requestedBrokersByOrderAtom);
    const benchmarks = get(bondBenchmarksAtom);
    const requestedByVenue = Object.fromEntries(
        Object.entries(get(requestedByVenueAtom)).map(([venue, requested]) => [venue, new Set(requested)])
    );
    const selectedDesks = get(selectedDesksAtom);
    const venues = Object.keys(requestedByVenue).filter(venue => venue !== "DIRECT");
    return get(rfqsAtom).map((rfq) => {
        const benchmark = rfq.benchmark ?? benchmarks[rfq.order.asset.cusip];
        const requestedDirect = requestedByVenue.DIRECT;
        return {
            "ordNum": rfq.order.ordNum,
            "spreadIndex": benchmark?.cusip ?? null,
            "benchPrice": benchmark?.price ?? null,
            "brokers": [...requestedBrokersByOrder.get(rfq.order)!]
                .filter((b) => requestedDirect.has(b))
                .map((broker) => {
                    const {shortName, defaultDesk} = broker;
                    return {
                        broker: shortName,
                        subBrokerId: selectedDesks.get(broker)?.subBrokerID ?? defaultDesk.subBrokerID
                    } as BrokerDeskPairing;
                }),
            "venueBrokers": venues.map(venue => {
                const venueBroker = brokers.find(broker => broker.shortName === venue)!;
                return {
                    venueBroker: venue,
                    executingBrokers: [...requestedBrokersByOrder.get(rfq.order)!]
                        .filter((b) => requestedByVenue[venue].has(b))
                        .map(({shortName}) => shortName),
                    subBrokerId: selectedDesks.get(venueBroker)?.subBrokerID ?? venueBroker.defaultDesk.subBrokerID
                };
            }),
            "placementAllocationStrategy": {
                "strategy": "EXACT_AMOUNT",
                "value": rfq.size
            },
            "limitType": rfq.priceType === "spread" ? "S" : "P",
            "spotType": rfq.spotTime,
            "settleDate": rfq.order.asset.defaultSettleDate
        } as PlacementQuoteRequest;
    });
});

export const focusedRfqIndexAtom = atom<number>(-1);

export const focusedOrderAtom = atom(get => {
    const rfqs = get(rfqsAtom);
    const focusedIndex = get(focusedRfqIndexAtom);
    return focusedIndex > -1 ? rfqs[Math.min(focusedIndex, rfqs.length - 1)]?.order : null;
}, (get, set, ordNum: number|null) => {
    const rfqs = get(rfqsAtom);
    if (ordNum) {
        set(focusedRfqIndexAtom, rfqs.findIndex(({order}) => order.ordNum === ordNum));
    } else {
        set(focusedRfqIndexAtom, -1);
    }
});