import { atom } from "jotai";
import { requestedVenuesAtom, Venue } from "./brokers";
import { rfqsAtom } from "./rfqs";

export const TIME_ZONE = "America/New_York";

export const TIME_OFFSET = Intl.DateTimeFormat("ia", {
    timeZone: TIME_ZONE,
    timeZoneName: "long"
})
    .formatToParts()[6]
    .value.replace(/[a-z ]/g, "");

export type SpotTimeCode = "A" | "N" | `${0 | 1 | 2}${number}:${0 | 1 | 2 | 3 | 4 | 5}${number}`;

export type SpotTimes = Record<Venue, SpotTimeOptions>

export type SpotTimeOption = { value: SpotTimeCode, label: string };

export type SpotTimeOptions = Array<SpotTimeOption>;

export const spotTimeOptionsAtom = atom<SpotTimes>({
    "DIRECT": [{value: "A", label: "Spot Now"}],
    "TWRFQUS": [{value: "A", label: "Spot Now"}],
    "SIMTWEB": [{value: "A", label: "Spot Now"}],
})

export const spotTimeLabelsAtom = atom(get => {
    const map = new Map();
    for (const options of Object.values(get(spotTimeOptionsAtom))) {
        for (const {value, label} of options) {
            map.set(value, label);
        }
    }
    return map
})

export const availableSpotTimeOptionsAtom = atom<SpotTimeOptions, [Set<SpotTimeCode>], void>((get, {setSelf}) => {
    const spotTimeOptions = get(spotTimeOptionsAtom);
    const requestedVenues = [...get(requestedVenuesAtom)];
    if (requestedVenues.length === 0) {
        return [];
    }
    const firstVenue = requestedVenues.pop();
    if (!firstVenue) {
        return [];
    }
    let intersection: SpotTimeOptions = spotTimeOptions[firstVenue];
    if (intersection.length === 0) {
        return [];
    }
    for (const venue of requestedVenues) {
        const values = new Set(spotTimeOptions[venue].map(option => option.value));
        intersection = intersection.filter(option => values.has(option.value));
    }
    requestAnimationFrame(() => {
        setSelf(new Set(intersection.map(option => option.value)));
    })
    return intersection;
}, (get, set, availableSpotTimeValues) => {
    let rfqs = get(rfqsAtom);
    let shouldUpdate = rfqs.some(rfq => rfq.spotTime && !availableSpotTimeValues.has(rfq.spotTime));
    if (shouldUpdate) {
        set(rfqsAtom, {
            spotTime: rfq => rfq.spotTime && !availableSpotTimeValues.has(rfq.spotTime) && null || null
        });
    }
});
