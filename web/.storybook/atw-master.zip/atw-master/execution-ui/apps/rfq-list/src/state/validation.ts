import {atom} from "jotai";
import {RFQ, rfqsAtom, rfqTimeAtom} from "./rfqs";
import {formatQuantity, formatSecurity, Order} from "@atx/commons";
import {AtomGetter, AtomSetter} from "@atx/toolkit";
import {eligibleBrokersAtom, requestedBrokersAtom} from "./brokers";
import {rfqRestrictionsAtom} from "./restrictions";
import {atomRef} from "@atx/toolkit/atoms/utils/atom-ref";

export type IssueLevel = "error" | "warning" | "info"

export type QuickFix = (get: AtomGetter, set: AtomSetter) => void;

export type RfqIssue = {
    level: IssueLevel;
    message: string;
    field?: keyof RFQ
    type?: "order"|"broker"|"validation";
    quickFix?: QuickFix;
};

type IssueType = keyof RFQ | "broker" | "validation";

function toIssue(type:IssueType, level: IssueLevel, message: string, quickFix?: QuickFix): RfqIssue {
    switch (type) {
        case "broker":
        case "validation":
            return {
                type,
                level,
                message,
                quickFix
            }
        default:
            return {
                field: type,
                type: "order",
                level,
                message,
                quickFix
            }
    }
}

function toError(order: Order, type: IssueType, message: string, quickFix?: QuickFix): RfqIssue {
    return toIssue(type, "error", message, (get, set) => set(rfqsAtom, order, "delete"));
}

function toWarning(order: Order, type: IssueType, message: string, quickFix?: QuickFix): RfqIssue {
    return toIssue(type, "warning", message, (get, set) => set(rfqsAtom, order, "delete"));
}

export const dueAtTimeout = atom<any>(0);
export const dueAtExpired = atom<boolean>(false);

export const dueAtValidationAtom = atom((get): RfqIssue | undefined => {
    const {dueProtocol, dueAt} = get(rfqTimeAtom);
    if (dueProtocol === "Due At") {
        if (dueAt === null) {
            return {level: "error", message: "You must provide a due at time"};
        }
        if (get(dueAtExpired)) {
            return {level: "error", message: "You must provide a due at time in the future"};
        }
    }
}, (get, set, dueAt: Date | null) => {
    clearTimeout(get(dueAtTimeout));
    set(dueAtExpired, false);
    if (dueAt) {
        const timeout = Math.max(dueAt.getTime() - Date.now(), 0);
        set(dueAtTimeout, setTimeout(() => set(dueAtExpired, true), timeout));
    }
});

export const orderIssuesAtom = atomRef(new Map<Order, RfqIssue[]>());
export const validationIssuesAtom = atomRef(new Map<Order, RfqIssue[]>());
export const brokerIssuesAtom = atom(get => {
    const rfqs = get(rfqsAtom);
    const eligibleBrokers = get(eligibleBrokersAtom);
    const restrictions = get(rfqRestrictionsAtom);
    const issues = new Map<Order, RfqIssue[]>();
    for (const {order} of rfqs) {
        const eligible = eligibleBrokers.get(order)!;
        const {restricted, exclusions} = restrictions.get(order)!;
        const found = [] as RfqIssue[];
        if (!eligible?.size) found.push(toError(order, "broker", "No eligible brokers"));
        if (restricted?.size) found.push(toWarning(order, "broker", "Some brokers are restricted"));
        if (exclusions?.size) found.push(toWarning(order, "broker", "Some brokers are excluded"));
        if (found?.length) {
            issues.set(order, found);
        }
    }
    return issues;
});

const issueLevelComparator = (l: RfqIssue, r: RfqIssue) => {
    switch (l.level) {
        case "error":
            return r.level === "error" ? 0 : -1;
        case "warning":
            return r.level === "error" ? 1 : r.level === "warning" ? 0 : -1;
        default:
            return r.level === "error" || r.level === "warning" ? 1 : 0;
    }
};

export const rfqIssuesAtom = atom<Map<Order, RfqIssue[]>>(get => {
    const rfqs = get(rfqsAtom);
    const orderIssues = get(orderIssuesAtom);
    const backendIssues = get(validationIssuesAtom);
    const brokerIssues = get(brokerIssuesAtom);
    const issues = new Map<Order, RfqIssue[]>();
    for (const {order} of rfqs) {
        const found = [] as RfqIssue[];
        found.push(...(orderIssues.get(order) ?? []))
        found.push(...(backendIssues.get(order) ?? []))
        found.push(...(brokerIssues.get(order) ?? []).slice(0, 1))
        if (found?.length) {
            found.sort(issueLevelComparator)
            issues.set(order, found)
        }
    }
    return issues;
});

export const requestIssuesAtom = atom((get): RfqIssue[] => {
    const issues = [] as (RfqIssue | undefined)[];

    const rfqs = get(rfqsAtom);
    if (!rfqs.length) {
        issues.push({level: "error", message: "No orders requested"});
    }

    const requestedBrokers = get(requestedBrokersAtom);
    if (!requestedBrokers.length) {
        issues.push({level: "error", message: "No brokers requested"});
    }

    issues.push(get(dueAtValidationAtom));


    return issues.filter(issue => issue) as RfqIssue[];
});

export const requestValidationSummaryAtom = atom(get => {
    let errors = [] as string[];
    let warnings = [] as string[];
    let infos = [] as string[];
    for (let {level, message} of get(requestIssuesAtom)) {
        switch (level) {
            case "error":
                errors.push(message!);
                continue;
            case "warning":
                warnings.push(message!);
                continue;
            default:
                infos.push(message!);
        }
    }
    const rfqIssues = get(rfqIssuesAtom);
    for (const {order} of get(rfqsAtom)) {
        const issues = rfqIssues.get(order);
        if (issues) for (const issue of issues) {
            if (issue) {
                const text = `${issue.message ?? issue.level} for <b>${formatSecurity(order.asset)}</b>`;
                switch (issue.level) {
                    case "error":
                        errors.push(text);
                        continue;
                    case "warning":
                        warnings.push(text);
                        continue;
                    default:
                        infos.push(text);
                }
            }
        }
    }
    return {
        errors,
        warnings,
        infos
    };
}, (get, set, action: "QuickFix") => {
    switch (action) {
        case "QuickFix": {
            get(requestIssuesAtom).forEach(({quickFix}) => quickFix?.(get, set));
            // get(rfqIssuesAtom).forEach(({quickFix}) => quickFix?.(get, set));
        }
    }
});

export const validateOrdersAtom = atom(null, (get, set, changedRfqs: RFQ[], changedFields: Set<keyof RFQ>) => {

    const validationIssues = get(validationIssuesAtom);
    for (const {order} of changedRfqs) {
        const issues = validationIssues.get(order)?.filter(({field}) => field && changedFields.has(field));
        if (issues?.length) {
            validationIssues.set(order, issues);
        } else {
            validationIssues.delete(order);
        }
    }
    set(validationIssuesAtom, validationIssues);

    const orderIssues = get(orderIssuesAtom);
    for (const rfq of changedRfqs) {
        const issues = validateOrder(rfq);
        if (issues?.length) {
            orderIssues.set(rfq.order, issues);
        } else {
            orderIssues.delete(rfq.order);
        }
    }
    set(orderIssuesAtom, orderIssues);
});

function validateOrder(rfq: RFQ): RfqIssue[] {
    let issues = [] as (RfqIssue | undefined)[];
    issues.push(validateQty(rfq));
    issues.push(validateBenchmark(rfq));
    issues.push(validateSpotTime(rfq));
    return issues.filter((result) => result) as RfqIssue[];
}

function validateQty(rfq: RFQ): RfqIssue | undefined {
    const {order, size, eligibleQty} = rfq
    const {side} = order;
    if (size === null || isNaN(size)) {
        return toError(order, "size", "Not a valid quantity");
    }
    if (!eligibleQty) {
        return toError(order, "size", "Nothing left on this order");
    }
    if (!size) {
        return toError(order, "size", "Quantity must be greater than zero");
    }
    if (Math.abs(size) > Math.abs(eligibleQty)) {
        return toError(order, "size", `Quantity must be less or equal to ${formatQuantity(eligibleQty)}`);
    }
    if (side === "BUY" && size < 0) {
        return toError(order, "size", `Quantity must be positive`);
    }
    if (side === "SELL" && size > 0) {
        return toError(order, "size", `Quantity must be negative`);
    }
    if (size % 1) {
        return toError(order, "size", `Fractions are not allowed`);
    }
}

function validateBenchmark({benchmark, order, priceType}: RFQ): RfqIssue | undefined {
    if (priceType === "spread" && !benchmark) {
        return toError(order, "benchmark", "Missing benchmark");
    }
    if (priceType === "spread" && benchmark  && !benchmark.price) {
        return toWarning(order, "benchmark", `Missing price for benchmark ${benchmark.description}`);
    }
}

function validateSpotTime({order, priceType, spotTime}: RFQ): RfqIssue | undefined {
    if (priceType === "spread" && !spotTime) {
        return toError(order, "spotTime", "Missing Spot Time");
    }
}
