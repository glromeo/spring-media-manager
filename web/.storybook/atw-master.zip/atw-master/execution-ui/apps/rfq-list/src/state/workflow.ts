import { atom } from "jotai";
import { hasSearchParam, searchParam } from "@atx/toolkit/utils";

export const STAGES = ["Request", "Response"];

export const STEPS: Step[] = ["Request", "Validation", "Confirmation", "Response"];

export type Step = "Request" | "Validation" | "Confirmation" | "Response";

export const stepIndexAtom = atom<number>(hasSearchParam("step") ? parseInt(searchParam("step")!) : 0);

export const stepAtom = atom<Step, [Step], void>(
    (get) => {
        return STEPS[get(stepIndexAtom)];
    },
    (get, set, step: Step) => {
        const index = STEPS.indexOf(step);
        if (index >= 0) {
            set(stepIndexAtom, index);
        } else {
            throw new Error(`Invalid step: ${step}`);
        }
    }
);

export const stageAtom = atom(
    (get) => (get(stepIndexAtom) < STEPS.indexOf("Response") ? "Request" : "Response"),
    (get, set, stage: "Request" | "Response") => {
        set(stepIndexAtom, STEPS.indexOf(stage));
    }
);
