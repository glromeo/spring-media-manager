import React from "react";
import { AtxApp, AtxSettings, AtxTitleBar } from "@atx/toolkit";
import { ListRFQ } from "../src/components/list-rfq";
import { OrderDetailsSettingsTab } from "../src/components/settings/order-details-settings-tab";
import { css } from "@atx/stories";

import "../src/components/list-rfq.scss";

// language=css
css`
    .fixture {
        height: 100%;
        width: 100%;
    }
`;

export default () => {
    return (
        <AtxApp atoms={{}}>
            <AtxTitleBar />
            <ListRFQ />
            <AtxSettings>
                <OrderDetailsSettingsTab tab-title="Order Details" />
            </AtxSettings>
        </AtxApp>
    );
};
