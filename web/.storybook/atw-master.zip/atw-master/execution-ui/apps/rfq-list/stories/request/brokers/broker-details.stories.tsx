import { BrokerDetails, BrokerToggle } from "../../../src/components/body/tabs/brokers";
import { useAtom, useAtomValue } from "jotai";
import { Broker, tokensAtom } from "@atx/commons";
import { useParameter } from "@atx/stories";
import { useEffect } from "react";
import { configurationsAtom } from "../../../src/state/configurations";
import { brokerAllocationsAtom, brokersAtom } from "../../../src/state/brokers";

export default () => {

    let [AladdinTraderMIFIDEligible] = useParameter<"true" | "false">(
        "AladdinTraderMIFIDEligible",
        ["true", "false"],
        "true"
    );
    let [tokens, setTokens] = useAtom(tokensAtom);

    let [userMifidEligibility] = useParameter<"true" | "false">("userMifidEligibility", ["true", "false"], "true");
    let [configurations, setConfigurations] = useAtom(configurationsAtom);

    useEffect(() => {
        setTokens({ ...tokens, AladdinTraderMIFIDEligible });
        setConfigurations({ ...configurations, userMifidEligibility });
    }, [AladdinTraderMIFIDEligible]);

    let style = { border: "1px solid lightgray", background: "white", margin: 10 };
    const brokers = useAtomValue(brokersAtom);
    const allocations = useAtomValue(brokerAllocationsAtom);

    return brokers.length ? (
        <div className="flex-column">
            <div className="flex-row" style={{ alignItems: "start" }}>
                <div style={style}>
                    <BrokerToggle broker={{} as Broker} selected={false} onDeskSelection={console.log} />
                </div>
                <div style={{ ...style, flexGrow: 1 }}>
                    <BrokerDetails broker={{} as Broker} allocations={[]} />
                </div>
            </div>
            {brokers.map((broker, index) => (
                <div className="flex-row" key={index} style={{ alignItems: "start" }}>
                    <div style={style}>
                        <BrokerToggle broker={broker} selected={false} onDeskSelection={console.log} />
                    </div>
                    <div style={{ ...style, flexGrow: 1 }}>
                        <BrokerDetails broker={broker} allocations={allocations[broker.code] ?? []} />
                    </div>
                </div>
            ))}
        </div>
    ) : null;
};
