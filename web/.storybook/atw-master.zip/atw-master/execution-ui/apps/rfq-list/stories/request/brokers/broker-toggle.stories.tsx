import { TipIcon } from "../../../src/components/body/tabs/brokers/broker-tips";
import { BrokerToggle } from "../../../src/components/body/tabs/brokers";
import { useState } from "react";

export const ICON_TIPS = () => (
    <div className="flex-column">
        <div className="flex-row">
            <TipIcon level="info" popup={() => `This is an INFO Tip!`} />
        </div>
        <div className="flex-row">
            <TipIcon level="warning" popup={() => `This is an WARN Tip!`} />
        </div>
        <div className="flex-row">
            <TipIcon level="danger" popup={() => `This is an DANGER Tip!`} />
        </div>
    </div>
);

export const BROKER_TOGGLE = () => {
    const [selectedBrokers, setSelectedBrokers] = useState<Record<string, boolean>>({});
    let desks = [{
        subBrokerID: 0,
        salesman: "S",
        brokerCode: 0,
        brokerType: "T"
    }];
    return (
        <div className="flex-column" style={{ margin: 16 }}>
            <div className="flex-row" style={{ backgroundColor: "white", padding: 16, margin: "1px solid lightgray" }}>
                <BrokerToggle
                    broker={{
                        code: 0,
                        name: "Broker One",
                        shortName: "BRK-1",
                        desks: desks,
                        defaultDesk: desks[0],
                        isMifidTagEnabled: false,
                        isCounteringEnabled: false,
                        isDelayedSpotEnabled: false,
                        isSpreadFlowEnabled: false
                    }}
                    onChange={(selected) => {
                        console.log("onChange selected:", selected);
                        setSelectedBrokers({ ...selectedBrokers, TST_BRK_1: selected });
                    }}
                    selected={selectedBrokers["TST_BRK_1"]}
                    onDeskSelection={(brokers) => console.log("onDeskSelection brokers:", brokers)}
                />
            </div>
        </div>
    );
};
