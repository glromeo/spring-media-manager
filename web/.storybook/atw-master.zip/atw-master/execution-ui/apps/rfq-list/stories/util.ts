import { DueProtocol, PricingType, Timer } from "@atx/commons/model";

type Randomizer<T> = () => T;

export const randomPriceType: Randomizer<PricingType> = () => (Math.random() > 0.5 ? "price" : "spread");

export const randomDueProtocol: Randomizer<DueProtocol> = () => (Math.random() > 0.5 ? "Due At" : "Due In");

export const randomTimer: Randomizer<Timer> = () => (Math.random() > 0.5 ? "ASAP" : "Bin");

export const randomDueIn: Randomizer<string | null> = () => {
    return null;
};

export const randomDueAt: Randomizer<string | null> = () => {
    return null;
};
