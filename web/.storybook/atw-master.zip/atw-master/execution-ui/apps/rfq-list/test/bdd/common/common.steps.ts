/// <reference types="cypress" />

// https://www.npmjs.com/package/cypress-cucumber-preprocessor

import { Given, When } from "cypress-cucumber-preprocessor/steps";
import { TableDefinition } from "cypress-cucumber-preprocessor";

export const testUser = "test";

Given("I selected the following rows in dashboard", function (this, table: TableDefinition) {
    this.message = {text:"hello"};
    // await page.route("*/**/api/bfm-cef", async (route) => {
    //     const json = {
    //         READY: [] as { ordNum: number, cusip: string }[],
    //         MKTXS_BENCHMARKS: {} as Record<string, string>
    //     };
    //     for (const [ordNum, cusip] of table.rows()) {
    //         json.READY.push({
    //             ordNum: parseInt(ordNum),
    //             cusip: cusip
    //         });
    //     }
    //     await route.fulfill({json});
    // });
});

When("I open create RFQ", function (this) {
    console.log(this.message)
    cy.visit(`localhost:3070/apps/at-rfq-list/index.html?user=${testUser}&bfm-cef=auto`);
    // await expect(page).toHaveTitle(/RFQ List/);
});

When("I keep the browser open", function () {
    // await new Promise(resolve => setTimeout(resolve, 1_000_000));
})