/// <reference types="cypress" />

import { Given, When, Then } from "cypress-cucumber-preprocessor/steps";

Then(/^I get a order list with (\d+) entries$/, function (entries: number) {
    console.log("entries !!!", entries);
});

Then(/^I can see '([^']+)' in the ([\w]+) column$/, function (ticker: string, column: string) {
    console.log("ticker", ticker);
    console.log("column", column);
});

Then(/Bond '([^']+)' has (Spread|Price) protocol/, async (ticker: string, protocol: string) => {
    // await expect(page.locator(".atx-grid-row", {hasText: ticker})).toHaveCount(2);
    // await expect(page.locator(".atx-grid-row", {hasText: ticker}).getByTestId("protocol")).toHaveAttribute("checked", protocol.toLowerCase());
})