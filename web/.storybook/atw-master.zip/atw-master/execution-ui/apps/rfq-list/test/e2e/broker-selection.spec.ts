/// <reference types="cypress" />

context("broker selection", () => {

    beforeEach(()=>{
        cy.visit(
            "http://localhost:3070/apps/at-rfq-list/index.html?user=test&bfm-cef=202310230000"
        );
    })

    it("broker tab should always be shown by default", ()=> {
        cy.get(".request-section .details-section .atx-tab-tag.selected").contains("Brokers");
    });

    it("broker tab applies to all orders", ()=>{
        cy.get('[data-test-id="broker-selection"] .direct-brokers-selection > .broker-tile').then($tiles => expect($tiles.length).to.eq(7));
        cy.get('[data-test-id="broker-selection"] .direct-brokers-selection > .broker-tile.disabled').should('not.exist');
        cy.get('[data-test-id="broker-selection"] .direct-brokers-selection > .broker-tile.selected').then($tiles => expect($tiles.length).to.eq(7));

        cy.get('[data-test-id="broker-selection"] .venue-brokers-selection > .broker-tile').then($tiles => expect($tiles.length).to.eq(5));
        cy.get('[data-test-id="broker-selection"] .venue-brokers-selection > .broker-tile.disabled').should('not.exist');
        cy.get('[data-test-id="broker-selection"] .venue-brokers-selection > .broker-tile.selected').should('not.exist');
    });

    /*
    Broker tab should always be shown by default. Broker tab applies to all orders.
Updates to the Broker component apply to all orders. On each order row, the # of brokers requested is the max # eligible for that given order.
Hide Restricted - This checkbox should be grayed out and unchecked. We do not want to offer this feature to the users but want to show it for consistency.
Select Axed broker -  This checkbox should be grayed out and unchecked. This is a day 2 feature.
Presets - Remove for now? Day 2 feature?
Direct Brokers: Count of number of eligible direct brokers available to who are eligible to select for List RFQ.
Direct eligible broker names
D icon?
Venue - Allows the user to select Brokers to request from the Venue API.
Select All - selects all brokers in this box
If a Direct broker is selected via the Venue box, unselect in Direct and vice versa. (We will never allow the user to select a Direct broker in more than one way.)
All to All Network - Remove for now? Day 2 feature?
This wuill be covered in another feature can be skipped.
Brokers are clickable in this box unless there is a uniform issue that would prevent it from being clicked for all orders, i.e. all orders are in Spread mode and broker X is not enabled for spread-flow trading.
What if brokers don't have valid desk info?
Is there a MFID check needed here?
Broker Restrictions:
If the broker has a restriction for any order, there is a tooltip icon that represents the most severe restriction for any order. Hovering on the icon shows all of the restrictions for that broker for all orders.
Multiple desks:
Three dots shown for brokers with >1 desk. Clicking on this triggers the Desk Selection popup for that broker.
On Next -> if the user hasn't selected a desk for at least one broker, we show the Desk Selection popup as in SO RFQ?
     */
});
