context("request page", () => {

    before(() => {
        cy.visit("http://localhost:3070/apps/at-rfq-list/index.html?user=test&bfm-cef=202310230000");
    })

    it("given a well defined row I can see order details as expected", () => {
        cy.get(`[data-test-id="order-details"]`).should('not.exist');
        cy.get(`[row-index="0"]`)
            .should('have.class', 'selected')
            .and('contain.text', '607556711')
        cy.get(`[data-test-id="request-tabs"] [tab-title="Order Details"]`).click();
        cy.get(`[data-test-id="order-details"]`)
            .should('be.visible');

        cy.get(`[data-test-id="order-details"] .order-field`)
            .should('have.length', 13)
            .then($fields => {
                const expected = [
                    ['Side', 'You BUY'],
                    ['Bond', 'T 4.45 4/1/24'],
                    ['Security Bmk', 'TNOTE 0.125% 12/15/23'],
                    ['CCY', 'USD'],
                    ['CUSIP', '00206RDC3'],
                    ['ISIN', 'US00206RDC34'],
                    ['Original Size', '443,000'],
                    ['Unbooked Amt', '443,000'],
                    ['Order Leaves', '443,000'],
                    ['Limit', '-'],
                    ['Limit Type', '-'],
                    ['Instructions', '-'],
                    ['Trading Bmk', '-']
                ];
                $fields.each((i, field) => {
                    const [label, value] = expected[i];
                    expect(field.innerText)
                        .to.contain(label)
                        .and.contain(value)
                });
            });

        cy.get(`[row-index="1"] [column-index="0"]`)
            .click();

        cy.get(`[row-index="1"]`)
            .should('have.class', 'selected')
            .and('contain.text', '762697409')

        cy.get(`[data-test-id="order-details"] .order-field`)
            .should('have.length', 13)
            .then($fields => {
                const expected = [
                    ['Side', 'You SELL'],
                    ['Bond', 'UAL 4.625 4/15/29'],
                    ['Security Bmk', 'N/A'],
                    ['CCY', 'USD'],
                    ['CUSIP', '90932LAH0'],
                    ['ISIN', 'US90932LAH06'],
                    ['Original Size', '6,000'],
                    ['Unbooked Amt', '6,000'],
                    ['Order Leaves', '-6,000'],
                    ['Limit', '-'],
                    ['Limit Type', '-'],
                    ['Instructions', '-'],
                    ['Trading Bmk', '-']
                ];
                $fields.each((i, field) => {
                    const [label, value] = expected[i];
                    expect(field.innerText)
                        .to.contain(label)
                        .and.contain(value)
                });
            });
    });
});