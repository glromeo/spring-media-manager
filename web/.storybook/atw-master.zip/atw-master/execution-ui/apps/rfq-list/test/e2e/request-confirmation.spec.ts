/// <reference types="cypress" />

context("request confirmation", () => {

    before(() => {
        cy.visit("http://localhost:3070/apps/at-rfq-list/index.html?user=test&bfm-cef=202310230000&step=2");
    });

    it("grid checks", ()=>{
        cy.get('[data-test-id="confirmation-grid"] [row-index="0"] [column-index="0"]').should('have.text', "BUY");
        cy.get('[data-test-id="confirmation-grid"] [row-index="0"] [column-index="0"] .atx-grid-cell-content')
            .then($content => {
                expect(getComputedStyle($content[0]).color).to.eq('rgb(0, 94, 155)');
            });
        cy.get('[data-test-id="confirmation-grid"] [row-index="3"] [column-index="0"] .atx-grid-cell-content')
            .then($content => {
                expect(getComputedStyle($content[0]).color).to.eq('rgb(188, 3, 0)');
            });
        cy.get('[data-test-id="confirmation-grid"] [row-index="0"] [column-index="1"]').should('have.text', "DISH 5.125 6/1/29");
        cy.get('[data-test-id="confirmation-grid"] [row-index="0"] [column-index="2"]').should('have.text', "7,000");
        cy.get('[data-test-id="confirmation-grid"] [row-index="0"] [column-index="3"]').should('have.text', "Price");
        cy.get('[data-test-id="confirmation-grid"] [row-index="1"] [column-index="3"]').should('have.text', "Spread");
        cy.get('[data-test-id="confirmation-grid"] [row-index="0"] [column-index="4"]').should('have.text', "N/A");
        cy.get('[data-test-id="confirmation-grid"] [row-index="1"] [column-index="4"]').should('have.text', "Spot Now");
        cy.get('[data-test-id="confirmation-grid"] [row-index="0"] [column-index="5"]').should('have.text', "(2) SIMCS SIMBNP");
        cy.get('[data-test-id="confirmation-grid"] [row-index="1"] [column-index="5"]').should('have.text', "(1) SIMBNP");
        cy.get('[data-test-id="confirmation-grid"] [row-index="3"] [column-index="5"]').should('have.text', "(3) CGLTD SIMCS SIMBNP");
    });

    it("final Confirmation statement", ()=> {
        cy.get('[data-test-id="confirm-message"]').should('have.text', 'Would you like to proceed?')
    });

});