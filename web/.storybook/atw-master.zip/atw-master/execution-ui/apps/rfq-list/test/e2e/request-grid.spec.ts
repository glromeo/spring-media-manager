/// <reference types="cypress" />

import { formatSecurity, parseQuantity } from "@atx/commons/utils";

const {data: {fiOrderListSummary: {fiOrderSummaries}}} = require("../fixtures/order-list-summary/202310230000.json")
const {data: {fiAssetList}} = require("../fixtures/asset-list/202310230000.json")


context("request grid", () => {

    before(() => {
        cy.visit("http://localhost:3070/apps/at-rfq-list/index.html?user=test&bfm-cef=202310230000");
    });

    it("one row per order", () => {
        const expected = fiOrderSummaries.length;
        cy.get(`.atx-grid-row .atx-grid-cell [data-field="ordNum"]`).should('have.length', expected);
    });

    it("first order is always selected", () => {
        cy.get(`.atx-grid-row:first-child`).should('have.class', 'selected');
    });

    it("first order is always selected", () => {
        cy.get(`.atx-grid-row:first-child`).should('have.class', 'selected');
    });

    it("orders will load with whatever order they were highlighted in from Orders", () => {
        const expected = fiOrderSummaries.map(({order}) => String(order.ordNum));
        cy.get(`.atx-grid-row .atx-grid-cell [data-field="ordNum"]`).then($rfqs => {
            return $rfqs.map((index, el) => expect(el.innerText).to.eq(expected[index], `same ordNum at row: ${index}`))
        })
    });

    it("User has the ability to sort any of the column via normal column clicking", () => {

        cy.get(`.atx-grid-header .atx-grid-cell[column-field="ordNum"] .sort`).should('not.exist');
        cy.get(`.atx-grid-header .atx-grid-cell[column-field="ordNum"]`).click();
        cy.get(`.atx-grid-row .atx-grid-cell [data-field="ordNum"]`).then($rfqs => {
            const expected = fiOrderSummaries.map(({order}) => String(order.ordNum)).sort();
            $rfqs.map((index, el) => expect(el.innerText).to.eq(expected[index], `same ordNum at row: ${index}`))
        });

        cy.get(`.atx-grid-header .atx-grid-cell[column-field="asset"]`).click();
        cy.get(`.atx-grid-row .atx-grid-cell [data-field="asset"]`).then($rfqs => {
            const securities = new Map(
                fiAssetList.map(({cusip, couponValue: coupon, bAsset: {ticker, maturity}}) => {
                    return [cusip, formatSecurity({ticker, coupon, maturity})];
                })
            );
            const expected = fiOrderSummaries.map(({order}) => securities.get(order.cusip)).sort();
            $rfqs.map((index, el) => expect(el.innerText).to.eq(expected[index], `same asset at row: ${index}`))
        });

        cy.get(`.atx-grid-header .atx-grid-cell[column-field="side"]`)
            .click()
            .click();
        cy.get(`.atx-grid-row .atx-grid-cell [data-field="side"]`).then($rfqs => {
            const expected = fiOrderSummaries.map(({order}) => String(order.effectiveTranType)).sort().reverse();
            $rfqs.map((index, el) => expect(el.innerText).to.eq(expected[index], `same side at row: ${index}`))
        });

        cy.get(`.atx-grid-header .atx-grid-cell[column-field="size"]`).click();
        cy.get(`.atx-grid-row .atx-grid-cell [data-test-id="size"] input`).then($rfqs => {
            // initialized with the order leaves
            const expected = fiOrderSummaries.map(({order}) => String(order.orderLeaves)).sort();
            $rfqs.map((index, el) => {
                const quantity = String(parseQuantity((el as HTMLInputElement).value));
                return expect(quantity).to.eq(expected[index], `same size at row: ${index}`);
            })
        });

        cy.get(`.atx-grid-header .atx-grid-cell[column-field="priceType"]`).click();
        cy.get(`.atx-grid-row .atx-grid-cell [data-test-id="protocol"]`).then($rfqs => {
            const expected = ["spread", "price", "spread", "price", "price", "price", "price"].sort();
            $rfqs.map((index, el) => {
                const protocol = el.getAttribute("data-checked");
                return expect(protocol).to.eq(expected[index], `same protocol at row: ${index}`);
            })
        });

        cy.get(`.atx-grid-header .atx-grid-cell[column-field="spotTime"]`).click();
        cy.get(`.atx-grid-row .atx-grid-cell [data-test-id="spot-time"]`).then($rfqs => {
            const expected = ["A", "null", "A", "null", "null", "null", "null"].sort();
            $rfqs.map((index, el) => {
                const spotTime = el.getAttribute("data-value");
                return expect(spotTime).to.eq(expected[index], `same spot-time at row: ${index}`);
            })
        });

        cy.get(`.atx-grid-header .atx-grid-cell[column-field="benchmark"]`).click();
        cy.get(`.atx-grid-row .atx-grid-cell [data-test-id="benchmark"]`).then($rfqs => {
            const expected = ["TNOTE 0.125 12/15/23", "null", "TNOTE 0.125 12/15/23", "null", "null", "null", "null"].sort();
            $rfqs.map((index, el) => {
                const benchmark = el.getAttribute("data-value");
                return expect(benchmark).to.eq(expected[index], `same benchmark at row: ${index}`);
            })
        });
    });

    context("validation", () => {

        before(() => {
            cy.visit("http://localhost:3070/apps/at-rfq-list/index.html?user=test&bfm-cef=202310230000&NO_VRT");
            cy.wait(250); // This is to let benchmarks settle...
        });

        it("size is required", () => {
            cy.get(`[data-test-id="size"] input`).first().clear().blur();
            cy.wait(50); // This is bue to a re-parenting bug in AtxTooltip
            cy.get(`[data-test-id="size"] input`).first()
                .should('have.class', 'error')
                .closest('.atx-grid-row')
                .should('have.class', 'danger');
        })

        it("can type numbers with M/MM", () => {
            cy.get(`[data-test-id="size"] input`).first().clear().type("10M").blur();
            cy.wait(50); // This is bue to a re-parenting bug in AtxTooltip
            cy.get(`[data-test-id="size"] input`).first()
                .should('not.have.class', 'error')
                .and('have.value', '10,000');
            cy.get(`[data-test-id="size"] input`).first().clear().type("2MM").blur();
            cy.wait(50); // This is bue to a re-parenting bug in AtxTooltip
            cy.get(`[data-test-id="size"] input`).first()
                .should('have.class', 'error')
                .and('have.value', '2,000,000');
        });

        it("no decimals", () => {
            cy.get(`[data-test-id="size"] input`).first().clear().type("1000.5").blur();
            cy.wait(50); // This is bue to a re-parenting bug in AtxTooltip
            cy.get(`[data-test-id="size"] input`).first()
                .should('have.class', 'error')
                .and('have.value', '1,000.5');
            cy.get(`[data-test-id="size"] [data-test-id="clear"] svg`).click();
            cy.get(`[row-index="0"]`).should('not.have.class', 'danger');
        });

        it("benchmark is carried over from respective order", () => {
            cy.get(`[row-index="0"] [data-test-id="protocol"]`).should('have.attr', 'data-checked', 'spread');
            cy.get(`[row-index="0"] [data-test-id="benchmark"] input`).first()
                .should('have.value', 'TNOTE 0.125 12/15/23');
        });

        it("initialized based on existing RFQ logic to fetch prices", () => {
            cy.get(`[row-index="0"] [data-test-id="benchmark"] input`).first().closest(".benchmark-cell")
                .should('have.attr', 'data-price', "111.204822")
                .and('have.attr', 'data-source', "Aladdin");
        });

        it("benchmark is required", () => {
            cy.get(`[row-index="0"] [data-test-id="benchmark"] [data-test-id="clear"] svg`).click();
            cy.wait(50);
            cy.get(`[row-index="0"] [data-test-id="benchmark"] input`).first()
                .should('have.class', 'error')
                .closest('.atx-grid-row')
                .should('have.class', 'danger');
        });

        it("user should be able to add the BMK details", () => {
            cy.get(`[row-index="0"] [data-test-id="benchmark"] input`).first().type("tre");
            cy.wait(150);
            cy.get(`.atx-lookup-option .atx-lookup-cell[title="TREASURY NOTE 1.625 15-MAY-2031"]`)
                .should('have.text', 'TREASURY NOTE 1.625 15-MAY-2031')
                .click();
            cy.get(`[row-index="0"] [data-test-id="benchmark"] input`).first()
                .should('have.value', 'TREASURY NOTE 1.625 5/15/31')
        });
    });

    context("brokers requested (at row level)", () => {

        it("If any broker selected is ineligible for that order, that row will have an icon representing just a restriction (i.e. warning)", () => {
            cy.get(`[row-index="0"] [data-test-id="brk-req"] [data-test-id="count"]`).should("have.text", "1");
            cy.get(`[row-index="0"] [data-test-id="brk-req"] .atx-icon`).should("have.class", "warning");
        });

        it("If all brokers selected are ineligible for that order, that row will have an icon representing the most severe restriction.", () => {
            cy.get(`[row-index="0"] [data-test-id="brk-req"] [data-test-id="count"]`).should("have.text", "0");
            cy.get(`[row-index="1"] [data-test-id="brk-req"] .atx-icon`).should("have.class", "danger");
        });

    });

});