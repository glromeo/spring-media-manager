/// <reference types="cypress" />

context("request page", () => {

    before(() => {
        cy.visit("http://localhost:3070/apps/at-rfq-list/index.html?user=test&bfm-cef=202310230000");
    })

    it("page checks", ()=>{
        cy.title().should('eq', 'RFQ List');

        cy.get('[data-test-id="next-button"]')
            .should('have.text', "Next")
            .should('be.disabled');

        cy.get('[data-test-id="cancel-button"]')
            .should('have.text', "Cancel List RFQ")
            .should('not.be.disabled');

        cy.get('atx-notification')
            .should('not.exist');
    });

    it("stepper should show either Request or Response depending on what page we are in", () => {
        cy.get('[data-test-id="rfq-stepper"]').get(".aux-progress-stepper__step-button-active", {includeShadowDom: true}).contains("Request");
        cy.get('[data-test-id="rfq-stepper"]').get(".aux-progress-stepper__step-button-disabled", {includeShadowDom: true}).contains("Response");
    });

    it("ribbon summary checks", ()=> {
        cy.get('[data-test-id="buy-order-totals"]').should('have.text', "3 / 893,000");
        cy.get('[data-test-id="buy-order-totals"]')
        cy.get('[data-test-id="sell-order-totals"]').should('have.text', "4 / -17,000");

        let sell = cy.get('[data-test-id="orders-grid"] [row-index="1"] [column-index="3"] input');
        sell.should('have.value', '-6,000');
        sell.focus();
        sell.clear();
        sell.type("-3000");
        sell.blur();

        let buy = cy.get('[data-test-id="orders-grid"] [row-index="2"] [column-index="3"] input');
        buy.should('have.value', '443,000');
        buy.focus();
        buy.clear();
        buy.type("430000");
        buy.blur();
    });

    it("ribbon color checks (BUY is blue, SELL is red)", ()=>{
        cy.get('.ribbon-section .atx-badge').then(($badges) => {
            expect(getComputedStyle($badges[0]).backgroundColor).eq('rgb(0, 122, 201)');
            expect(getComputedStyle($badges[1]).backgroundColor).eq('rgb(217, 4, 0)');
        });
    });

    it("ribbon should show the max number of brokers requested", ()=> {
        cy.get('.ribbon-section [data-test-id="brokers-requested"]')
            .should('contain.text', 'Brokers Requested')
            .should('contain.text', '7');
    });

    it("grid checks", ()=>{
        cy.get('[data-test-id="orders-grid"] [row-index="0"] [column-index="1"]').should('have.text', "T 4.45 4/1/24");
        cy.get('[data-test-id="orders-grid"] [row-index="1"] [column-index="1"]').should('have.text', "UAL 4.625 4/15/29");
        cy.get('[data-test-id="orders-grid"] [row-index="4"] [column-index="1"]').should('have.text', "DISH 5.125 6/1/29");
        cy.get('[data-test-id="orders-grid"] [row-index="0"] [column-index="2"]').should('have.text', "BUY");
        cy.get('[data-test-id="orders-grid"] [row-index="1"] [column-index="2"]').should('have.text', "SELL");
    });
});
