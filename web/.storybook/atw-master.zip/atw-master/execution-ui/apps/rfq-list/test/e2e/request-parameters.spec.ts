/// <reference types="cypress" />

context("request parameters", () => {

    // These parameters should overwrite any "row-level" selection for applicable orders.
    // The parameters should be "filled in" or "selected" if all orders are uniform for that parameter.

    context("pricing protocol", () => {
        before(() => {
            cy.visit("http://localhost:3070/apps/at-rfq-list/index.html?user=test&bfm-cef=202310230000");
        })

        // initialized without a selection, unless all of the orders are initialized in the same protocol

        it("pricing protocol defaults to undetermined because there are two rows that are spread based", () => {
            cy.get('[data-test-id="summary-price-type"]').contains("Pricing Protocol");
            cy.get('[data-test-id="summary-price-type"] input[value=price]').should('not.be.checked');
            cy.get('[data-test-id="summary-price-type"] input[value=spread]').should('not.be.checked');
            cy.get(`.atx-grid-cell [data-test-id="protocol"]`).should('have.length', 7);
            cy.get(`.atx-grid-cell [data-test-id="protocol"][data-checked="spread"]`).should('have.length', 2);
            cy.get(`.atx-grid-cell [data-test-id="protocol"][data-checked="price"]`).should('have.length', 5);
        });

        // If all of the orders are price, the ribbon should be initialized as price.

        it("removing the two spread rows switched to price", () => {
            cy.get(`[data-test-id=orders-grid] .atx-grid-body.scroll .atx-grid-row[row-index="2"] .atx-grid-cell[column-index="0"]`).should('have.text', "607557411");
            cy.get(`[data-test-id=orders-grid] .atx-grid-body.scroll .atx-grid-row[row-index="2"] .atx-grid-cell[column-index="7"] .atx-icon.delete-row.widget-delete`).click()
            cy.get(`[data-test-id=orders-grid] .atx-grid-body.scroll .atx-grid-row[row-index="0"] .atx-grid-cell[column-index="0"]`).should('have.text', "607556711");
            cy.get(`[data-test-id=orders-grid] .atx-grid-body.scroll .atx-grid-row[row-index="0"] .atx-grid-cell[column-index="7"] .atx-icon.delete-row.widget-delete`).click()

            cy.get(`.atx-grid-cell [data-test-id="protocol"]`).should('have.length', 5);
            cy.get(`.atx-grid-cell [data-test-id="protocol"][data-checked="spread"]`).should('have.length', 0);
            cy.get(`.atx-grid-cell [data-test-id="protocol"][data-checked="price"]`).should('have.length', 5);

            cy.get('[data-test-id="summary-price-type"] input[value=price]').should('be.checked');
            cy.get('[data-test-id="summary-price-type"] input[value=spread]').should('not.be.checked');
        })

        // When clicked, it should set all orders to Price or to Spread mode...

        it("clicking on spread changes everything accordingly", () => {
            cy.get(`[data-test-id="summary-price-type"] input[value="spread"]`).closest("label").click();
            cy.get(`.atx-grid-cell [data-test-id="protocol"][data-checked="price"]`).should('have.length', 0);
            cy.get(`.atx-grid-cell [data-test-id="protocol"][data-checked="spread"]`).should('have.length', 5);
        });

        // If the user changes one order to price, the ribbon is un-selected again.

        it("now we change one back to price and the summary pricing type goes back to undetermined", () => {
            cy.get(`[data-test-id=orders-grid] .atx-grid-body.scroll .atx-grid-row[row-index="1"] [data-test-id="protocol"] input[value=price]`).closest("label").click();
            cy.get('[data-test-id="summary-price-type"] input[value=price]').should('not.be.checked');
            cy.get('[data-test-id="summary-price-type"] input[value=spread]').should('not.be.checked');
        });

        // If the user changes that order back to spread, the ribbon will show Spread.

        it("at this point we change that row back to spread and all goes to spread", () => {
            cy.get(`[data-test-id=orders-grid] .atx-grid-body.scroll .atx-grid-row[row-index="1"] [data-test-id="protocol"] input[value=spread]`).closest("label").click();
            cy.get(`.atx-grid-cell [data-test-id="protocol"][data-checked="price"]`).should('have.length', 0);
            cy.get(`.atx-grid-cell [data-test-id="protocol"][data-checked="spread"]`).should('have.length', 5);

            cy.get('[data-test-id="summary-price-type"] input[value=spread]').should('be.checked');
        });

        // Or, if the user selected Price in the ribbon, it should move that single order back to Price

        it("lastly we click summary price and all goes to price", () => {
            cy.get(`[data-test-id="summary-price-type"] input[value="price"]`).closest("label").click();
            cy.get(`.atx-grid-cell [data-test-id="protocol"][data-checked="price"]`).should('have.length', 5);
            cy.get(`.atx-grid-cell [data-test-id="protocol"][data-checked="spread"]`).should('have.length', 0);
        });
    });

    context("spot time", () => {
        const reload = () => {
            cy.visit("http://localhost:3070/apps/at-rfq-list/index.html?user=test&bfm-cef=202310230000");
        };

        before(reload);

        it("should always be enabled on load if at least 1 order is in spread mode", () => {
            cy.get(`.atx-grid-cell [data-test-id="protocol"][data-checked="spread"]`).should('have.length.at.least', 1);
            cy.get('[data-test-id="summary-spot-time"] .spot-time-select').should('not.be.disabled');
        });

        it("if enabled, should be initialized as Spot Now", () => {
            cy.get('[data-test-id="summary-spot-time"] .spot-time-select').contains("Spot Now");
        });

        it("when a given Spot Time is selected, it should set all spread orders to that spot time. ", () => {
            cy.get('[data-test-id="summary-spot-time"] .spot-time-select').click();
            cy.get(`.spot-time-select .dropdown-option`).should('have.length', 6);
            cy.get(`.spot-time-select .dropdown-option[data-label="1pm ET"]`).click();
            cy.get(`.atx-grid-cell [data-test-id="spot-time"][data-label="1pm ET"]`).should('have.length', 2);
            cy.get(`.atx-grid-cell [data-test-id="spot-time"][data-label="N/A"]`).should('have.length', 5);
        });

        it("if all orders are in price, this should be greyed out with a blank selection", () => {
            cy.get(`[data-test-id="summary-price-type"] input[value="price"]`).closest("label").click();
            cy.get(`.atx-grid-cell [data-test-id="protocol"][data-checked="spread"]`).should('have.length', 0);
            cy.get('[data-test-id="summary-spot-time"] .spot-time-select').should('be.disabled').and('have.text', "N/A");
            cy.get(`.atx-grid-cell [data-test-id="spot-time"][data-label="N/A"]`).should('have.length', 7);
            reload();
        });

        it("with direct brokers selected I see only direct spot times and I can apply one to all spread RFQs", () => {
            cy.get('.direct-brokers-selection .broker-tile.selected').should('have.length', 7);
            cy.get('.venue-brokers-selection .broker-tile.selected').should('have.length', 0);
            cy.get('[data-test-id="summary-spot-time"] .spot-time-select').click();
            cy.get(`.spot-time-select .dropdown-option`).then(options => {
                const csv = [...options].map(el => el.innerText).join(",");
                expect(csv).to.eq('Spot Now,11am ET,1pm ET,3pm ET,4pm ET,4:30pm ET');
            })
            cy.get(`[data-label="3pm ET"]`).click();
            cy.get(`.atx-grid-cell [data-test-id="spot-time"][data-label="3pm ET"]`).should('have.length', 2);
            cy.get(`.atx-grid-cell [data-test-id="spot-time"][data-label="N/A"]`).should('have.length', 5);
            reload();
        })

        it("selecting venue I should see venue's options", () => {
            cy.get('.venue-select-all label').click();
            cy.get('.venue-brokers-selection .broker-tile.selected').should('have.length', 5);
            cy.get('.direct-brokers-selection .broker-tile.selected').should('have.length', 2).click({multiple: true});
            cy.get('.direct-brokers-selection .broker-tile.selected').should('have.length', 0);
            cy.get('[data-test-id="summary-spot-time"] .spot-time-select').click();
            cy.get(`.spot-time-select .dropdown-option`).then(options => {
                const csv = [...options].map(el => el.innerText).join(",");
                expect(csv).to.eq('Spot Now,Spot Next,10am ET,11am ET,1pm ET,1:45pm ET,2pm ET,3pm ET,4pm ET,4:30pm ET');
            })
            cy.get(`[data-label="Spot Next"]`).click();
            cy.get(`.atx-grid-cell [data-test-id="spot-time"][data-label="Spot Next"]`).should('have.length', 2);
            cy.get(`.atx-grid-cell [data-test-id="spot-time"][data-label="N/A"]`).should('have.length', 5);
            reload();
        })

        it.only("when the intersection narrows down the choice is left blank and it's a blocker", () => {
            cy.get('.venue-select-all label').click();
            cy.get('.venue-brokers-selection .broker-tile.selected').should('have.length', 5);
            cy.get('.direct-brokers-selection .broker-tile.selected').should('have.length', 2).click({multiple: true});
            cy.get('.direct-brokers-selection .broker-tile.selected').should('have.length', 0);
            cy.get('[data-test-id="summary-spot-time"] .spot-time-select').click();
            cy.get(`[data-label="Spot Next"]`).click();
            cy.get('.direct-brokers-selection [data-test-id="broker-tile-SIMJPM"]').click();
            cy.get(`.atx-grid-cell [data-test-id="spot-time"][data-label="Spot Next"]`).should('have.length', 0);
            cy.get(`.atx-grid-cell [data-test-id="spot-time"][data-label=""]`).should('have.length', 2);
            cy.get(`.atx-grid-cell [data-test-id="spot-time"][data-value="N"]`).should('have.length', 0);
            cy.get(`.atx-grid-cell [data-test-id="spot-time"][data-label="N/A"]`).should('have.length', 5);
            cy.get(`.atx-grid-cell [data-test-id="spot-time"][data-value="null"]`).should('have.length', 7);
            cy.get('[data-test-id="summary-spot-time"] .spot-time-select').click();
            cy.get(`.spot-time-select .dropdown-option`).then(options => {
                const csv = [...options].map(el => el.innerText).join(",");
                expect(csv).to.eq('Spot Now,11am ET,1pm ET,3pm ET,4pm ET,4:30pm ET');
            });
            cy.get('[data-test-id="summary-spot-time"] .spot-time-select').click();

            cy.get(`.atx-grid-cell [data-test-id="spot-time"][data-label=""]`).should('have.class', 'error');
        });
    });

    context("timer", () => {
        before(() => {
            cy.visit("http://localhost:3070/apps/at-rfq-list/index.html?user=test&bfm-cef=202310230000");
        });

        after(() => {
            cy.clock().then(clock => clock.restore());
        })

        it("Timer should be initialized as ASAP", () => {
            cy.get('[data-test-id="summary-timer"]').should('have.attr', 'data-checked').and('match', /ASAP/);
            cy.get('[data-test-id="summary-due-protocol"] input[value="Due In"]').should('be.disabled').and('be.checked');
            cy.get('[data-test-id="summary-due-protocol"] input[value="Due At"]').should('be.disabled').and('not.be.checked');
        });

        it("When clicked, this should update the timer for all orders", () => {
            cy.get('[data-test-id="summary-timer"] input[value="Bin"]').closest("label").click();
            cy.get('[data-test-id="summary-timer"]').should('have.attr', 'data-checked').and('match', /Bin/);

            cy.get('[data-test-id="summary-due-in"]').click();
            cy.get(".due-in-select .dropdown-option")
                .should('have.length', 5)
                .and('contain.text', '2 minutes')
                .and('contain.text', '3 minutes')
                .and('contain.text', '5 minutes')
                .and('contain.text', '10 minutes')
                .and('contain.text', '30 minutes');
            cy.get('[data-test-id="summary-due-in"]').click();

            cy.intercept('POST', '/oemsgqlserver/graphql', req => {
                for (const request of req.body.variables.request) {
                    expect(request.isBin).eq(true, `ordNum: ${request.ordNum} should be Bin`);
                }
                req.reply({errors: []});
            }).as('validation');
            cy.get('[data-test-id="next-button"]').click();
            cy.wait("@validation")

            cy.get('[data-test-id="confirmation-dialog"] [data-test-id="Cancel"]').click()
        });

        it("User can enter a timestamp in HH:MM AM", () => {
            const now = new Date('2023-10-27T15:00:00.000Z').getTime(); // This is 16:00 GMT+1, NY is at 11:00 EDT
            cy.clock(now, ["Date", "setTimeout"]).visit("http://localhost:3070/apps/at-rfq-list/index.html?user=test&bfm-cef=202310230000");

            // cypress messing up with the clock prevents the default broker selection
            // I will look into that eventually, for now I want to get this story done
            // so I select one myselft to enable next
            cy.get(`.direct-brokers-selection [data-test-id="broker-tile-SIMJPM"]`).click();

            cy.get('[data-test-id="summary-timer"] input[value="Bin"]').closest("label").click();
            cy.get('[data-test-id="summary-due-protocol"] input[value="Due At"]').closest("label").click();
            const input = cy.get('[data-test-id="summary-due-at"] input');
            input.should('have.value', '11:30  AM');
            input.focus();
            input.type("9");
            input.should('have.value', 'HH:MM  AM');
            input.type("1");
            input.should('have.value', '1H:MM  AM');
            input.type("5");
            input.should('have.value', '1H:MM  AM');
            input.type("1");
            input.should('have.value', '11:MM  AM');
            input.type("{backspace}2");
            input.should('have.value', '12:MM  PM');
            input.type("30");
            input.should('have.value', '12:30  PM');
            input.blur();

            // re-validated on Next would mean the user is tricked into thinking it can press next
            // but actually can't so there's a timeout that triggers invalidation of the due at
            // when it's before now... and of course that blocks next

            cy.get('[data-test-id="next-button"]').should('not.be.disabled');
            cy.tick(60 * 60 * 1000).then(clock => {
                cy.get('[data-test-id="next-button"]').should('be.disabled');
                cy.get('[data-test-id="summary-due-at"] input').should('have.class', 'error');
            })

            cy.clock().then(clock => clock.restore());
        });
    });

});