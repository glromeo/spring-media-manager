context("request validation", () => {

    before(() => {
        cy.visit("http://localhost:3070/apps/at-rfq-list/index.html?user=test&bfm-cef=202310230000&NO_GZIP");
    })

    it("Validations on Next: the UI should hit the GQL validation endpoint.", () => {
        const now = new Date('2023-10-27T15:00:00.000Z').getTime(); // This is 16:00 GMT+1, NY is at 11:00 EDT
        cy.clock(now, ["Date", "setTimeout"]).visit("http://localhost:3070/apps/at-rfq-list/index.html?user=test&bfm-cef=202310230000");

        const [variables, response] = require("../fixtures/validate-placements/202310230000.json");

        cy.intercept('POST', '/oemsgqlserver/graphql', req => {
            if (req.headers["x-fixture"]==="validate-placements") {
                expect(JSON.stringify(req.body.variables)).eq(JSON.stringify(variables));
                req.reply(response);
            } else {
                req.continue();
            }
        }).as('validation');

        cy.get(`[data-test-id="next-button"]`).should('not.be.disabled').click();

        cy.wait('@validation');
        cy.clock().then(clock => clock.restore());

        cy.get(`.atx-alert.actionable.danger`)
            .should('contain.text', 'Validation Error!')
            .and('contain.text', 'There are 2 errors and 1 warnings resulting from backend validation.');

        cy.get(`[data-test-id="orders-grid"] [row-index="2"] [column-index="7"] .atx-icon.danger`).realHover();

        cy.get(`.atx-tooltip .atx-alert.danger .content .message`)
            .should('have.text', 'Placement quantity value of  443000 is greater than order leaves value of  15000')

        cy.get(`[data-test-id="next-button"]`)
            .should('be.disabled')
            .and('have.text', 'Acknowledge and Send');

        cy.get(`[data-test-id="orders-grid"] [row-index="0"] [column-index="7"] .atx-icon.delete-row`).click();
        cy.wait(250);
        cy.get(`[data-test-id="orders-grid"] [row-index="1"] [column-index="7"] .atx-icon.delete-row`).click();

        cy.get(`[data-test-id="next-button"]`)
            .should('not.be.disabled')
            .and('have.text', 'Acknowledge and Send');

        cy.get("body").realHover({ position: "topLeft" });
    })
})

