/// <reference types="cypress" />

context("response page", () => {

    before(() => {
        cy.visit(
            "http://localhost:3070/apps/at-rfq-list/index.html?user=gromeo&bfm-cef=202307150000&step=3"
        );
    })

    it("page checks", ()=>{
        cy.title().should('eq', 'RFQ List');

        cy.get('[data-test-id="next-button"]')
            .should('not.exist');

        cy.get('[data-test-id="cancel-button"]')
            .should('have.text', "Cancel All Remaining")
            .should('not.be.disabled');

        cy.get('atx-notification')
            .should('not.exist');
    });

    it("stepper should show either Request or Response depending on what page we are in", () => {
        cy.get('[data-test-id="rfq-stepper"]').get(".aux-progress-stepper__step-button-disabled", {includeShadowDom: true}).contains("Request");
        cy.get('[data-test-id="rfq-stepper"]').get(".aux-progress-stepper__step-button-active", {includeShadowDom: true}).contains("Response");
    });

    it("ribbon checks", ()=>{
        cy.get('[data-test-id="buy-order-totals"]').should('have.text', "14 / 3,780,000");
        cy.get('[data-test-id="sell-order-totals"]').should('have.text', "14 / -5,164,600");
    });

    // it("grid checks", ()=>{
    //     cy.get('[data-test-id="orders-grid"] [row-index="0"] [column-index="1"]').should('have.text', "FDX 4.4 1/15/47");
    //     cy.get('[data-test-id="orders-grid"] [row-index="2"] [column-index="1"]').should('have.text', "JPM 4.565 6/14/30");
    //     cy.get('[data-test-id="orders-grid"] [row-index="8"] [column-index="1"]').should('have.text', "GIS 3.907 4/13/29");
    // });

});
