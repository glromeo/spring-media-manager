import { Browser, BrowserContext, Page } from "playwright-core";

declare global {
    var browser: Browser;
    var context: BrowserContext;
    var page: Page;
}
