# Introduction

RFQ Single UI

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

# Getting Started

Clone the project then run

```
yarn install
```

To add local environment variables, add a .env.local file in the root directory with fields below:

```
SKIP_PREFLIGHT_CHECK=true
BROWSER=none
HOST=localhost
CYPRESS_DEV_SERVER_PORT=4001
CHOKIDAR_USEPOLLING=true
LOCAL_FIXTURES=false
ENV=TST
DEV_COOKIE=
TST_COOKIE=
```
LOCAL_FIXTURES {true, false} - stub API responses with local fixtures

ENV {DEV, TST} - target backend env

DEV_COOKIE & TST_COOKIE [instructions](https://webster.bfm.com/Wiki/display/CTPT/AT+UI+Getting+Started+Guide#ATUIGettingStartedGuide-4.Runtheapplicationlocally)

# Build and Test

## Market Depth

To start the development server:

```
yarn start
```

To start the storybook server:

```
yarn storybook
```

# Running

To fiddle with the API url go to: src/api/utils.ts

# Release

Once a new pull request is merged in `develop` the publish pipeline will automatically create a new release package for
SRPT.

Check that the build is green: https://dev.azure.com/1A4D/trading/_build?view=folders&pipelineNameFilter=rfq-single

Then you can use the following URLs to release and activate the package in the desidered environment.

### Application

https://www.admin.blackrock.com/srptweb/applicationSummary?appId=?

### Package

https://www.admin.blackrock.com/srptweb/applicationPackageSummary?appId=?
