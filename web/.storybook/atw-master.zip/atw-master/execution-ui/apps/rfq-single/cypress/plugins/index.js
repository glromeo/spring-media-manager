module.exports = (on, config) => {
    require("@atw/scripts").cypressPlugins(on, config);
    require("cypress-terminal-report/src/installLogsPrinter")(on);
    on("task", {
        async ["clean:prefs"]() {
            const { rm } = require("fs").promises;
            await rm("tmp/prefs.urlencoded.txt");
            return null;
        }
    });
};
