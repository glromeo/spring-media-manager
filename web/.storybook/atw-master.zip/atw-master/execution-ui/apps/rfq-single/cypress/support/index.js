import "@atw/testing/coverage-hooks";
import "cypress-wait-until";
import "cypress-real-events";
require("cypress-terminal-report/src/installLogsCollector")();
import chaiAsPromised from "chai-as-promised";

// require('cypress-terminal-report/src/installLogsCollector')();
chai.use(chaiAsPromised);
