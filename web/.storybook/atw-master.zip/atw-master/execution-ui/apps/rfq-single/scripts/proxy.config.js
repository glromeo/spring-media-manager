const { createProxyMiddleware } = require("http-proxy-middleware");
const url = require("url");
const log = process.env.CI ? () => void null : (...args) => console.log("[ATW]", ...args);

require('dotenv').config({ path: `.env.local`, override: true });

const createDashboardRedirect =
    ({ target }) =>
    (req, res, next) => {
        if (req.header("User-Agent").endsWith("AWC/3.4")) {
            log(`redirect: ${req.method} ${req.originalUrl} -> ${target}`);
            res.redirect(308, `${target}${req.originalUrl}`);
        } else {
            return next();
        }
    };

module.exports = (app) => {
    app.use(require("@atw/scripts").prefsMiddleware);
    app.use(require("@atw/scripts").recordingMiddleware);
    if (process.env.LOCAL_FIXTURES === "true") {
    app.use(require("@atw/scripts").fixturesMiddleware);
    }
    if (!process.env.CI) {
        const { ENV } = process.env;
        const target = ENV === "DEV" ? "https://dev.blackrock.com" : "https://tst.blackrock.com";

        const dashboardRedirect = createDashboardRedirect({ target });
        const proxyMiddleware = createProxyMiddleware({
            target,
            changeOrigin: true,
            logLevel: "debug",
            onProxyReq(proxyReq, req) {
                try {
                    const cookie = ENV == "DEV" ? process.env.DEV_COOKIE : process.env.TST_COOKIE;
                    if (cookie) {
                        proxyReq.setHeader("cookie", cookie);
                    }
                } catch (ignored) {
                    log(
                        "[proxy] unable to set cookie for proxy req, make sure an up to date dev or tst cookie content is available in .env.local"
                    );
                }
            }
        });

        app.use("/weblications", dashboardRedirect, proxyMiddleware);
        app.use("/oemsgqlserver", dashboardRedirect, proxyMiddleware);
        app.use("/api", dashboardRedirect, proxyMiddleware);
        app.use("/std", proxyMiddleware);
        app.use("/bms/request/app/explore/securitySearch", createDashboardRedirect({ target }), proxyMiddleware);
        app.use("/apps/at-rfq-single-beta/index.html", (req, res) => {
            res.redirect(
                url.format({
                    pathname: "/apps/at-rfq-single/index.html",
                    query: req.query
                })
            );
        });
    }
};
