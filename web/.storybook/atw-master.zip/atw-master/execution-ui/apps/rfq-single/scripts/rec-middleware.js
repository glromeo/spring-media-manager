const fs = require("fs");
const path = require("path");
const JSZip = require("jszip");

try {
    fs.mkdirSync(".tmp");
} catch (e) {}

let recording = { http: {}, ws: {} };
let playback = null;

function parseQuery(query) {
    object = {};
    if (query.indexOf("?") != -1) {
        query = query.split("?");
        query = query[1];
    }
    let tokens = query.split("&");
    for (var i = 0; i < tokens.length; i++) {
        pair = tokens[i].split("=");
        key = decodeURIComponent(pair[0]);
        if (key.length == 0) continue;
        value = decodeURIComponent(pair[1].replace("+", " "));

        if (object[key] == undefined) object[key] = value;
        else if (object[key] instanceof Array) object[key].push(value);
        else object[key] = [object[key], value];
    }
    return object;
}

function nextRecording(fixture) {
    const script = recording.http[fixture];
    if (script)
        try {
            return script[playback[fixture] ?? 0];
        } finally {
            if (playback[fixture] + 1 < script.length) {
                playback[fixture]++;
            }
        }
    else {
        return null;
    }
}

function replyWithRecording(fixture, req, res) {
    const sample = nextRecording(fixture);
    if (sample) {
        const { response } = sample;
        console.log(`Playback: ${req.method} ${req.originalUrl} -> ${fixture}`);
        const body = typeof response.body === "object" ? JSON.stringify(response.body) : response.body;
        res.status(response.status, response.headers).send(body);
        return true;
    }
}

function isPlaybackAvailable() {
    return playback !== null;
}

function isPlaybackMode(url) {
    const parsed = parseQuery(url);
    return parsed.playback === "true";
}

function getOrderNum(url) {
    const parsed = parseQuery(url);
    return parsed.orderNumber;
}

function getRecordingPath(orderNum, isZipped) {
    if (isZipped) return path.resolve(__dirname, "../playback", `recording-${orderNum}.zip`);
    else return path.resolve(__dirname, "../.tmp", `recording-${orderNum}.json`);
}

async function unzip(zipPath, jsonPath) {
    return new Promise((resolve) => {
        fs.readFile(zipPath, function (err, data) {
            if (!err) {
                var zip = new JSZip();
                zip.loadAsync(data).then(function (contents) {
                    Object.keys(contents.files).forEach(function (filename) {
                        // if json path filename doesn't equal filename, don't unzip
                        // when zipping using mac's compress, the zipped file has a hidden macox file that shouldn't be used for playback
                        if (jsonPath.split("/").at(-1) !== filename) return;
                        zip.file(filename)
                            .async("nodebuffer")
                            .then(function (content) {
                                if (jsonPath !== undefined) fs.writeFileSync(jsonPath, content);
                                resolve(true);
                            });
                    });
                });
            } else resolve(false);
        });
    });
}

async function isInCache(orderNum) {
    return new Promise(async (resolve) => {
        // is it already unzipped?
        const cachePath = getRecordingPath(orderNum);
        if (fs.existsSync(cachePath)) resolve(true);
        resolve(false);
    });
}

async function unzipToCache(orderNum) {
    return new Promise(async (resolve) => {
        // one last thing - maybe we have it ...but it's zipped!!
        const zipPath = getRecordingPath(orderNum, true);
        if (fs.existsSync(zipPath)) {
            // found zip ... let's unzip to cache...
            const cachePath = getRecordingPath(orderNum);
            const success = await unzip(zipPath, cachePath);
            resolve(success);
        }
        resolve(false);
    });
}

function getRecording(orderNum) {
    const recordingPath = getRecordingPath(orderNum);
    return JSON.parse(fs.readFileSync(recordingPath, { encoding: "utf8" }));
}

function initializePlayback(orderNum) {
    playback = {};
    recording = getRecording(orderNum);
    console.log("Found a recording...");
}

function initialRequest(url) {
    return url.includes("index.html");
}

async function preparePlayback() {
    // look at playback.json under /playback folder ... iterate through list (unzip if needed and grab url)
    const playbackfile = path.resolve(__dirname, "../playback", "playback.json");
    const origin = "http://localhost:3001";
    return new Promise(async (resolve) => {
        const playbackJSON = JSON.parse(fs.readFileSync(playbackfile));
        // for each item ... we need to unzip ...and grab the url
        let responseList = [];
        for (const item of playbackJSON) {
            // first check if in cache
            let recordingJSON = null;
            const inCache = await isInCache(item.orderNum);
            if (!inCache) {
                const zipFound = await unzipToCache(item.orderNum);
                if (!zipFound) return;
            }
            recordingJSON = getRecording(item.orderNum);
            if (!recordingJSON.url.includes(origin)) {
                recordingJSON.url = origin + recordingJSON.url;
            }
            const urlParsed = new URL(recordingJSON.url);
            let url = origin + urlParsed.pathname + urlParsed.search + "&playback=true";
            if (item.automation) {
                url += "&automation=" + JSON.stringify(item.automation);
            }
            responseList.push({ name: item.name, url: url, automation: item.automation });
        }
        resolve(responseList);
    });
}

async function playbackMiddleware(req, res, next) {
    const playbackList = await preparePlayback();
    res.status(200).send(playbackList);
}

async function recordingMiddleware(req, res, next) {
    if (initialRequest(req.url)) {
        if (isPlaybackMode(req.url)) {
            const orderNum = getOrderNum(req.url);
            const inCache = await isInCache(orderNum);
            if (inCache) {
                initializePlayback(orderNum);
            } else {
                const zipFound = await unzipToCache(orderNum);
                if (!zipFound) {
                    playback = null;
                    console.log(`Recording for orderNum: ${orderNum} not found - unable to playback...`);
                }
            }
        } else {
            // not in playback mode anymore??
            playback = null;
        }
    } else {
        let fixture = req.header("X-Fixture");
        if (fixture && playback && !Object.keys(playback).includes(fixture)) {
            playback[fixture] = 0;
        }
        if (fixture && isPlaybackAvailable()) {
            if (replyWithRecording(fixture, req, res)) {
                return;
            }
        }
    }
    return next();
}

module.exports = {
    playbackMiddleware: playbackMiddleware,
    recordingMiddleware: recordingMiddleware
};
