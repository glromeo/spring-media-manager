import { VenueName } from "src/features/order/order";
import { CounterParty, Desk } from "../features/brokers/brokers";
import { Side } from "../models/common";
// refactor-todo: can we use code-gen to generate the types?

export const placementSchema = `
placements {
  placementNum,
  basketID,
  axeID,    
  limitValue,
  inquiryType,
  limitType,
  quantity,
  status,
  modifyReason,
  modifiedTime,
  placementGenFields {
    key,
    value
  },
  externRefID,
  quotes {
    spread,
    quoteStatus,
    price,
    type,
    side,
    quoteID,
    expTime,
    quantity,
    counterparty {
      ticker,
      code,
      shortName
    }
  }
  desk {
    salesman,
    brokerType,
    subBrokerID
  },
  broker {
    ticker,
    type,
    shortName,
    code
  },
  ordNum,
  dueInTime,
  spreadIndex,
  settleDate,
  modifiedBy,
  type
}
`;
export const requestPlacementQuoteMutation = `mutation requestPlacementQuote($request: PlacementQuoteRequest!, $user: String) {
  requestPlacementQuote(request: $request, user: $user) {
      order {
        ordNum
      },
     ${placementSchema}
    }
  }`;

export const executeRFQPlacementQuoteMutation = `mutation executePlacementQuote($request: PlacementQuoteExecute!, $quotes: [PlacementQuotes], $user: String) {
  executePlacementQuote(request: $request, quotes: $quotes, user: $user) {
    order {
      ordNum
    },
    ${placementSchema}
  }
}`;

export const counterRFQPlacementQuoteMutation = `
mutation counterPlacementQuote($request: PlacementQuoteExecute!, $quotes: [PlacementQuotes], $user: String) {
  counterPlacementQuote(request: $request, quotes: $quotes, user: $user) {
    order {
      ordNum
    },
    ${placementSchema}
  }
}`;

// refactor-todo - I think we can delete placementValidations, executionValidations
export const validatePlacementsCounteringMutation = `mutation validatePlacementsCountering($request: PlacementQuoteRequest!, $warnings: String, $user: String) {
  validatePlacementsCountering(request: $request, warnings: $warnings, user: $user) {
    placementNum,
    placementValidations {
      validationID {
        id
        validationKey
        validationType
        touchCount
      }
      fillNums
      type
      violation
      severityType
      validationState
      validationDate
    }
    executionValidations {
      validationID {
        id
        validationKey
        validationType
        touchCount
      }
      fillNums
      type
      violation
      severityType
      validationState
      validationDate
    }
  }
}`;

export const cancelRFQPlacementsMutation = `mutation cancelRFQPlacements($placementNumList: [Int!], $user: String!) {
  cancelRFQPlacements(placementNumList: $placementNumList, user: $user) {
    placementNum
    status
    modifyReason
  }
}`;

export const validatePlacementsExecutionMutation = `mutation validatePlacementsExecution($request: PlacementQuoteExecute!, $user: String) {
    validatePlacementsExecution(request: $request, user: $user) {
      placementNum,
    }
  }`;

export const brokerQuery = `query fiOrderSummary($ordNum: Int!) {
    fiOrderSummary(ordNum: $ordNum) {
      brokerEntity {
        key
        value
      }
    }
  }
  `;

export const orderLeavesQuery = `query fiOrderSummary($ordNum: Int!) {
    fiOrderSummary(ordNum: $ordNum) {
      order {
        orderLeaves
      }
    }
  }
  `;

const orderSchema = `
  order {
    price
    effectiveTranType
    updateInstr
    face
    fillAmt
    limitValue
    limitType
    orderLeaves
    settleDate
    tradingBenchmark
    priceCurrency
  }
  orderDetails {
    quantity
    quantityBooked
    portfolio {
      portfolioCode
      portfolioName
    }
  }
  directBrokers
  venueBrokers {
    brokerCode,
    brokerName,
    executingBrokerCodes
 }
  delayedSpotEnabled
  mifidTagEnabled
  spreadFlowEnabled
  brokerAllocations {
    broker {
      defaultDesk
      shortName
      code
      desks {
        brokerType
        salesman
        subBrokerID
      }
    }
    availablePlacementQuantity
    eligiblePlacementQuantity
    eligiblePlacementQuantityAsPct
    portfolioAllocations {
      portfolioCode
      quantityAvailable
    }
  }
  fiAsset {
    bAsset {
      ticker
      maturity
      cusip
      secGroup
      secType
      minTrdSize
    }
    bondQuality
    couponValue
    isin
    defaultSettleDate
    isMiFID2Eligible
  },
  ${placementSchema},
  userMifidEligibility,
  counteringEnabled,
  actionableCounteringEnabled,
  spotTimes {
    venue,
    spotTime {
      code,
      displayName
    }
  }
}
`;

export const orderRFQQuery = `query fiOrderSummary($ordNum: Int!, $user: String!, $rfqExecution: Boolean!) {
  fiOrderSummary(ordNum: $ordNum, user: $user, rfqExecution: $rfqExecution) {
    ${orderSchema}
 }
 `;

export const benchmarkQuery = `query fiAsset($secId: String) {
    fiAsset(secId: $secId) {
      bAsset {
        secDesc1
        maturity
        ticker
      }
      couponValue
    }
  }`;

export const pricesQuery = `query prices($cusips: [String!], $startInclusive: BFMTimestamp) {
  prices(cusips: $cusips, startInclusive: $startInclusive) {
    indexName
    price
  }
}
`;

export const basketQuery = `query fiBasketSummary($basketId: String!, $user: String!) {
  fiBasketSummary(basketId: $basketId, user: $user) {
    ${placementSchema}
  }
}`;

export type GraphQLOrderDetails = {
    quantity: number;
    quantityBooked: number;
    portfolio: {
        portfolioCode: number;
        portfolioName: string;
    };
};

export type GraphQLQuote = {
    spread: number | null;
    price: number | null;
    quoteID: string;
    expTime: number;
    quantity: number;
    counterparty: CounterParty;
    type: "PRICE" | "SPREAD";
    side: "ASK" | "BID";
    broker: string;
    quoteStatus: string | null;
};

export type GraphQLPartialQuote = Pick<GraphQLQuote, "broker" | "price" | "quantity" | "quoteID">;

export type GraphQLPlacement = {
    placementNum: number;
    basketID: string;
    axeID: string;
    limitValue: number;
    inquiryType: 1 | 2;
    limitType: "Price" | "Spread";
    quantity: number;
    status: string;
    modifyReason: string;
    modifiedTime: number;
    externRefID: string;
    placementGenFields: GraphQLPlacementGenFields[];
    quotes: GraphQLQuote[];
    desk?: Desk;
    broker: CounterParty;
    settleDate: string;
    ordNum: number;
    dueInTime: number;
    spreadIndex: string;
    modifiedBy: string;
    type: string;
};
export type GraphQLPlacements = GraphQLPlacement[] | [] | undefined;

export type GraphQLOrder = {
    effectiveTranType: Side;
    updateInstr: string;
    face: number;
    fillAmt: number;
    limitValue: number;
    limitType: string;
    orderLeaves: number;
    settleDate: string;
    tradingBenchmark: string;
    priceCurrency: string;
    price: number;
};
export type GraphQLAsset = {
    bAsset: {
        ticker: string;
        maturity: string;
        cusip: string;
        secGroup: string;
        secType: string;
        minTrdSize: number;
    };
    bondQuality: string;
    couponValue: string;
    isin: string;
    defaultSettleDate: string;
    isMiFID2Eligible: boolean;
};

export type GraphQLBrokerEntity = {
    key: string;
    value: string[];
};
export type GraphQLPorfolioAllocation = {
    portfolioCode: number;
    quantityAvailable: number;
};
export type GraphQLBrokerAllocationDesk = {
    brokerType: string;
    salesman: string;
    subBrokerID: number;
};

export type GraphQLBrokerEntityDesks = {
    defaultDesk?: string;
    shortName: string;
    code: number;
    desks: GraphQLBrokerAllocationDesk[];
};

export type GraphQLBrokerAllocation = {
    broker: GraphQLBrokerEntityDesks;
    availablePlacementQuantity: number;
    eligiblePlacementQuantity: number;
    eligiblePlacementQuantityAsPct: number;
    portfolioAllocations: GraphQLPorfolioAllocation[];
};
export type GraphQLSpotTimes = {
    venue: VenueName;
    spotTime: {
        code: string;
        displayName: string;
    }[];
};

export type GraphQLPlacementGenFields = {
    key: string;
    value: string;
};

export type GraphQLOrderSummary = {
    order: GraphQLOrder;
    orderDetails: GraphQLOrderDetails[];
    fiAsset: GraphQLAsset;
    brokerAllocations: GraphQLBrokerAllocation[];
    brokerEntity: GraphQLBrokerEntity[];
    delayedSpotEnabled: number[];
    mifidTagEnabled: number[];
    spreadFlowEnabled?: number[];
    placement?: GraphQLPlacement[];
    userMifidEligibility: "true" | "false";
    counteringEnabled: number[];
    actionableCounteringEnabled: number[];
    spotTimes: GraphQLSpotTimes[];
    directBrokers: number[];
    venueBrokers: GraphQLVenueBrokers[];
};
export type GraphQLVenueBrokers = {
    brokerCode: number;
    brokerName: VenueName;
    executingBrokerCodes: number[];
};
export type GraphQLOrderSummaryResponse = {
    fiOrderSummary: GraphQLOrderSummary;
    errors: GraphQLValidation[];
};
export type GraphQLBrokerVariables = {
    ordNum: number;
};
export type GraphQLOrderSummaryVariables = {
    ordNum: number;
    brokerList?: number[];
    rfqExecution?: boolean;
    user: string;
};
// refactor-todo- we can get rid of this but not sure what it should be
export type GraphQLValidation = {
    validationID: {
        id: number;
        validationKey: string;
        validationType: string;
        touchCount: number;
    };
    fillNums: number;
    type: number;
    violation: string;
    severityType: string;
    validationState: string;
    validationDate: string;
};
export type GraphQLValidationResponse = {
    placementNum: number;
    placementValidations: GraphQLValidation[];
    executionValidations: GraphQLValidation[];
};
export type GraphQLErrorLocation = {
    line: number;
    column: number;
    sourceName: string;
};
export type GraphQLError = {
    locations: GraphQLErrorLocation[];
    message: string;
    errorType: string;
    extensions: any;
    path: any;
};
export type GraphQLResult<R> = {
    errors?: GraphQLError[];
    data: R;
};
export type GraphQLCounteringValidationResponse = {
    validatePlacementsCountering: [];
};
export type GraphQLOrderValidationResponse = {};
export type GraphQLBenchmarkVariables = {
    secId: string;
};
export type GraphQLBenchmarkResponse = {
    fiAsset: {
        bAsset: {
            secDesc1?: string;
            maturity: string;
            ticker: string;
        };
        couponValue: number;
    };
};
// refactor-todo - i THINK we can get rid of the price stuff
export type GraphQLPricesVariables = {
    cusips: string[];
    startInclusive: number;
};
export type GraphQLPricesResponse = {
    prices: [
        {
            indexName: string;
            price: number;
        }
    ];
};
export type GraphQLVenueBrokerDeskPairing = {
    venueBroker: string;
    subBrokerId: number;
    executingBrokers: string[];
};
export type GraphQLBrokerDeskPairing = {
    broker: string;
    subBrokerId: number;
};
export type GraphQLPlacementQuoteRequest = {
    ordNum: number;
    brokers: GraphQLBrokerDeskPairing[];
    venueBrokers?: GraphQLVenueBrokerDeskPairing[];
    placementAllocationStrategy: {
        strategy: string;
        value: number;
    };
    limitType: string;
    dueInTime: string;
    limitValue?: number;
    externRefID?: string;
    axeLevel?: number;
    spreadIndex?: string;
    spotType?: string;
    settleDate?: string;
    axeID?: string;
    isBin?: boolean;
    benchPrice?: number;
};
export type GraphQLPlacementCreationVariables = {
    request: GraphQLPlacementQuoteRequest;
    user: string;
};
export type GraphQLPlacementCreationResponse = {
    requestPlacementQuote: GraphQLPlacementQuote[];
};

// refactor-todo - this seems incorrectly named
export type GraphQLPlacementQuote = {
    order: {
        ordNum: number;
    };
    placements: GraphQLPlacement[];
};
export type GraphQlExecutePlacementQuoteRequest = {
    placementNum: number;
    externId: string;
    quantity: number;
    askPrice: number;
    bidPrice: number;
    counterparty: string;
    lastPrice?: string;
    dueInTime?: string;
};
export type GraphQlExecutePlacementQuoteResponse = {
    executePlacementQuote: GraphQLPlacementQuote[];
    errors: GraphQLValidation[];
};
export type GraphQlExecutePlacementQuoteVariables = {
    request: GraphQlExecutePlacementQuoteRequest;
    quotes?: GraphQLPartialQuote[];
    user: string;
};
export type GraphQlCounterPlacementQuoteResponse = {
    counterPlacementQuote: GraphQLPlacementQuote[];
};
export type GraphQlCounterPlacementQuoteVariables = {
    request: GraphQlExecutePlacementQuoteRequest;
    user: string;
};
export type GraphQlCancelRFQPlacementsVariables = {
    placementNumList: number[];
    user: string;
};

export type GraphQlCancelRFQPlacements = {
    placementNum: number;
    status: string;
    modifyReason: string;
};

export type GraphQlCancelRFQPlacementsResponse = {
    cancelRFQPlacements: GraphQlCancelRFQPlacements[];
};

export type GraphQLBasketSummaryVariables = {
    basketId: string;
    user: string;
};
export type GraphQLBasketSummaryResponse = {
    fiBasketSummary: {
        placements: GraphQLPlacement[];
    };
};
