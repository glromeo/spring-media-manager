export const TEXT = {
    // ERROR CONSTANTS
    NO_BROKERS_CERTIFIED: "No brokers have been certified for this workflow.",
    NO_ORDER_LEAVES: "The order does not have any order leaves remaining.",
    // POPUP/REVIEW CONSTANTS
    CONFIRM_PROCEED_TEXT: "Would you still like to proceed?",
    PLEASE_REACH_OUT_TO_THE_BROKER_OR_VOICE_STP: "Please reach out to the Broker or Voice STP",
    ACK_SEND_BUTTON_LABEL: "Acknowledge & Send",
    CONFIRM_SEND: "Confirm Send",
    CONFIRM_CANCEL: "Confirm Cancel",
    CONFIRM_HIT: "Confirm Hit",
    CONFIRM_LIFT: "Confirm Lift",
    COUNTER_REJECTED: "Counter Rejected",
    LIFT_REJECTED: "Lift Rejected",
    HIT_REJECTED: "Hit Rejected",
    YOUR_COUNTER_REQUEST_HAS_BEEN_CANCELLED: "Your Counter Request has been cancelled",
    YOUR_HIT_REQUEST_HAS_BEEN_CANCELLED: "Your Hit Request has been cancelled",
    YOUR_LIFT_REQUEST_HAS_BEEN_CANCELLED: "Your Lift Request has been cancelled",
    COUNTERING: "Countering",
    SEND: "Send",
    PASS: "Pass",
    NEXT: "Next",
    CANCEL: "Cancel",
    CLOSE: "Close",
    COUNTER: "Counter",
    SPLIT_AND_NEXT: "Split & Next",
    SPLIT_AND_SEND: "Split & Send",
};

export const STYLE = {
    SIDE_COLUMN_WIDTH: 50,
    SECURITY_COLUMN_WIDTH: 140,
    SIZE_COLUMN_WIDTH: 80,
    SOURCE_COLUMN_WIDTH: 80,
    SPOT_TIME_COLUMN_WIDTH: 80,
    BROKER_COLUMN_WIDTH: 80
};

export const TIMEZONES = [
    {
        displayValue: "ET",
        isSelected: true,
        value: "America/New_York"
    }
];
