import { useEffect } from "react";
import { useAtom, useAtomValue } from "jotai";
import { StepperStatus, statusAtom } from "../../features/stepper/stepper";
import { selectedBrokerNamesAtom } from "../../features/brokers/brokers";
import { rfqTradeFormAtom } from "../../features/rfqTradeForm/rfqTradeForm";
import { tradeFormAtom } from "../../features/tradeForm";
import { alertsAtom } from "../../features/alerts/alert";

export function useValidationResetOnInput() {
    const [alerts, setAlerts] = useAtom(alertsAtom);
    const [{ status }, setStatus] = useAtom(statusAtom);
    const selectedBrokers = useAtomValue(selectedBrokerNamesAtom);
    const rfqTradeForm = useAtomValue(rfqTradeFormAtom);
    const miniFormSpread = useAtomValue(tradeFormAtom).spread;
    const miniFormPrice = useAtomValue(tradeFormAtom).price;
    const miniFormSize = useAtomValue(tradeFormAtom).size;

    useEffect(() => {
        if (alerts.length > 0 || status === StepperStatus.ACK_VALIDATION) {
            setAlerts([]);
            setStatus({ status: StepperStatus.STEPS });
        }
    }, [rfqTradeForm, miniFormSpread, miniFormPrice, miniFormSize, selectedBrokers.join()]);
}
