import { logClick } from "@atw/toolkit/telemetry";
import { useAtom, useAtomValue, useSetAtom } from "jotai";
import { useEffect } from "react";
import { StepperStatus, StepperSubStatus, statusAtom, stepperAtom } from "../../features/stepper/stepper";
import { alertsAtom } from "../../features/alerts/alert";

export function useValidationResetOnWorkflow() {
    const stepper = useAtomValue(stepperAtom);
    const setStatus = useSetAtom(statusAtom);
    const [alerts, setAlerts] = useAtom(alertsAtom);

    useEffect(() => {
        if (stepper.previousStatus === StepperStatus.ACK_VALIDATION && stepper.status === StepperStatus.SENDING && alerts.length > 0) {
            logClick("User about to Acknowledge & Send");
            console.log(
                "User bypassing soft warnings: [" + alerts.map((a) => a.type + ": " + a.message).join(", ") + "]"
            );
            setAlerts([]);
        } else if (
            stepper.previousStatus === StepperStatus.ACK_VALIDATION &&
            (stepper.subStatus === StepperSubStatus.COUNTER || stepper.subStatus === StepperSubStatus.DEFAULT_ACTION) &&
            alerts.length > 0
        ) {
            // User clicked back or cancel on a popup
            setAlerts([]);
            setStatus({ status: StepperStatus.STEPS });
        }
    }, [stepper.status, stepper.previousStatus]);
}
