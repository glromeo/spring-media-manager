import { useAtom, useAtomValue, useSetAtom } from "jotai";
import { useEffect } from "react";
import { alertStatusAtom, apiErrorSinkAtom } from "../../features/alerts/alert";
import { StepperStatus, StepperSubStatus, statusAtom, stepIndexAtom, stepperAtom } from "../../features/stepper/stepper";
import { useRFQActions } from "../../features/stepper/useRFQActions";
import { tradeFormAtom, tradeFormSink } from "../../features/tradeForm";
import { orderHasValidDataAtom, orderSettleDateAtom } from "../../features/order/order";
import { fetchBasketAtom } from "../../features/rfq/rfq";

export function useWorkflow() {
    const setApiError = useSetAtom(apiErrorSinkAtom);
    const fetchBasket = useSetAtom(fetchBasketAtom);
    const [stepper] = useAtom(stepperAtom);
    const setStatus = useSetAtom(statusAtom);
    const [, setStepIndex] = useAtom(stepIndexAtom);

    const orderHasValidData = useAtomValue(orderHasValidDataAtom);
    const orderSettleDate = useAtomValue(orderSettleDateAtom);
    const tradeForm = useAtomValue(tradeFormAtom);
    const alertStatus = useAtomValue(alertStatusAtom);

    const setTradeForm = useSetAtom(tradeFormSink);

    const previousStep = () => {
        const stepIdx = Math.max(stepper.stepIdx - 1, 0);
        if (stepIdx === 0 && orderHasValidData && tradeForm.hasValidData) {
            if (tradeForm.settleDate !== orderSettleDate) {
                setTradeForm({ ...tradeForm, settleDate: orderSettleDate });
            }
        }
        setStepIndex(stepIdx);
    };

    const [validateRFQOrder, sendRFQOrder] = useRFQActions();

    useEffect(() => {
        switch (stepper.status) {
            case StepperStatus.VALIDATING:
                if (alertStatus === "ERROR") {
                    // User cannot proceed
                    previousStep();
                    setStatus({ status: StepperStatus.STEPS });
                } else if (alertStatus === "WARNING") {
                    // Transition to Acknowledge & Send
                    setStatus({ status: StepperStatus.ACK_VALIDATION });
                } else {
                    validateRFQOrder()
                        .then(() => {
                            console.log("validateRFQOrder.fulfilled : SENDING");
                            setStatus({
                                status: StepperStatus.SENDING
                            });
                        })
                        .catch(setApiError);
                }
                break;
            case StepperStatus.SENDING:
                // only send when no more alert status
                if (alertStatus === "WARNING") return;
                if (alertStatus === "ERROR") {
                    // User cannot proceed
                    previousStep();
                    setStatus({ status: StepperStatus.STEPS });
                } else {
                    sendRFQOrder()
                        .then(() => {
                            console.log("sendRFQOrder.fulfilled : SENT");
                            if (stepper.subStatus === StepperSubStatus.CANCELING) {
                                setStatus({
                                    subStatus: StepperSubStatus.CANCELED,
                                    status: StepperStatus.SENT
                                });
                            } else {
                                setStatus({
                                    status: StepperStatus.SENT
                                });
                            }
                        })
                        .catch(setApiError);
                }
                break;
            case StepperStatus.SENT:
                if (stepper.subStatus !== StepperSubStatus.DEFAULT_ACTION) {
                    // Took an action, need to update
                    fetchBasket();
                }
                break;
        }
    }, [stepper.status, stepper.subStatus, alertStatus]);
}
