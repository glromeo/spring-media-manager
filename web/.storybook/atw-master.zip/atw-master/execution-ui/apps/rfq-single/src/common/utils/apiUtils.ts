import { logError } from "@atw/toolkit/telemetry";
import { apiFetch, apiGet, apiPost, apiQuery, QueryResult } from "@atw/toolkit/utility/apiUtils";
import { SerializedError } from "@reduxjs/toolkit";
import {
    GraphQLError,
    GraphQlExecutePlacementQuoteRequest,
    GraphQlExecutePlacementQuoteVariables,
    GraphQLPartialQuote,
    GraphQLPlacement,
    GraphQLPlacementCreationVariables
} from "../../api/types";
import { urlUserAtom } from "../../models/atoms";
import { Alert } from "../../features/alerts/alert";
import { BrokerEntity } from "../../features/brokers/brokers";
import { DIRECT_PLACEMENT_TYPES, RFQQuote, VENUE_PLACEMENT_TYPES } from "../../features/rfq/rfq";
import { RfqTradeForm } from "../../features/rfqTradeForm/rfqTradeForm";
import { TradeForm } from "../../features/tradeForm";
import { PRICE } from "../../models/common";
import { genericUtils } from "./genericUtils";
import { rfqUtils } from "./rfqUtils";
import { jotaiStore } from "@atx/toolkit/atoms";

export interface ApiQueryFailureResponse<R> extends QueryResult<R> {
    message: "Query Failure";
}

export type ApiError = {
    name: string;
    message: string;
};

export function apiError(name: string, message: string) {
    return { name, message };
}
const EXCLUDED_FIXTURES = ["filesDat"];
const trace = (options: any, text: any) => {
    const fixturePrefix = options?.fixture?.split("/")[0];
    if (EXCLUDED_FIXTURES.includes(fixturePrefix)) return;
    // console.log(`fixture: ${options.fixture}, msg: ${text}`);
};

export const apiUtils = {
    apiFetch: async (url: string, options: any = {}) => {
        return apiFetch(url, { trace, ...options });
    },

    apiGet: async <R>(url: string, options: any = {}): Promise<R> => {
        return apiGet(url, { trace, ...options });
    },

    apiPost: async <P, R>(url: string, body: P, options: any = {}): Promise<R> => {
        return apiPost(url, body, { trace, ...options });
    },
    apiQuery: async <V, R>(query: string, variables: V, options: any = {}): Promise<R> => {
        return apiQuery(query, variables, {
            trace,
            ...options
        });
    },
    // Tries to return response as JSON, then as text
    parseFetchResponse: async (response: Response) => {
        const text = await response.text();
        try {
            return JSON.parse(text);
        } catch (err) {
            return text;
        }
    },
    getUnableToFetchMessage: (targetObject: string, identifier?: string | number, identifierName?: string) => {
        let str = "Unable to fetch " + targetObject;
        if (identifierName && identifier) {
            str += " for " + identifierName + ": " + identifier;
        } else if (identifier) {
            str += ": " + identifier;
        }
        return str;
    },
    apiError: (name: string, message: string) => {
        return { name, message };
    },
    apiErrors: (alerts: Alert[]) => {
        const thrownAlerts = alerts.map((alert) => {
            return { ...alert, id: genericUtils.nextNumber(), timeout: alert.timeout ?? 3600000 };
        });
        return JSON.stringify(thrownAlerts);
    },
    reduceApiErrorsTo: (alerts: Alert[], { error }: { error: SerializedError }): Alert[] => {
        const throwAlerts = JSON.parse(error.message!);
        console.error(error.message!);
        return [...alerts, ...throwAlerts];
    },
    handleGQLErrorRes: (errors: GraphQLError[], message: string) => {
        let errorMessage = errors.map((m) => {
            return m.message + "\n";
        });
        logError(message, {
            message: errorMessage.toString().trim()
        });
        return apiUtils.apiError(message, errorMessage.toString().trim());
    },
    handleInvalidGQLRes: (order: any, req: GraphQlExecutePlacementQuoteRequest, message: string) => {
        logError(message, {
            "order id": order.id,
            "placement no": req.placementNum,
            "quote no": req.externId
        });
        throw new Error(`${message} for order: ${order.id}`);
    },
    getMostRecentPlacementNumber: (placements: GraphQLPlacement[]): { placementNum: number; basketID: string } => {
        const modifiedBy = jotaiStore.get(urlUserAtom)?.toLowerCase();
        const eligiblePlacements = placements.filter((p) => {
            const validAxe = !p.axeID; // RFQ shouldn't have axe
            const validBasketID = p.basketID !== null; // RFQ needs basketID
            const validPlacementType =
                DIRECT_PLACEMENT_TYPES.includes(p.type) || VENUE_PLACEMENT_TYPES.includes(p.type); // type = RFQ, RFQW, LP, LPC
            const validModifiedBy = p.modifiedBy?.toLowerCase() === modifiedBy; // modifiedBy = user
            return validAxe && validBasketID && validPlacementType && validModifiedBy;
        });
        return eligiblePlacements.sort((a, b) => b.placementNum - a.placementNum)[0];
    },
    // Create request for initial RFQ validation and request
    constructRfqRequest: (
        ordNum: number,
        rfqTradeForm: RfqTradeForm,
        user: string,
        spotType?: string
    ): GraphQLPlacementCreationVariables => {
        const isSpread = rfqTradeForm.pricingProtocolChecked === "Spread";
        const selectedDirectBrokersAndDesks = rfqTradeForm.selectedDirectBrokers.map((broker: BrokerEntity) => {
            const subBrokerId = rfqTradeForm?.selectedDeskMap?.[broker.name] || broker.desk[0].subBrokerID;
            return { broker: broker.name, subBrokerId: subBrokerId };
        });

        const rfqVariables: GraphQLPlacementCreationVariables = {
            request: {
                ordNum: ordNum,
                brokers: selectedDirectBrokersAndDesks,
                placementAllocationStrategy: {
                    strategy: "EXACT_AMOUNT",
                    value: rfqTradeForm.size
                },
                limitType: isSpread ? "S" : "P",
                dueInTime: rfqUtils.getDueInOrAtAsDateStr(rfqTradeForm),
                settleDate: rfqTradeForm.settleDate,
                isBin: rfqUtils.getRFQIsBin(rfqTradeForm)
            },
            user
        };
        const selectedVenue = rfqTradeForm.venues.find((venue) => venue.code === rfqTradeForm.selectedVenue?.code);
        let venueBrokersToSend;
        if (selectedVenue && rfqTradeForm.selectedVenueBrokers.length) {
            venueBrokersToSend = {
                venueBroker: selectedVenue.name,
                subBrokerId: selectedVenue.subBrokerID,
                executingBrokers: rfqTradeForm.selectedVenueBrokers.map((entity) => entity.name)
            };
            rfqVariables.request.venueBrokers = venueBrokersToSend ? [venueBrokersToSend] : [];
        }

        if (isSpread) {
            rfqVariables.request.spreadIndex = rfqTradeForm.benchmarkSelected.value;
            rfqVariables.request.spotType = spotType;
        }

        return rfqVariables;
    },
    // Create request for RFQ hit/lift and counter
    constructRfqActionRequest: (
        rfqQuotes: RFQQuote[],
        selectedQuoteID: string,
        tradeForm: TradeForm,
        user: string,
        isCounter?: boolean
    ): GraphQlExecutePlacementQuoteVariables => {
        const selectedQuote = rfqQuotes.find((q) => q.id === selectedQuoteID);
        const otherQuotes = rfqQuotes.filter((q) => q.id !== selectedQuoteID);
        if (!selectedQuote) {
            throw new Error("No matching quote found for quote ID: " + selectedQuoteID);
        }

        const { placementNum, id, size, broker } = selectedQuote;
        const pricingValue = selectedQuote.pricingType === PRICE ? tradeForm.price : tradeForm.spread;
        const request: GraphQlExecutePlacementQuoteVariables = {
            user,
            request: {
                placementNum,
                externId: id,
                quantity: size,
                askPrice: pricingValue as number,
                bidPrice: pricingValue as number,
                counterparty: broker
            },
            quotes: otherQuotes.map((quote: RFQQuote) => {
                return {
                    broker: quote.broker,
                    price: quote.pricingValue === "-" ? null : quote.pricingValue,
                    quantity: quote.size,
                    quoteID: quote.id
                } as GraphQLPartialQuote;
            })
        };

        if (isCounter) {
            // only send due in for countering
            request.request.dueInTime = genericUtils.getConvertedDueTime(parseInt(tradeForm.dueInSelected!));
        }

        return request;
    }
};
