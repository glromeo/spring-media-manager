import { APPLICATON_NAME, PRESET_TITLE, YES, NO } from "@atx/commons/model/preset";
import { createFavorite, queryFavorites, updateFavorite, deleteFavorite } from "@atw/toolkit/utility/favoritesApi";
import { storeObject, retrieveObject } from "@atx/toolkit/utils/storage";

export const FavoritesAPI = {
    createFavorite,
    queryFavorites,
    updateFavorite,
    deleteFavorite
};

type BrokerCodes = { [key: string]: number[] };

export type PresetContent = {
    presetName: string;
    selectedBrokerCodes: BrokerCodes;
    isDefault: string;
    id?: string;
};

const APP_ID = process.env.APP_ID;

export const PRESETS = "presets";

// Create new OR save as
export async function savePreset(
    name: string,
    selectedDirectBrokerCodes: number[],
    selectedVenueBrokerCodes: number[],
    selectedVenue: string,
    isShared: boolean
): Promise<PresetContent | null> {
    try {
        const brokers = createSelectedBrokers(selectedDirectBrokerCodes, selectedVenueBrokerCodes, selectedVenue);
        const content = createContent(name, brokers, NO);
        const newPreset = await FavoritesAPI.createFavorite({
            applicationName: APPLICATON_NAME,
            favoriteType: process.env.APP_ID?.includes("rfq") ? "RFQ" : APP_ID,
            title: PRESET_TITLE,
            activeFlag: isShared ? YES : NO,
            content: content
        });
        console.log(`preset ${name} was created successfully`);
        content.id = newPreset.id;
        updateLocalStorage(content, "SAVE");
        return content;
    } catch (error: any) {
        console.error(error.message);
        return null;
    }
}

export function createContent(presetName: string, brokers: BrokerCodes, isDefault: string, id?: string): PresetContent {
    return {
        presetName: presetName,
        selectedBrokerCodes: brokers,
        isDefault: isDefault,
        id: id
    };
}

export function createSelectedBrokers(
    selectedDirectBrokerCodes: number[],
    selectedVenueBrokerCodes: number[],
    selectedVenue: string
): BrokerCodes {
    return {
        DIRECT: selectedDirectBrokerCodes,
        [selectedVenue]: selectedVenueBrokerCodes
    };
}

export async function getPresets(): Promise<PresetContent[]> {
    try {
        const presets = retrieveObject<PresetContent[]>(PRESETS);
        if (!presets) {
            let types = ["RFQ"];
            if (APP_ID) {
                types.push(APP_ID);
            }
            const presetFavorites = await FavoritesAPI.queryFavorites<PresetContent>(
                {
                    applicationNames: [APPLICATON_NAME],
                    favoriteTypes: types,
                    favoriteTitles: [PRESET_TITLE]
                },
                "full"
            );
            const userPresets = presetFavorites.map((favoriteEntry) => { return {
                ...favoriteEntry.content,
                id: favoriteEntry.id
            }});
            storeObject(PRESETS, userPresets);
            return userPresets;
        } else {
            return presets;
        }
    } catch (error: any) {
        console.error(error.message);
        storeObject(PRESETS, []);
        return [];
    }
}

export function getIdIfExists(preset: PresetContent): string {
    if (preset.id) {
        return preset.id;
    } else {
        throw new Error(`preset id was not provided in content`);
    }
}

export function updateLocalStorage(newPresetContent: PresetContent, action: "UPDATE" | "SAVE" | "DELETE"): void {
    let presets = retrieveObject<PresetContent[]>(PRESETS);
    if (!presets) {
        getPresets();
    } else {
        switch (action) {
            case "DELETE":
                presets = presets.filter((brokerPreset) => brokerPreset.id !== newPresetContent.id);
                break;
            case "SAVE":
                presets.push(newPresetContent);
                break;
            case "UPDATE":
                const brokerPresetIndex = presets.findIndex((brokerPreset) => brokerPreset.id === newPresetContent.id);
                if (brokerPresetIndex > -1) {
                    presets[brokerPresetIndex] = newPresetContent;
                }
                break;
        }
        storeObject(PRESETS, presets);
    }
}

// Same brokers, new name
export async function renamePreset(preset: PresetContent, newName: string): Promise<PresetContent | null> {
    try {
        const presetId = getIdIfExists(preset);
        const newContent = { ...preset, presetName: newName };
        await FavoritesAPI.updateFavorite(presetId, {
            applicationName: APPLICATON_NAME, // have to specify, otherwise it's overriden by the library method from Aladdin_Trader to single-rfq
            content: newContent
        });
        console.log(`preset ${newName} was successfully updated`);
        updateLocalStorage(newContent, "UPDATE");
        return newContent;
    } catch (error: any) {
        console.error(error.message);
        return null;
    }
}

// Same name, new brokers
export async function updatePresetBrokers(
    preset: PresetContent,
    newSelectedDirectBrokerCodes: number[],
    newSelectedVenueBrokerCodes: number[],
    selectedVenue: string
): Promise<PresetContent | null> {
    try {
        const presetId = getIdIfExists(preset);
        const newContent = {
            ...preset,
            selectedBrokerCodes: createSelectedBrokers(
                newSelectedDirectBrokerCodes,
                newSelectedVenueBrokerCodes,
                selectedVenue
            )
        };
        await FavoritesAPI.updateFavorite(presetId, {
            applicationName: APPLICATON_NAME,
            content: newContent
        });
        console.log(`preset ${preset.presetName} was successfully updated`);
        updateLocalStorage(newContent, "UPDATE");
        return newContent;
    } catch (error: any) {
        console.error(error.message);
        return null;
    }
}

export async function deletePreset(preset: PresetContent): Promise<string | null> {
    try {
        const presetId = getIdIfExists(preset);
        await FavoritesAPI.deleteFavorite(presetId);
        console.log(`preset ${preset.presetName} was successfully deleted`);
        updateLocalStorage(preset, "DELETE");
        return presetId;
    } catch (error: any) {
        console.error(error.message);
        return null;
    }
}

// new default preset
// making a call to remove the old default preset- if it succeeds, proceed to set a new default
// if the first update call succeeds, but second fails, there is no default preset set
export async function setAsDefault(
    newDefaultPreset: PresetContent,
    oldDefaultPreset?: PresetContent
): Promise<PresetContent | null> {
    try {
        if (oldDefaultPreset) {
            const oldPresetId = getIdIfExists(oldDefaultPreset);
            oldDefaultPreset.isDefault = NO;
            await FavoritesAPI.updateFavorite(oldPresetId, {
                applicationName: APPLICATON_NAME,
                content: oldDefaultPreset
            });
            console.log(`${oldDefaultPreset.presetName} was updated to non-default`);
            updateLocalStorage(oldDefaultPreset, "UPDATE");
        }
        const presetId = getIdIfExists(newDefaultPreset);
        newDefaultPreset.isDefault = YES;
        await FavoritesAPI.updateFavorite(presetId, {
            applicationName: APPLICATON_NAME,
            content: newDefaultPreset
        });
        console.log(`${newDefaultPreset.presetName} was set as default`);
        updateLocalStorage(newDefaultPreset, "UPDATE");
        return newDefaultPreset;
    } catch (error: any) {
        console.log(error.message);
        return null;
    }
}

export const brokerPresetsAPI = {
    savePreset,
    getPresets,
    renamePreset,
    updatePresetBrokers,
    deletePreset,
    setAsDefault
};
