import {
    BrokerEligibility,
    BrokerEntity,
    BrokerRestrictionAllocation,
    BrokerRestrictionLevel
} from "../../features/brokers/brokers";

export const brokerUtils = {
    isFullyRestricted: (entity: BrokerEntity) => entity?.restriction?.quantity === 0,

    isFullyAvailable: (entity: BrokerEntity) =>
        entity?.restriction?.allocation.filter((allocation) => allocation.isRestricted).length === 0,

    isRestrictedBrokerEntity: (entity: BrokerEntity): boolean => {
        if (!entity.restriction) return false;
        return entity.restriction.percent !== 100;
    },

    isAllocated: (allocations: BrokerRestrictionAllocation[], code: number) =>
        allocations.find((allocation) => allocation.code === code) !== undefined,

    hasBrokerRestrictions: (entities: BrokerEntity[]) => {
        const ent = entities.filter((entity: BrokerEntity) => {
            if (!entity.restriction) return false;
            const restricted = entity.restriction.allocation.filter((allocation) => allocation.isRestricted);
            return restricted.length > 0;
        });
        return ent.length > 0;
    },
    getBrokersWithMultipleDesks: (selectedBrokers: BrokerEntity[]): BrokerEntity[] => {
        return selectedBrokers?.filter((b) => b.desk.length > 1);
    },
    getBrokerEligibilities: (brokers: BrokerEntity[]): { [key: number]: BrokerEligibility } => {
        let eligibilities: { [key: number]: BrokerEligibility } = {};
        brokers?.forEach((broker) => {
            {
                const restrictionLevel: BrokerRestrictionLevel = brokerUtils.isFullyAvailable(broker)
                    ? "NONE"
                    : brokerUtils.isFullyRestricted(broker)
                    ? "FULL"
                    : "PARTIAL";
                const eligibility = {
                    name: broker.name,
                    spreadEligible: brokers
                        .filter((b) => b.isSpreadFlowEnabled)
                        .map((b) => b.code)
                        .includes(broker.code),
                    spotTimeEligible: brokers
                        .filter((b) => b.isDelayedSpot)
                        .map((b) => b.code)
                        .includes(broker.code),
                    restrictionLevel
                };
                eligibilities[broker.code] = eligibility;
            }
        });

        return eligibilities;
    }
};
