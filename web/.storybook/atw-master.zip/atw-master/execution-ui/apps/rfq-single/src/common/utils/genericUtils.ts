/****************************
 ***** GENERIC UTILS ********
 ****************************/

import { logClick, logView } from "@atw/toolkit/telemetry";
import { DateTime } from "luxon";
import { NUM_PLACE_HOLDER, Side } from "../../models/common";
import { SpotTime } from "src/features/order/order";

let _nextNumber = 1;
type FormatDateConfig = {
    fullYear: boolean;
    month?: "short" | "number";
    separator?: "slash" | "dash";
};

export const genericUtils = {
    updateBrowserTitle: (newTitle: string) => (document.title = newTitle),
    nextNumber: () => {
        return _nextNumber++;
    },
    formatSize: (size: number, decimals?: number): string => {
        let num = Math.abs(size).toString();
        if (decimals) num = size.toFixed(decimals);
        return num.replace(/\B(?=(\d{3}){1,25}(?!\d))/g, ",");
    },
    isValidNumber: (num: any): boolean => {
        return !Number.isNaN(Number.parseFloat(num)) && num !== NUM_PLACE_HOLDER;
    },
    isValidString: (string: any): boolean => {
        return string && string !== "-";
    },
    removeCommas: (val: string): string => {
        // eslint-disable-next-line
        return val.replace(/[^0-9\.-]/g, "");
    },
    removeSpace: (val: string = "", lowerCase: boolean = true): string => {
        // eslint-disable-next-line
        const newVal = val.replace(/\s/g, "");
        return lowerCase ? newVal.toLowerCase() : newVal;
    },
    titleCase: (val: string): string => {
        if (val === null || val === undefined || val === "") return "";
        else val = val.toString();

        return val.replace(/\w\S*/g, function (txt) {
            return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
        });
    },
    formatDate: (
        val: string | undefined,
        dateConfig: FormatDateConfig = {
            fullYear: true,
            month: "number",
            separator: "slash"
        }
    ): string | undefined => {
        const { fullYear, month, separator } = dateConfig;
        let dateString: string = "-";
        let formattedMonth: string = "-";
        let date: Date = val ? new Date(val) : new Date();
        let formattedDay = ("0" + date.getDate()).slice(-2);
        if (month === "short") formattedMonth = date.toLocaleString("en-US", { month: "short" });
        if (month === "number" || month === undefined) formattedMonth = ("0" + (date.getMonth() + 1)).slice(-2);
        let formattedYear = fullYear ? date.getFullYear() : date.getFullYear().toString().substr(2, 2);
        if (separator === "dash") {
            dateString = `${formattedDay}-${formattedMonth.toUpperCase()}-${formattedYear}`;
        }
        if (separator === "slash" || separator === undefined) {
            dateString = formattedMonth + "/" + formattedDay + "/" + formattedYear;
        }
        return dateString;
    },
    getTodaysDate: (isFullYear: boolean) => {
        return genericUtils.formatDate(undefined, { fullYear: isFullYear });
    },
    getCurrentTime: (timeZone: string = "", offsetMins?: number) => {
        return DateTime.local({ zone: timeZone })
            .plus({ minutes: offsetMins || 0 })
            .toFormat("hh:mm a");
    },
    convertHHmmToDate: (hourMins: string | null): DateTime | null => {
        // sets current computer location's date with inputted time
        if (!hourMins || hourMins === "-") {
            return null;
        }
        return DateTime.fromFormat(hourMins.replace("  ", " "), "t", {
            zone: "America/New_York"
        });
    },
    formatPrice: (price: number): string => {
        return price !== null ? genericUtils.convertToMinPrecision(price, 3) : "-";
    },
    formatSpread: (spread: number): string => {
        if (spread !== null) {
            const prefix = spread > 0 ? `+` : ``;
            return `${prefix}${genericUtils.convertToMinPrecision(spread, 3)}`;
        }
        return "-";
    },
    convertToMinPrecision: (num: number, minPrecision: number, maxPrecision?: number): string => {
        return Intl.NumberFormat("en-US", {
            minimumFractionDigits: minPrecision,
            maximumFractionDigits: maxPrecision || 20 // max allowed is 20
        }).format(num);
    },
    getSideTitle: (side: Side) => {
        return side === "BUY" ? "Lift" : "Hit";
    },
    getTimeDiff: (t1: Date, t2: Date): number => {
        let dif = t1.getTime() - t2.getTime();
        return dif / 1000;
    },
    getSpotTimesInString: (spotTimeMs: number | null) => {
        let currentTime = "";
        if (spotTimeMs) {
            let spotTime = DateTime.fromMillis(spotTimeMs).setZone("America/New_York");
            if (spotTime.minute === 0) {
                currentTime = spotTime.toFormat("h a") + " ET";
            } else {
                currentTime = spotTime.toFormat("h:mm a") + " ET";
            }
        } else {
            currentTime = "Spot Now";
        }
        return currentTime;
    },
    getConvertedDueTime: (offsetMins?: number) => {
        return `${DateTime.local({ zone: "America/New_york" })
            .plus({ minutes: offsetMins || 0 })
            .toFormat("HH:mm:ss")}|America/New_York`;
    },
    sortSpotTimes: (spotTimes: SpotTime[]) => {
        const compareSpotTimesAscending = (a: SpotTime, b: SpotTime) => {
            if (!a.code.includes(":") && !b.code.includes(":")) return a.code.localeCompare(b.code);
            if (!a.code.includes(":")) return -1;
            if (!b.code.includes(":")) return 1;
            return a.code.localeCompare(b.code);
        };

        return [...spotTimes].sort(compareSpotTimesAscending);
    },
    parseSecondsToMinutesString: (val: string): string => {
        const seconds = parseInt(genericUtils.removeSpace(val));
        const remainder = seconds % 60;
        const minutes = (seconds - remainder) / 60;
        if (!isNaN(seconds)) {
            let minutesString = minutes.toString() + " minutes";
            return remainder > 0 ? minutesString + " " + remainder.toString() + " seconds" : minutesString;
        } else {
            throw new Error(`Unable to parse token ${val} to 'Due In' minutes string.`);
        }
    },
    wait: async (ms: number) => {
        return new Promise<boolean>((resolve) => {
            setTimeout(() => resolve(true), ms);
        });
    },
    getAppname: () => {
        return "at-rfq-single";
    },
    isNumPlaceHolder: (num: number) => {
        return num === NUM_PLACE_HOLDER;
    },
    isFloat: (value: number | string) => {
        return Number(value) === value && value % 1 !== 0;
    },
    logTelemetryView() {
        logView(`User Initialized Single Order RFQ`);
    },
    logTelemetryClick(label: string, field: string, newValue: string) {
        logClick(`User changed ${label}`, { [field]: newValue });
    }
};
