import { GraphQLOrderSummary } from "../../api/types";
import { BrokerEntity, BrokerRestrictionAllocation } from "../../features/brokers/brokers";

export const orderUtils = {
    isFullyRestricted: (entity: BrokerEntity) => entity?.restriction?.quantity === 0,

    isFullyAvailable: (entity: BrokerEntity) =>
        entity?.restriction?.allocation.filter((allocation) => allocation.isRestricted).length === 0,

    isRestrictedBrokerEntity: (entity: BrokerEntity): boolean => {
        if (!entity.restriction) return false;
        return entity.restriction.percent !== 100;
    },

    isAllocated: (allocations: BrokerRestrictionAllocation[], code: number) =>
        allocations.find((allocation) => allocation.code === code) !== undefined,

    hasBrokerRestrictions: (entities: BrokerEntity[]) => {
        const ent = entities.filter((entity: BrokerEntity) => {
            if (!entity.restriction) return false;
            const restricted = entity.restriction.allocation.filter((allocation) => allocation.isRestricted);
            return restricted.length > 0;
        });
        return ent.length > 0;
    },

    isCounteringEnabled: (code: number, fiOrderSummary: GraphQLOrderSummary) => {
        return fiOrderSummary?.actionableCounteringEnabled?.includes(code) ?? false;
    }
};
