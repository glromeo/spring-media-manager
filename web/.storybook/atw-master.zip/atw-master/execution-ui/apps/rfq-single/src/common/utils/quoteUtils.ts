import { DateTime } from "luxon";
import { genericUtils, rfqUtils } from ".";
import { GraphQLPlacement, GraphQLQuote } from "../../api/types";
import { PLACEMENT_STATUS, PLACEMENT_TYPE } from "../../features/placement/placement";
import {
    BROKER_RESPONDED,
    CANCELED,
    COMMITTED_PLACEMENT_TYPES,
    DECLINED,
    ERROR,
    EXPIRED,
    PENDING_CANCEL,
    QUOTE_SUBJECT,
    REQUEST_SENT,
    RFQStatus,
    TRADE_CONFIRMED,
    TRADE_PENDING,
    TRADED,
    UNKNOWN,
    VENUE_PLACEMENT_TYPES
} from "../../features/rfq/rfq";
import { Side } from "../../models/common";
import { Tokens } from "@atx/commons/atoms";

export const quoteUtils = {
    placementDueInExpired: (placement: GraphQLPlacement, tokens: Tokens): boolean => {
        return (
            rfqUtils.getServiceAccountLogins(tokens).includes(placement.modifiedBy?.toUpperCase()) &&
            placement.modifiedBy !== ""
        );
    },
    getValidRFQPlacementQuotes: (placement: GraphQLPlacement, side: Side) => {
        return placement.quotes.filter((quote) => {
            if (quote.counterparty) {
                // refactor-todo: do we still need this? confirm w/ backend team
                if (
                    !genericUtils.isValidNumber(quote.counterparty.code) ||
                    !genericUtils.isValidString(quote.counterparty.shortName) ||
                    !genericUtils.isValidString(quote.counterparty.ticker)
                ) {
                    console.error(`no counterparty defined for quote: ${JSON.stringify(quote)}`);
                    return false;
                }
                if ((side == "BUY" && quote.side !== "ASK") || (side === "SELL" && quote.side !== "BID")) {
                    // BUY order must have ASK quotes; SELL order must have BID quotes
                    return false;
                }
            } else {
                console.error(`no counterparty defined for quote: ${JSON.stringify(quote)}`);
                return false;
            }
            return true;
        });
    },
    getRFQStatusForDirect: (placement: GraphQLPlacement, tokens: Tokens): RFQStatus => {
        // NOSONAR
        let { modifyReason, status, type } = placement;
        status = status.toLocaleUpperCase();
        const MODIFY_REASON = rfqUtils.getModifyReasonLib();
        if (
            (status === PLACEMENT_STATUS.PA && modifyReason === MODIFY_REASON.NOS) || // Pending Active (A) / New Order Single (NOS)
            (status === PLACEMENT_STATUS.PQL && modifyReason === MODIFY_REASON.RQCR) // Pending Quote Lift (PQL) // Quote Counter (RQCR)
        ) {
            return REQUEST_SENT; // Initial request has been sent
        } else if (status === PLACEMENT_STATUS.Q && modifyReason === MODIFY_REASON.RQQA) {
            // Quoted (Q) / Quoted (RQQA)
            return BROKER_RESPONDED; // Broker has responded
        } else if (
            status === PLACEMENT_STATUS.PQL &&
            modifyReason === MODIFY_REASON.RQLP // Pending Quote Lift (PQL) / Lift Requested (RQLP)
        ) {
            return TRADE_PENDING; // Trade Request pending broker agreement
        } else if (
            (status === PLACEMENT_STATUS.Q && modifyReason === MODIFY_REASON.QCR) || // Quoted (Q) / Quote Confirmed (QCR)
            (status === PLACEMENT_STATUS.PQL && modifyReason === MODIFY_REASON.RQLA) // Pending Quote Lift (PQL) / Lift Accepted (RQLA)) {
        ) {
            return TRADE_CONFIRMED; // Trade Request pending delayed spot info
        } else if (
            (status === PLACEMENT_STATUS.F && modifyReason === MODIFY_REASON.F) || // Filled (F) / Fill (F)
            (status === PLACEMENT_STATUS.F && modifyReason === MODIFY_REASON.TCRT) || // Filled (F) / Trade Correct (TCRT)
            (status === PLACEMENT_STATUS.F && modifyReason === MODIFY_REASON.PT) || // Filled (F) / Pending Trade (PT)
            (status === PLACEMENT_STATUS.COM && modifyReason === MODIFY_REASON.TB) // Completed (COM) / Post Trade (TB)
        ) {
            return TRADED; // Successfully traded with the broker
        } else if (
            (status === PLACEMENT_STATUS.ERR && modifyReason === MODIFY_REASON.REJ) || // Error (ERR) / Rejected (REJ)
            (status === PLACEMENT_STATUS.A && modifyReason === MODIFY_REASON.RQLR) || // Active (A) / Lift Rejected (RQLR)
            (status === PLACEMENT_STATUS.C && modifyReason === MODIFY_REASON.RQQP) || // Cancelled (C) / Quote Passed (RQQP)
            (status === PLACEMENT_STATUS.PCL && modifyReason === MODIFY_REASON.RPPR) || // Pending Cancel (PCL) / Quote Pass Request (RPPR)
            (status === PLACEMENT_STATUS.C && modifyReason === MODIFY_REASON.RQQC) // Cancelled (C) / Quote Cancelled (RQQC)
        ) {
            return DECLINED; // Broker declined
        } else if (
            (status === PLACEMENT_STATUS.C && modifyReason === MODIFY_REASON.RQQE) || // Cancelled (C) / Quote Expired (RQQE)
            (status === PLACEMENT_STATUS.X && modifyReason === MODIFY_REASON.PE) || // Expired (X) / Placement Expired (PE)
            (status === PLACEMENT_STATUS.C && quoteUtils.placementDueInExpired(placement, tokens)) // System expired placement
        ) {
            return EXPIRED; // Timer expired
        } else if (status === PLACEMENT_STATUS.Q && modifyReason === MODIFY_REASON.QSUB) {
            // Quoted (Q) / Quote Subjected (QSUB)
            return QUOTE_SUBJECT; // Broker response is subjective
        } else if (
            (status === PLACEMENT_STATUS.Q && modifyReason === MODIFY_REASON.RQT) || // Quoted (Q) / Quote Tied (RQT)
            (status === PLACEMENT_STATUS.Q && modifyReason === MODIFY_REASON.RQCT) || // Quoted (Q) / Quote Cover Tied (RQCT)
            (status === PLACEMENT_STATUS.Q && modifyReason === MODIFY_REASON.RQDA) || // Quoted (Q) / Quote Done Away (RQDA)
            (status === PLACEMENT_STATUS.Q && modifyReason === MODIFY_REASON.RQC) || // Quoted (Q) / Quote Cover (RQC)
            (status === PLACEMENT_STATUS.PCL && modifyReason === MODIFY_REASON.CR) || // Pending Cancel (PCL) / Cancel Request (CR)
            (status === PLACEMENT_STATUS.PCL && modifyReason === MODIFY_REASON.RQCS) || // Pending Cancel (PCL) / Quote Color Sent (RQCS)
            (status === PLACEMENT_STATUS.PCL && modifyReason === MODIFY_REASON.RQDT) // Pending Cancel (PCL) / Quote Color Sent DNT (RQDT)
        ) {
            return PENDING_CANCEL; // Either Trader or Broker are trying to cancel the request
        } else if (
            (status === PLACEMENT_STATUS.C && modifyReason === MODIFY_REASON.MC) || // Cancelled (C) / Manual Cancel (MC)
            (status === PLACEMENT_STATUS.C && modifyReason === MODIFY_REASON.C) || // Cancelled (C) / Cancelation (C)
            (status === PLACEMENT_STATUS.ERR && modifyReason === MODIFY_REASON.SF) // Error (ERR) / Sending Failure (SF)
        ) {
            return CANCELED; // Broker request canceled
        }
        console.log(
            `Reached UNKNOWN RFQ Status for ${type === PLACEMENT_TYPE.RFQW ? "committed (RFQW)" : "uncommitted (RFQ)"} direct quote. PlacementStatus=${status}, modifyReason=${modifyReason} for placementNum=${placement.placementNum}.`
        );
        return UNKNOWN;
    },
    // LP placements only
    getRFQStatusForUncommittedVenue: (placement: GraphQLPlacement, quote: GraphQLQuote): RFQStatus => {
        // NOSONAR
        const { modifyReason, status } = placement;
        const { quoteStatus } = quote;
        const { NOS, N, C, MC, CR, RQQE, RFQC, RQQP, RQPN, RQPC } = rfqUtils.getModifyReasonLib();
        const QUOTE_STATUS = rfqUtils.getQuoteStatusLib();
        const isNullQuoteStatus = !genericUtils.isValidString(quoteStatus);
        const isCoveredQuoteStatus = isNullQuoteStatus
            ? false
            : [QUOTE_STATUS.D, QUOTE_STATUS.N, QUOTE_STATUS.S, QUOTE_STATUS.U, QUOTE_STATUS.B].includes(quoteStatus!);

        if (
            (status === PLACEMENT_STATUS.PA && modifyReason === NOS && isNullQuoteStatus) || // Pending Active (PA) / New Order Single (NOS) / empty or null quote status
            (status === PLACEMENT_STATUS.A && modifyReason === N && isNullQuoteStatus) // Active (A) / New (N) / empty or null quote status
        ) {
            return REQUEST_SENT; // Initial request has been sent
        } else if (status === PLACEMENT_STATUS.A && modifyReason === N && quoteStatus === QUOTE_STATUS.A) {
            // Active (A) / New (N) / Active (A)
            return BROKER_RESPONDED; // Broker has responded
        } else if (
            (status === PLACEMENT_STATUS.C && modifyReason === RQQE && quoteStatus === QUOTE_STATUS.A) || // Cancelled (C) / Quote Expired (RQQE) / Active (A)
            (status === PLACEMENT_STATUS.C && modifyReason === RQQE && isNullQuoteStatus) // Cancelled (C) / Quote Expired (RQQE) / empty or null quote status
        ) {
            return EXPIRED; // Timer expired
        } else if (
            (status === PLACEMENT_STATUS.PCL && modifyReason === CR) || // Pending Cancel (PCL) / Cancel Request (CR)
            (status === PLACEMENT_STATUS.A && modifyReason === RQPN && quoteStatus === QUOTE_STATUS.Z) || // Active (A) / Pending Negotiation (RQPN) / Not Received (Z)
            (status === PLACEMENT_STATUS.A && modifyReason === RQPN && isCoveredQuoteStatus) || // Active (A) / Pending Negotiation (RQPN) // Covered++
            (status === PLACEMENT_STATUS.A && modifyReason === RFQC && isCoveredQuoteStatus) || // Active (A) / RFQ Color (RFQC) // Covered++
            (status === PLACEMENT_STATUS.A && modifyReason === RFQC && quoteStatus === QUOTE_STATUS.Z) || // Active (A) / RFQ Color (RFQC) / Not Received (Z)
            (status === PLACEMENT_STATUS.A && modifyReason === RQPC && isCoveredQuoteStatus) || // Active (A) / Pending Counter (RQPC) / Covered++
            (status === PLACEMENT_STATUS.A && modifyReason === RQPC && quoteStatus === QUOTE_STATUS.Z) || // Active (A) / Pending Counter (RQPC) / Not Received (Z)
            (status === PLACEMENT_STATUS.A && modifyReason === N && isCoveredQuoteStatus) || // Active (A) / New (N) / Covered++
            (status === PLACEMENT_STATUS.A && modifyReason === N && quoteStatus === QUOTE_STATUS.Z) || // Active (A) / New (N) / Not Received (Z)
            (status === PLACEMENT_STATUS.A && modifyReason === RQPC && quoteStatus === QUOTE_STATUS.Z) // Active (A) / Pending Counter (RQPC) / Not Received (Z)
        ) {
            return PENDING_CANCEL; // Either Trader or Broker are trying to cancel the request
        } else if (
            (status === PLACEMENT_STATUS.C && modifyReason === C) || // Cancelled (C) / Cancelation (C)
            (status === PLACEMENT_STATUS.C && modifyReason === MC) // Cancelled (C) / Manual Cancel (MC)
        ) {
            return CANCELED; // Broker request canceled
        } else if (status === PLACEMENT_STATUS.A && modifyReason === N && quoteStatus === QUOTE_STATUS.C) {
            // Active (A) / New (N) / Cancelled (C)
            return DECLINED; // Broker declined request
        } else if (
            (status === PLACEMENT_STATUS.C && modifyReason === RQQP && isNullQuoteStatus) || // Cancelled (C) / Quote Passed (RQQP) / empty or null quote status
            status === PLACEMENT_STATUS.ERR // Error (ERR)
        ) {
            console.log(
                `Reached ERROR RFQ Status for uncommitted (LP) venue quote. PlacementStatus=${status}, modifyReason=${modifyReason}, quoteStatus=${quoteStatus} for placementNum=${placement.placementNum} and quoteID=${quote.quoteID}.`
            );
            return ERROR;
        }
        console.log(
            `Reached UNKNOWN RFQ Status for uncommitted (LP) venue quote. PlacementStatus=${status}, modifyReason=${modifyReason}, quoteStatus=${quoteStatus} for placementNum=${placement.placementNum} and quoteID=${quote.quoteID}.`
        );
        return UNKNOWN;
    },
    // LPC placements only
    getRFQStatusForCommittedVenue: (placement: GraphQLPlacement, quote: GraphQLQuote): RFQStatus => {
        // NOSONAR
        const { modifyReason, status } = placement;
        const { quoteStatus } = quote;
        const { RQLP, RQLA, F, QCR, TCRT, RQCR, RQQP, RQQE, C, MC } = rfqUtils.getModifyReasonLib();
        const QUOTE_STATUS = rfqUtils.getQuoteStatusLib();
        if (status === PLACEMENT_STATUS.PQL && modifyReason === RQLP && quoteStatus === QUOTE_STATUS.T) {
            // Pending Quote Lift (PQL) / Lift Requested (RQLP) / Traded (T)
            return TRADE_PENDING; // Broker acked, awaiting fills
        } else if (status === PLACEMENT_STATUS.PQL && modifyReason === RQCR && quoteStatus === QUOTE_STATUS.T) {
            // Pending Quote Lift (PQL) / Quote Counter (RQCR) / Traded (T)
            return REQUEST_SENT;
        } else if (
            status === PLACEMENT_STATUS.PQL &&
            modifyReason === RQLA &&
            quoteStatus === QUOTE_STATUS.T // Pending Quote Lift (PQL) / Lift Accepted (RQLA) / Traded (T)
        ) {
            return TRADE_CONFIRMED; // Broker acked, awaiting fills
        } else if (
            (status === PLACEMENT_STATUS.F && modifyReason === F && quoteStatus === QUOTE_STATUS.T) || // Filled (F) / Fill (F) / Traded (T)
            (status === PLACEMENT_STATUS.Q && modifyReason === QCR && quoteStatus === QUOTE_STATUS.T) || // Quoted (Q) / Quote Confirmed (TCRT) / Traded (T)
            (status === PLACEMENT_STATUS.F && modifyReason === TCRT && quoteStatus === QUOTE_STATUS.T) // Filled (F) / Trade Correct (TCRT) / Traded (T)
        ) {
            return TRADED; // Filled
        } else if (
            status === PLACEMENT_STATUS.C &&
            modifyReason === RQQP &&
            quoteStatus === QUOTE_STATUS.T // Cancelled (C) / Quote Passed (RQQP) / Traded (T)
        ) {
            return DECLINED; //Quote Declined
        } else if (
            status === PLACEMENT_STATUS.C &&
            modifyReason === RQQE &&
            quoteStatus === QUOTE_STATUS.T // Cancelled (C) / Quote Expired (RQQE) / Traded (T)
        ) {
            return EXPIRED; //Quote Expired
        } else if (
            (status === PLACEMENT_STATUS.C && modifyReason === C) || // Cancelled (C) / Cancelation (C)
            (status === PLACEMENT_STATUS.C && modifyReason === MC) // Cancelled (C) / Manual Cancel (MC)
        ) {
            return CANCELED; // Broker request canceled
        }
        console.log(
            `Reached UNKNOWN RFQ Status for committed (LPC) venue quote. PlacementStatus=${status}, modifyReason=${modifyReason}, quoteStatus=${quoteStatus} for placementNum=${placement.placementNum} and quoteID=${quote.quoteID}.`
        );
        return UNKNOWN;
    },
    getRfqStatus: (placement: GraphQLPlacement, quote: GraphQLQuote, tokens: Tokens): RFQStatus => {
        const isVenue = VENUE_PLACEMENT_TYPES.includes(placement.type); // LP, LPC
        const isCommitted = COMMITTED_PLACEMENT_TYPES.includes(placement.type); // LPC
        if (isVenue) {
            // LP, LPC placements have different mappings
            return isCommitted
                ? quoteUtils.getRFQStatusForCommittedVenue(placement, quote)
                : quoteUtils.getRFQStatusForUncommittedVenue(placement, quote);
        } else {
            // RFQ, RFQW placements have the same mappings
            return quoteUtils.getRFQStatusForDirect(placement, tokens);
        }
    },
    isExpired: (time: number | null | "-", rfqStatus?: RFQStatus): boolean => {
        if (!genericUtils.isValidNumber(time) || rfqStatus === QUOTE_SUBJECT) {
            return false;
        }
        let currentDateTime = DateTime.local({ zone: "America/New_York" });
        return (
            DateTime.fromMillis(Number(time!), { zone: "America/New_York" }).diff(currentDateTime).as("seconds") <= 0
        );
    }
};
