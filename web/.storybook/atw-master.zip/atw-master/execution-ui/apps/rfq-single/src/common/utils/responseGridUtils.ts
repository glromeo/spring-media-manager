import { PricingType } from "../../features/order/order";
import { RFQQuote } from "../../features/rfq/rfq";
import { Side } from "../../models/common";
import { genericUtils } from "./genericUtils";

export const responseGridUtils = {
    sortResponses: (rfqQuotes: RFQQuote[], side: Side) => {
        return rfqQuotes?.sort((quoteA: RFQQuote, quoteB: RFQQuote): number => {
            const pricingType = quoteA.pricingType;

            // If no quote price or spread (usually on just initial RFQ request), sort by broker alphabetically
            if (!genericUtils.isValidNumber(quoteA.pricingValue) && !genericUtils.isValidNumber(quoteB.pricingValue)) {
                return quoteA.broker.localeCompare(quoteB.broker);
            }

            if (!genericUtils.isValidNumber(quoteA.pricingValue)) {
                return 1;
            }

            if (!genericUtils.isValidNumber(quoteB.pricingValue)) {
                return -1;
            }

            // if both quotes have same price/spread, sort based on earlier modified time
            if (quoteA.pricingValue === quoteB.pricingValue) {
                return +quoteA.modifiedTime - +quoteB.modifiedTime;
            }

            if ((side === "BUY" && pricingType === "PRICE") || (side === "SELL" && pricingType === "SPREAD")) {
                // sort by lowest price or spread
                return +quoteA.pricingValue - +quoteB.pricingValue;
            }
            if ((side === "SELL" && pricingType === "PRICE") || (side === "BUY" && pricingType === "SPREAD")) {
                // sort by highest price or spread
                return +quoteB.pricingValue - +quoteA.pricingValue;
            }

            return 0;
        });
    },
    formatValueByPricingType: (value: number | null, pricingType: PricingType): string => {
        if (!genericUtils.isValidNumber(value)) {
            return "-";
        }

        if (pricingType === "SPREAD") {
            return genericUtils.formatSpread(value!);
        } else {
            return genericUtils.formatPrice(value!);
        }
    },
    parseStringValue: (str: string | undefined | null): string => {
        if (str === undefined || str === null) {
            return "-";
        }
        return str;
    }
};
