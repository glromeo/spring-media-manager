import { DateTime } from "luxon";
import { BrokerEntity } from "../../features/brokers/brokers";
import { decodesAtom } from "../../features/decodes";
import { PricingType } from "../../features/order/order";
import { MODIFY_REASON } from "../../features/placement/modifyReason";
import { QUOTE_STATUS } from "../../features/placement/quoteStatus";
import {
    BROKER_RESPONDED,
    QUOTE_SUBJECT,
    REQUEST_SENT,
    RFQQuote,
    TRADE_CONFIRMED,
    TRADE_PENDING,
    TRADED,
    CANCELED,
    DECLINED
} from "../../features/rfq/rfq";
import { PricingProtocol, RfqTradeForm } from "../../features/rfqTradeForm/rfqTradeForm";
import { Tokens } from "@atx/commons/atoms";
import { Side } from "../../models/common";
import { genericUtils } from "./genericUtils";
import { jotaiStore } from "@atx/toolkit/atoms";

// Need to temporarily use the store on the window due to cypress tests. Need to get tests to work without using window...

export const rfqUtils = {
    getDueInOrAt: (rfqTradeForm: RfqTradeForm): { dueValue: string; dueLabel: string | undefined } => {
        const dueLabel = rfqTradeForm.dueProtocolChecked;
        if (dueLabel === "Due At") {
            return { dueLabel, dueValue: rfqTradeForm.dueAt! };
        } else {
            return { dueLabel, dueValue: rfqTradeForm.dueInSelected.value };
        }
    },
    isRfqTradeFormDueAt: (rfqTradeForm: RfqTradeForm): boolean => {
        return Boolean(rfqTradeForm.dueProtocolChecked === "Due At" && rfqTradeForm.dueAt);
    },
    getDueInOrAtAsDate: (rfqTradeForm: RfqTradeForm): DateTime | null => {
        if (rfqTradeForm.dueProtocolChecked === "Due At") {
            return genericUtils.convertHHmmToDate(rfqTradeForm.dueAt!);
        } else {
            return DateTime.local({ zone: "America/New_York" }).plus({
                seconds: parseInt(rfqTradeForm.dueInSelected.value)
            });
        }
    },
    getDueInOrAtAsDateStr: (rfqTradeForm: RfqTradeForm): string => {
        if (rfqTradeForm.dueProtocolChecked === "Due At") {
            const date = genericUtils.convertHHmmToDate(rfqTradeForm.dueAt!);
            return date?.toFormat("HH:mm:ss") + "|America/New_York";
        } else {
            return genericUtils.getConvertedDueTime(parseInt(rfqTradeForm.dueInSelected.value));
        }
    },
    getDueLabelWithTimerType: (rfqTradeForm: RfqTradeForm): string => {
        return (
            rfqUtils.getDueInOrAt(rfqTradeForm).dueLabel + (rfqUtils.getRFQIsBin(rfqTradeForm) ? " (Bin)" : " (ASAP)")
        );
    },
    isDueAtExpired: (dueAtTime: string) => {
        // does not take into account seconds
        const dueTime = genericUtils.convertHHmmToDate(dueAtTime)!;
        const localTime = DateTime.local({ zone: "America/New_York" });
        return dueTime <= localTime;
    },
    isDueAtBetweenTradingHours: (dueAtTime: string) => {
        const userDueAtTime = genericUtils.convertHHmmToDate(dueAtTime);
        const startTime = genericUtils.convertHHmmToDate("07:30 AM");
        const endTime = genericUtils.convertHHmmToDate("05:30 PM");
        return startTime! < userDueAtTime! && userDueAtTime! <= endTime!;
    },
    isValidDueAt(value: string): [boolean, string] {
        const time = value.split(" ")[0];
        if (rfqUtils.isTradingWindowClosed()) {
            return [false, `Today's trading window is closed`];
        } else if (time === "-" || time.includes("H") || time.includes("M")) {
            return [false, "Time must be a valid HH:MM AM/PM time"];
        } else if (!rfqUtils.isDueAtBetweenTradingHours(value)) {
            return [false, `Time must be between trading hours of 7:31 AM - 5:30 PM ET`];
        } else if (rfqUtils.isDueAtExpired(value)) {
            return [false, `Time must be after ${genericUtils.getCurrentTime("America/New_York")} ET`];
        }
        return [true, ""];
    },
    isTradingWindowClosed: () => {
        const currentTime = DateTime.local({ zone: "America/New_York" });
        const endTime = genericUtils.convertHHmmToDate("05:30 PM");
        return currentTime! >= endTime!;
    },
    getUnconfiguredDesks: (
        selectedBrokers: BrokerEntity[],
        selectedDeskMap: { [key: string]: number } | undefined
    ): BrokerEntity[] => {
        // idea - for each of the selected brokers (that have multiple desks) - do they appear in our selectedDeskMap list? if not, we need to trigger selection
        const multiDeskBrokers = rfqUtils.getBrokersWithMultipleDesks(selectedBrokers);
        if (selectedDeskMap === undefined || Object.keys(selectedDeskMap!).length === 0) return multiDeskBrokers;
        // for each of these multidesk brokers - are they configured?
        return multiDeskBrokers.filter((broker) => {
            // is this broker configured??
            return selectedDeskMap![broker.name] === undefined;
        });
    },
    getRFQIsBin: (rfqTradeForm: RfqTradeForm): boolean => {
        return rfqTradeForm.timerChecked === "Bin";
    },
    brokerHasMultipleDesks: (selectedBrokers: BrokerEntity[], broker: BrokerEntity) => {
        return (
            rfqUtils.getBrokersWithMultipleDesks(selectedBrokers).find((b: BrokerEntity) => b === broker) !== undefined
        );
    },
    getBrokersWithSingleDesk: (selectedBrokers: BrokerEntity[]): BrokerEntity[] => {
        return selectedBrokers?.filter((b) => b.desk.length === 1);
    },
    getBrokersWithMultipleDesks: (selectedBrokers: BrokerEntity[]): BrokerEntity[] => {
        return selectedBrokers?.filter((b) => b.desk.length > 1);
    },
    brokerEnabledForSpotTime: (isDelayedSpot: boolean, spotTimeSelectedCode?: string) => {
        if (spotTimeSelectedCode !== "A" && spotTimeSelectedCode !== "-") {
            return isDelayedSpot;
        }
        return true;
    },
    brokerEnabledForPricingType: (isSpreadFlowEnabled: boolean, pricingProtocolSelected?: PricingProtocol) => {
        if (pricingProtocolSelected === "Spread") {
            return isSpreadFlowEnabled;
        }
        return true;
    },
    constructDeskSelectionMap: (
        brokers: BrokerEntity[],
        selectedDeskMap: { [key: string]: number } | undefined
    ): { [key: string]: number } => {
        // for each broker - make sure we have corresponding desk
        const singleDeskBrokers = rfqUtils.getBrokersWithSingleDesk(brokers).map((broker: BrokerEntity) => {
            return Object.assign({}, { [broker.name]: broker.desk[0].subBrokerID });
        });
        const multiDeskBrokers = rfqUtils.getBrokersWithMultipleDesks(brokers).map((broker: BrokerEntity) => {
            return Object.assign({}, { [broker.name]: selectedDeskMap![broker.name] });
        });
        return Object.assign({}, ...singleDeskBrokers, ...multiDeskBrokers);
    },
    goodForEnabled: (rfqQuote: RFQQuote): boolean => {
        return [BROKER_RESPONDED, QUOTE_SUBJECT].includes(rfqQuote.rfqStatus);
    },
    dueInEnabled: (rfqQuotes: RFQQuote[]): boolean => {
        return rfqQuotes.some((b) => [REQUEST_SENT, BROKER_RESPONDED, TRADE_PENDING].includes(b.rfqStatus));
    },
    cancelButtonEnabled: (rfqQuotes: RFQQuote[]): boolean => {
        return rfqQuotes.some((b) =>
            [REQUEST_SENT, BROKER_RESPONDED, QUOTE_SUBJECT, TRADE_PENDING].includes(b.rfqStatus)
        );
    },
    isFilled: (rfqQuote: RFQQuote): boolean => {
        return [TRADED, TRADE_CONFIRMED].includes(rfqQuote.rfqStatus);
    },
    shouldShowSize: (rfqQuote: RFQQuote): boolean => {
        if (genericUtils.isValidNumber(rfqQuote.size)) {
            if ((rfqQuote.rfqStatus === CANCELED || rfqQuote.rfqStatus === DECLINED) && rfqQuote.size === 0) {
                return false;
            }
            return true;
        }
        return false;
    },
    selectedBestQuote: (rfqQuotes: RFQQuote[], side: Side, selectedQuoteID: string): boolean => {
        const selectedQuote = rfqQuotes.find((b) => b.id === selectedQuoteID);
        if (!selectedQuote) {
            throw new Error("No matching quote found for quote ID: " + selectedQuoteID);
        }

        const otherQuotes = rfqQuotes.filter((b) => b.id !== selectedQuoteID);
        const quoteValues = otherQuotes
            .filter((q) => genericUtils.isValidNumber(q.pricingValue))
            .map((q) => q.pricingValue as number);

        if (quoteValues.length === 0) {
            return true;
        }

        const highestQuote = Math.max(...quoteValues);
        const lowestQuote = Math.min(...quoteValues);
        return rfqUtils.getSelectedBestQuote(
            side,
            selectedQuote?.pricingType,
            selectedQuote.pricingValue,
            lowestQuote,
            highestQuote
        );
    },

    getSelectedBestQuote(
        side: Side,
        pricingType: PricingType,
        selectedValue: number | "-",
        lowestQuote?: number,
        highestQuote?: number
    ) {
        if (selectedValue === "-") return false;
        if (
            // Not buying the lowest available quote value
            (side === "BUY" && pricingType === "PRICE" && selectedValue > lowestQuote!) ||
            // Not selling at the highest  available quote value
            (side === "SELL" && pricingType === "PRICE" && selectedValue < highestQuote!) ||
            // Not buying at the lowest (highest spread) available quote value
            (side === "BUY" && pricingType === "SPREAD" && selectedValue < highestQuote!) ||
            // Not selling at the highest (lowest spread) available quote value
            (side === "SELL" && pricingType === "SPREAD" && selectedValue > lowestQuote!)
        ) {
            return false;
        }

        return true;
    },
    getModifyReasonLib: () => {
        const MODIFY_REASON_DECODES = jotaiStore.get(decodesAtom)["MODIFY_REASON"] ?? [];
        return Object.keys(MODIFY_REASON_DECODES).length > 0 ? MODIFY_REASON_DECODES : MODIFY_REASON;
    },
    getQuoteStatusLib: () => {
        return QUOTE_STATUS;
    },
    getServiceAccountLogins: (tokens: Tokens) => {
        return ["TSGOPS", tokens["DB.USER.TRADING.RO"], tokens["DB.USER.TRADING.RW"]].filter((str) => str?.length > 0);
    }
};

export function isRFQRequest(basketID: string) {
    return basketID === "-";
}
