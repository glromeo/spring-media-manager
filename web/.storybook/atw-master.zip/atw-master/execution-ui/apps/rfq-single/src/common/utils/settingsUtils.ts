import { Settings } from "../../features/settings";
import { KeyValueNumber } from "../../models/common";

export const settingsUtils = {
    getDeskSettings: (settings: Settings) => {
        if (settings.desks === "") return {};
        const desks: KeyValueNumber = JSON.parse(settings.desks);
        console.log("desks", desks);
        return desks;
    }
};
