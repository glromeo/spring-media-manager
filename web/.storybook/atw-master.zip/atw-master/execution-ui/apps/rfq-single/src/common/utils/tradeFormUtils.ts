import { BrokerEntity, Desk } from "../../features/brokers/brokers";

export const tradeFormUtils = {
    getDeskKey: (desk: Desk) => `${desk.brokerType} - ${desk.salesman}`.trim(),

    getBrokerNames: (entities: BrokerEntity[]): string[] => {
        return entities.filter((entity) => entity.name !== "-").map((entity) => entity.name);
    },
    getDesks: (entities: BrokerEntity[], broker: string): string[] => {
        const entity = entities.find((ent) => ent.name === broker);
        if (entity === undefined) return [];
        return entity.desk.map((desk) => tradeFormUtils.getDeskKey(desk));
    },
    getDefaultDesk: (entities: BrokerEntity[], broker: string): string => {
        const entity = entities.find((ent) => ent.name === broker);
        if (entity === undefined) return "";
        let desk = entity.desk[0];
        if (entity.defaultDesk === undefined) return tradeFormUtils.getDeskKey(desk);
        desk = entity.desk[entity.defaultDesk];
        return tradeFormUtils.getDeskKey(desk);
    }
};
