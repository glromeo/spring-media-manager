import { Dimension } from "../../models/common";

export const windowUtils = {
    host: window as any as {
        bfmCefQuery?: (args: {
            request: string;
            persistent?: boolean;
            onSuccess: (message: string) => void;
            onFailure: (id: string, message: string) => void;
        }) => void;
    },

    closeWindow: (reason: string) => {
        if (windowUtils.host.bfmCefQuery) {
            console.log("request window close because of " + reason);
            windowUtils.host.bfmCefQuery({
                request: "close:" + reason,
                onSuccess: () => {
                    console.log("window closed");
                },
                onFailure: () => {
                    console.log("unable to close window");
                }
            });
        } else {
            window.close();
        }
    },

    resizeWindow: (dim: Dimension | null) => {
        if (dim && windowUtils.host.bfmCefQuery) {
            const dimension = JSON.stringify(dim);
            windowUtils.host.bfmCefQuery({
                request: "resizeWindow:" + dimension,
                onSuccess: () => {
                    console.log("window resized to ", dimension);
                },
                onFailure: () => {
                    console.log("unable to resize window to ", dimension);
                }
            });
        }
    },

    foregroundWindow: () => {
        if (windowUtils.host.bfmCefQuery) {
            windowUtils.host.bfmCefQuery({
                request: "foregroundWindow",
                onSuccess: () => {
                    console.log("requested window foregrounding");
                },
                onFailure: () => {
                    console.log("unable to request window foregrounding");
                }
            });
        }
    },

    registerPlacementForUrl: (placementNum: number) => {
        if (placementNum && windowUtils.host.bfmCefQuery) {
            windowUtils.host.bfmCefQuery({
                request: "registerPlacementNum:" + placementNum,
                onSuccess: () => {
                    console.log("placement num registered: ", placementNum);
                },
                onFailure: () => {
                    console.log("unable register placement num: ", placementNum);
                }
            });
        }
    },

    registerRFQForUrl: (ordNum: number, basketID: string) => {
        if (basketID && ordNum && windowUtils.host.bfmCefQuery) {
            windowUtils.host.bfmCefQuery({
                request: "registerRFQ:" + basketID,
                onSuccess: () => {
                    console.log(`RFQ registered with basketID: ${basketID} and ordNum: ${ordNum}`);
                },
                onFailure: () => {
                    console.log(`unable to register RFQ with basketID: ${basketID} and ordNum: ${ordNum}`);
                }
            });
        }
    },

    isProd: () => {
        return (
            window.location.host !== "dev.blackrock.com" &&
            window.location.host !== "tst.blackrock.com" &&
            !window.location.host.includes("localhost")
        );
    }
};
