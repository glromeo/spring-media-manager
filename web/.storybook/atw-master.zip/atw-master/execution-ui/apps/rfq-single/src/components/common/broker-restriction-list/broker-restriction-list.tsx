import { AuxButton, AuxCard, AuxCardType, AuxNotification } from "@blk/aladdin-react-components-es";
import { AuxButtonTypeEnum, AuxNotificationStyleEnum } from "@blk/aladdin-web-components";
import { useEffect, useState } from "react";
import { brokerUtils, genericUtils } from "@atx/at-rfq-single/src/common/utils";
import { BrokerEntity, BrokerRestrictionAllocation } from "@atx/at-rfq-single/src/features/brokers/brokers";

export function BrokerRestrictionList({
    restrictedBrokers,
    filteredBroker,
    dataTestId,
    brokerSourceDisplayName
}: {
    restrictedBrokers?: BrokerEntity[];
    filteredBroker?: BrokerEntity;
    dataTestId?: string;
    brokerSourceDisplayName?: string;
}) {
    const [brokersWithRestrictions, setBrokersWithRestrictions] = useState<BrokerEntity[]>([]);
    const [expandedMap, setExpandedMap] = useState(new Map<string, boolean>());
    const { formatSize } = genericUtils;
    const brokerText = brokerSourceDisplayName ? `${brokerSourceDisplayName} broker` : "broker";

    useEffect(() => {
        if (filteredBroker) {
            setBrokersWithRestrictions([filteredBroker]);
        } else if (restrictedBrokers) {
            setBrokersWithRestrictions(restrictedBrokers);
        }
    }, [filteredBroker, restrictedBrokers]);

    const RenderRestrictedText = (restrictedPortfolios: string[]) => {
        const getPortfolios = () => {
            if (restrictedPortfolios.length > 5) {
                restrictedPortfolios.length = 5;
                return restrictedPortfolios.join(", ") + "...";
            }
            return restrictedPortfolios.join(", ");
        };

        let restrictedText;
        if (restrictedPortfolios.length === 0) {
            restrictedText = "No portfolios will be removed from this placement";
        } else {
            restrictedText = `Portfolio${
                restrictedPortfolios.length > 1 ? "s" : ""
            } ${getPortfolios()} will be removed from this placement`;
        }

        return <div className={"restrictionCardRemovedTextRFQ"}>{restrictedText}</div>;
    };
    const RenderAllocations = ({
        allocations,
        restrictedPorfolios
    }: {
        allocations: BrokerRestrictionAllocation[];
        restrictedPorfolios: string[];
    }) => {
        return (
            <div>
                <table className="aux-simple-table aux-simple-table__container--vertical restrictionTable">
                    <tbody>
                        <tr>
                            <th>Restriction</th>
                            <th>Portfolio</th>
                            <th>Quantity</th>
                            <th>% of available</th>
                        </tr>
                        {allocations.map((allocation: BrokerRestrictionAllocation, idx: number) => {
                            return (
                                <tr key={allocation.name + idx}>
                                    <td className={allocation.isRestricted ? "restrictedLabel" : ""}>
                                        {allocation.isRestricted ? "Restricted" : "Eligible"}
                                    </td>
                                    <td>{allocation.name}</td>
                                    <td>{formatSize(allocation.quantity)}</td>
                                    <td>{formatSize(allocation.percent, 2) + "%"}</td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
                {RenderRestrictedText(restrictedPorfolios)}
            </div>
        );
    };
    // refactor-todo -> pull this out to a new component
    const RenderEntity = ({
        entity,
        isSelected,
        brokerIdx
    }: {
        entity: BrokerEntity;
        isSelected: boolean;
        brokerIdx: number;
    }) => {
        // refactor-todo: could probably leverage some common methods here
        const restrictedPorfolios: string[] = entity
            .restriction!.allocation.filter((allocation) => allocation.isRestricted)
            .map((allocation) => allocation.name);
        const getFooterText = () => {
            const restricted = entity.restriction!.allocation.filter((allocation) => allocation.isRestricted);
            if (restricted.length === 0) {
                return "There are no restrictions for this broker";
            } else {
                return `${restricted.length} of ${entity.restriction!.allocation.length} portfolios restricted`;
            }
        };
        const isExpanded = (name: string) => {
            if (!expandedMap.has(name)) {
                return false;
            }
            return expandedMap.get(name);
        };
        const toggleExpanded = (name: string) => {
            setExpandedMap(new Map(expandedMap.set(name, !isExpanded(name))));
        };
        return (
            <div data-test-id={"restrictioncard" + (brokerIdx + 1)} className="restrictionCard">
                {isSelected ? <div className="restrictionCardSelected"></div> : null}
                <AuxCard
                    isVerticallyExpanded={isExpanded(entity.name)}
                    header={"left-right" as AuxCardType}
                    className="aux-container"
                    borderPadding="8"
                >
                    <div slot="right" className="restrictionCardExpanderButton">
                        <AuxButton
                            data-test-id="expander"
                            icon={isExpanded(entity.name) ? "arrow-up" : "arrow-down"}
                            ref={(el) => el?.addEventListener("click", () => toggleExpanded(entity.name))}
                            type={AuxButtonTypeEnum.TERTIARY_SUBTLE}
                            ariaConfig={{
                                "aria-expanded": `${isExpanded(entity.name)}`
                            }}
                            isDisabled={false}
                        ></AuxButton>
                    </div>

                    <div slot="left" className="restrictionCardZindexFix">
                        <div className="restrictionCardHeader">
                            <div
                                className={
                                    brokerUtils.isFullyRestricted(entity)
                                        ? "restrictionCardBroker restrictionCardDisabled"
                                        : "restrictionCardBroker"
                                }
                            >
                                {entity.name}
                            </div>
                            <div>
                                <span
                                    className={
                                        brokerUtils.isFullyRestricted(entity)
                                            ? "restrictionCardQuantityNone"
                                            : "restrictionCardQuantity"
                                    }
                                >
                                    {`${formatSize(entity.restriction!.quantity)} / ${formatSize(
                                        entity.restriction!.percent,
                                        2
                                    )}%`}
                                </span>
                                <span> of available quantity</span>
                            </div>
                        </div>
                        <div>{getFooterText()}</div>
                        {isSelected && !isExpanded(entity.name) ? RenderRestrictedText(restrictedPorfolios) : null}
                    </div>

                    <div slot="content" className="restrictionCardZindexFix">
                        {isExpanded(entity.name) ? (
                            <RenderAllocations
                                allocations={entity.restriction!.allocation}
                                restrictedPorfolios={restrictedPorfolios}
                            ></RenderAllocations>
                        ) : null}
                    </div>
                </AuxCard>
            </div>
        );
    };
    const RenderBroker = () => {
        return (
            <div className="restrictionRenderBroker">
                {brokersWithRestrictions.map((entity: BrokerEntity, idx: number) => {
                    return (
                        <RenderEntity
                            key={entity.name}
                            entity={entity}
                            isSelected={false}
                            brokerIdx={idx}
                        ></RenderEntity>
                    );
                })}
            </div>
        );
    };
    const RenderInfo = () => {
        let msg =
            brokersWithRestrictions.length === 1
                ? `${brokersWithRestrictions[0].name} is a ${
                      brokerUtils.isFullyRestricted(brokersWithRestrictions[0]) ? "fully" : "partially"
                  } restricted ${brokerText}`
                : `There are ${brokersWithRestrictions.length} restricted ${brokerText}s`;

        return (
            <div className="restrictionRenderInfo">
                <AuxNotification
                    data-test-id="restrictions-notification"
                    message={msg}
                    notificationStyle={AuxNotificationStyleEnum.WARNING}
                    showCloseIcon={false}
                />
            </div>
        );
    };
    return (
        <div data-test-id={dataTestId}>
            {RenderInfo()}
            {RenderBroker()}
        </div>
    );
}
