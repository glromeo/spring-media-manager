import { useAtomValue } from "jotai";
import { AuxButton } from "@blk/aladdin-react-components-es";
import { AuxButtonSizeEnum, AuxButtonTypeEnum } from "@blk/aladdin-web-components";
import { useEffect, useState } from "react";
import { genericUtils, rfqUtils } from "@atx/at-rfq-single/src/common/utils";
import { DeskSelectionType } from "@atx/at-rfq-single/src/features/rfq/rfq";
import "./broker-selection.scss";
import { BrokerEligibility, BrokerEntity, brokerSource, DIRECT } from "@atx/at-rfq-single/src/features/brokers/brokers";
import { AtxIcon } from "@atx/toolkit";
import { AuxWrapper } from "../aux-wrapper";
import { BrokerRestrictionList } from "../broker-restriction-list/broker-restriction-list";
import { PricingProtocol, selectedVenueAtom, spotTimeSelectedAtom } from "../../../features/rfqTradeForm/rfqTradeForm";

export type BrokerChipProps = {
    broker: BrokerEntity;
    brokerSource: brokerSource;
    pricingType: PricingProtocol;
    brokerEligibility?: BrokerEligibility;
    selected?: boolean;
    handleSelectBroker?: (broker: BrokerEntity) => void;
    onTriggerDeskSelection: (needsDeskSelection: DeskSelectionType, brokers?: BrokerEntity[]) => void;
    onBrokerSelectionChange: (type: "ADD" | "REMOVE", brokerSourceName: string, selectedBroker: BrokerEntity) => void;
};
export function BrokerChip({
    broker,
    brokerSource,
    pricingType,
    brokerEligibility,
    selected = false,
    onTriggerDeskSelection,
    onBrokerSelectionChange
}: BrokerChipProps) {
    const [isDisabledWithWarning, setIsDisabledWithWarning] = useState(true);
    const [isSelected, setIsSelected] = useState(selected);
    const [brokerDisabledMessage, setBrokerDisabledMessage] = useState<string>("");
    const spotTimeSelected = useAtomValue(spotTimeSelectedAtom);
    const selectedVenue = useAtomValue(selectedVenueAtom);
    const { name: brokerSourceName, displayName: brokerSourceDisplayName } = brokerSource;

    const updateBrokerDisabledMessage = (isDisabledPricingType: boolean, isDisabledSpotTime: boolean) => {
        if (isDisabledPricingType && isDisabledSpotTime) {
            setBrokerDisabledMessage(`${broker.name} is not enabled for spread trading and delayed spotting.`);
        } else if (isDisabledSpotTime) {
            setBrokerDisabledMessage(`${broker.name} is not enabled for delayed spotting.`);
        } else if (isDisabledPricingType) {
            setBrokerDisabledMessage(`${broker.name} is not enabled for spread trading.`);
        } else {
            setBrokerDisabledMessage("");
        }
    };
    useEffect(() => {
        if (brokerEligibility?.restrictionLevel === "NONE") {
            // will only run when the spot time or pricing type changes; we want to reselect everything eligible
            const isSpreadFlowEnabled =
                brokerSource.name === DIRECT ? broker.isSpreadFlowEnabled : selectedVenue?.isSpreadFlowEnabled ?? false;
            const isDelayedSpot = brokerSource.name === DIRECT ? broker.isDelayedSpot : selectedVenue?.isDelayedSpot ?? false;
            const isDisabledPricingType = !rfqUtils.brokerEnabledForPricingType(isSpreadFlowEnabled, pricingType);
            const isDisabledSpotTime =
                pricingType === "Spread" && !rfqUtils.brokerEnabledForSpotTime(isDelayedSpot, spotTimeSelected.value);
            updateBrokerDisabledMessage(isDisabledPricingType, isDisabledSpotTime);
            const shouldBeDisabled = isDisabledPricingType || isDisabledSpotTime;
            setIsDisabledWithWarning(shouldBeDisabled);
        }
    }, [pricingType, spotTimeSelected]);

    useEffect(() => {
        setIsSelected(selected);
    }, [selected]);

    const selectBroker = (selectedBroker: BrokerEntity) => {
        if (isSelected) {
            onBrokerSelectionChange("REMOVE", brokerSourceName, selectedBroker);
            setIsSelected(false);
        } else {
            onBrokerSelectionChange("ADD", brokerSourceName, selectedBroker);
            setIsSelected(true);
        }
    };
    const renderRestrictedIcon = () => {
        return (
            <div className="chipIcon">
                <AtxIcon
                    testId={`${brokerSourceName.toLowerCase()}-broker-icon-${genericUtils.removeSpace(broker.name)}`}
                    name={brokerEligibility?.restrictionLevel === "FULL" ? "alert-bold" : "alert-subtle"}
                    type="primary"
                    title={{
                        placement: "bottom",
                        title: () => (
                            <div slot="content" className="restrictionContent">
                                <BrokerRestrictionList
                                    filteredBroker={broker}
                                    brokerSourceDisplayName={brokerSourceDisplayName}
                                />
                            </div>
                        )
                    }}
                />
            </div>
        );
    };
    const renderDisabledIcon = () => {
        return (
            <div className="chipIcon">
                <AtxIcon
                    testId={`${brokerSourceName.toLowerCase()}-disabled-broker-icon-${genericUtils.removeSpace(
                        broker.name
                    )}`}
                    name="alert"
                    type="primary"
                    title={{
                        placement: "bottom",
                        trigger: "hover",
                        title: () => (
                            <div
                                data-test-id={`${brokerSourceName.toLowerCase()}-broker-${genericUtils.removeSpace(
                                    broker.name
                                )}-disabled-reason`}
                            >
                                {brokerDisabledMessage}
                            </div>
                        )
                    }}
                />
            </div>
        );
    };

    const renderDirectIcon = () => {
        return (
            <div className="chipIcon">
                <AtxIcon
                    testId={`${brokerSourceName.toLowerCase()}-broker-icon-${genericUtils.removeSpace(broker.name)}`}
                    name="direct"
                    type="primary"
                    size="large"
                    title={{
                        placement: "bottom",
                        title: () => (
                            <div
                                data-test-id={`${brokerSourceName.toLowerCase()}-broker-${genericUtils.removeSpace(
                                    broker.name
                                )}-disabled-reason`}
                            >
                                {`${broker.name} is a direct broker.`}
                            </div>
                        )
                    }}
                />
            </div>
        );
    };

    const renderFullyAvailableIcons = () => {
        if (isDisabledWithWarning) {
            // Disabled warning takes precendence over multiple desk icon
            return renderDisabledIcon();
        }
        // only show direct icon if the venue broker is also on direct broker selection (has to have at least one desk)
        if (brokerSourceName !== DIRECT && broker.isDirect && broker?.desk?.length > 0) {
            return renderDirectIcon();
        }
        return renderDeskIcon();
    };

    const renderDeskIcon = () => {
        return broker.desk?.length > 1 ? (
            <div className="chipIcon">
                <AtxIcon
                    testId={`desk-${genericUtils.removeSpace(broker.name)}-icon`}
                    name="alert-bold"
                    type="info"
                    title={{ placement: "bottom", title: () => <div>{`${broker.name} has multiple desks.`}</div> }}
                    onClick={() => onTriggerDeskSelection("open", [broker])}
                />
            </div>
        ) : null;
    };
    const isChipDisabled = brokerEligibility?.restrictionLevel !== "NONE" || isDisabledWithWarning;
    return (
        <div className={isSelected ? "brokerChipContainer selectedBorder" : "brokerChipContainer defaultBorder"}>
            <AuxWrapper size={77}>
                <AuxButton
                    data-test-id={`${brokerSourceName.toLowerCase()}-broker-chip-${genericUtils.removeSpace(
                        broker.name
                    )}`}
                    className="brokerChip"
                    isDisabled={isChipDisabled}
                    label={broker.name.length > 6 ? broker.name.substring(0, 6) + "..." : broker.name}
                    size={AuxButtonSizeEnum.SMALL}
                    type={AuxButtonTypeEnum.SECONDARY}
                    isDualState={true}
                    isOnDualState={isSelected && !isDisabledWithWarning}
                    shouldToggleStateOnClick={true}
                    onClick={() => selectBroker(broker)}
                />
            </AuxWrapper>
            {brokerEligibility?.restrictionLevel === "NONE" ? renderFullyAvailableIcons() : renderRestrictedIcon()}
        </div>
    );
}
