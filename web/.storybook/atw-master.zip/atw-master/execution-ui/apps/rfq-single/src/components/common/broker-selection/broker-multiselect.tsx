import { AuxBadge, AuxCheckbox, AuxIcon, AuxPopover } from "@blk/aladdin-react-components-es";
import { AuxBadgeStyleEnum, AuxBadgeTypeEnum, AuxDynamicPositionEnum } from "@blk/aladdin-web-components";
import { useEffect, useState } from "react";
import { brokerUtils, genericUtils } from "@atx/at-rfq-single/src/common/utils";
import { DeskSelectionType } from "@atx/at-rfq-single/src/features/rfq/rfq";
import { BrokerRestrictionList } from "../broker-restriction-list/broker-restriction-list";
import { BrokerChip } from "./broker-chip";
import "./broker-selection.scss";
import { BrokerEligibility, BrokerEntity, DIRECT, brokerSource } from "@atx/at-rfq-single/src/features/brokers/brokers";
import { PricingProtocol } from "../../../features/rfqTradeForm/rfqTradeForm";
import { eligibleVenueBrokersAtom } from "../../../features/brokers/brokers";
import { useAtomValue } from "jotai";

export type BrokerMultiSelectProps = {
    brokers: BrokerEntity[];
    brokerSource: brokerSource;
    isValid: boolean;
    hideRestrictedBrokers: boolean;
    selectedBrokers: BrokerEntity[];
    numSelectedBrokers: number;
    pricingType: PricingProtocol;
    checkBox?: checkBoxOptions[];
    isSelectAllChecked?: boolean;
    type?: "Direct" | "Venue";
    onTriggerDeskSelection: (needsDeskSelection: DeskSelectionType, brokers?: BrokerEntity[]) => void;
    onBrokerSelectionChange: (type: "ADD" | "REMOVE", brokerSourceName: string, selectedBroker: BrokerEntity) => void;
    handleSelectAllChecked?: (checked: boolean) => void;
};

type checkBoxOptions = "Select All";

export function BrokerMultiSelect({
    brokers,
    numSelectedBrokers,
    pricingType,
    onTriggerDeskSelection,
    onBrokerSelectionChange,
    handleSelectAllChecked = () => {},
    selectedBrokers,
    brokerSource,
    isValid = false,
    checkBox = [],
    isSelectAllChecked = false,
    hideRestrictedBrokers = false
}: BrokerMultiSelectProps) {
    // refactor-todo: as soon as the data loads...(move to initialize)
    const [brokerEligibilities, setBrokerEligibilities] = useState<{ [key: number]: BrokerEligibility }>({});
    const [restrictedBrokers, setRestrictedBrokers] = useState<BrokerEntity[]>([]);
    const [selectAllChecked, setSelectAllChecked] = useState<boolean>(isSelectAllChecked);
    const { name: brokerSourceName, displayName: brokerSourceDisplayName } = brokerSource;
    const eligibleVenueBrokers = useAtomValue(eligibleVenueBrokersAtom);

    useEffect(() => {
        if (isSelectAllChecked !== selectAllChecked) setSelectAllChecked(isSelectAllChecked);
    }, [isSelectAllChecked]);

    useEffect(() => {
        const eligibilities = brokerUtils.getBrokerEligibilities(brokers);
        if (eligibilities && Object.keys(eligibilities).length > 0) {
            setBrokerEligibilities(eligibilities);
            setRestrictedBrokers(brokers.filter((b) => eligibilities[b.code]?.restrictionLevel !== "NONE"));
        }
    }, [brokers]);

    const brokerLogTelemetryClick = () => {
        genericUtils.logTelemetryClick("Hide Restricted", "hideRestricted", hideRestrictedBrokers.toString());
    };
    const shouldShowDeskIcon = () => {
        return (
            brokerSourceName === DIRECT &&
            brokerUtils.getBrokersWithMultipleDesks(brokers).filter((broker) => !restrictedBrokers.includes(broker))
                .length > 1
        );
    };
    const shouldShowBrokerChip = (broker: BrokerEntity) => {
        // if we have hide restrictions checked and this broker isn't fully available - we filter out
        if (hideRestrictedBrokers && brokerEligibilities[broker.code]?.restrictionLevel !== "NONE") return false;
        return true;
    };
    return (
        <div className="brokers-multiselect-container">
            <header className="brokerHeader brokerHeader-default">
                <section className="brokers-multiselect-header-container">
                    <div data-test-id={`${genericUtils.removeSpace(brokerSourceName)}brokersmultiselecttitle`}>
                        <span className="brokers-multiselect-header-container__title">{`${brokerSourceDisplayName} Brokers `}</span>
                        <span className="brokers-multiselect-header-container__title--count">
                            {numSelectedBrokers || 0}
                        </span>
                    </div>
                    {restrictedBrokers.length > 0 ? (
                        <div className="restricted-brokerHeaderIcon-container">
                            <span className="restricted-brokerHeaderIcon">
                                <AuxPopover overridePlacement={AuxDynamicPositionEnum.BOTTOM_CENTER} trigger="hover">
                                    <AuxBadge
                                        data-test-id={`${brokerSourceName.toLowerCase()}-brokers-restrictions-icon`}
                                        type={AuxBadgeTypeEnum.ICON}
                                        badgeStyle={AuxBadgeStyleEnum.WARNING}
                                        slot="target"
                                    ></AuxBadge>
                                    <div slot="content" className="restrictionContent">
                                        <BrokerRestrictionList
                                            dataTestId={`${genericUtils.removeSpace(
                                                brokerSourceName
                                            )}-brokers-restrictions-list`}
                                            restrictedBrokers={restrictedBrokers}
                                            brokerSourceDisplayName={brokerSourceDisplayName}
                                        ></BrokerRestrictionList>
                                    </div>
                                </AuxPopover>
                            </span>
                        </div>
                    ) : null}
                    {/* only show desk icon if there are broker chips */}
                    {shouldShowDeskIcon() && brokers.filter(shouldShowBrokerChip).length > 1 ? (
                        <div className="desk-brokerHeaderIcon-container">
                            <span className="desk-brokerHeaderIcon">
                                <AuxPopover overridePlacement={AuxDynamicPositionEnum.BOTTOM_CENTER} trigger="hover">
                                    <AuxIcon
                                        type="alert-bold"
                                        state="informational"
                                        slot="target"
                                        data-test-id="desk-brokers-icon"
                                        onClick={() => onTriggerDeskSelection("open")}
                                    />
                                    <div slot="content">{`There are ${
                                        brokerUtils.getBrokersWithMultipleDesks(brokers).length
                                    } brokers with multiple desks`}</div>
                                </AuxPopover>
                            </span>
                        </div>
                    ) : null}
                </section>
            </header>
            <div className={`brokersContainer ${!isValid ? "brokersContainer-error" : ""}`}>
                {checkBox.includes("Select All") && brokers.filter(shouldShowBrokerChip).length > 1 && (
                    <AuxCheckbox
                        data-test-id={`${genericUtils.removeSpace(brokerSourceName)}-select-all`}
                        label="Select All"
                        isChecked={selectAllChecked}
                        isDisabled={eligibleVenueBrokers.length == 0}
                        onCheckboxChanged={() => {
                            setSelectAllChecked(!selectAllChecked);
                            handleSelectAllChecked(!selectAllChecked);
                        }}
                        className="broker-multiselect-select-all"
                    ></AuxCheckbox>
                )}
                <section
                    data-test-id={`${genericUtils.removeSpace(brokerSourceName)}-broker-chips-container`}
                    className="broker-chips-container"
                >
                    {brokers.filter(shouldShowBrokerChip).map((broker) => (
                        <BrokerChip
                            key={broker.code}
                            broker={broker}
                            brokerSource={brokerSource}
                            brokerEligibility={brokerEligibilities[broker.code]}
                            pricingType={pricingType}
                            selected={selectedBrokers.includes(broker)}
                            onTriggerDeskSelection={onTriggerDeskSelection}
                            onBrokerSelectionChange={(type, brokerSource, broker) => {
                                onBrokerSelectionChange(type, brokerSource, broker);
                            }}
                        ></BrokerChip>
                    ))}
                </section>
            </div>
        </div>
    );
}
