import { brokerUtils, genericUtils } from "@atx/at-rfq-single/src/common/utils";
import { AuxCheckbox } from "@blk/aladdin-react-components-es";
import { useEffect, useState } from "react";
import { BrokerMultiSelect } from "./broker-multiselect";
import { DeskSelectionType } from "@atx/at-rfq-single/src/features/rfq/rfq";
import { BrokerEntity, DIRECT, VenueEntity } from "@atx/at-rfq-single/src/features/brokers/brokers";
import { PricingProtocol } from "../../../features/rfqTradeForm/rfqTradeForm";

export type BrokerSelectionProps = {
    directBrokers: BrokerEntity[];
    venueBrokers: BrokerEntity[];
    selectedVenue?: VenueEntity;
    selectedDirectBrokers: BrokerEntity[];
    selectedVenueBrokers: BrokerEntity[];
    pricingType: PricingProtocol;
    isVenueSelectAllChecked: boolean;
    onTriggerDeskSelection: (needsDeskSelection: DeskSelectionType, brokers?: BrokerEntity[]) => void;
    onBrokerSelectionChange: (type: "ADD" | "REMOVE", brokerSourceName: string, selectedBroker: BrokerEntity) => void;
    onVenueSelectAllChecked: (checked: boolean) => void;
};
export const BrokerSelection = ({
    directBrokers,
    venueBrokers,
    selectedVenue,
    selectedDirectBrokers,
    selectedVenueBrokers,
    pricingType,
    isVenueSelectAllChecked,
    onTriggerDeskSelection,
    onBrokerSelectionChange,
    onVenueSelectAllChecked
}: BrokerSelectionProps) => {
    const [hideRestricted, setHideRestricted] = useState<boolean>(true);
    const [isValid, setIsValid] = useState<boolean>(selectedDirectBrokers.length + selectedVenueBrokers.length !== 0);
    const LogRestrictionsToggle = () => {
        genericUtils.logTelemetryClick("Hide Restricted", "hideRestricted", hideRestricted.toString());
    };
    const brokers = directBrokers.concat(venueBrokers);
    const eligibilities = brokerUtils.getBrokerEligibilities(brokers);

    let restrictedBrokers: BrokerEntity[] = [];
    if (eligibilities && Object.keys(eligibilities).length > 0) {
        restrictedBrokers = brokers.filter((b) => eligibilities[b.code]?.restrictionLevel !== "NONE");
    }

    useEffect(() => {
        setIsValid(selectedDirectBrokers.length + selectedVenueBrokers.length !== 0);
    }, [selectedDirectBrokers, selectedVenueBrokers]);

    return (
        <div data-test-id="rfq-trade-form-brokerselection" className="broker-selection-container">
            {restrictedBrokers.length > 0 ? (
                <span>
                    <AuxCheckbox
                        data-test-id={`broker-selection-hide-restrictions-checkbox`}
                        style={{ fontWeight: "normal" }}
                        isChecked={hideRestricted}
                        label={"Hide Restricted (" + restrictedBrokers.length + ")"}
                        onCheckboxChanged={() => (hideRestricted ? setHideRestricted(false) : setHideRestricted(true))}
                        onClick={LogRestrictionsToggle}
                    />
                </span>
            ) : null}
            {/* not in use until we work on broker presets */}
            {/* {venueBrokers.length > 0 && (
                <AtwSelect
                    size="regular"
                    options={{ presets: "Presets" }}
                    value={"presets"}
                    onChange={() => {}}
                ></AtwSelect>
            )} */}
            <BrokerMultiSelect
                brokerSource={{ name: DIRECT, displayName: "Direct" }}
                isValid={isValid}
                hideRestrictedBrokers={hideRestricted}
                selectedBrokers={selectedDirectBrokers}
                brokers={directBrokers}
                numSelectedBrokers={selectedDirectBrokers.length}
                pricingType={pricingType}
                onTriggerDeskSelection={onTriggerDeskSelection}
                onBrokerSelectionChange={onBrokerSelectionChange}
            ></BrokerMultiSelect>
            {selectedVenue && venueBrokers.length > 0 && (
                <BrokerMultiSelect
                    checkBox={["Select All"]}
                    isSelectAllChecked={isVenueSelectAllChecked}
                    handleSelectAllChecked={(checked) => {
                        onVenueSelectAllChecked(checked);
                    }}
                    brokerSource={selectedVenue}
                    isValid={isValid}
                    hideRestrictedBrokers={hideRestricted}
                    selectedBrokers={selectedVenueBrokers}
                    brokers={venueBrokers}
                    numSelectedBrokers={selectedVenueBrokers.length}
                    pricingType={pricingType}
                    onTriggerDeskSelection={onTriggerDeskSelection}
                    onBrokerSelectionChange={onBrokerSelectionChange}
                ></BrokerMultiSelect>
            )}
            {!isValid && <div className={`${!isValid ? "text-error" : ""}`}>Must select at least 1 broker.</div>}
        </div>
    );
};
