import {
    AtwContextMenu,
    AtwContextMenuCopy,
    AtwContextMenuCopyEvent,
    AtwContextMenuGroup,
    AtwContextMenuItem,
    copyToClipboard,
    hasSearchParam
} from "@atw/toolkit";
import { useSetAtom } from "jotai";
import { debugInfoAtom } from "../../models/atoms";

export const ContextMenu = () => {
    const setDebugInfo = useSetAtom(debugInfoAtom);
    const isEmbedded = hasSearchParam("embedded");

    return isEmbedded ? (
        <div data-test-id="context-menu">
            <AtwContextMenu>
                <AtwContextMenuGroup>
                    <AtwContextMenuCopy
                        onClick={({ detail }: AtwContextMenuCopyEvent) => copyToClipboard({ text: detail.selection })}
                    />
                </AtwContextMenuGroup>
                <AtwContextMenuItem onClick={() => setDebugInfo(true)} label={"Debug Info"} />
            </AtwContextMenu>
        </div>
    ) : null;
};
