import React, { memo, useEffect, useState } from "react";
import { genericUtils } from "../../common/utils";
import { DateTime } from "luxon";

export const CountDown = memo(
    ({
        timer,
        title = "Good For ",
        type = "basic",
        onCountDownEnd
    }: {
        timer: number;
        title?: string;
        type?: string;
        onCountDownEnd?: Function;
    }) => {
        const [countDown, setCountDown] = useState("00:00");
        useEffect(() => {
            if (!genericUtils.isValidNumber(timer)) return;

            let gmtTime = DateTime.fromMillis(timer, { zone: "America/New_York" });
            let local = DateTime.local({ zone: "America/New_York" });
            let secondsleft = gmtTime.diff(local).as("seconds");

            const updateCountDown = () => {
                if (secondsleft > 0) {
                    setCountDown(
                        DateTime.fromMillis(secondsleft * 1000, { zone: "utc" }).toFormat(
                            secondsleft > 3600 ? "HH:mm:ss" : "mm:ss"
                        )
                    );
                } else {
                    setCountDown("00:00");
                }
            };

            if (secondsleft <= 0) {
                updateCountDown();
                // Don't call set the countdown interval
                // if timer was already in the past
                return;
            }

            const interval = setInterval(() => {
                secondsleft--;
                updateCountDown();
                if (secondsleft <= 0) {
                    clearInterval(interval);
                    if (typeof onCountDownEnd === "function") {
                        onCountDownEnd();
                    }
                }
            }, 1000);

            updateCountDown();

            return () => {
                clearInterval(interval);
                setCountDown("00:00");
            };
        }, [timer]);
        return (
            <div data-test-id={"countdownbox"} className={`countdownBox`}>
                {type === "basic" ? (
                    <span>{countDown}</span>
                ) : (
                    <div data-test-id={"countdown"} className={`countdownItem countdownItem--${type}`}>
                        <span className={`${type}PopupLabel`} data-test-id={`${type}-popup-label`}>
                            {title}
                        </span>
                        <span className={`${type}PopupValue`} data-test-id={`${type}-popup-value`}>
                            {countDown}
                        </span>
                    </div>
                )}
            </div>
        );
    }
);
