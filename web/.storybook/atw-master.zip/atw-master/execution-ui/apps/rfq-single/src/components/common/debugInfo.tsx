import { useCallback, useEffect } from "react";
import { useAtom } from "jotai";
import { debugInfoAtom } from "../../models/atoms";
import { copyToClipboard } from "@atw/toolkit";
import { logPrefix } from "@atx/toolkit";

/**
 * The purpose of this component is to add a hidden row to the summary section that expands to debug information
 * when a secret key sequence is pressed. This is fundamental to troubleshoot in production and allows us to
 * avoid depending on console.log.
 *
 * @constructor
 */
export default function DebugInfo() {
    const [debugInfo, setDebugInfo] = useAtom(debugInfoAtom);

    const keydownCallback = useCallback((event: KeyboardEvent) => {
        if ((event.key === "X" && event.ctrlKey) || (event.key === "M" && event.ctrlKey)) {
            event.preventDefault();
            event.stopPropagation();
            setDebugInfo(true);
        } else {
            if (event.keyCode === 27) setDebugInfo(false);
        }
    }, []);

    useEffect(() => {
        window.addEventListener("keydown", keydownCallback);
        return () => {
            window.removeEventListener("keydown", keydownCallback);
        };
    }, [keydownCallback]);

    const copy = () => {
        const element: any = document.getElementById("url");
        copyToClipboard({ text: element.textContent });
    };

    return debugInfo ? (
        <div data-test-id="debuginfo" className="debug-info">
            <div className="item">
                <label style={{ marginRight: 25 }}>Application ID: {logPrefix}</label>
            </div>
            <div className="item">
                <label style={{ marginRight: 25 }}>Url</label>
                <button onClick={copy}>copy </button>
                <span id="url">{String(window.location)}</span>
            </div>
        </div>
    ) : null;
}
