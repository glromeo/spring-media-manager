import { SecurityLookupProps } from "@atw/toolkit";
import { DateTime } from "luxon";
import { useMemo } from "react";
import { genericUtils } from "../../common/utils";
import { FieldType, NUM_PLACE_HOLDER, SideColor } from "../../models/common";
import { Rating } from "./rating";

export type DetailsTableRowType = {
    label: string;
    value: number | string | boolean;
    type: FieldType | SecurityLookupProps["type"];
    renderType?: FieldType;
    renderValue?: number | string | boolean;
    color?: SideColor;
    className?: string;
    editable?: boolean;
    onSelectionChange?: Function;
    onValidate?: Function;
    ref?: Function;
    separator?: boolean;
    dropdownOffsetWidth?: number;
};

export function DetailsTable({ name, data }: { name: string; data: DetailsTableRowType[] }) {
    return (
        <table className="rfqSimpleTable executeTable">
            <tbody>
                {data.map((info: DetailsTableRowType) => (
                    <TableRow key={info.label} name={name} info={info} />
                ))}
            </tbody>
        </table>
    );
}

function TableRow({ info, name }: { info: DetailsTableRowType; name: string }) {
    const renderValue = useMemo(
        () => () => {
            if (info.type !== "security" && info.value === "-") {
                return info.value;
            }

            switch (info.type) {
                case "boolean":
                    return info.value ? "Yes" : "No";
                case "size":
                    return info.value === NUM_PLACE_HOLDER || info.value === null
                        ? "-"
                        : genericUtils.formatSize(info.value as number);
                case "price":
                    return info.value === NUM_PLACE_HOLDER || info.value === null
                        ? "-"
                        : genericUtils.formatPrice(info.value as number);
                case "spread":
                    return info.value === NUM_PLACE_HOLDER || info.value === null
                        ? "-"
                        : genericUtils.formatSpread(info.value as number);
                case "time":
                    return DateTime.fromMillis(info.value as number, { zone: "America/New_York" })
                        .toFormat("hh:mm a")
                        .toLowerCase();
                case "rating":
                    return <Rating rating={info.value as number} />;
                case "security":
                    return info.value === null ? "-" : info.value.toString();
                default:
                    return info.value;
            }
        },
        [info]
    );

    const getRenderStyle = (info: DetailsTableRowType) => {
        if (info.renderType === undefined || info.renderType !== "progress") return undefined;
        return {
            background: info.color!,
            width: info.renderValue! + "%"
        };
    };

    const getDataTestId = (info: DetailsTableRowType) => {
        return `${genericUtils.removeSpace(name, true)}-${genericUtils.removeSpace(info.label, true)}`;
    };

    let className = `align-right ${info.className}`;
    if (info.renderType !== undefined) {
        className = `${className} progressTd`;
    }

    return (
        <>
            <tr key={info.label} className="executeTableRow">
                <td>{info.label}</td>
                {info.renderType === undefined ? (
                    <td data-test-id={getDataTestId(info)} className={className}>
                        {renderValue()}
                    </td>
                ) : (
                    <td data-test-id={getDataTestId(info)} className={className}>
                        <div
                            data-test-id={`${getDataTestId(info)}-container`}
                            className="progessContainer"
                            style={getRenderStyle(info)}
                        />
                        <div data-test-id={`${getDataTestId(info)}-value`} className="progessValue">
                            {renderValue()}
                        </div>
                    </td>
                )}
            </tr>
            {info.separator && (
                <tr className="executeTableRow">
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
            )}
        </>
    );
}
