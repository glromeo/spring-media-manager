import { AuxProgressStepper, AuxProgressStepperInterface } from "@blk/aladdin-react-components-es";
import { useAtomValue } from "jotai";
import { useMemo } from "react";
import { stepIndexAtom, StepperState, WORKFLOWS } from "../../features/stepper/stepper";

export function HeaderBase() {
    const stepIndex = useAtomValue(stepIndexAtom);
    const steps = useMemo(
        (): AuxProgressStepperInterface[] =>
            WORKFLOWS.map((step: StepperState, idx: number) => {
                return {
                    index: idx,
                    label: step.toString(),
                    state: getState(stepIndex, idx),
                    value: idx + 1
                };
            }),
        [stepIndex]
    );

    return (
        <div className="executionHeader">
            <div className="display-only">
                <AuxProgressStepper data-test-id="axe-stepper" isResponsive={false} steps={steps} type="button" />
            </div>
        </div>
    );
}

const getState = (stepIndex: number, idx: number) => {
    if (stepIndex === idx) return "active";
    if (stepIndex > idx) return "complete";
    return "disabled";
};
