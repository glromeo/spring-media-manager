import {
    AuxNotificationGroup,
    AuxNotificationGroupConfig,
    AuxNotificationGroupTypeEnum,
    AuxNotificationStyleEnum,
    AuxNotificationToastTypeEnum
} from "@blk/aladdin-react-components-es";

import "./message-bar.scss";

export function MessageBar({
    config: { color, message, popup }
}: {
    config: { color: "RED" | "GREEN" | "YELLOW"; message: string; popup?: boolean };
}) {
    const getType = (barColor: "RED" | "GREEN" | "YELLOW"): AuxNotificationStyleEnum => {
        switch (barColor) {
            case "RED":
                return "error" as AuxNotificationStyleEnum;
            case "YELLOW":
                return "warning" as AuxNotificationStyleEnum;
            case "GREEN":
            default:
                return "success" as AuxNotificationStyleEnum;
        }
    };

    const popupConfig: AuxNotificationGroupConfig[] = [
        {
            id: message,
            message,
            notificationStyle: getType(color),
            eventData: message,
            showCloseIcon: false,
            toastType: AuxNotificationToastTypeEnum.PERSISTENT
        }
    ];

    return (
        <div className={popup ? "notifications-container popup" : "notifications-container message-bar"}>
            <div className="notifications__group-container">
                <AuxNotificationGroup
                    key="alert-notifications"
                    data-test-id="message-bar"
                    config={popupConfig}
                    openOnLoad={true}
                    type={AuxNotificationGroupTypeEnum.WIDGET_INLINE}
                />
            </div>
        </div>
    );
}
