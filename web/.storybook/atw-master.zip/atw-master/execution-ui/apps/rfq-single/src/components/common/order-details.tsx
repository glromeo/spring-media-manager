import { useAtomValue } from "jotai";
import { orderDetailsInfoAtom } from "../../features/order/order";
import { DetailsTable } from "./details-table";

export function OrderDetails() {
    const orderDetailsInfo = useAtomValue(orderDetailsInfoAtom);

    return (
        <div>
            <div className="tableHeader">Your Order</div>
            <DetailsTable name="yourorder" data={orderDetailsInfo} />
        </div>
    );
}
