import * as ReactDOM from "react-dom";
import { StepperStatus, StepperSubStatus } from "../../features/stepper/stepper";
import { Spinner } from "./spinner";
import { useEffect, useState } from "react";
import { logClick } from "@atw/toolkit/telemetry";
import { useAtomValue } from "jotai";
import { orderIdAtom } from "../../features/order/order";

export function Overlay({ children }: { children: JSX.Element }) {
    const orderNumber = useAtomValue(orderIdAtom);
    useEffect(() => {
        overlayInd();
    }, []);

    function overlayInd() {
        logClick(`${children.props.title}`, { orderNumber });
    }
    return ReactDOM.createPortal(<div className="overlay">{children}</div>, document.body);
}

export function OverlayStatus({ status, subStatus }: { status: StepperStatus; subStatus?: StepperSubStatus }) {
    const [title, setTitle] = useState("");

    useEffect(() => {
        let title = "";
        switch (status) {
            case StepperStatus.VALIDATING:
                title = "Validating RFQ";
                break;
            case StepperStatus.SENDING:
                switch (subStatus) {
                    case StepperSubStatus.HITLIFT:
                        title = "Accepting Quote";
                        break;
                    case StepperSubStatus.COUNTER_REVIEW:
                        title = "Countering Quote";
                        break;
                    case StepperSubStatus.CANCELING:
                        title = "Canceling RFQ";
                        break;
                    default:
                        title = "Sending RFQ";
                        break;
                }
        }
        setTitle(title);
    }, [status, subStatus]);

    return title ? (
        <Overlay>
            <Spinner title={title} />
        </Overlay>
    ) : null;
}
