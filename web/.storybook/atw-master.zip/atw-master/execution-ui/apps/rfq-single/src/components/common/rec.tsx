import { useCallback, useEffect, useState } from "react";
import { recording } from "@atw/toolkit/utility";
import { useAtomValue } from "jotai";
import { orderIdAtom } from "../../features/order/order";

export default function Rec() {
    const [display, setDisplay] = useState<boolean>(localStorage.getItem("recording") === "true");
    const orderNumber = useAtomValue(orderIdAtom);

    useEffect(() => {
        if (!display) {
            const keydownCallback = (event: KeyboardEvent) => {
                if (event.key === "R" && event.ctrlKey) {
                    event.preventDefault();
                    event.stopPropagation();
                    localStorage.setItem("recording", "true");
                    window.location.reload();
                }
            };
            window.addEventListener("keydown", keydownCallback);
            return () => {
                window.removeEventListener("keydown", keydownCallback);
            };
        }
    }, [display]);

    const onClick = useCallback(
        (event: React.MouseEvent<any>) => {
            recording?.download(String(orderNumber));
            localStorage.setItem("recording", "false");
            setDisplay(false);
        },
        [orderNumber]
    );

    return display ? (
        <div className="recording">
            <div>Recording...</div>
            <button name="stop" onClick={onClick}>
                STOP
            </button>
        </div>
    ) : null;
}
