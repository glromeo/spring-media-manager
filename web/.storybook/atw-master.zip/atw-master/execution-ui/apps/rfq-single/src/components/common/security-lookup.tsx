import { apiPost } from "@atw/toolkit/utility/apiUtils";
import { formatSecurityDate } from "@atw/toolkit/utility/format";
import { AuxTypeAhead, AuxTypeAheadSuggestionGroup } from "@blk/aladdin-react-components-es";
import { useCallback, useEffect, useMemo, useState } from "react";
import "./security-lookup.scss";

export type SecurityOption = {
    desc1: string;
    cusip: string;
    isin: string;
    ticker: string;
    sedol: string;
    secGroup: string;
    secType: string;
};

type SecurityOptionsResponse = {
    output?: {
        data?: SecurityOption[];
    };
};

const COLUMN_DEFS: Record<
    keyof SecurityOption,
    {
        label: string;
        mapper: (option: SecurityOption) => { displayValue: string; value: any };
    }
> = {
    cusip: {
        label: "CUSIP",
        mapper: (option: SecurityOption) => ({
            displayValue: option.cusip,
            value: option
        })
    },
    desc1: {
        label: "Security Description",
        mapper: (option: SecurityOption) => ({
            displayValue: option.desc1,
            value: option
        })
    },
    ticker: {
        label: "Ticker",
        mapper: (option: SecurityOption) => ({
            displayValue: option.ticker,
            value: option
        })
    },
    sedol: {
        label: "SEDOL",
        mapper: (option: SecurityOption) => ({
            displayValue: option.sedol,
            value: option
        })
    },
    isin: {
        label: "ISIN",
        mapper: (option: SecurityOption) => ({
            displayValue: option.isin,
            value: option
        })
    },
    secGroup: {
        label: "Security Group",
        mapper: (option: SecurityOption) => ({
            displayValue: option.secGroup,
            value: option
        })
    },
    secType: {
        label: "Security Type",
        mapper: (option: SecurityOption) => ({
            displayValue: option.secType,
            value: option
        })
    }
};

const INITIAL_TYPEAHEAD_DATA = [
    {
        label: "Title",
        totalResults: 0,
        limit: 0,
        values: []
    }
];

export type SecurityLookupProps = {
    testId?: string;
    className?: string;
    placeholder?: string;
    editable?: boolean;
    validate?: (text: string | null) => string[] | undefined;
    filter?: (security: SecurityOption) => boolean;
    columns?: (keyof SecurityOption)[];
    value: { displayValue: string; value: string };
    onChange: (cusip: string | null, description: string | null) => void;
    dropdownOffsetWidth?: number;
};

let controller: AbortController | null = null;

export function SecurityLookup(props: SecurityLookupProps) {
    const {
        testId,
        className,
        placeholder = "-",
        editable = true,
        value: { displayValue, value },
        columns = Object.keys(COLUMN_DEFS) as (keyof SecurityOption)[],
        filter,
        validate,
        onChange,
        dropdownOffsetWidth = 400
    } = props;

    const columnDefs = columns?.map((col) => COLUMN_DEFS[col] || COLUMN_DEFS);

    // need to set initial selected item to match the data in the typeAhead Dropdown
    const InitialSelection = {
        desc1: displayValue,
        cusip: value,
        isin: "",
        ticker: "",
        sedol: "",
        secGroup: "",
        secType: ""
    };

    const [inputValue, setInputValue] = useState<string>(displayValue || "");
    const [selection, setSelection] = useState<SecurityOption | null>(InitialSelection);
    const [typeAheadData, setTypeAheadData] = useState<AuxTypeAheadSuggestionGroup[]>(
        columnDefs.map(({ label, mapper }) => ({
            label,
            values: [InitialSelection].map(mapper)
        }))
    );
    const [customNoResultsMessage, setCustomNoResultsMessage] = useState<string | undefined>();
    const [auxTypeAhead, setAuxTypeAhead] = useState<HTMLAuxTypeAheadElement | null>(null);

    useEffect(() => {
        if (displayValue !== inputValue) {
            setInputValue(displayValue || "");
        }
    }, [displayValue]);

    const [errorMessages, setErrorMessages] = useState<string[]>([]);
    useEffect(() => {
        setErrorMessages(validate?.(displayValue === placeholder ? null : displayValue) ?? []);
    }, [displayValue, validate]);

    useEffect(() => {
        auxTypeAhead?.validate?.();
    }, [errorMessages]);

    let timeout: NodeJS.Timeout;

    const debouncedApiCall = (callback: Function, waitTime: number) => {
        function wrapper() {
            if (timeout) {
                clearTimeout(timeout);
            }

            timeout = setTimeout(() => {
                callback();
            }, waitTime);
        }

        return wrapper;
    };


    useEffect(() => {
        if (!selection || inputValue !== selection.desc1) {
            setSelection(null);
            fetchSecurities(inputValue);
        }
        return () => {
            if (controller) controller.abort();
        };
    }, [inputValue]);

    const fetchSecurities = useCallback((searchText: string): any => {
        setTypeAheadData([]);
        if (searchText.length < 3) {
            setCustomNoResultsMessage("Please provide at least 3 characters...");
            setTypeAheadData(INITIAL_TYPEAHEAD_DATA);
            onChange(searchText, null);
        } else {
            setCustomNoResultsMessage("searching...");
            const query = () =>
                apiPost<any, SecurityOptionsResponse[]>(
                    "/bms/request/app/explore/securitySearch",
                    {
                        searchText,
                        asOfDate: formatSecurityDate(undefined, true),
                        universe: "ALADDIN_PORTFOLIOS",
                        multipleSecuritiesFlag: false,
                    },
                    {
                        fixture: "security-search/" + searchText,
                        ready: (abortController: AbortController) => {
                            controller = abortController;
                        }
                    }
                )
                    .then((response) => {
                        let data = response[0]?.output?.data ?? [];
                        if (filter) {
                            data = data.filter(filter);
                        }
                        setTypeAheadData(
                            columnDefs.map(({ label, mapper }) => ({
                                label,
                                values: data.map(mapper)
                            }))
                        );
                        setCustomNoResultsMessage(undefined);
                    })
                    .catch((error) => {
                        if (error.name !== "AbortError" || error.timeout) {
                            setCustomNoResultsMessage(error.message);
                        }
                    })
                    .finally(() => {
                        controller = null;
                    });

            const debouncedQuery = debouncedApiCall(query, 200);

            debouncedQuery();
        }
    }, []);

    let ignoreOnBlur = false;

    return (
        <div key={"security-lookup"} className="atw-security-lookup aux-simple-table__cell-input">
            {!editable ? (
                <div className={className}>{displayValue}</div>
            ) : (
                <div className={className}>
                    <AuxTypeAhead
                        className={className}
                        data-test-id={testId}
                        ref={setAuxTypeAhead}
                        autoFocus={false}
                        debounceTime={500}
                        data={typeAheadData}
                        dropdownOffsetWidth={dropdownOffsetWidth}
                        isLoading={false}
                        isRequired
                        onInputValueChanged={(evt) => {
                            console.log("onInputValueChanged", evt);
                            const searchText = evt.detail.value.trim();
                            setInputValue(searchText);
                        }}
                        onTypeaheadSelectionChanged={(evt: any) => {
                            evt.preventDefault();
                            console.log("onTypeaheadSelectionChanged", evt);
                            const security = evt.detail.option.value;
                            setSelection(security);
                            if (security) {
                                evt.target.inputValue = security.desc1;
                                setInputValue(security.desc1);
                                onChange(security.cusip, security.desc1);
                            } else {
                                setInputValue("");
                                onChange(null, "");
                            }
                            ignoreOnBlur = true;
                        }}
                        onFocus={(evt) => {
                            // @ts-ignore
                            evt.target.shadowRoot
                                .querySelector("aux-text-input")
                                .shadowRoot.querySelector("input")
                                .select();
                        }}
                        type={"tabular"}
                        validator={useMemo(
                            () => [
                                {
                                    validate: () => {
                                        return errorMessages ? errorMessages.length === 0 : true;
                                    },
                                    errorMessage: errorMessages ? errorMessages.join("\n") : ""
                                }
                            ],
                            [errorMessages]
                        )}
                        onBlur={(evt) => {
                            if (!ignoreOnBlur) {
                                console.log("onBlur");
                                if (selection) {
                                    evt.target.inputValue = selection.desc1;
                                    setInputValue(selection.desc1);
                                    onChange(selection.cusip, selection.desc1);
                                } else {
                                    setInputValue("");
                                    onChange(null, "");
                                }
                            }
                        }}
                        placeholder={placeholder}
                        inputValue={inputValue}
                        customNoResultsMessage={customNoResultsMessage}
                    />
                </div>
            )}
        </div>
    );
}
