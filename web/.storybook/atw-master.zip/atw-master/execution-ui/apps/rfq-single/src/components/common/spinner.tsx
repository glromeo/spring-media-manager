import { logClick } from "@atw/toolkit/telemetry";
import {
    AuxProgressIndicator,
    AuxProgressIndicatorSizeEnum,
    AuxProgressIndicatorTypeEnum
} from "@blk/aladdin-react-components-es";
import { useEffect } from "react";
import { useAtomValue } from "jotai";
import { orderIdAtom } from "../../features/order/order";

// refactor-todo -> update this
export function Spinner({ title }: { title: string }) {
    const orderNumber = useAtomValue(orderIdAtom);

    useEffect(() => {
        progressInd();
    }, []);

    function progressInd() {
        {
            logClick(`${title}`, { orderNumber });
        }
    }

    return (
        <div className="restrictionLoading">
            <AuxProgressIndicator
                hasCounter
                hasLabel
                isSpinner
                loadingLabel={title}
                progress={30}
                size={AuxProgressIndicatorSizeEnum.LARGE}
                type={AuxProgressIndicatorTypeEnum.LOADING}
            />
        </div>
    );
}
