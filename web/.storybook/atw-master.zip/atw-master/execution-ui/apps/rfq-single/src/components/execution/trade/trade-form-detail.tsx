import { AuxBadge, AuxBadgeStyleEnum, AuxBadgeTypeEnum } from "@blk/aladdin-react-components-es";
import { genericUtils } from "../../../common/utils";
import { stepperAtom, StepperSubStatus } from "../../../features/stepper/stepper";
import { tradeFormInfoAtom, TradeFormSchema } from "../../../features/tradeForm";
import { DetailsTable } from "../../common/details-table";
import { useAtomValue } from "jotai";
import { pricingTypeAtom } from "../../../models/atoms";
import { orderSideAtom } from "../../../features/order/order";
import { decodesAtom } from "../../../features/decodes";

export function TradeFormDetail() {
    const side = useAtomValue(orderSideAtom);
    const { subStatus } = useAtomValue(stepperAtom);
    const spotTimeDecodes = useAtomValue(decodesAtom)["SPOT_TIMES"] ?? {};
    const tradeFormInfo = useAtomValue(tradeFormInfoAtom);
    const pricingType = useAtomValue(pricingTypeAtom);

    const getTradeFormDetails = () => {
        return tradeFormInfo.schema
            .filter((schema: TradeFormSchema) => schema.visibleFor(pricingType, subStatus) && schema.summarize === true)
            .map((schema: TradeFormSchema) => {
                const field = schema.type === "select" ? schema.field + "Selected" : schema.field;

                let value = (tradeFormInfo.tradeForm as any)[field];

                if (field === "spotTimeSelected" && spotTimeDecodes) {
                    value = spotTimeDecodes[value] ?? value;
                }

                return {
                    label: schema.label,
                    value: value,
                    type: schema.type
                };
            });
    };
    const title = "Mini Trade Form Details";
    const sideTitle = genericUtils.removeSpace(title);
    // refactor-todo: can we delete the case with DEFAULT_ACTION? do we trigger this in RFQ?
    return (
        <div>
            {subStatus === StepperSubStatus.DEFAULT_ACTION ? (
                <div className="tableHeader">
                    <div>{title}</div>
                    <div className="tradeFormDetailBadge">
                        <AuxBadge
                            badgeStyle={side === "BUY" ? AuxBadgeStyleEnum.IN_PROGRESS : AuxBadgeStyleEnum.ALERT}
                            type={AuxBadgeTypeEnum.CUSTOM}
                        >
                            <div slot="custom">{`${genericUtils.titleCase(side)} Order`}</div>
                        </AuxBadge>
                    </div>
                </div>
            ) : null}
            <DetailsTable name={sideTitle} data={getTradeFormDetails()} />
        </div>
    );
}
