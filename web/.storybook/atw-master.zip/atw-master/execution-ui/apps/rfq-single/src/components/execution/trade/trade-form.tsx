import { atomWithEffects } from "@atx/toolkit/atoms";
import { useAtom, useAtomValue, useSetAtom } from "jotai";
import { useCallback, useEffect } from "react";
import { pricingTypeAtom } from "../../../models/atoms";
import { genericUtils, tradeFormUtils } from "../../../common/utils";
import { orderBmkIdAtom, orderHasValidDataAtom, orderLeavesAtom } from "../../../features/order/order";
import { stepperAtom, StepperSubStatus } from "../../../features/stepper/stepper";
import {
    TradeForm,
    tradeFormAtom,
    TradeFormSchema,
    tradeFormSchemaAtom,
    tradeFormSink
} from "../../../features/tradeForm";
import { SPREAD } from "../../../models/common";
import {
    FormSelectOptionType,
    PriceRenderer,
    SelectRenderer,
    SizeRenderer,
    SpreadRenderer,
    validationCheck
} from "../../common/form-renderers";
import { brokerAtom } from "../../../features/brokers/brokers";
import { decodesAtom } from "../../../features/decodes";

const getDataTestId = (title: string, field: string) => {
    return genericUtils.removeSpace(`${title}-${field}`);
};

function isValidBenchmark(id: string) {
    return id && id !== "-";
}

const validationAtom = atomWithEffects<Map<string, boolean>>(new Map(), (get, set, validationMap) => {
    for (const isValid of validationMap.values()) {
        if (!isValid) {
            set(tradeFormSink, { hasValidData: false });
            return;
        }
    }
    const currentPricingType = get(pricingTypeAtom);
    if (currentPricingType === SPREAD && !isValidBenchmark(get(orderBmkIdAtom))) {
        set(tradeFormSink, { hasValidData: false });
        return;
    }
    set(tradeFormSink, { hasValidData: true });
});

export function TradeForm() {
    const orderHasValidData = useAtomValue(orderHasValidDataAtom);
    const [tradeForm, setTradeForm] = useAtom(tradeFormAtom);
    const entities = useAtomValue(brokerAtom).entity;
    const setValidations = useSetAtom(validationAtom);

    useEffect(() => {
        if (orderHasValidData) {
            // rfq doesn't need to set initial trade form, just dump store
            // refactor-todo: can we put this dumpStore elsewhere and delete it from here
            // genericUtils.dumpStore();
        }
        setValidations(new Map());
    }, []);

    useEffect(() => {
        if (orderHasValidData && tradeForm.hasValidData) {
            setTradeForm({
                ...tradeForm,
                broker: tradeFormUtils.getBrokerNames(entities)
            });
        }
    }, [orderHasValidData, tradeForm.hasValidData]); // eslint-disable-line react-hooks/exhaustive-deps

    return (
        <div data-test-id="trade-form" className={`tradeFormContainer`}>
            <TradeFormBody />
        </div>
    );
}

function TradeFormBody() {
    const brokerDecodes = useAtomValue(decodesAtom)["PLACEMENT_SEND"] ?? {};
    const orderLeaves = useAtomValue(orderLeavesAtom);
    const schema = useAtomValue(tradeFormSchemaAtom);
    const [tradeForm, setTradeForm] = useAtom(tradeFormAtom);
    const [validations, setValidations] = useAtom(validationAtom);
    const pricingType = useAtomValue(pricingTypeAtom);
    const { subStatus } = useAtomValue(stepperAtom);
    const title = "Mini Trade Form";

    const onValidate = useCallback(
        (id: string, valid: boolean) => {
            if (validations.get(id) === valid) return;
            setValidations(new Map(validations.set(id, valid)));
        },
        [validations]
    );

    const hasTradeFormChanged = (id: string, value: string | { label: string; value: string }) => {
        const tradeFormItemValue = tradeForm[id as keyof TradeForm];
        const updatedValue = tradeFormItemValue ? tradeFormItemValue.toString() : tradeFormItemValue;
        return updatedValue !== value;
    };
    const getUpdatedTradeForm = (
        key?: string,
        value?: string | { label: string; value: string }
    ): Partial<TradeForm> => {
        let tradeForm: Partial<TradeForm> = {};
        if (key === undefined) return tradeForm;
        const aSchema = schema.find((schema) => schema.field === key);
        if (aSchema === undefined) {
            (tradeForm as any)[key] = value;
        } else {
            switch (aSchema!.type) {
                case "boolean":
                    (tradeForm as any)[key] = Boolean(value);
                    break;
                case "size":
                case "spread":
                case "price":
                    (tradeForm as any)[key] = Number(genericUtils.removeCommas(value as string));
                    break;
                default:
                    (tradeForm as any)[key] = value;
                    break;
            }
        }
        return tradeForm;
    };

    const entities = useAtomValue(brokerAtom).entity;

    const onValueChanged = (id: string, value: string | { label: string; value: string }) => {
        if (!hasTradeFormChanged(id, value)) return;
        const update = getUpdatedTradeForm(id, value);
        // broker is not a straight publish ...
        if (id === "brokerSelected" && update.brokerSelected && update.brokerSelected !== value) {
            // in this case - we need to update the desk select, based on selected broker...
            update.desk = tradeFormUtils.getDesks(entities, update.brokerSelected!);
            update.deskSelected = tradeFormUtils.getDefaultDesk(entities, update.brokerSelected!);
        }
        setTradeForm({ ...tradeForm, ...update });
    };

    // eslint-disable-next-line
    return (
        <>
            {schema.map((schema: TradeFormSchema) => {
                if (!schema.visibleFor(pricingType, subStatus)) return null;
                const isControlDisabled = schema.disabledFor();
                const label = schema.label;
                switch (schema.type) {
                    case "price": {
                        const isDisabledOverride = isControlDisabled || subStatus !== StepperSubStatus.COUNTER;
                        return (
                            <div
                                data-test-id={getDataTestId(title, schema.field)}
                                className="tradeFormItem"
                                key={label}
                            >
                                <label className="tradeFormLabel">{label}</label>
                                <div className="tradeFormValue">
                                    <PriceRenderer
                                        formItemData={{
                                            formTitle: title,
                                            label: label,
                                            field: schema.field,
                                            value: tradeForm[schema.field]! as number,
                                            value2: tradeForm[schema.field]!,
                                            disabled: isDisabledOverride,
                                            onValidate,
                                            onValueChanged
                                        }}
                                    />
                                </div>
                            </div>
                        );
                    }
                    case "spread": {
                        const isDisabledOverride = isControlDisabled || subStatus !== StepperSubStatus.COUNTER;
                        return (
                            <div
                                data-test-id={getDataTestId(title, schema.field)}
                                className="tradeFormItem"
                                key={label}
                            >
                                <label className="tradeFormLabel">{label}</label>
                                <div className="tradeFormValue">
                                    <SpreadRenderer
                                        formItemData={{
                                            formTitle: title,
                                            label: label,
                                            field: schema.field,
                                            value: tradeForm[schema.field]! as number,
                                            value2: tradeForm[schema.field]!,
                                            disabled: isDisabledOverride,
                                            onValidate,
                                            onValueChanged
                                        }}
                                    />
                                </div>
                            </div>
                        );
                    }
                    case "size": {
                        return (
                            <div
                                data-test-id={getDataTestId(title, schema.field)}
                                className="tradeFormItem"
                                key={label}
                            >
                                <label className="tradeFormLabel">{label}</label>
                                <div className="tradeFormValue">
                                    <SizeRenderer
                                        formItemData={{
                                            formTitle: title,
                                            label: label,
                                            field: schema.field,
                                            value: tradeForm[schema.field]! as number,
                                            disabled: isControlDisabled,
                                            min: 1,
                                            max: orderLeaves,
                                            onValidate,
                                            onValueChanged
                                        }}
                                    />
                                </div>
                            </div>
                        );
                    }
                    case "select": {
                        // in case of select - field2/value2 holds the selected value (where field/value contains the original data value(s))
                        // selects also transforms the data into {label,value}
                        const field2 = schema.field + "Selected";
                        const value2 = tradeForm[field2 as keyof TradeForm];
                        const getSelectData = (data: string[], field: string) => {
                            // select data has {label, value} pairs
                            let formData: FormSelectOptionType[] = [];
                            if (field === "broker") {
                                formData = data.map((value) => ({
                                    displayValue: (brokerDecodes && brokerDecodes[value]) ?? value,
                                    value
                                }));
                            } else {
                                formData = data.map((value) => {
                                    return { displayValue: value, value };
                                });
                            }

                            if (field === "dueIn") return formData;

                            return formData.sort((a, b) => String(a.displayValue).localeCompare(b.displayValue));
                        };
                        let value: FormSelectOptionType[] = getSelectData(tradeForm[schema.field]! as [], schema.field);
                        const isDisabledOverride =
                            isControlDisabled || (schema.field === "desk" && tradeForm.deskSelected === "");
                        let validator: validationCheck = () => ({
                            isValid: true,
                            errorMessage: ""
                        });
                        return (
                            <div
                                data-test-id={getDataTestId(title, schema.field)}
                                className="tradeFormItem"
                                key={label}
                            >
                                <label className="tradeFormLabel">{label}</label>
                                <div className="tradeFormValue">
                                    <SelectRenderer
                                        formItemData={{
                                            formTitle: title,
                                            disabled: isDisabledOverride,
                                            label: label,
                                            field: schema.field,
                                            value: value,
                                            field2: field2,
                                            value2: value2,
                                            onValidate,
                                            onValueChanged,
                                            validator
                                        }}
                                    />
                                </div>
                            </div>
                        );
                    }
                }
                return null;
            })}
        </>
    );
}
