import React from "react";
import { TEXT } from "../../../common/constants";
import { genericUtils } from "../../../common/utils";
import { stepperAtom, StepperSubStatus } from "../../../features/stepper/stepper";
import { DEFAULT_TRADEFORM_SCHEMA, tradeFormInfoAtom, TradeFormSchema } from "../../../features/tradeForm";
import { PRICE, SPREAD } from "../../../models/common";
import "./trade-summary.scss";
import { useAtomValue } from "jotai";
import { pricingTypeAtom } from "../../../models/atoms";
import { orderBondAtom, orderCurrencyAtom, orderSideAtom } from "../../../features/order/order";

// refactor-todo - rename this
export function TradeSummary() {
    const { subStatus } = useAtomValue(stepperAtom);
    const side = useAtomValue(orderSideAtom);
    const currency = useAtomValue(orderCurrencyAtom);
    const bond = useAtomValue(orderBondAtom);
    const pricingType = useAtomValue(pricingTypeAtom);
    const tradeFormInfo = useAtomValue(tradeFormInfoAtom);
    const tradeForm = tradeFormInfo.tradeForm;

    const confirmValue = `${side} ${subStatus === StepperSubStatus.COUNTER_REVIEW ? "" : "order for"} ${genericUtils.formatSize(
        tradeForm.size!
    )}`;

    const getReviewText = () => {
        if (subStatus === StepperSubStatus.COUNTER_REVIEW) return "You will send a Counter Request to";
        else return TEXT.CONFIRM_SEND;
    };
    const price =
            pricingType === PRICE &&
            `$${genericUtils.formatPrice(
                typeof tradeForm.price! === "string" ? parseFloat(tradeForm.price!) : tradeForm.price!
            )} ${currency}`,
        spread =
            pricingType === SPREAD &&
            `${genericUtils.formatSpread(
                typeof tradeForm.spread! === "string" ? parseFloat(tradeForm.spread!) : tradeForm.spread!
            )}`;

    const TradeSummaryText = () => {
        const dueInSchema: TradeFormSchema | undefined = DEFAULT_TRADEFORM_SCHEMA.find(
            (input) => input.field === "dueIn" && input.visibleFor("PRICE", subStatus)
        );
        const dueIn = tradeForm.dueInSelected;
        const dueInText = dueInSchema?.label === "Good For" ? "for" : "due in";
        return (
            <div>
                {getReviewText()}
                <span className="trade-summary-value">{confirmValue}</span> of
                <span className="trade-summary-value">{bond}</span> at
                <span className="trade-summary-value">{price || spread}</span>
                <span> to</span>
                <span className="trade-summary-value">{tradeForm.brokerSelected}</span>
                {subStatus === StepperSubStatus.COUNTER_REVIEW ? (
                    <React.Fragment>
                        <span> {dueInText}</span>
                        <span className="trade-summary-value">{dueIn}</span>
                    </React.Fragment>
                ) : null}
            </div>
        );
    };

    return (
        <div data-test-id="trade-summary" className="trade-summary">
            {TradeSummaryText()}
        </div>
    );
}
