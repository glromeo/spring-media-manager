import { useAtomValue } from "jotai";
import React from "react";
import { basketIDAtom } from "../../../models/atoms";
import { useValidationResetOnInput } from "../../../common/hooks/useValidationResetOnInput";
import { useValidationResetOnWorkflow } from "../../../common/hooks/useValidationResetOnWorkflow";
import { useWorkflow } from "../../../common/hooks/useWorkflow";
import { isRFQRequest } from "../../../common/utils/rfqUtils";
import { OrderDetails } from "../../common/order-details";
import { Spinner } from "../../common/spinner";
import { Ribbon } from "../ribbon/ribbon";
import { Request } from "./request/request";
import { Response } from "./response/response";
import { orderHasValidDataAtom } from "../../../features/order/order";

export const Body = React.memo(() => {
    const basketID = useAtomValue(basketIDAtom);
    const orderHasValidData = useAtomValue(orderHasValidDataAtom);
    useValidationResetOnInput();
    useValidationResetOnWorkflow();
    useWorkflow();

    const isRequest = isRFQRequest(basketID);

    return (
        <div className="rfqContainer">
            {!orderHasValidData ? (
                <Spinner title="Loading Order Details" />
            ) : (
                <React.Fragment>
                    <Ribbon />
                    <div className="rfqBody">
                        <div className="leftColumn">
                            <OrderDetails />
                        </div>
                        {isRequest ? (
                            <Request />
                        ) : (
                            <div className="responseColumn">
                                <Response />
                            </div>
                        )}
                    </div>
                </React.Fragment>
            )}
        </div>
    );
});
