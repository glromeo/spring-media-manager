import { useAtom, useAtomValue, useSetAtom } from "jotai";
import { Fragment, useEffect } from "react";
import { genericUtils, rfqUtils } from "../../../../common/utils";
import {
    brokerAtom,
    BrokerEntity,
    DIRECT,
    directBrokersAtom,
    eligibleVenueBrokersAtom,
    isVenueSelectAllCheckedAtom,
    currentVenueBrokersAtom,
    eligibleDirectBrokersAtom,
    pricingTypeEligibleDirectBrokersAtom
} from "../../../../features/brokers/brokers";
import { orderEligibleVenueNamesAtom } from "../../../../features/order/order";
import { DeskSelectionType, rfqAtom, triggerDeskSelectionSink } from "../../../../features/rfq/rfq";
import {
    pricingProtocolCheckedAtom,
    rfqSelectedBrokerSink,
    selectedDirectBrokersAtom,
    selectedVenueAtom,
    selectedVenueBrokersAtom,
    spotTimeSelectedAtom
} from "../../../../features/rfqTradeForm/rfqTradeForm";
import { StepperStatus, stepperAtom } from "../../../../features/stepper/stepper";
import { DeskSelection } from "../../desk/desk-selection";
import { RFQPopup } from "../../misc/rfq-popup";
import { RfqTradeForm } from "./rfq-trade-form";
import { BrokerSelection } from "../../../common/broker-selection";

export function Request() {
    const { status } = useAtomValue(stepperAtom);
    const deskSelectionTriggered = useAtomValue(rfqAtom).triggerDeskSelection;
    const brokers = useAtomValue(brokerAtom).entity;
    const hasEligibleVenueNames = useAtomValue(orderEligibleVenueNamesAtom).length;
    const directBrokers = useAtomValue(directBrokersAtom);
    const currentVenueBrokers = useAtomValue(currentVenueBrokersAtom);
    const eligibleVenueBrokers = useAtomValue(eligibleVenueBrokersAtom);
    const eligibleDirectBrokers = useAtomValue(eligibleDirectBrokersAtom);
    const pricingTypeEligibleDirectBrokers = useAtomValue(pricingTypeEligibleDirectBrokersAtom);
    const [selectedDirectBrokers, setSelectedDirectBrokers] = useAtom(selectedDirectBrokersAtom);
    const [selectedVenueBrokers, setSelectedVenueBrokers] = useAtom(selectedVenueBrokersAtom);
    const pricingProtocolChecked = useAtomValue(pricingProtocolCheckedAtom);
    const [spotTimeSelected, setSpotTimeSelected] = useAtom(spotTimeSelectedAtom);
    const isVenueSelectAllChecked = useAtomValue(isVenueSelectAllCheckedAtom);
    const triggerDeskSelection = useSetAtom(triggerDeskSelectionSink);
    const updateBrokerSelection = useSetAtom(rfqSelectedBrokerSink);
    const configureDesks = (needsDeskSelection: DeskSelectionType, specificBrokers?: BrokerEntity[]) => {
        const brokersToConfigure = specificBrokers || brokers;
        const triggeredBrokers = rfqUtils.getBrokersWithMultipleDesks(brokersToConfigure);
        triggerDeskSelection(needsDeskSelection, triggeredBrokers);
    };
    const selectedVenue = useAtomValue(selectedVenueAtom);

    useEffect(() => {
        if (pricingProtocolChecked === "Spread") setSpotTimeSelected({ displayValue: "Spot Now", value: "A" });

        setSelectedDirectBrokers(pricingTypeEligibleDirectBrokers);
        if (hasEligibleVenueNames && selectedVenue) {
            // refactor-todo: find a way to not use useEffect, maybe in rfq-trade-form.....
            // when pricing protocol changes, update broker selection to unselect all venue brokers
            setSelectedVenueBrokers([]);
        }
    }, [pricingProtocolChecked]);

    useEffect(() => {
        // when spot time changes, filter out the selected brokers that are not delayed spot eligible
        // refactor-todo: selectedDirectBrokers can be a derived atom that derives from eligible brokers here
        if (pricingProtocolChecked === "Spread") {
            const selectedSpotEligibleDirectBrokers = selectedDirectBrokers.filter((broker) =>
                eligibleDirectBrokers.includes(broker)
            );
            setSelectedDirectBrokers(selectedSpotEligibleDirectBrokers);

            if (hasEligibleVenueNames && selectedVenue) {
                const selectedSpotEligibleVenueBrokers = selectedVenueBrokers.filter((broker) =>
                    eligibleVenueBrokers.includes(broker)
                );
                setSelectedVenueBrokers(selectedSpotEligibleVenueBrokers);
            }
        }
    }, [spotTimeSelected]);

    const handleBrokerSelectionChange = (
        type: "ADD" | "REMOVE",
        brokerSourceName: string,
        selectedBroker: BrokerEntity
    ) => {
        const oppositeBrokerSource = brokerSourceName === DIRECT ? selectedVenue?.name : DIRECT;
        const oppositeSelectedBrokers = brokerSourceName === DIRECT ? selectedVenueBrokers : selectedDirectBrokers;
        const selectedBrokers = brokerSourceName === DIRECT ? selectedDirectBrokers : selectedVenueBrokers;
        const lastBrokerUnselected =
            selectedBrokers &&
            type === "REMOVE" &&
            selectedBrokers.length === 1 &&
            oppositeSelectedBrokers.length === 0;
        updateBrokerSelection(type, selectedBroker, brokerSourceName);
        // if broker selected in direct is also selected in venue, unselect the one in venue, and vice versa
        if (type === "ADD" && oppositeBrokerSource && oppositeSelectedBrokers.includes(selectedBroker)) {
            updateBrokerSelection("REMOVE", selectedBroker, oppositeBrokerSource);
        }

        if (lastBrokerUnselected && pricingProtocolChecked === "Spread") {
            // If no brokers were selected (length of direct&venue is 0), and we try to select the broker after that then spotTimeSelected should be "-".
            setSpotTimeSelected({ displayValue: "-", value: "-" });
        }

        genericUtils.logTelemetryClick(
            "Selected Brokers",
            "selectedBroker " + type,
            `${brokerSourceName} {selectedBroker.name}`
        );
    };

    const handleVenueSelectAllChecked = (checked: boolean) => {
        setSelectedVenueBrokers(checked ? eligibleVenueBrokers : []);
        if (checked) {
            // for each selected direct broker, if not an eligible venue broker to be checked, push that to newSelectedDirectBrokers to be checked
            const newSelectedDirectBrokers = [];
            for (const selectedDirectBroker of selectedDirectBrokers) {
                if (!eligibleVenueBrokers.includes(selectedDirectBroker)) {
                    newSelectedDirectBrokers.push(selectedDirectBroker);
                }
            }
            setSelectedDirectBrokers(newSelectedDirectBrokers);
        }

        if (pricingProtocolChecked === "Spread") {
            // If there are no direct brokers selected, and there is at least one eligible venue broker, and then user unchecks select all, then spotTimeSelected should be reset to "-" ("Select").

            // now it would be opposite......
            setSpotTimeSelected(
                !checked && selectedDirectBrokers.length === 0 && eligibleVenueBrokers.length > 0
                    ? { displayValue: "-", value: "-" }
                    : spotTimeSelected
            );
        }
    };

    return (
        <Fragment>
            <div>
                <div className="columnHeader">Parameters</div>
                <div className="rfqTradeFormItemGutter line"></div>

                <RfqTradeForm />
            </div>
            <div className="rightColumn">
                <div className="columnHeader">Brokers</div>
                <div className="rfqTradeFormItemGutter line"></div>
                <BrokerSelection
                    directBrokers={directBrokers}
                    venueBrokers={currentVenueBrokers}
                    selectedVenue={selectedVenue}
                    selectedDirectBrokers={selectedDirectBrokers}
                    selectedVenueBrokers={selectedVenueBrokers}
                    pricingType={pricingProtocolChecked}
                    onTriggerDeskSelection={configureDesks}
                    onBrokerSelectionChange={handleBrokerSelectionChange}
                    onVenueSelectAllChecked={handleVenueSelectAllChecked}
                    isVenueSelectAllChecked={isVenueSelectAllChecked}
                ></BrokerSelection>
                <div>{deskSelectionTriggered === "open" ? <DeskSelection /> : null}</div>
            </div>
            {status === StepperStatus.SEND ? <RFQPopup /> : null}
        </Fragment>
    );
}
