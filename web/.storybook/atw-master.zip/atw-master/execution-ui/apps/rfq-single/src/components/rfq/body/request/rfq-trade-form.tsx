import { AuxRadioInterface } from "@blk/aladdin-react-components-es";
import React, { memo, useEffect, useState } from "react";
import { genericUtils } from "../../../../common/utils";

import { useAtom, useAtomValue, useSetAtom } from "jotai";
import _ from "lodash";
import { DateTime } from "luxon";
import { pricingTypeAtom } from "../../../../models/atoms";
import {
    PricingProtocol,
    RFQ_DUEIN_DATA,
    RfqTradeForm as RfqTradeFormState,
    rfqTradeFormHasValidDataAtom,
    rfqTradeFormInfoAtom,
    RfqTradeFormSchema,
    rfqTradeFormSink,
    RfqTradeFormTimerData,
    spotTimesAtom,
    spotTimeSelectedAtom,
    SelectData
} from "../../../../features/rfqTradeForm/rfqTradeForm";
import {
    DateRenderer,
    FormSelectOptionType,
    RadioRenderer,
    SecurityLookupRenderer,
    SelectRenderer,
    SizeRenderer,
    TimeRenderer
} from "../../../common/form-renderers";
import { tokensAtom } from "@atx/commons";
import {
    orderBmkAtom,
    orderBmkIdAtom,
    orderHasValidDataAtom,
    orderLeavesAtom,
    orderSettleDateAtom,
    PricingType
} from "../../../../features/order/order";
import { selectedBrokersCountAtom } from "src/features/brokers/brokers";

export const RfqTradeForm = memo(() => {
    const selectedBrokersCount = useAtomValue(selectedBrokersCountAtom);
    const updateRfqTradeForm = useSetAtom(rfqTradeFormSink);
    const [spotTimeSelected, setSpotTimeSelected] = useAtom(spotTimeSelectedAtom);
    const spotTimes = useAtomValue(spotTimesAtom);
    const updateRfqTradeFormHasValidData = useSetAtom(rfqTradeFormHasValidDataAtom);
    const [pricingType, setPricingType] = useAtom(pricingTypeAtom);
    const orderHasValidData = useAtomValue(orderHasValidDataAtom);
    const orderBmk = useAtomValue(orderBmkAtom);
    const orderBmkId = useAtomValue(orderBmkIdAtom);
    const orderSettleDate = useAtomValue(orderSettleDateAtom);
    const orderLeaves = useAtomValue(orderLeavesAtom);
    const tradeFormInfo = useAtomValue(rfqTradeFormInfoAtom);
    const rfqTradeForm = tradeFormInfo.tradeForm;
    const [validationMap, setValidationMap] = useState(new Map<string, boolean>());
    const formTitle = "rfq-trade-form";
    const getDataTestId = (title: string, field: string) => {
        return genericUtils.removeSpace(`${title}-${field}`);
    };
    const rawAsapTokenDueInTimes = useAtomValue(tokensAtom).AladdinTraderRFQTimers;
    const asapTokenDueInTimes: string[] = rawAsapTokenDueInTimes
        .split(",")
        .map(genericUtils.parseSecondsToMinutesString);

    useEffect(() => {
        if (orderHasValidData) {
            const dueInData = getDueInData(pricingType, "Bin");

            const dueAt = genericUtils.getCurrentTime("America/New_York", 30);

            updateRfqTradeForm({
                // refactor-todo: can this logic be moved to startRFQSink? Can also be derived atoms like spotTime
                pricingProtocolChecked: genericUtils.titleCase(pricingType) as PricingProtocol,
                dueIn: dueInData.values.map((dueInDataValue) => ({
                    displayValue: dueInDataValue,
                    value: dueInDataValue
                })),
                dueInSelected: { displayValue: dueInData.selected, value: dueInData.selected },
                dueAt: dueAt,
                settleDate: getInitialSettleDate(),
                benchmarkSelected: { displayValue: orderBmk, value: orderBmkId }
            });
            updateRfqTradeFormHasValidData(true);
        }
        validate();
    }, [orderHasValidData]);

    useEffect(() => {
        validate();
    }, [
        rfqTradeForm.pricingProtocolChecked,
        rfqTradeForm.dueProtocolChecked,
        rfqTradeForm.benchmarkSelected,
        orderLeaves
    ]);

    useEffect(() => {
        if (
            spotTimes &&
            spotTimes.length > 0 &&
            !spotTimes.find((spotTime) => spotTime.value === spotTimeSelected.value) &&
            spotTimeSelected.value !== "-"
        ) {
            setSpotTimeSelected({ displayValue: "-", value: "-" });
        }
    }, [spotTimes]);

    const validate = () => {
        for (let [field, valid] of validationMap) {
            const isFieldVisible = tradeFormInfo.schema
                .find((schema) => schema.field === field)
                ?.visibleFor(tradeFormInfo);

            if (isFieldVisible && !valid) {
                updateRfqTradeFormHasValidData(false);
                return false;
            }
        }
        updateRfqTradeFormHasValidData(true);
        return true;
    };

    const onValidate = (id: string, valid: boolean) => {
        if (validationMap.get(id) === valid) return;
        setValidationMap(new Map(validationMap.set(id, valid)));
        validate();
    };
    const hasRfqTradeFormChanged = (id: string, value: string | SelectData) => {
        if (typeof value === "object" && "value" in value) {
            const tradeFormItemValue = rfqTradeForm[id as keyof RfqTradeFormState] as {
                displayValue: string;
                value: string;
            };
            return tradeFormItemValue.value !== value.value;
        }
        const tradeFormItemValue = rfqTradeForm[id as keyof RfqTradeFormState]!.toString();
        return tradeFormItemValue !== value;
    };
    const updateTradeFormDueIn = (updatedTradeForm: Partial<RfqTradeFormState>) => {
        updatedTradeForm.dueIn = asapTokenDueInTimes.map((asapTokenDueInTime) => ({
            displayValue: asapTokenDueInTime,
            value: asapTokenDueInTime
        }));
        updatedTradeForm.dueInSelected = { displayValue: asapTokenDueInTimes[0], value: asapTokenDueInTimes[0] };
        updatedTradeForm.dueProtocolChecked = "Due In";
        return updatedTradeForm;
    };
    const onValueChanged = (id: string, value: string | SelectData) => {
        if (!hasRfqTradeFormChanged(id, value)) return;

        const currentTradeForm = rfqTradeForm;
        let updatedTradeForm = getUpdatedTradeForm(id, value);
        const valueHasChanged = (selectedId: keyof RfqTradeFormState) => {
            return id === selectedId && currentTradeForm[selectedId] && currentTradeForm[selectedId] !== value;
        };
        if (valueHasChanged("pricingProtocolChecked")) {
            if (rfqTradeForm.timerChecked === "ASAP") {
                // still in ASAP mode, another field changed
                updatedTradeForm = updateTradeFormDueIn(updatedTradeForm);
            } else {
                const dueInData = getDueInData(
                    updatedTradeForm.pricingProtocolChecked?.toUpperCase() as "PRICE" | "SPREAD",
                    currentTradeForm.timerChecked?.toUpperCase() as RfqTradeFormTimerData
                );
                updatedTradeForm.dueIn = dueInData.values.map((dueInDataValue) => ({
                    displayValue: dueInDataValue,
                    value: dueInDataValue
                }));
                updatedTradeForm.dueInSelected = { displayValue: dueInData.selected, value: dueInData.selected };
            }
            setPricingType(updatedTradeForm.pricingProtocolChecked?.toUpperCase() as "PRICE" | "SPREAD");
        }
        if (valueHasChanged("timerChecked")) {
            if (updatedTradeForm.timerChecked === "ASAP") {
                // switching to ASAP mode
                updatedTradeForm = updateTradeFormDueIn(updatedTradeForm);
            } else {
                const dueinData = getDueInData(
                    currentTradeForm.pricingProtocolChecked?.toUpperCase() as "PRICE" | "SPREAD",
                    updatedTradeForm.timerChecked?.toUpperCase() as RfqTradeFormTimerData
                );
                updatedTradeForm.dueIn = dueinData.values.map((dueInDataValue) => ({
                    displayValue: dueInDataValue,
                    value: dueInDataValue
                }));
                updatedTradeForm.dueInSelected = { displayValue: dueinData.selected, value: dueinData.selected };
            }
        }

        updateRfqTradeForm(updatedTradeForm);
    };

    const getUpdatedTradeForm = (key?: string, value?: string | SelectData): Partial<RfqTradeFormState> => {
        let tradeForm: Partial<RfqTradeFormState> = {};
        if (key === undefined) return tradeForm;
        const schema = tradeFormInfo.schema.find((schema) => schema.field === key);
        if (schema === undefined) {
            (tradeForm as any)[key] = value;
        } else {
            switch (schema!.type) {
                case "boolean":
                    (tradeForm as any)[key] = Boolean(value);
                    break;
                case "size":
                    (tradeForm as any)[key] = Number(genericUtils.removeCommas(value! as string));
                    break;
                case "time":
                // time input sanitizing
                default:
                    (tradeForm as any)[key] = value;
                    break;
            }
        }
        return tradeForm;
    };

    const getMinSize = () => {
        return 1; // no longer need to look at order.minTrdSize (this will be handled via backend validation before send)
    };
    const getSelectData = (data: SelectData[], field: string) => {
        // select data has {label, value} pairs
        if (field === "spotTime" || field === "dueIn") return data;

        return data.sort((a, b) => String(a.displayValue).localeCompare(b.displayValue));
    };

    const getInitialSettleDate = () => {
        const minValue = tradeFormInfo.schema.find((schema) => schema.field === "settleDate")?.minValue;
        if (
            minValue &&
            DateTime.fromFormat(minValue, "dd-MMM-yyyy") > DateTime.fromFormat(orderSettleDate, "dd-MMM-yyyy")
        ) {
            return minValue;
        }
        return orderSettleDate;
    };

    const getDueInData = (pricingMode: PricingType, timer: RfqTradeFormTimerData) =>
        RFQ_DUEIN_DATA[pricingMode][timer.toUpperCase() as "BIN"];

    return (
        <div data-test-id={`${genericUtils.removeSpace(formTitle)}`} className="tradeFormContainer">
            {tradeFormInfo.schema.map((schema: RfqTradeFormSchema, i: number) => {
                if (!schema.visibleFor(tradeFormInfo)) return null;
                let isDisabledOverride = schema.field === "dueProtocol" && rfqTradeForm.timerChecked === "ASAP";
                const label = schema.label;
                let tradeFormItem;
                switch (schema.type) {
                    case "radio": {
                        const checkedField = schema.field + "Checked";
                        const checkedValue = rfqTradeForm[checkedField as keyof RfqTradeFormState];
                        let value: AuxRadioInterface[] = (rfqTradeForm[schema.field] as string[]).map((item) => ({
                            label: item,
                            eventData: item,
                            checked: checkedValue === item,
                            disabled: isDisabledOverride
                        }));
                        tradeFormItem = (
                            <div
                                data-test-id={getDataTestId(formTitle, schema.field)}
                                className="rfqTradeFormItemRadio"
                            >
                                <label className="tradeFormLabelRadio">{label}</label>
                                <div className="tradeFormValue">
                                    <RadioRenderer
                                        formItemData={{
                                            formTitle,
                                            label: label,
                                            field: schema.field,
                                            value: value,
                                            field2: checkedField,
                                            value2: checkedValue as string,
                                            onValidate,
                                            onValueChanged
                                        }}
                                    />
                                </div>
                            </div>
                        );
                        break;
                    }
                    case "size": {
                        const maxSize = orderLeaves;
                        tradeFormItem = (
                            <div data-test-id={getDataTestId(formTitle, schema.field)} className="rfqTradeFormItem">
                                <label className="tradeFormLabel">{label}</label>
                                <div className="tradeFormValue">
                                    <SizeRenderer
                                        formItemData={{
                                            formTitle,
                                            label: label,
                                            field: schema.field,
                                            value: rfqTradeForm[schema.field]! as number,
                                            disabled: false,
                                            min: getMinSize(),
                                            max: maxSize,
                                            onValidate,
                                            onValueChanged
                                        }}
                                    />
                                </div>
                            </div>
                        );
                        break;
                    }
                    case "time": {
                        tradeFormItem = (
                            <div data-test-id={getDataTestId(formTitle, schema.field)} className="rfqTradeFormItem">
                                <label className="tradeFormLabel">{label}</label>
                                <div className="tradeFormValue">
                                    <TimeRenderer
                                        formItemData={{
                                            formTitle,
                                            label: label,
                                            field: schema.field,
                                            value: rfqTradeForm[schema.field]! as number,
                                            onValidate,
                                            onValueChanged
                                        }}
                                    />
                                </div>
                            </div>
                        );
                        break;
                    }
                    case "select": {
                        // in case of select - field2/value2 holds the selected value (where field/value contains the original data value(s))
                        // selects also transforms the data into {displayValue,value}

                        const field2 = schema.field + "Selected";
                        const value2 = rfqTradeForm[field2 as keyof RfqTradeFormState];
                        let value: FormSelectOptionType[] = getSelectData(
                            rfqTradeForm[schema.field]! as [],
                            schema.field
                        );
                        const isDisabled =
                            schema.disabledFor(tradeFormInfo) ||
                            (schema.field === "dueIn" && rfqTradeForm.timerChecked === "ASAP");

                        tradeFormItem = (
                            <div data-test-id={getDataTestId(formTitle, schema.field)} className="rfqTradeFormItem">
                                <label className="tradeFormLabel">{label}</label>
                                <div className="tradeFormValue">
                                    <SelectRenderer
                                        formItemData={{
                                            formTitle,
                                            disabled: isDisabled,
                                            label: label,
                                            field: schema.field,
                                            value: value,
                                            field2: field2,
                                            value2: value2 as string,
                                            onValidate,
                                            onValueChanged
                                        }}
                                    />
                                </div>
                            </div>
                        );
                        break;
                    }
                    case "date": {
                        let value = rfqTradeForm[schema.field]! as string;
                        const value2 = schema.minValue ?? rfqTradeForm[schema.field]!;

                        tradeFormItem = (
                            <div data-test-id={getDataTestId(formTitle, schema.field)} className="rfqTradeFormItem">
                                <label className="tradeFormLabel">{label}</label>
                                <div className="tradeFormValue">
                                    <DateRenderer
                                        formItemData={{
                                            formTitle,
                                            field: schema.field,
                                            label: label,
                                            value: value,
                                            value2: value2 as string,
                                            disabled: false,
                                            onValidate,
                                            onValueChanged
                                        }}
                                    />
                                </div>
                            </div>
                        );
                        break;
                    }
                    case "securityLookup": {
                        const field2 = schema.field + "Selected";
                        const value2 = (rfqTradeForm[field2 as keyof RfqTradeFormState] as {
                            displayValue: string;
                            value: string;
                        }) || { label: "", value: "" };
                        tradeFormItem = (
                            <div data-test-id={getDataTestId(formTitle, schema.field)} className="rfqTradeFormItem">
                                <label className="tradeFormLabel">{label}</label>
                                <div className="tradeFormValue">
                                    <SecurityLookupRenderer
                                        formItemData={{
                                            formTitle,
                                            field: schema.field,
                                            label: label,
                                            value: value2.displayValue,
                                            field2,
                                            value2: value2,
                                            disabled: false,
                                            onValidate,
                                            onValueChanged
                                        }}
                                    />
                                </div>
                            </div>
                        );
                        break;
                    }
                }
                if (tradeFormItem) {
                    return (
                        <React.Fragment key={i}>
                            <div
                                className={`rfqTradeFormItemGutter ${
                                    ["timer", "settleDate"].includes(schema.field) ? "line" : ""
                                }`}
                            />
                            {tradeFormItem}
                        </React.Fragment>
                    );
                }

                return null;
            })}
        </div>
    );
});
