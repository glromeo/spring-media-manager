import { AtwColumnDef, AtwTable, RenderOpts } from "@atw/toolkit";
import { AuxButton, AuxButtonSizeEnum, AuxButtonTypeEnum } from "@blk/aladdin-react-components-es";
import { useAtomValue, useSetAtom } from "jotai";
import { useEffect, useState } from "react";
import { pricingTypeAtom } from "../../../../models/atoms";
import { genericUtils, quoteUtils, responseGridUtils, rfqUtils } from "../../../../common/utils";
import {
    BROKER_RESPONDED,
    QUOTE_SUBJECT,
    rfqAtom,
    rfqDueInTimedOutAtom,
    RFQQuote,
    rfqQuotesAtom,
    updateQuoteAtom
} from "../../../../features/rfq/rfq";
import { statusAtom, StepperStatus, StepperSubStatus } from "../../../../features/stepper/stepper";
import { tradeFormSink } from "../../../../features/tradeForm";
import { CountDown } from "../../../common/countdown";
import { orderSideAtom } from "../../../../features/order/order";
import { AtxIcon } from "@atx/toolkit/components/atx-icon";
import { AuxWrapper } from "../../../common/aux-wrapper";
import { TEXT } from "../../../../common/constants";

export function ResponseGrid({ onQuoteActionClick }: { onQuoteActionClick: (row: RFQQuote) => void }) {
    const rfqQuotes = useAtomValue(rfqQuotesAtom);
    const setStatus = useSetAtom(statusAtom);
    const setTradeForm = useSetAtom(tradeFormSink);
    const side = useAtomValue(orderSideAtom);
    const pricingType = useAtomValue(pricingTypeAtom);
    const timerMode = useAtomValue(rfqAtom).dueInProtocol;
    const [rowData, setRowData] = useState<any[]>([]);
    const [columnDefs, setColumnDefs] = useState<AtwColumnDef<any>[]>([]);
    const dueInTimedOut = useAtomValue(rfqDueInTimedOutAtom);
    const [isActiveBin, setIsActiveBin] = useState<boolean>(true);
    const dataTestIdLabel = "rfq-response-table";
    const [needsCounterCol, setNeedsCounterCol] = useState(false);
    const [highestQuoteLevel, setHighestQuoteLevel] = useState<number>();
    const [lowestQuoteLevel, setLowestQuoteLevel] = useState<number>();
    const updateQuote = useSetAtom(updateQuoteAtom);
    const { RQCR } = rfqUtils.getModifyReasonLib();

    function getTradeForm(rfqQuote: RFQQuote) {
        const { pricingValue, size, broker, deskKey, spotTime } = rfqQuote;
        let formattedPrice;
        if (genericUtils.isValidNumber(pricingValue)) {
            formattedPrice = responseGridUtils.formatValueByPricingType(pricingValue as number, pricingType);
        }
        return {
            price: pricingType === "PRICE" ? formattedPrice : undefined,
            spread: pricingType === "SPREAD" ? formattedPrice : undefined,
            size: size,
            brokerSelected: broker,
            deskSelected: deskKey,
            broker: [broker],
            desk: [deskKey],
            spotTime: [spotTime],
            spotTimeSelected: spotTime
        };
    }

    function hitLift(rfqQuote: RFQQuote) {
        setTradeForm(getTradeForm(rfqQuote));
        setStatus({ status: StepperStatus.SEND, subStatus: StepperSubStatus.HITLIFT });
        onQuoteActionClick(rfqQuote);
    }

    function counter(rfqQuote: RFQQuote) {
        setTradeForm(getTradeForm(rfqQuote));
        setStatus({ status: StepperStatus.SEND, subStatus: StepperSubStatus.COUNTER });
        onQuoteActionClick(rfqQuote);
    }

    useEffect(() => {
        setIsActiveBin(timerMode === "BIN" && !dueInTimedOut);
    }, [timerMode, dueInTimedOut]);

    useEffect(() => {
        if (pricingType) {
            const pricingTypeLabel = pricingType === "PRICE" ? "Price" : "Spread";
            let responseTableColData: AtwColumnDef<RFQQuote>[] = [
                {
                    type: "string",
                    field: "broker",
                    label: "Broker",
                    width: 80,
                    render: (row: RFQQuote, opts: RenderOpts<RFQQuote>) => {
                        // refactor-todo: move this into a separate file
                        const brokerName = responseGridUtils.parseStringValue(row[opts.field] as string);
                        if (rfqUtils.isFilled(row)) {
                            return (
                                <div data-test-id={`${row.broker.toLowerCase()}-filled-row`} className="filled-broker">
                                    <span data-test-id={`${row.broker.toLowerCase()}-filled-name`}>{brokerName}</span>
                                    <AtxIcon
                                        testId={`${row.broker.toLowerCase()}-filled-icon`}
                                        name="success-bold"
                                        type="success"
                                    />
                                </div>
                            );
                        }
                        return <span>{brokerName}</span>;
                    }
                },
                {
                    type: "string",
                    field: "pricingValue",
                    label: pricingTypeLabel,
                    width: 60,
                    className: "text-align-r",
                    render: (row: RFQQuote, _opts: RenderOpts<RFQQuote>) => {
                        // refactor-todo: move this into a separate file
                        let value;
                        // only show value if row is not quote counter
                        if (row.modifyReason !== RQCR && genericUtils.isValidNumber(row.pricingValue)) {
                            value = responseGridUtils.formatValueByPricingType(
                                row.pricingValue as number,
                                pricingType
                            )!;
                        } else {
                            value = "-";
                        }
                        return <span>{value}</span>;
                    }
                },
                {
                    type: "number",
                    field: "size",
                    label: "Size",
                    width: 80,
                    className: "text-align-r",
                    render: (row: RFQQuote, _opts: RenderOpts<RFQQuote>) => {
                        // refactor-todo: move this into a separate file
                        const value = rfqUtils.shouldShowSize(row) ? genericUtils.formatSize(row.size) : "-";
                        return <span>{value}</span>;
                    }
                },
                { type: "string", field: "source", label: "Source", width: 100 },
                {
                    type: "string",
                    field: "goodFor",
                    label: "Good For",
                    width: 70,
                    render: (row: RFQQuote, _opts: RenderOpts<RFQQuote>) => {
                        // refactor-todo: move this into a separate file
                        let value = "-";
                        const showGoodFor = !isActiveBin && rfqUtils.goodForEnabled(row);
                        if (!genericUtils.isValidNumber(row.goodFor) || !showGoodFor) {
                            return <span>{value}</span>;
                        }
                        return (
                            <CountDown
                                timer={Number(row.goodFor)}
                                type="basic"
                                onCountDownEnd={() => {
                                    handleOnCountDownEnd(row);
                                }}
                            />
                        );
                    }
                }, // maybe this would be better as "time"
                {
                    type: "string",
                    field: "rfqStatus",
                    label: "RFQ Status",
                    width: 160
                },
                {
                    type: "button", // this type can be anything except 'unknown', it is mapped to the classname in AtwTable.
                    field: "actionBtns",
                    label: "",
                    width: 142,
                    render: (row: RFQQuote, _opts: RenderOpts<RFQQuote>) => {
                        // refactor-todo: move this into a separate file
                        const label = side === "BUY" ? "Lift" : "Hit";
                        if (isActiveBin) {
                            // Blank
                            return <span></span>;
                        }

                        if (row.rfqStatus === BROKER_RESPONDED) {
                            // Hit/Lift + Counter
                            return (
                                <div className="atw-grid-cell-content executeCellContainer">
                                    <AuxWrapper size={60}>
                                        <AuxButton
                                            className="actionButton"
                                            label={label}
                                            size={AuxButtonSizeEnum.SMALL}
                                            type={AuxButtonTypeEnum.PRIMARY}
                                            slot="primary-button"
                                            onClick={() => hitLift(row)}
                                            data-test-id={`${label.toLowerCase()}-placement-${row.broker.toLowerCase()}`}
                                        />
                                    </AuxWrapper>
                                    <AuxWrapper size={60}>
                                        <AuxButton
                                            className="actionButton"
                                            label={TEXT.COUNTER}
                                            size={AuxButtonSizeEnum.SMALL}
                                            type={AuxButtonTypeEnum.SECONDARY}
                                            slot="secondary-button"
                                            onClick={() => counter(row)}
                                            data-test-id={`counter-placement-${row.broker.toLowerCase()}`}
                                        />
                                    </AuxWrapper>
                                </div>
                            );
                        } else if (row.rfqStatus === QUOTE_SUBJECT) {
                            // Counter only
                            return (
                                <div className="atw-grid-cell-content executeCellContainer">
                                    <AuxWrapper size={60}>
                                        <AuxButton
                                            className="actionButton"
                                            label={TEXT.COUNTER}
                                            size={AuxButtonSizeEnum.SMALL}
                                            type={AuxButtonTypeEnum.SECONDARY}
                                            slot="secondary-button"
                                            onClick={() => counter(row)}
                                            data-test-id={`counter-placement-${row.broker.toLowerCase()}`}
                                        />
                                    </AuxWrapper>
                                </div>
                            );
                        } else {
                            return <span></span>;
                        }
                    }
                }
            ];
            if (needsCounterCol) {
                responseTableColData.splice(2, 0, {
                    type: "string",
                    field: "counterValue",
                    label: "Counter " + pricingTypeLabel,
                    width: 105,
                    className: "text-align-r",
                    render: (row: RFQQuote, _opts: RenderOpts<RFQQuote>) => {
                        // refactor-todo: move this into a separate file
                        let value =
                            row.modifyReason === RQCR
                                ? responseGridUtils.formatValueByPricingType(row.counterValue as number, pricingType)!
                                : "-";
                        return <span>{value}</span>;
                    }
                });
            }
            setColumnDefs([...responseTableColData]);
        }
    }, [pricingType, needsCounterCol, isActiveBin]);

    useEffect(() => {
        if (!rfqQuotes?.length) {
            return;
        }

        setRowData(responseGridUtils.sortResponses(rfqQuotes, side));
        // show counter price/spread column if there is a valid quote limit value and request sent
        setNeedsCounterCol(
            rfqQuotes.findIndex((row) => genericUtils.isValidNumber(row.counterValue) && row.modifyReason === RQCR) > -1
        );
        // Extract the max and min quote from all responses
        const quoteValues = rfqQuotes
            .filter((row) => genericUtils.isValidNumber(row.pricingValue))
            .map((quote) => quote.pricingValue as number);
        if (quoteValues.length !== 0) {
            setHighestQuoteLevel(Math.max(...quoteValues));
            setLowestQuoteLevel(Math.min(...quoteValues));
        }
    }, [rfqQuotes]);

    const getRowClassName = (row: RFQQuote, _index: number) => {
        let rowState: string = "";

        if (rfqUtils.isFilled(row)) {
            rowState = "filled";
        } else if (
            genericUtils.isValidNumber(row.pricingValue) &&
            rfqUtils.getSelectedBestQuote(side, row.pricingType, row.pricingValue, lowestQuoteLevel, highestQuoteLevel)
        ) {
            rowState = "best-quote";
        }
        return `rfq-response-grid-row ${rowState}`.trim();
    };

    const handleOnCountDownEnd = (row: RFQQuote) => {
        updateQuote({ ...row, expired: quoteUtils.isExpired(row.goodFor, row.rfqStatus) });
    };

    return (
        <div data-test-id={dataTestIdLabel} className="rfq rfq-responseGrid">
            <AtwTable
                dataTestPrefix={dataTestIdLabel}
                rowHeight={34}
                rowClassName={getRowClassName}
                headerHeight={34}
                rowData={rowData}
                columnDefs={columnDefs}
                columnWidth={100}
            />
        </div>
    );
}
