import { useAtomValue, useSetAtom } from "jotai";
import React, { useCallback, useEffect } from "react";
import { fetchBasketAtom, RFQQuote, rfqQuotesAtom, setRFQSelectedQuoteIDSink } from "../../../../features/rfq/rfq";
import { stepperAtom, StepperStatus, StepperSubStatus } from "../../../../features/stepper/stepper";
import { RFQPopup } from "../../misc/rfq-popup";
import { ResponseGrid } from "./response-grid";
import { Spinner } from "../../../common/spinner";
import { orderHasValidDataAtom } from "../../../../features/order/order";
import { inResumeRFQAtom } from "../../../../models/atoms";

export function Response() {
    const setRFQSelectedQuote = useSetAtom(setRFQSelectedQuoteIDSink);
    const rfqQuotes = useAtomValue(rfqQuotesAtom);
    const orderHasValidData = useAtomValue(orderHasValidDataAtom);
    const fetchBasket = useSetAtom(fetchBasketAtom);
    const stepper = useAtomValue(stepperAtom);
    const inResumeRfq = useAtomValue(inResumeRFQAtom);

    useEffect(() => {
        if (orderHasValidData) {
            fetchBasket();
            if (!inResumeRfq) {
                const extraFetchBasket = setTimeout(() => {
                    // This second, artificially delayed fetchBasket is to cover our bases
                    // in case that the RFQ screen misses the ADDED placement update from Dashboard
                    // todo-refactor: remove this when the BQLs have been updated accordingly
                    fetchBasket();
                }, 2_000);

                return () => clearTimeout(extraFetchBasket);
            }
        }
    }, [orderHasValidData]);

    const handleQuoteActionClick = useCallback((row: RFQQuote) => {
        setRFQSelectedQuote(row.id);
    }, []);

    return (
        <React.Fragment>
            <div className="columnHeader" data-test-id="rfq-response">
                Responses
            </div>
            {rfqQuotes.length === 0 ? (
                <Spinner title="Loading Quotes" />
            ) : (
                <div>
                    <ResponseGrid onQuoteActionClick={handleQuoteActionClick} />
                    {stepper.subStatus !== StepperSubStatus.DEFAULT_ACTION &&
                        stepper.status !== StepperStatus.SENT &&
                        stepper.status !== StepperStatus.SENDING && <RFQPopup />}
                </div>
            )}
        </React.Fragment>
    );
}
