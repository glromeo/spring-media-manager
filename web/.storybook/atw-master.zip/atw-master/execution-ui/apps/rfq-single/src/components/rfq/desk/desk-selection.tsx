import {
    AuxButton,
    AuxButtonSizeEnum,
    AuxButtonTypeEnum,
    AuxCheckbox,
    AuxCheckboxChangedDetailInterface,
    AuxModal,
    AuxSelect,
    AuxSelectOption,
    AuxSelectOptionGroup,
    AuxSelectSelectionChangedDetailInterface
} from "@blk/aladdin-react-components-es";

import { useEffect, useState } from "react";
import * as ReactDOM from "react-dom";
import { genericUtils, tradeFormUtils } from "../../../common/utils";
import { settingsUtils } from "../../../common/utils/settingsUtils";
import { BrokerEntity } from "../../../features/brokers/brokers";
import { KeyValueBoolean, KeyValueNumber } from "../../../models/common";
import "./desk-selection.scss";
import { useAtom, useAtomValue, useSetAtom } from "jotai";
import { atoms } from "../../../models/atoms";
import { rfqAtom, triggerDeskSelectionSink } from "../../../features/rfq/rfq";
import { rfqTradeFormAtom, selectedDeskMapAtom } from "../../../features/rfqTradeForm/rfqTradeForm";
import { AuxWrapper } from "../../common/aux-wrapper";

export function DeskSelection() {
    const tradeForm = useAtomValue(rfqTradeFormAtom);
    const setSelectedDeskMap = useSetAtom(selectedDeskMapAtom);
    const rfq = useAtomValue(rfqAtom);
    const deskSelectionTriggered = rfq.triggerDeskSelection;
    const deskSelectionBrokersTriggered = rfq.triggeredDeskBrokerSelection ?? [];
    const [settings, setSettings] = useAtom(atoms.settings);
    const [deskSelections, setDeskSelections] = useState<KeyValueNumber>({});
    const [okEnabled, setOkEnabled] = useState<boolean>(false);
    const [isSaved, setSaved] = useState<KeyValueBoolean>({});
    const triggerDeskSelection = useSetAtom(triggerDeskSelectionSink);

    useEffect(() => {
        if (deskSelectionTriggered === "open") initialize();
    }, [deskSelectionTriggered]);

    useEffect(() => {
        const desks = deskSelectionBrokersTriggered;
        // determine if each of these desks have a value in deskSelections (contain the entire universe of selected brokers who have multi-desks previously configured)
        const previouslyConfiguredBrokers = Object.keys(deskSelections);
        const allConfigured = desks.filter((desk) => {
            return previouslyConfiguredBrokers.includes(desk.name);
        });
        const areAllDesksConfigured = allConfigured.length === desks.length;

        const isEnabled = areAllDesksConfigured && (hasDeskChanged() || hasSaveChanged());
        setOkEnabled(isEnabled);
    }, [deskSelections, deskSelectionBrokersTriggered, isSaved]);

    const initialize = () => {
        // load from persistence and initialize
        const persistedDesks: KeyValueNumber = settingsUtils.getDeskSettings(settings);
        let combinedDesks = { ...persistedDesks, ...tradeForm.selectedDeskMap };
        if (Object.keys(persistedDesks).length > 0) {
            // update which of those (we loaded from persistence - but if there is a local override honor that instead)
            Object.keys(persistedDesks).forEach((brokerName) => {
                // if user has overridden this desk (even if not saved ...then do not check it ...because it is different than persistence)
                if (tradeForm.selectedDeskMap && tradeForm.selectedDeskMap[brokerName] !== undefined) {
                    // is it the same?
                    isSaved[brokerName] = isDeskSameAs(brokerName, tradeForm.selectedDeskMap);
                } else {
                    isSaved[brokerName] = true;
                }
            });
        }
        setSaved({ ...isSaved });
        setDeskSelections({ ...combinedDesks });
        setSelectedDeskMap(combinedDesks);
    };
    const onOK = () => {
        triggerDeskSelection("close");
        setSelectedDeskMap(deskSelections);
        save();
    };

    const onCancel = () => {
        triggerDeskSelection("cancel");
    };
    const isDeskSameAs = (brokerName: string, against?: KeyValueNumber, against2?: KeyValueNumber) => {
        // if what we have previously saved out - is the same as what user selected - then it's checked
        const persistedDesks: KeyValueNumber = settingsUtils.getDeskSettings(settings);
        if (against === undefined) against = deskSelections;
        if (against2 === undefined) against2 = persistedDesks;
        if (Object.keys(against).length === 0) return false;
        return against2[brokerName] === against[brokerName];
    };
    const onSelectDesk = (event: CustomEvent<AuxSelectSelectionChangedDetailInterface>) => {
        if (event.detail.value) {
            const selectedDeskID = (event.detail.value as AuxSelectOption).value.desk;
            const selectedBroker = (event.detail.value as AuxSelectOption).value.broker;
            deskSelections[selectedBroker] = selectedDeskID;
            console.log("Selecting desk subBrokerID: " + selectedDeskID + " for " + selectedBroker);
            // we need to also automatically update the isPersisted state - i.e. if this is DIFFERENT than what was previously saved - we need to uncheck the 'save as default' checkbox
            updateDefault(selectedBroker, isDeskSameAs(selectedBroker));
            setDeskSelections({ ...deskSelections });
        }
    };
    const hasDeskChanged = () => {
        const keys = Object.keys(deskSelections);
        if (keys.length === 0) return false;
        for (let brokerName of keys) {
            if (!isDeskSameAs(brokerName, deskSelections, tradeForm.selectedDeskMap)) {
                return true;
            }
        }
        return false;
    };
    const hasSaveChanged = () => {
        // iterate again ...if save is (different) that what we have in persistence ...user should be able to save
        let persistedDesks: KeyValueNumber = settingsUtils.getDeskSettings(settings);
        const keys = Object.keys(isSaved);
        if (Object.keys(persistedDesks).length === 0) {
            // in this case - does user have anything checked? if so enabled save...even if not saved yet to persistence
            return keys.some((brokerName) => isSaved[brokerName]);
        }
        if (keys.length === 0) return false;
        for (let brokerName of keys) {
            // if we never had this saved ...then by definition we should be able to save!
            if (persistedDesks[brokerName] === undefined) {
                return true;
            }
        }
        return false;
    };

    const save = () => {
        // if no changes - then do not persist
        const keys = Object.keys(isSaved);
        if (keys.length === 0) return;
        // re-initialize from persistence - udpate any changes (only if user has selected to update persistence)
        let persistedDesks: KeyValueNumber = settingsUtils.getDeskSettings(settings);
        // now update any changes to broker desks defaults...
        let needsToUpdate = false;
        keys.forEach((k) => {
            // only save out (i.e. udpate persistence if user has checked - saveAsDefault checkbox)
            if (isSaved[k] && persistedDesks[k] !== deskSelections[k]) {
                needsToUpdate = true;
                persistedDesks[k] = deskSelections[k];
            }
        });
        // if no changes really needed - no need to update anything
        if (!needsToUpdate) return;
        // bug in ATW ... for now, make it JSON storage
        const deskJSON = JSON.stringify(persistedDesks);
        // finally update our local redux and persist changes
        setSettings({ ...settings, desks: deskJSON }, true);
    };
    const getSelectData = (broker: BrokerEntity): AuxSelectOptionGroup[] => {
        return [
            {
                values: broker.desk.map((desk) => ({
                    displayValue: tradeFormUtils.getDeskKey(desk),
                    value: {
                        desk: desk.subBrokerID,
                        broker: broker.name
                    },
                    auxId: String(desk.subBrokerID),
                    isSelected: deskSelections[broker.name] === desk.subBrokerID
                }))
            }
        ];
    };

    const updateDefault = (brokerName: string, saveState: boolean) => {
        isSaved[brokerName] = saveState;
        setSaved({ ...isSaved });
    };

    return ReactDOM.createPortal(
        <AuxModal
            isEscapeDisabled={true}
            closeAllModalsOnEscape={false}
            header="Please choose a desk"
            type="action"
            isOpen={true}
        >
            <div slot="content">
                <div data-test-id="deskselection" className="desk-selection-modal">
                    {deskSelectionBrokersTriggered.map((broker: BrokerEntity) => (
                        <div key={broker.code} className="desk-selection-row">
                            <div>
                                <AuxWrapper size={100} selector=".aux-select__label-container">
                                    <AuxSelect
                                        data-test-id={genericUtils.removeSpace("deskselection-control-" + broker.name)}
                                        label={broker.name}
                                        isLeftLabel={true}
                                        size="regular"
                                        type="simple"
                                        hasInitialOptionPlaceholder={false}
                                        data={getSelectData(broker)}
                                        onSelectionChanged={onSelectDesk}
                                    />
                                </AuxWrapper>
                            </div>
                            <div className="desk-selection-checbox">
                                <AuxCheckbox
                                    data-test-id={genericUtils.removeSpace(
                                        `deskselection-control-${broker.name}-checkbox`
                                    )}
                                    isDisabled={!deskSelections[broker.name]}
                                    isChecked={isSaved[broker.name]}
                                    label="Save selection as default"
                                    onCheckboxChanged={(event: CustomEvent<AuxCheckboxChangedDetailInterface>) => {
                                        if (event.detail.value.checked !== undefined) {
                                            updateDefault(broker.name, event.detail.value.checked);
                                        }
                                    }}
                                />
                            </div>
                        </div>
                    ))}
                </div>
            </div>
            <AuxButton
                data-test-id="deskselectionokbutton"
                label="OK"
                onClick={onOK}
                slot="primary-button"
                isDisabled={!okEnabled}
            />
            <AuxButton
                data-test-id="deskselectioncancelbutton"
                label="Cancel"
                onClick={onCancel}
                slot="secondary-button"
                size={AuxButtonSizeEnum.REGULAR}
                type={AuxButtonTypeEnum.SECONDARY}
            />
        </AuxModal>,
        document.body
    );
}
