import { logClick } from "@atw/toolkit/telemetry";
import { AuxButton, AuxButtonSizeEnum, AuxButtonTypeEnum } from "@blk/aladdin-react-components-es";
import { useAtomValue, useSetAtom } from "jotai";
import React, { useEffect, useState } from "react";
import { atoms, basketIDAtom } from "../../models/atoms";
import { genericUtils, rfqUtils, windowUtils } from "../../common/utils";
import { isRFQRequest } from "../../common/utils/rfqUtils";
import { settingsUtils } from "../../common/utils/settingsUtils";
import { rfqAtom, rfqCancelEnabledAtom, triggerDeskSelectionSink } from "../../features/rfq/rfq";
import { statusAtom, stepperAtom, StepperStatus, StepperSubStatus } from "../../features/stepper/stepper";
import { KeyValueNumber } from "../../models/common";
import {
    rfqTradeFormAtom,
    rfqTradeFormHasValidDataAtom,
    selectedDeskMapAtom
} from "../../features/rfqTradeForm/rfqTradeForm";
import { alertsAtom, alertStatusAtom } from "../../features/alerts/alert";
import { orderHasValidDataAtom } from "../../features/order/order";
import { TEXT } from "src/common/constants";

export function Footer() {
    const setAlerts = useSetAtom(alertsAtom);
    const alertStatus = useAtomValue(alertStatusAtom);
    const basketID = useAtomValue(basketIDAtom);
    const setStatus = useSetAtom(statusAtom);

    const rfq = useAtomValue(rfqAtom);
    const rfqTradeForm = useAtomValue(rfqTradeFormAtom);
    const rfqTradeFormHasValidData = useAtomValue(rfqTradeFormHasValidDataAtom);
    const orderHasValidData = useAtomValue(orderHasValidDataAtom);
    const setSelectedDeskMap = useSetAtom(selectedDeskMapAtom);
    const triggeredDeskSelection = rfq.triggerDeskSelection;
    const stepper = useAtomValue(stepperAtom);
    const selectedDeskMap = rfqTradeForm.selectedDeskMap;
    const selectedDirectBrokers = rfqTradeForm.selectedDirectBrokers;
    const selectedVenueBrokers = rfqTradeForm.selectedVenueBrokers;
    const settings = useAtomValue(atoms.settings);
    const [sending, setSending] = useState(false);
    const isDisabled =
        (selectedDirectBrokers.length === 0 && selectedVenueBrokers.length === 0) ||
        !orderHasValidData ||
        !rfqTradeFormHasValidData ||
        alertStatus === "ERROR";

    let nextLabel = stepper.status === StepperStatus.ACK_VALIDATION ? "Acknowledge & Send" : "Next";
    const cancelEnabled = useAtomValue(rfqCancelEnabledAtom);

    useEffect(() => {
        if (sending && triggeredDeskSelection == "cancel") {
            setSending(false);
        } else if (sending && triggeredDeskSelection == "close") {
            // in this case - the user has updated all desks - and is now ready to send
            setSending(false);
            setStatus({ status: StepperStatus.SEND });
        }
    }, [sending, triggeredDeskSelection]);

    const triggerDeskSelection = useSetAtom(triggerDeskSelectionSink);

    const verifyDeskMappingsAndSend = () => {
        // before we get to response screen - we need to SEND first - before we send - verify we have valid desk mappings
        setAlerts([]);
        let newSelectedDeskMap = Object.assign({ ...selectedDeskMap });
        let brokersUnconfigured = rfqUtils.getUnconfiguredDesks(selectedDirectBrokers, newSelectedDeskMap);
        if (brokersUnconfigured.length > 0) {
            // grrr - there are some desks still not configured ... let's look at persisted settings ...maybe some are in there??
            const persistedDesks: KeyValueNumber = settingsUtils.getDeskSettings(settings);
            newSelectedDeskMap = Object.assign({}, { ...selectedDeskMap }, { ...persistedDesks });
            // try one more time ...
            brokersUnconfigured = rfqUtils.getUnconfiguredDesks(selectedDirectBrokers, newSelectedDeskMap);
        }
        if (brokersUnconfigured.length > 0) {
            // popup desk selection (filtered by only those that need to be configured) - note because of the disconnected nature of deskselection (probably should turn it into a callback??)
            // we need to keep state as 'sending'
            logClick("User has not configured some desks - configuring now");
            setSending(true);
            triggerDeskSelection("open", brokersUnconfigured);
        } else {
            logClick("User about to SEND RFQ");
            console.log("Bypassing desk selection because all brokers desks have previously been configured");
            setSelectedDeskMap(rfqUtils.constructDeskSelectionMap(selectedDirectBrokers, newSelectedDeskMap));
            setStatus({ status: StepperStatus.SEND });
        }
    };
    const onNext = async () => {
        if (nextLabel === TEXT.NEXT && stepper.status !== StepperStatus.SEND) {
            verifyDeskMappingsAndSend();
        }
        if (nextLabel === "Acknowledge & Send") {
            setStatus({ status: StepperStatus.SENDING });
        }
    };
    const onCancelRFQ = () => {
        logClick("User clicked on Cancel RFQ");
        setStatus({ status: StepperStatus.SEND, subStatus: StepperSubStatus.CANCELING });
    };
    const onCancel = () => {
        const click = "User clicked on Cancel";
        windowUtils.closeWindow(click);
    };
    return (
        <div className="executionFooter">
            <div />
            <div className="executionFooterButtons">
                {isRFQRequest(basketID) ? (
                    <React.Fragment>
                        <AuxButton
                            data-test-id={genericUtils.removeSpace(nextLabel) + "button"}
                            data-telemetry-id="ExecuteButton"
                            isDisabled={isDisabled}
                            label={nextLabel}
                            onClick={onNext}
                            size={AuxButtonSizeEnum.REGULAR}
                            type={AuxButtonTypeEnum.PRIMARY}
                        />

                        <AuxButton
                            data-test-id={genericUtils.removeSpace("Cancel") + "button"}
                            data-telemetry-id="CancelButton"
                            isDisabled={false}
                            label="Cancel"
                            onClick={onCancel}
                            size={AuxButtonSizeEnum.REGULAR}
                            type={AuxButtonTypeEnum.SECONDARY}
                            className="executionFooterCancel"
                        />
                    </React.Fragment>
                ) : (
                    <AuxButton
                        data-test-id={"cancelrfqbutton"}
                        data-telemetry-id="CancelRFQ"
                        isDisabled={!cancelEnabled}
                        label="Cancel RFQ"
                        onClick={onCancelRFQ}
                        size={AuxButtonSizeEnum.REGULAR}
                        type={AuxButtonTypeEnum.SECONDARY}
                    />
                )}
            </div>
        </div>
    );
}
