import { genericUtils } from "../../common/utils";
import { HeaderBase } from "../common/header-base";

export function Header() {
    genericUtils.updateBrowserTitle("RFQ");
    return <HeaderBase />;
}
