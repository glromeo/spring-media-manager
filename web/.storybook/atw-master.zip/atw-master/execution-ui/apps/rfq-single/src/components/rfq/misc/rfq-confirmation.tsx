import { AtwColumnDef } from "@atw/toolkit";
import { useAtomValue } from "jotai";
import { useEffect } from "react";
import { STYLE } from "../../../common/constants";
import { genericUtils, rfqUtils } from "../../../common/utils";
import { selectedBrokerNamesAtom } from "../../../features/brokers/brokers";
import { rfqAtom, selectedRfqQuoteAtom } from "../../../features/rfq/rfq";
import { stepperAtom, StepperSubStatus } from "../../../features/stepper/stepper";
import { NUM_PLACE_HOLDER } from "../../../models/common";
import "./rfq-confirmation.scss";
import CancelingConfirmation from "./rfqConfirmationSubStatus/canceling-confirmation";
import DefaultConfirmation, { cellRenderer } from "./rfqConfirmationSubStatus/default-confirmation";
import HitLiftConfirmation from "./rfqConfirmationSubStatus/hit-lift-confirmation";
import { orderBondAtom, orderIdAtom, orderSideAtom } from "../../../features/order/order";
import { rfqTradeFormAtom } from "../../../features/rfqTradeForm/rfqTradeForm";

export function RFQConfirmation() {
    const { subStatus } = useAtomValue(stepperAtom);
    const side = useAtomValue(orderSideAtom);
    const bond = useAtomValue(orderBondAtom);
    const orderId = useAtomValue(orderIdAtom);
    const rfqTradeForm = useAtomValue(rfqTradeFormAtom);
    const rfqPricingType = useAtomValue(rfqAtom).pricingType;
    const spotTypeSelected = rfqTradeForm.spotTimeSelected;
    const selectedBrokerNames = useAtomValue(selectedBrokerNamesAtom);
    const selectedQuote = useAtomValue(selectedRfqQuoteAtom);

    const getPricingType = () => {
        if (rfqPricingType !== "NOT_SET") {
            return rfqPricingType;
        } else {
            return rfqTradeForm.pricingProtocolChecked || "";
        }
    };
    const pricingType = getPricingType();
    const getQuoteSize = () => {
        if (
            genericUtils.isValidNumber(selectedQuote?.size) &&
            selectedQuote?.size !== NUM_PLACE_HOLDER &&
            selectedQuote?.size !== 0
        ) {
            return genericUtils.formatSize(selectedQuote?.size!);
        }
        if (genericUtils.isValidNumber(rfqTradeForm.size) && rfqTradeForm.size !== NUM_PLACE_HOLDER) {
            return genericUtils.formatSize(rfqTradeForm.size!);
        }
        return undefined;
    };
    const includesSize = () => {
        return subStatus !== StepperSubStatus.CANCELING;
    };
    const brokers = `(${selectedBrokerNames.length}) ${selectedBrokerNames.toString().replace(/,/g, ", ")}`,
        dueInOrAt = rfqUtils.getDueInOrAt(rfqTradeForm),
        dueLabel = rfqUtils.getDueLabelWithTimerType(rfqTradeForm),
        columns: AtwColumnDef<any>[] = [
            {
                type: "string",
                field: "side",
                label: "Side",
                width: STYLE.SIDE_COLUMN_WIDTH
            },
            {
                type: "string",
                field: "security",
                label: "Security",
                width: STYLE.SECURITY_COLUMN_WIDTH,
                render: cellRenderer
            }
        ],
        data: any[] = [
            {
                side: side,
                security: bond,
                broker: brokers,
                spotTimeSelected: spotTypeSelected
            }
        ];

    if (includesSize()) {
        columns.splice(2, 0, {
            type: "string",
            field: "size",
            label: "Size",
            width: STYLE.SIZE_COLUMN_WIDTH
        });
        data[0]["size"] = getQuoteSize();
    }

    useEffect(() => {
        // temp workaround until AtxTable creates a type "side" or can add classname to each td/cell
        const els = document.getElementsByClassName("atw-grid-cell-content side");
        els[0].classList.add(side.toLowerCase());
    }, []);

    const RenderBody = () => {
        switch (subStatus) {
            case StepperSubStatus.HITLIFT:
            case StepperSubStatus.HITLIFT_REJECTED:
            case StepperSubStatus.COUNTER_REJECTED:
                return (
                    // refactor-todo: rename/refactor this component to separate concerns, maybe create RejectedConfirmation separate from HitLiftConfirmation
                    <HitLiftConfirmation
                        columns={columns}
                        data={data}
                        pricingType={pricingType}
                        selectedQuote={selectedQuote}
                        stepperSubStatus={subStatus}
                        orderId={orderId}
                    />
                );
            case StepperSubStatus.CANCELING:
                return (
                    <CancelingConfirmation
                        columns={columns}
                        data={data}
                        pricingType={pricingType}
                        stepperSubStatus={subStatus}
                        orderId={orderId}
                    />
                );
            default:
                return (
                    <DefaultConfirmation
                        columns={columns}
                        data={data}
                        pricingType={pricingType}
                        stepperSubStatus={subStatus}
                        orderId={orderId}
                        dueFields={{
                            dueProtocolChecked: rfqTradeForm.dueProtocolChecked,
                            dueValue: dueInOrAt.dueValue,
                            dueLabel: dueLabel
                        }}
                    />
                );
        }
    };
    return (
        <div data-test-id="rfq-trade-confirmation" className="trade-confirmation">
            {RenderBody()}
        </div>
    );
}
