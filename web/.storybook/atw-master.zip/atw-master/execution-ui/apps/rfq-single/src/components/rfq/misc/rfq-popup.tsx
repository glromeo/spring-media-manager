import { AuxButton, AuxButtonSizeEnum, AuxButtonTypeEnum, AuxModal } from "@blk/aladdin-react-components-es";
import { useAtomValue, useSetAtom } from "jotai";
import React, { useCallback } from "react";
import * as ReactDOM from "react-dom";
import { TEXT } from "../../../common/constants";
import { genericUtils } from "../../../common/utils";
import { orderSideAtom } from "../../../features/order/order";
import { selectedRfqQuoteDisabledAtom, selectedRfqQuoteIDAtom } from "../../../features/rfq/rfq";
import {
    ALERT_SUBSTATUSES,
    statusAtom,
    stepperAtom,
    StepperStatus,
    StepperSubStatus
} from "../../../features/stepper/stepper";
import { Alerts } from "../../common/alerts";
import { MessageBar } from "../../common/message-bar";
import { TradeForm } from "../../execution/trade/trade-form";
import { TradeFormDetail } from "../../execution/trade/trade-form-detail";
import { TradeSummary } from "../../execution/trade/trade-summary";
import { RFQConfirmation } from "./rfq-confirmation";
import { alertsAtom } from "../../../features/alerts/alert";

export type RFQPopupProps = {
    headerText?: string;
    rfqModalInfo?: string;
    messageBarText?: string;
};

const { removeSpace } = genericUtils;
const { SEND, ACK_VALIDATION, SENDING, VALIDATING, STEPS } = StepperStatus;
const { DEFAULT_ACTION, CANCELING, HITLIFT, HITLIFT_REJECTED, COUNTER_REJECTED, COUNTER, COUNTER_REVIEW } =
    StepperSubStatus;

// todo-refactor: separate this out into their own popups, preferably using atx-dialog
export function RFQPopup() {
    const side = useAtomValue(orderSideAtom);
    const stepper = useAtomValue(stepperAtom);

    let headerText: string = "";
    let rfqModalInfo: string = "";
    let messageBarText: string = "";
    // when it comes here we are guaranteed to be in the 'send' state ...look at substatus to determine additional states
    switch (stepper.subStatus) {
        case DEFAULT_ACTION:
            headerText = TEXT.CONFIRM_SEND;
            rfqModalInfo = TEXT.CONFIRM_PROCEED_TEXT;
            break;
        case CANCELING:
            headerText = TEXT.CONFIRM_CANCEL;
            rfqModalInfo = TEXT.CONFIRM_PROCEED_TEXT;
            break;
        case HITLIFT:
            headerText = side === "BUY" ? TEXT.CONFIRM_LIFT : TEXT.CONFIRM_HIT;
            rfqModalInfo = TEXT.CONFIRM_PROCEED_TEXT;
            break;
        case HITLIFT_REJECTED:
            headerText = side === "BUY" ? TEXT.LIFT_REJECTED : TEXT.HIT_REJECTED;
            messageBarText =
                side === "BUY" ? TEXT.YOUR_LIFT_REQUEST_HAS_BEEN_CANCELLED : TEXT.YOUR_HIT_REQUEST_HAS_BEEN_CANCELLED;
            rfqModalInfo = TEXT.PLEASE_REACH_OUT_TO_THE_BROKER_OR_VOICE_STP;
            break;
        case COUNTER_REJECTED:
            headerText = TEXT.COUNTER_REJECTED;
            messageBarText = TEXT.YOUR_COUNTER_REQUEST_HAS_BEEN_CANCELLED;
            rfqModalInfo = TEXT.PLEASE_REACH_OUT_TO_THE_BROKER_OR_VOICE_STP;
            break;
        case COUNTER:
        case COUNTER_REVIEW:
            headerText = TEXT.COUNTERING;
            break;
    }

    return headerText === ""
        ? null
        : ReactDOM.createPortal(
              <aside className={removeSpace(headerText, true)}>
                  <AuxModal
                      isEscapeDisabled={true}
                      closeAllModalsOnEscape={false}
                      hasCustomHeader={true}
                      type="action"
                      isOpen={true}
                  >
                      <PopupBody headerText={headerText} rfqModalInfo={rfqModalInfo} messageBarText={messageBarText} />
                  </AuxModal>
                  ,
              </aside>,
              document.body
          );
}

const CounterForm = (props: RFQPopupProps) => {
    const { headerText } = props;

    return (
        <div data-test-id={removeSpace(headerText)} className="trade-confirmation-modal">
            <TradeForm />
        </div>
    );
};
const CounterReview = (props: RFQPopupProps) => {
    const { headerText } = props;
    return (
        <div data-test-id={removeSpace(headerText)} className="trade-confirmation-modal">
            <TradeFormDetail />
            <TradeSummary />
        </div>
    );
};
const Cancel = (props: RFQPopupProps) => {
    const { headerText, rfqModalInfo } = props;
    return (
        <div slot="content">
            <div data-test-id={removeSpace(headerText)} className="trade-confirmation-modal">
                <div className="message-bar">
                    <MessageBar config={{ color: "RED", message: headerText! }} />
                </div>
                <RFQConfirmation />
                <div data-test-id="rfq-trade-confirmation-modal-info" className="rfq-trade-confirmation-modal-Info">
                    {rfqModalInfo}
                </div>
            </div>
        </div>
    );
};
const Default = (props: RFQPopupProps) => {
    const { headerText, rfqModalInfo, messageBarText } = props;
    const { subStatus } = useAtomValue(stepperAtom);

    return (
        <div slot="content">
            <div data-test-id={removeSpace(headerText)} className="trade-confirmation-modal">
                {ALERT_SUBSTATUSES.includes(subStatus) && (
                    <div className="message-bar">
                        <MessageBar config={{ color: "RED", message: messageBarText! }} />
                    </div>
                )}
                <RFQConfirmation />
                <div data-test-id="rfq-trade-confirmation-modal-info" className="rfq-trade-confirmation-modal-Info">
                    <span className="fw-700">{rfqModalInfo}</span>
                </div>
            </div>
        </div>
    );
};

const CustomHeader = (props: RFQPopupProps) => {
    return (
        <h2 data-test-id="rfq-popup-header" className="aux-modal__header sc-aux-modal custom-header">
            {props.headerText}
        </h2>
    );
};

const PopupBody = React.memo((props: RFQPopupProps) => {
    const { subStatus } = useAtomValue(stepperAtom);
    let PopupContent;
    switch (subStatus) {
        case StepperSubStatus.COUNTER:
            PopupContent = CounterForm;
            break;
        case StepperSubStatus.COUNTER_REVIEW:
            PopupContent = CounterReview;
            break;
        case StepperSubStatus.CANCELING:
            PopupContent = Cancel;
            break;
        case StepperSubStatus.HITLIFT:
        case StepperSubStatus.HITLIFT_REJECTED:
        case StepperSubStatus.COUNTER_REJECTED:
        default:
            PopupContent = Default;
            break;
    }
    return (
        <React.Fragment>
            <div
                slot="content"
                className={
                    subStatus === StepperSubStatus.DEFAULT_ACTION || subStatus === StepperSubStatus.CANCELING
                        ? ""
                        : subStatus === StepperSubStatus.HITLIFT || ALERT_SUBSTATUSES.includes(subStatus)
                        ? "rfqhitlit-confirmation-modal"
                        : "rfqcounter-confirmation-modal"
                }
            >
                <Alerts />
                <CustomHeader {...props} />
                <PopupContent {...props} />
            </div>
            <Buttons {...props} />
        </React.Fragment>
    );
});

const BackButton = () => {
    const stepper = useAtomValue(stepperAtom);
    const setStatus = useSetAtom(statusAtom);
    if (stepper.subStatus !== StepperSubStatus.COUNTER_REVIEW) return null;
    return (
        <AuxButton
            data-test-id={removeSpace("<< Back") + "button"}
            isDisabled={false}
            label={"<< Back"}
            onClick={() => {
                setStatus({ status: SEND, subStatus: COUNTER });
            }}
            size={AuxButtonSizeEnum.REGULAR}
            type={AuxButtonTypeEnum.TERTIARY}
        />
    );
};

const ActionButton = (props: RFQPopupProps) => {
    const { headerText } = props;
    const setStatus = useSetAtom(statusAtom);
    const stepper = useAtomValue(stepperAtom);
    const label = stepper.status === StepperStatus.ACK_VALIDATION ? TEXT.ACK_SEND_BUTTON_LABEL : TEXT.SEND;
    const isDisabled = useAtomValue(selectedRfqQuoteDisabledAtom);
    const selectedQuoteID = useAtomValue(selectedRfqQuoteIDAtom);

    const onActionSend = useCallback(() => {
        if (stepper.status === ACK_VALIDATION) {
            setStatus({ status: SENDING });
        } else {
            setStatus({ status: VALIDATING });
        }
    }, [selectedQuoteID ?? null, stepper.status]);

    switch (stepper.subStatus) {
        case StepperSubStatus.DEFAULT_ACTION:
            return (
                <AuxButton
                    data-test-id={removeSpace(headerText) + "sendbutton"}
                    label={label}
                    onClick={() => {
                        setStatus({ status: VALIDATING });
                    }}
                    type={AuxButtonTypeEnum.PRIMARY}
                    slot="primary-button"
                    isDisabled={isDisabled}
                />
            );
        case StepperSubStatus.HITLIFT:
            return (
                <AuxButton
                    data-test-id={removeSpace(headerText) + removeSpace(label) + "button"}
                    label={label}
                    onClick={onActionSend}
                    type={AuxButtonTypeEnum.PRIMARY}
                    slot="primary-button"
                    isDisabled={isDisabled}
                />
            );
        case StepperSubStatus.COUNTER:
            return (
                <AuxButton
                    data-test-id={removeSpace(headerText) + "nextbutton"}
                    label={TEXT.NEXT}
                    isDisabled={isDisabled}
                    onClick={() => {
                        setStatus({ status: SEND, subStatus: COUNTER_REVIEW });
                    }}
                    type={AuxButtonTypeEnum.PRIMARY}
                    slot="primary-button"
                />
            );
        case StepperSubStatus.COUNTER_REVIEW:
            return (
                <AuxButton
                    data-test-id={removeSpace(headerText) + removeSpace(label) + "button"}
                    isDisabled={isDisabled}
                    label={label}
                    onClick={onActionSend}
                    type={AuxButtonTypeEnum.PRIMARY}
                    slot="primary-button"
                />
            );
        case StepperSubStatus.CANCELING:
            return (
                <AuxButton
                    data-test-id={removeSpace(headerText) + "sendbutton"}
                    label={label}
                    onClick={() => {
                        setStatus({ status: SENDING });
                    }}
                    type={AuxButtonTypeEnum.PRIMARY}
                    slot="primary-button"
                />
            );
    }
    return null;
};

const Buttons = (props: RFQPopupProps) => {
    const setStatus = useSetAtom(statusAtom);
    const setAlerts = useSetAtom(alertsAtom);
    const stepper = useAtomValue(stepperAtom);
    const cancelBtnLabel = ALERT_SUBSTATUSES.includes(stepper.subStatus) ? TEXT.CLOSE : TEXT.CANCEL;

    return (
        <>
            <div slot="tertiary-link">
                <BackButton />
            </div>
            <ActionButton {...props} />
            <AuxButton
                data-test-id={removeSpace(props.headerText) + "cancelbutton"}
                data-telemetry-id="CancelButton"
                label={cancelBtnLabel}
                onClick={() => {
                    setAlerts([]);
                    setStatus({ status: STEPS, subStatus: DEFAULT_ACTION });
                }}
                size={AuxButtonSizeEnum.REGULAR}
                type={AuxButtonTypeEnum.SECONDARY}
                slot="secondary-button"
            />
        </>
    );
};
