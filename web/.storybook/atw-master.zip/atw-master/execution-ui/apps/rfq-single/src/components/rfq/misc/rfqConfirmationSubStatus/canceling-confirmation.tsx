import { AtwColumnDef } from "@atw/toolkit";
import { StepperSubStatus } from "../../../../features/stepper/stepper";
import DefaultConfirmation from "./default-confirmation";

type CancelingConfirmationProps = {
    columns: AtwColumnDef<any>[];
    data: any[];
    pricingType: string;
    stepperSubStatus: StepperSubStatus;
    orderId: number;
};
export default function CancelingConfirmation({
    columns,
    data,
    pricingType,
    stepperSubStatus,
    orderId
}: CancelingConfirmationProps): JSX.Element {
    return (
        <DefaultConfirmation
            columns={columns}
            data={data}
            pricingType={pricingType}
            stepperSubStatus={stepperSubStatus}
            orderId={orderId}
        />
    );
}
