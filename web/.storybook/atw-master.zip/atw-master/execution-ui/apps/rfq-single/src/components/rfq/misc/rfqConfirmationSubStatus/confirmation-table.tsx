import { AtwColumnDef, AtwTable } from "@atw/toolkit";
import _ from "lodash";
import { StepperSubStatus } from "../../../../features/stepper/stepper";

export default function ConfirmationTable(
    columns: AtwColumnDef<any>[],
    data: any[],
    stepperSubStatus: StepperSubStatus
): JSX.Element {
    return (
        <div data-test-id="rfq-single-modal_table" className="rfq rfq-trade-confirmation-modal_table">
            <div className="rfq-trade-confirmation-modal-table-header">
                {shouldShowSummaryHeader(stepperSubStatus) ? (
                    <span className="trade-summary-value">Summary</span>
                ) : null}
            </div>
            <AtwTable
                rowHeight={34}
                headerHeight={30}
                rowData={data}
                columnDefs={_.uniqBy(columns, "label")}
                columnWidth={100}
            />
        </div>
    );
}

const shouldShowSummaryHeader = (stepperSubStatus: StepperSubStatus) => {
    return (
        stepperSubStatus !== StepperSubStatus.HITLIFT &&
        stepperSubStatus !== StepperSubStatus.CANCELING &&
        stepperSubStatus !== StepperSubStatus.DEFAULT_ACTION &&
        stepperSubStatus !== StepperSubStatus.HITLIFT_REJECTED &&
        stepperSubStatus !== StepperSubStatus.COUNTER_REJECTED
    );
};
