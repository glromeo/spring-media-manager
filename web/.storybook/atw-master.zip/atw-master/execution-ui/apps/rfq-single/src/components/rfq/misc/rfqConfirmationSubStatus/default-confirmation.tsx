import { AtwCellRenderer, AtwColumnDef, AtwTooltip } from "@atw/toolkit";
import { AuxValuePair } from "@blk/aladdin-react-components-es";
import { STYLE } from "../../../../common/constants";
import { genericUtils } from "../../../../common/utils";
import { DueProtocol } from "../../../../features/rfqTradeForm/rfqTradeForm";
import { StepperSubStatus } from "../../../../features/stepper/stepper";
import ConfirmationTable from "./confirmation-table";

type DueFields = {
    dueProtocolChecked: DueProtocol;
    dueValue: string;
    dueLabel: string;
};
type DefaultConfirmationProps = {
    columns: AtwColumnDef<any>[];
    data: any[];
    pricingType: string;
    stepperSubStatus: StepperSubStatus;
    orderId: number;
    dueFields?: DueFields;
};
export default function DefaultConfirmation({
    columns,
    data,
    pricingType,
    stepperSubStatus,
    orderId,
    dueFields
}: DefaultConfirmationProps): JSX.Element {
    [columns, data] = updateColumnsAndData(columns, data, pricingType, dueFields);

    return (
        <div slot="content">
            <div data-test-id={genericUtils.removeSpace(stepperSubStatus)} className="trade-confirmation-modal">
                <AuxValuePair label="Order#" value={String(orderId)} isBold={true} />
                {ConfirmationTable(columns, data, stepperSubStatus)}
            </div>
        </div>
    );
}

export function updateColumnsAndData(
    columns: AtwColumnDef<any>[],
    data: any[],
    pricingType: string,
    dueFields?: DueFields
): [columns: AtwColumnDef<any>[], data: any[]] {
    // Confirm Send (RFQ request) has Side, Security, Size, Pricing Protocol, Brokers, Due In
    columns.splice(3, 0, { type: "string", field: "pricingProtocol", label: "Protocol", width: 60 });
    data[0]["pricingProtocol"] = genericUtils.titleCase(pricingType);
    columns.push({
        type: "string",
        field: "broker",
        label: data[0]["broker"].includes(",") ? "Brokers" : "Broker",
        width: STYLE.BROKER_COLUMN_WIDTH,
        render: cellRenderer
    });
    if (pricingType === "Spread") {
        columns.push({
            type: "string",
            field: "spotTimeSelected",
            label: "Spot Time",
            width: STYLE.SPOT_TIME_COLUMN_WIDTH,
            render: cellRenderer
        });
    }

    // If dueFields is undefined, we are in canceling-confirmation
    if (dueFields !== undefined) {
        columns.push({
            type: "string",
            field: dueFields.dueProtocolChecked,
            label: dueFields.dueLabel,
            width: 100
        });
        data[0][dueFields.dueProtocolChecked] = dueFields.dueValue;
    }
    return [columns, data];
}

export const cellRenderer: AtwCellRenderer<any> = (row, opts) => {
    return (
        <div>
            <AtwTooltip className="overflow-text" message={row[opts.field]}>
                {row [opts.field].displayValue || row[opts.field]}
            </AtwTooltip>
        </div>
    );
};
