import { AtwColumnDef } from "@atw/toolkit";
import { useAtomValue } from "jotai";
import { AuxValuePair } from "@blk/aladdin-react-components-es";
import { STYLE } from "../../../../common/constants";
import { genericUtils } from "../../../../common/utils";
import { RFQQuote, selectedRfqQuoteAtom } from "../../../../features/rfq/rfq";
import { StepperSubStatus } from "../../../../features/stepper/stepper";
import { CountDown } from "../../../common/countdown";
import ConfirmationTable from "./confirmation-table";

type HitLiftConfirmationProps = {
    columns: AtwColumnDef<any>[];
    data: any[];
    pricingType: string;
    stepperSubStatus: StepperSubStatus;
    orderId: number;
};
export default function HitLiftConfirmation({
    columns,
    data,
    pricingType,
    stepperSubStatus,
    orderId
}: HitLiftConfirmationProps): JSX.Element {
    const selectedQuote = useAtomValue(selectedRfqQuoteAtom);
    [columns, data] = updateColumnsAndData(columns, data, pricingType, stepperSubStatus, selectedQuote);

    return (
        <div slot="content">
            <div data-test-id={genericUtils.removeSpace(stepperSubStatus)} className="trade-confirmation-modal">
                {stepperSubStatus === StepperSubStatus.HITLIFT && (
                    <div data-test-id="popup-goodfor" className="goodfor-container">
                        Good for:{" "}
                        <strong>
                            <CountDown timer={Number(selectedQuote?.goodFor)} type="basic" />
                        </strong>
                    </div>
                )}
                <AuxValuePair label="Order#" value={String(orderId)} isBold={true} />
                <AuxValuePair label="Placement#" value={String(selectedQuote?.placementNum)} isBold={true} />
                {ConfirmationTable(columns, data, stepperSubStatus)}
            </div>
        </div>
    );
}

function updateColumnsAndData(
    columns: AtwColumnDef<any>[],
    data: any[],
    pricingType: string,
    stepperSubStatus: StepperSubStatus,
    selectedQuote?: RFQQuote
): [columns: AtwColumnDef<any>[], data: any[]] {
    // Confirm Hit/Lift popup has: Side, Security, Size, Price/Spread, Broker, Source
    const priceSpread =
        stepperSubStatus === StepperSubStatus.COUNTER_REJECTED
            ? selectedQuote?.counterValue
            : selectedQuote?.pricingValue;
    const formattedPriceSpread =
        pricingType === "PRICE"
            ? genericUtils.formatPrice(Number(priceSpread))
            : "SPREAD"
            ? genericUtils.formatSpread(Number(priceSpread))
            : "";
    const leftAlignedPriceLabel =
        (stepperSubStatus === StepperSubStatus.COUNTER_REJECTED && "Counter " + genericUtils.titleCase(pricingType)) ||
        genericUtils.titleCase(pricingType);
    const leftAlignedPriceWidth = stepperSubStatus === StepperSubStatus.COUNTER_REJECTED ? 100 : 80;

    columns.push(
        {
            type: "string",
            // using a non price or spread field since atw table defaults to right align for those
            field: "leftAlignedPrice",
            label: leftAlignedPriceLabel,
            width: leftAlignedPriceWidth
        },
        { type: "string", field: "broker", label: "Broker", width: 80 },
        { type: "string", field: "source", label: "Source", width: STYLE.SOURCE_COLUMN_WIDTH }
    );

    if (pricingType === "SPREAD") {
        columns.push({
            type: "string",
            field: "spotTimeSelected",
            label: "Spot Time",
            width: STYLE.SPOT_TIME_COLUMN_WIDTH
        });
    }

    data[0]["leftAlignedPrice"] = formattedPriceSpread;
    data[0]["broker"] = selectedQuote?.broker;
    data[0]["source"] = selectedQuote?.source;
    data[0]["spotTimeSelected"] = selectedQuote?.spotTime;

    return [columns, data];
}
