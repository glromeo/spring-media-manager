import { useAtomValue } from "jotai";
import { rfqAtom } from "../../../features/rfq/rfq";
import { rfqTradeFormAtom } from "../../../features/rfqTradeForm/rfqTradeForm";

export function BenchmarkDisplay() {
    const { benchmarkDesc: rfqBenchmark } = useAtomValue(rfqAtom);
    const tradeFormBenchmark = useAtomValue(rfqTradeFormAtom).benchmarkSelected.displayValue;

    return (
        <div className="benchmark" data-test-id="benchmark-ribbon">
            vs. {tradeFormBenchmark && tradeFormBenchmark !== "-" ? tradeFormBenchmark : rfqBenchmark}
        </div>
    );
}
