import { AuxBadge, AuxBadgeStyleEnum, AuxBadgeTypeEnum } from "@blk/aladdin-react-components-es";
import { useMemo } from "react";
import { genericUtils } from "../../../common/utils";
import { Side } from "../../../models/common";
import { BenchmarkDisplay } from "./benchmarkDisplay";
import { PricingType } from "../../../features/order/order";

export function Bond({
    side,
    bond,
    pricingType
}: {
    side: Side;
    bond: string;
    pricingType: PricingType;
}) {
    return useMemo(() => {
        return (
            <div className="bondSummary">
                <div className="bondBadge">
                    <div className="badgeBox" data-test-id="badge-box">
                        <AuxBadge
                            badgeStyle={side === "BUY" ? AuxBadgeStyleEnum.IN_PROGRESS : AuxBadgeStyleEnum.ALERT}
                            type={AuxBadgeTypeEnum.CUSTOM}
                        >
                            <div slot="custom">{`${genericUtils.titleCase(side)}`}</div>
                        </AuxBadge>
                    </div>
                    <div className="bond" data-test-id="bond">
                        {bond}
                    </div>
                </div>
                {pricingType === "SPREAD" ? <BenchmarkDisplay /> : null}
            </div>
        );
    }, [bond, side, pricingType]);
}
