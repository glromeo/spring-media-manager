export function Brokers({
    isRequest,
    numSelected,
    numQuoted
}: {
    isRequest: boolean;
    numSelected: number;
    numQuoted?: number;
}) {
    return (
        <div className="brokersTotalBox">
            <div className="brokersTotalItem">
                <div className="brokersTotalLabel">Brokers Requested</div>
                <div className="brokersTotalValue" data-test-id="num-brokers-requested">
                    {numSelected || 0}
                </div>
            </div>
            {!isRequest ? (
                <div className="brokersTotalItem">
                    <div className="brokersTotalLabel">Brokers Quoted</div>
                    <div className="brokersTotalValue" data-test-id="num-brokers-quoted">
                        {numQuoted || 0}
                    </div>
                </div>
            ) : null}
        </div>
    );
}
