import { useAtomValue, useSetAtom } from "jotai";
import { useCallback } from "react";
import { basketIDAtom, pricingTypeAtom } from "../../../models/atoms";
import { windowUtils } from "../../../common/utils";
import { orderBondAtom, orderSideAtom } from "../../../features/order/order";
import {
    BROKER_RESPONDED,
    rfqDueInAtom,
    rfqDueInEnabledAtom,
    rfqDueInTimedOutAtom,
    rfqQuotesAtom
} from "../../../features/rfq/rfq";
import { CountDown } from "../../common/countdown";
import { Bond } from "./bond";
import { Brokers } from "./brokers";
import { selectedBrokersCountAtom } from "../../../features/brokers/brokers";
import { isRFQRequest } from "../../../common/utils/rfqUtils";

export function Ribbon() {
    const time = useAtomValue(rfqDueInAtom);
    const setDueInTimedOut = useSetAtom(rfqDueInTimedOutAtom);
    const basketID = useAtomValue(basketIDAtom);
    const rfqQuotes = useAtomValue(rfqQuotesAtom);
    const side = useAtomValue(orderSideAtom);
    const bond = useAtomValue(orderBondAtom);
    const numSelectedBrokers = useAtomValue(selectedBrokersCountAtom);
    const dueInEnabled = useAtomValue(rfqDueInEnabledAtom);
    const spotTime = rfqQuotes[0]?.spotTime || ""; // refactor-todo: - can diff placements have diff spot times? if not, we can move this into RFQ rather than quotes
    const numQuoted = rfqQuotes.filter((b) => b.rfqStatus === BROKER_RESPONDED).length;
    const pricingType = useAtomValue(pricingTypeAtom);

    const isRequest = isRFQRequest(basketID);

    const onCountDownEnd = useCallback(() => {
        setDueInTimedOut(true);
        windowUtils.foregroundWindow();
    }, []);

    return (
        <div className="ribbon">
            <div className="ribbonSummary" data-test-id="ribbon">
                <Bond side={side} bond={bond} pricingType={pricingType} />

                {!isRequest && pricingType === "SPREAD" ? (
                    <div className="spotTimeTotalBox">
                        <div className="spotTimeTotalItem" data-test-id="spot-time-ribbon">
                            <div className="spotTimeLabel">Spot Time</div>
                            <div className="spotTime">{spotTime}</div>
                        </div>
                    </div>
                ) : null}

                {!isRequest && dueInEnabled ? (
                    <CountDown
                        type="rfq"
                        timer={time?.toMillis() ?? 0}
                        title={"Due In"}
                        onCountDownEnd={onCountDownEnd}
                    />
                ) : null}
            </div>
            <Brokers isRequest={isRequest} numSelected={numSelectedBrokers} numQuoted={numQuoted} />
        </div>
    );
}
