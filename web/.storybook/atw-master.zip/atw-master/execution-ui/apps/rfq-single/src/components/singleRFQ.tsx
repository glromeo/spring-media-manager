import { useBenchmark } from "@atx/commons";
import { useAtomValue, useSetAtom } from "jotai";
import { useEffect } from "react";
import { Alerts } from "./common/alerts";
import DebugInfo from "./common/debugInfo";
import { OverlayStatus } from "./common/overlay";
import Rec from "./common/rec";
import { Body } from "./rfq/body/body";
import { Footer } from "./rfq/footer";
import { Header } from "./rfq/header";
import { useDecodes } from "../features/decodes";
import { orderCusipAtom, orderIdAtom, startRfqSink } from "../features/order/order";
import { stepperAtom, StepperSubStatus } from "../features/stepper/stepper";
import { modifyReasonAtom } from "../features/placement/modifyReason";

export function SingleRFQ() {
    const stepper = useAtomValue(stepperAtom);
    const setModifyReason = useSetAtom(modifyReasonAtom);
    const orderNumber = useAtomValue(orderIdAtom);
    const cusip = useAtomValue(orderCusipAtom);
    const startRfq = useSetAtom(startRfqSink);
    const benchmark = useBenchmark(cusip);
    const { MODIFY_REASON } = useDecodes("MODIFY_REASON");

    useEffect(() => {
        console.log(
            `New RFQ workflow initiated at location: ${document.location.href}, Order: ${orderNumber}, Cusip:  ${cusip}`
        );
        return () => {
            console.log("unload RFQ");
        };
    }, []);
    
    useEffect(() => {
        setModifyReason(MODIFY_REASON as Record<string, string>);
    }, [MODIFY_REASON]);

    useEffect(() => {
        // benchmark starts as null and completes as an object when
        if (orderNumber && benchmark) startRfq(orderNumber, benchmark);
    }, [orderNumber, benchmark]);

    return (
        <div className="execution rfq">
            <OverlayStatus status={stepper.status} subStatus={stepper.subStatus} />
            <DebugInfo />
            <Rec />
            {stepper.subStatus === StepperSubStatus.DEFAULT_ACTION ? <Alerts /> : null}
            <Header />
            <Body />
            <Footer />
        </div>
    );
}
