// "ERROR" and "WARNING" maps to notifications on the top that notifities a user and maybe prevent them from continuing workflow
// "ALERT" maps to a popup that forces user to close window
import { alertUtils } from "../../common/utils/alertUtils";
import { atom } from "jotai";
import { genericUtils } from "../../common/utils";

export type AlertType = "PROMPT" | "ALERT" | "ERROR" | "MESSAGE" | "SUCCESS" | "WARNING";

export type Alert = {
    id?: number;
    name?: string;
    message: string;
    type: AlertType;
    timeout?: number;
};

export const alertsAtom = atom<Alert[]>([]);

export const alertSinkAtom = atom(null, (get, set, alert: Alert) => {
    set(alertsAtom, [...get(alertsAtom), alert]);
});

/**
 * NOTE: I don't think the reduceApiErrorTo/reduceApiErrorsTo were actually working fine to start with
 */

export const apiErrorSinkAtom = atom(null, (get, set, error: any = {}) => {
    if (error.error) {
        error = error.error;
    }
    if (typeof error === "string") {
        try {
            error = JSON.parse(error);
        } catch {
            error = [{ type: "ERROR", message: error }];
        }
    }

    function sinkOne(error: any) {
        const { title, type, message } = error;
        console.error(`${title}: ${message}`);
        set(alertSinkAtom, {
            id: genericUtils.nextNumber(),
            name: title,
            message,
            type: type ?? "ALERT",
            timeout: 3600000
        });
    }

    if (Array.isArray(error)) {
        error.map(sinkOne);
    } else {
        sinkOne(error);
    }
});

export const alertStatusAtom = atom<"NONE" | "ERROR" | "WARNING" | "SUCCESS">((get) => {
    const alerts = get(alertsAtom);
    if (alertUtils.hasFatalErrorOrHardNotification(alerts)) {
        return "ERROR";
    } else if (alertUtils.hasSoftNotification(alerts)) {
        return "WARNING";
    } else if (alertUtils.hasSuccessNotification(alerts)) {
        return "SUCCESS";
    }
    return "NONE";
});
