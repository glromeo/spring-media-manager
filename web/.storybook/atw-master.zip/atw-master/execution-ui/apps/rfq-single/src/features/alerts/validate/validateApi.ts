import { logError } from "@atw/toolkit/telemetry";
import {
    GraphQLCounteringValidationResponse,
    GraphQLError,
    GraphQlExecutePlacementQuoteVariables,
    GraphQLPlacementCreationVariables,
    GraphQLValidationResponse,
    validatePlacementsCounteringMutation,
    validatePlacementsExecutionMutation
} from "../../../api/types";
import { apiUtils, rfqUtils } from "../../../common/utils";
import { Side } from "../../../models/common";
import { RFQ, RFQQuote } from "../../rfq/rfq";
import { RfqTradeForm } from "../../rfqTradeForm/rfqTradeForm";
import { TradeForm } from "../../tradeForm";
import { Alert } from "../alert";

/***
 * Called before countering or hit/lift off of an RFQ
 */
export async function validateBeforeUpdatingPlacementQuote(
    rfq: RFQ,
    rfqQuotes: RFQQuote[],
    tradeForm: TradeForm,
    user: string
): Promise<boolean> {
    const validationAction = "validation before countering or hit/lift placement quote";
    let alerts: Alert[] = [];
    const executePlacementQuoteVars = apiUtils.constructRfqActionRequest(
        rfqQuotes,
        rfq.selectedQuoteID!,
        tradeForm,
        user
    );
    delete executePlacementQuoteVars.quotes; // don't send quotes for validation
    try {
        console.log(`Running ${validationAction}: ${JSON.stringify(executePlacementQuoteVars)}`);
        await apiUtils.apiQuery<GraphQlExecutePlacementQuoteVariables, GraphQLValidationResponse>(
            validatePlacementsExecutionMutation,
            executePlacementQuoteVars,
            {
                fixture: `placement_quote-update-validation/${rfq.orderNumber}`,
                telemetry: [validateBeforeUpdatingPlacementQuote.name, validationAction]
            }
        );
        alerts = alerts.concat(parseExecutingRFQAlerts(rfqQuotes, rfq.side, rfq));
    } catch (e: any) {
        // if successful call with warnings/errors
        if (e.data) {
            alerts = parseAlertsFromGraphQLError(e.errors, validationAction);
            alerts = alerts.concat(parseExecutingRFQAlerts(rfqQuotes, rfq.side, rfq));
        } else {
            const validateErrorMessage = `Error encountered in ${validationAction} on placement ${executePlacementQuoteVars.request.placementNum}`;
            const errorMessage = generateError(e, validateErrorMessage);
            alerts.push({
                name: `Error in ${validationAction}`,
                message: errorMessage,
                type: "ERROR"
            });
        }
    }
    if (alerts.length > 0) {
        throw apiUtils.apiErrors(alerts);
    }
    return true;
}

/***
 * Called before sending initial RFQ request
 */
export async function performRFQValidation(
    ordNum: number,
    tradeForm: RfqTradeForm,
    user: string,
    spotType?: string
): Promise<boolean> {
    const validationAction = "validation before requesting RFQ";
    let alerts: Alert[] = [];
    try {
        const placementCreationVariables = apiUtils.constructRfqRequest(ordNum, tradeForm, user, spotType);
        // refactor-todo: have this request only created once and passed into the actual call.
        console.log(`Running ${validationAction}: ${JSON.stringify(placementCreationVariables)}`);

        await apiUtils.apiQuery<GraphQLPlacementCreationVariables, GraphQLCounteringValidationResponse>(
            validatePlacementsCounteringMutation,
            placementCreationVariables,
            {
                fixture: `countering-validation/${ordNum}`,
                telemetry: [performRFQValidation.name, validationAction]
            }
        );
    } catch (e: any) {
        // if successful call with warnings/errors
        if (e.data) {
            alerts = parseAlertsFromGraphQLError(e.errors, validationAction);
        } else {
            const validateErrorMessage = `Error encountered in performing ${validationAction} on order# ${ordNum}`;
            const errorMessage = generateError(e, validateErrorMessage);
            alerts.push({
                name: `Error in ${validationAction}`,
                message: errorMessage,
                type: "ERROR"
            });
        }
    }

    if (alerts.length > 0) {
        throw apiUtils.apiErrors(alerts);
    }
    return true;
}

// the parsing here has to be changed.....find a clean way to show what errors....
export function parseAlertsFromGraphQLError(errors: Partial<GraphQLError>[] | [], validationAction: string): Alert[] {
    const alerts: Alert[] = errors?.map((error: Partial<GraphQLError>): Alert => {
        if (!error.message) {
            return {
                message: `When running ${validationAction}, received ${error.errorType} type error without a message`,
                type: "ERROR"
            };
        }
        const validationResponse = error.message.split(",");
        if (validationResponse.length !== 3) {
            return {
                message: `When running ${validationAction}, received error message "${error.message}"`,
                type: "ERROR"
            };
        } else {
            return {
                message: validationResponse[2],
                type: validationResponse[0].indexOf("warning") < 0 ? "ERROR" : "WARNING"
            };
        }
    }) ?? [
        {
            message: `Unable to run ${validationAction}, received a null or invalid API response`,
            type: "ERROR"
        }
    ];
    alerts.forEach((alert) =>
        logError(`Received ${alert.type} during validation`, {
            message: alert.message
        })
    );
    return alerts;
}

export function parseExecutingRFQAlerts(rfqQuotes: RFQQuote[], side: Side, rfq: RFQ): Alert[] {
    const alerts: Alert[] = [];
    if (!rfqUtils.selectedBestQuote(rfqQuotes, side, rfq.selectedQuoteID!)) {
        alerts.push({
            id: 1,
            message: `Broker is not best level from RFQ Responses`,
            type: "WARNING"
        } as Alert);
    }
    return alerts;
}

export function generateError(e: any, validateErrorMessage: string) {
    const errorMessage = e.errors
        .map((e: any) => e.message + "\n")
        .toString()
        .trim();
    logError(validateErrorMessage, {
        message: errorMessage
    });
    return errorMessage;
}
