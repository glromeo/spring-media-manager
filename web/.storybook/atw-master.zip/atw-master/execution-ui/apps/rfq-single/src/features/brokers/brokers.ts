import { atom } from "jotai";
import { orderUtils, rfqUtils } from "../../common/utils";
import { isRFQRequest } from "../../common/utils/rfqUtils";
import { basketIDAtom } from "../../models/atoms";
import { NUM_PLACE_HOLDER } from "../../models/common";
import { VenueName, venueSpotTimesAtom } from "../order/order";
import { rfqAtom } from "../rfq/rfq";
import {
    pricingProtocolCheckedAtom,
    selectedDirectBrokersAtom,
    selectedVenueAtom,
    selectedVenueBrokersAtom,
    spotTimeSelectedAtom
} from "../rfqTradeForm/rfqTradeForm";

export type Desk = {
    brokerType: string;
    salesman: string;
    subBrokerID: number;
};

export type BrokerRestrictionAllocation = {
    isRestricted: boolean;
    name: string;
    code: number;
    quantity: number;
    percent: number;
    expiryTime?: number | null;
    effectiveTime?: number;
};

export type BrokerRestriction = {
    quantity: number;
    percent: number;
    allocation: BrokerRestrictionAllocation[];
};

export type BrokerEntity = {
    name: string;
    code: number;
    desk: Desk[];
    restriction?: BrokerRestriction;
    defaultDesk?: number;
    isDirect: boolean;
    venues: number[];
} & brokerEnablementConfig;

export type brokerEnablementConfig = {
    isDelayedSpot: boolean;
    isCounteringEnabled: boolean;
    isSpreadFlowEnabled: boolean;
    isMifidTagEnabled?: boolean;
};

export type VenueEntity = {
    name: VenueName;
    code: number;
    displayName: string;
    subBrokerID: number; // desk
} & brokerEnablementConfig;

export type brokerSource = { displayName: "Direct"; name: "DIRECT" } | VenueEntity;

export type Broker = {
    rollup: string; // refactor-todo: DELETE?
    entity: BrokerEntity[];
};

export type BrokerRestrictionLevel = "FULL" | "PARTIAL" | "NONE";
export type BrokerEligibility = {
    name: string;
    spreadEligible: boolean;
    spotTimeEligible: boolean;
    restrictionLevel: BrokerRestrictionLevel;
};

export type CounterParty = {
    ticker: string; // refactor-todo: DELETE?
    shortName: string;
    code: number;
};

export const DIRECT = "DIRECT";

export const brokerAtom = atom<Broker>({
    rollup: "-",
    entity: [
        {
            name: "-",
            code: NUM_PLACE_HOLDER,
            desk: [],
            isDelayedSpot: false,
            isCounteringEnabled: false,
            isSpreadFlowEnabled: false,
            isMifidTagEnabled: false,
            isDirect: false,
            venues: []
        }
    ]
});

// direct broker atoms

export const directBrokersAtom = atom((get) => {
    const brokers = get(brokerAtom).entity;

    // only return brokers that are direct, have at least one desk, and if mifid enabled or no property added
    return brokers.filter((b) => b.isDirect && b.desk.length > 0 && (b.isMifidTagEnabled ?? true));
});

export const pricingTypeEligibleDirectBrokersAtom = atom((get) => {
    const directBrokers = get(directBrokersAtom);
    const pricingProtocolChecked = get(pricingProtocolCheckedAtom);

    return (
        directBrokers?.filter(
            (b) =>
                orderUtils.isFullyAvailable(b) &&
                rfqUtils.brokerEnabledForPricingType(b.isSpreadFlowEnabled, pricingProtocolChecked)
        ) ?? []
    );
});

export const eligibleDirectBrokersAtom = atom((get) => {
    const directBrokers = get(directBrokersAtom);
    const pricingProtocolChecked = get(pricingProtocolCheckedAtom);
    const spotTimeSelected = get(spotTimeSelectedAtom);

    return directBrokers?.filter(
        (b) =>
            orderUtils.isFullyAvailable(b) &&
            rfqUtils.brokerEnabledForPricingType(b.isSpreadFlowEnabled, pricingProtocolChecked) &&
            (pricingProtocolChecked === "Spread"
                ? rfqUtils.brokerEnabledForSpotTime(b.isDelayedSpot, spotTimeSelected.value)
                : true)
    );
});

// venue broker atoms

export const currentVenueBrokersAtom = atom((get) => {
    const brokers = get(brokerAtom).entity;
    const selectedVenue = get(selectedVenueAtom);

    if (!selectedVenue) return [];

    // return brokers that is part of selected venue, and mifid enabled does not equal false
    return brokers.filter((b) => b.venues.includes(selectedVenue.code) && (selectedVenue.isMifidTagEnabled ?? true));
});

export const eligibleVenueBrokersAtom = atom((get) => {
    const currentVenueBrokers = get(currentVenueBrokersAtom);
    const selectedVenue = get(selectedVenueAtom);
    const pricingProtocolChecked = get(pricingProtocolCheckedAtom);
    const spotTimeSelected = get(spotTimeSelectedAtom);

    return currentVenueBrokers?.filter(
        (b) =>
            orderUtils.isFullyAvailable(b) &&
            rfqUtils.brokerEnabledForPricingType(selectedVenue?.isSpreadFlowEnabled ?? false, pricingProtocolChecked) &&
            (pricingProtocolChecked === "Spread"
                ? rfqUtils.brokerEnabledForSpotTime(selectedVenue?.isDelayedSpot ?? false, spotTimeSelected.value)
                : true)
    );
});

export const isVenueSelectAllCheckedAtom = atom<boolean>((get) => {
    const selectedVenueBrokers = get(selectedVenueBrokersAtom);
    const eligibleVenueBrokers = get(eligibleVenueBrokersAtom);

    // don't check select all if all venue brokers are disabled
    if (eligibleVenueBrokers.length === 0) return false;

    // if selectedVenueBrokers includes at least all eligible venue brokers
    const selectedVenueBrokerCodes = selectedVenueBrokers.map((b) => b.code);
    const eligibleVenueBrokerCodes = eligibleVenueBrokers.map((b) => b.code);

    return eligibleVenueBrokerCodes.every((code) => selectedVenueBrokerCodes.includes(code));
});

// both direct and venue broker atoms

export const currentBrokersAtom = atom((get) => {
    const directBrokers = get(directBrokersAtom);
    const currentVenueBrokers = get(currentVenueBrokersAtom);

    return directBrokers.concat(currentVenueBrokers);
});

export const pricingTypeEligibleBrokersAtom = atom((get) => {
    const brokers = get(currentBrokersAtom);
    const pricingProtocolChecked = get(pricingProtocolCheckedAtom);

    return (
        brokers?.filter(
            (b) =>
                orderUtils.isFullyAvailable(b) &&
                rfqUtils.brokerEnabledForPricingType(b.isSpreadFlowEnabled, pricingProtocolChecked)
        ) ?? []
    );
});

export const delayedSpotTimeEligibleBrokersAtom = atom((get) => {
    const currentBrokers = get(currentBrokersAtom);
    const spotTimeSelected = get(spotTimeSelectedAtom);

    return (
        currentBrokers.filter((b) => {
            return (
                orderUtils.isFullyAvailable(b) &&
                rfqUtils.brokerEnabledForSpotTime(b.isDelayedSpot, spotTimeSelected.value)
            );
        }) ?? []
    );
});

export const selectedBrokerNamesAtom = atom((get) => {
    const selectedDirectBrokers = get(selectedDirectBrokersAtom);
    const selectedVenueBrokers = get(selectedVenueBrokersAtom);
    const responseSelectedBrokers = get(rfqAtom).negotiationBrokerNames;
    const isRequest = isRFQRequest(get(basketIDAtom));
    const selected = isRequest
        ? [selectedDirectBrokers, selectedVenueBrokers].flat().map((b) => b.name)
        : responseSelectedBrokers;

    return selected.sort();
});

export const selectedBrokersCountAtom = atom((get) => {
    const selectedBrokerNames = get(selectedBrokerNamesAtom);
    return selectedBrokerNames.length;
});

export const selectedVenueSpotTimesAtom = atom((get) => {
    const selectedVenueName = get(selectedVenueAtom)?.name;
    const venueSpotTimes = get(venueSpotTimesAtom);
    return (selectedVenueName && venueSpotTimes[selectedVenueName]) || [];
});
