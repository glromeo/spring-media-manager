import { logClick, logError } from "@atw/toolkit/telemetry";
import _ from "lodash";
import {
    counterRFQPlacementQuoteMutation,
    executeRFQPlacementQuoteMutation,
    GraphQlCounterPlacementQuoteResponse,
    GraphQlCounterPlacementQuoteVariables,
    GraphQlExecutePlacementQuoteRequest,
    GraphQlExecutePlacementQuoteResponse,
    GraphQlExecutePlacementQuoteVariables
} from "../../api/types";
import { apiUtils } from "../../common/utils/";
import { RFQ, RFQQuote } from "../rfq/rfq";
import { TradeForm } from "../tradeForm";

/***
 * Used for countering off of an RFQ
 */
export async function counterPlacementQuoteFromRFQ(
    rfq: RFQ,
    rfqQuotes: RFQQuote[],
    tradeForm: TradeForm,
    user: string
): Promise<boolean> {
    const action = "counter placement quote";
    try {
        const counterPlacementQuoteVars = apiUtils.constructRfqActionRequest(
            rfqQuotes,
            rfq.selectedQuoteID!,
            tradeForm,
            user,
            true
        );
        const req = counterPlacementQuoteVars.request;
        console.log(`${action}: ${JSON.stringify(counterPlacementQuoteVars)}`);
        const { counterPlacementQuote }: GraphQlCounterPlacementQuoteResponse = await apiUtils.apiQuery<
            GraphQlCounterPlacementQuoteVariables,
            GraphQlCounterPlacementQuoteResponse
        >(counterRFQPlacementQuoteMutation, counterPlacementQuoteVars, {
            fixture: `placement_quote-counter/${rfq.orderNumber}`,
            telemetry: [counterPlacementQuoteFromRFQ.name, action]
        });
        if (!(counterPlacementQuote?.length > 0)) {
            return apiUtils.handleInvalidGQLRes({ id: rfq.orderNumber }, req, `Unable to ${action}`);
        }

        const ordNum = _.get(counterPlacementQuote[0], "order.ordNum");
        generateLogging(ordNum, req, "COUNTERED");
        return true;
    } catch (e: any) {
        logError(`Error to ${action}`, { message: e });
        throw apiUtils.apiError(`Error to ${action}`, e.message);
    }
}

/***
 * Used for hit/Lift off of an RFQ
 */
export async function acceptPlacementQuoteFromRFQ(
    rfq: RFQ,
    rfqQuotes: RFQQuote[],
    tradeForm: TradeForm,
    user: string
): Promise<boolean> {
    const action = "accept placement quote";
    try {
        const executePlacementQuoteVars = apiUtils.constructRfqActionRequest(
            rfqQuotes,
            rfq.selectedQuoteID!,
            tradeForm,
            user
        );
        const req = executePlacementQuoteVars.request;
        console.log(`${action}: ${JSON.stringify(executePlacementQuoteVars)}`);
        const { executePlacementQuote }: GraphQlExecutePlacementQuoteResponse = await apiUtils.apiQuery<
            GraphQlExecutePlacementQuoteVariables,
            GraphQlExecutePlacementQuoteResponse
        >(executeRFQPlacementQuoteMutation, executePlacementQuoteVars, {
            fixture: `placement_quote-accept/${rfq.orderNumber}`,
            telemetry: [acceptPlacementQuoteFromRFQ.name, action]
        });

        if (!(executePlacementQuote?.length > 0)) {
            return apiUtils.handleInvalidGQLRes({ id: rfq.orderNumber }, req, `Unable to ${action}`);
        }

        const ordNum = _.get(executePlacementQuote[0], "order.ordNum");
        generateLogging(ordNum, req, "ACCEPTED");
        return true;
    } catch (e: any) {
        logError(`Error to ${action}`, { message: e });
        throw apiUtils.apiError(`Error to ${action}`, e.message);
    }
}

export const CounteringApi = {
    acceptPlacementQuoteFromRFQ,
    counterPlacementQuoteFromRFQ
};

function generateLogging(ordNum: number, req: GraphQlExecutePlacementQuoteRequest, workflowType: string) {
    logClick("User " + workflowType.toLowerCase() + " placement quote", {
        "order#": ordNum,
        "placement#": req.placementNum,
        "quote#": req.externId,
        workflow: workflowType
    });
    console.log(
        workflowType.toLowerCase() +
            ` order#: ${ordNum}, placement#: ${req.placementNum},
            quote#: ${req.externId}`
    );
}
