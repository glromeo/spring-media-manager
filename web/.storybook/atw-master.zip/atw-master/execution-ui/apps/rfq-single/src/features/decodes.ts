import { getDecodes } from "@atw/toolkit/utility";
import { atom, useAtom, useSetAtom } from "jotai";
import { useEffect } from "react";
import { apiErrorSinkAtom } from "./alerts/alert";

export type DecodeRecord = Record<string, string>;

export const decodesAtom = atom<Record<string, DecodeRecord>>({});
export const decodesSink = atom(null, (get, set, name: string, values: DecodeRecord) => {
    set(decodesAtom, { ...get(decodesAtom), [name]: values });
});

export function useDecodes(...required: string[]) {
    const [decodes, setDecodes] = useAtom(decodesAtom);
    const notifyApiError = useSetAtom(apiErrorSinkAtom);

    useEffect(() => {
        getDecodes(required)
            .then((response) => {
                for (const name of required) {
                    const values = (decodes[name] = {} as DecodeRecord);
                    for (const { code, decode } of response[name].decodes) {
                        values[code] = decode;
                    }
                }
                setDecodes({ ...decodes });
            })
            .catch(notifyApiError);
    }, required);

    return decodes;
}
