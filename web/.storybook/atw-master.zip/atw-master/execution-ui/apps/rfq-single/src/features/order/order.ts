import { searchParam } from "@atw/toolkit/utility";
import { latestTokens } from "@atx/commons/atoms/tokens";
import { VENUE_DISPLAY_NAME } from "@atx/commons/decodes/venue";
import { atom, Atom } from "jotai";
import { rfqUtils } from "../../common/utils";
import { settingsUtils } from "../../common/utils/settingsUtils";
import { DetailsTableRowType } from "../../components/common/details-table";
import { atoms, pricingTypeAtom } from "../../models/atoms";
import { FieldType, KeyValueNumber, NUM_PLACE_HOLDER, PRICE, Side, SPREAD } from "../../models/common";
import { apiErrorSinkAtom } from "../alerts/alert";
import { Broker, brokerAtom, VenueEntity } from "../brokers/brokers";
import { rfqAtom } from "../rfq/rfq";
import { selectedVenueAtom, sizeAtom, venuesAtom } from "../rfqTradeForm/rfqTradeForm";
import { stepIndexAtom } from "../stepper/stepper";
import { getRFQOrderByOrderNumber, validateOrderAttributes } from "./orderApi";

export type OrderDetailSchema = {
    field: keyof OrderDetailsInfo;
    label: string;
    type: FieldType;
    visibleFor: PricingType[];
    classNameFor: (side: Side, value?: number) => string;
    atom: Atom<any>;
};

export type PricingType = typeof PRICE | typeof SPREAD;

export type OrderDetailsInfo = {
    side: Side;
    id: number;
    bond: string;
    currency: string;
    cusip: string;
    isin: string;
    origSize: number;
    unbookedAmt: number;
    limit: number;
    limitType: string;
    instructions: string;
    settleDate: string;
    tradingBmk: string;
    minTrdSize: number;
    price: number;
    orderLeaves: number;
    orderBmk: string;
};

export type VenueName = "DIRECT" | "TWRFQUS" | "SIMTWEB";
export type VenueSpotTimes = Partial<Record<VenueName, SpotTime[]>>;

export type SpotTime = { code: string; displayName: string };

export const orderIdAtom = atom<number>(Number(searchParam("orderNumber") ?? "0"));
export const orderCusipAtom = atom<string>(searchParam("cusip") || "-");
export const orderSideAtom = atom<Side>("NOTSET");
export const orderBondAtom = atom<string>("-");
export const orderCurrencyAtom = atom<string>("-");
export const orderIsinAtom = atom<string>("-");
export const orderOrigSizeAtom = atom<number>(NUM_PLACE_HOLDER);
export const orderUnbookedAmtAtom = atom<number>(NUM_PLACE_HOLDER);
export const orderLimitAtom = atom<number>(NUM_PLACE_HOLDER);
export const orderLimitTypeAtom = atom<string>("-");
export const orderInstructionsAtom = atom<string>("-");
export const orderSettleDateAtom = atom<string>("-");
export const orderTradingBmkAtom = atom<string>("-");
export const orderMinTrdSizeAtom = atom<number>(NUM_PLACE_HOLDER);
export const orderPriceAtom = atom<number>(NUM_PLACE_HOLDER);
export const orderBmkAtom = atom<string>("-");
export const orderBmkIdAtom = atom<string>("-");
export const venueSpotTimesAtom = atom<VenueSpotTimes>({});
export const orderLeavesAtom = atom<number>(NUM_PLACE_HOLDER);
export const orderHasValidDataAtom = atom<boolean>(false);
export const orderEligibleVenueNamesAtom = atom<string[]>([]);

export const DEFAULT_ORDER_DETAIL_SCHEMA: OrderDetailSchema[] = [
    {
        field: "side",
        label: "Side",
        type: "side",
        visibleFor: [PRICE, SPREAD],
        classNameFor: (side: Side) => {
            return side === "BUY" ? "detail-side-row-buy" : "detail-side-row-sell";
        },
        atom: orderSideAtom
    },
    {
        field: "id",
        label: "Ord Num",
        type: "text",
        visibleFor: [PRICE, SPREAD],
        classNameFor: () => {
            return "";
        },
        atom: orderIdAtom
    },
    {
        field: "bond",
        label: "Bond",
        type: "text",
        visibleFor: [PRICE, SPREAD],
        classNameFor: () => {
            return "";
        },
        atom: orderBondAtom
    },
    {
        field: "orderBmk",
        label: "Security Bmk",
        type: "security",
        visibleFor: [SPREAD],
        classNameFor: () => {
            return "";
        },
        atom: orderBmkAtom
    },
    {
        field: "currency",
        label: "CCY",
        type: "text",
        visibleFor: [PRICE, SPREAD],
        classNameFor: () => {
            return "";
        },
        atom: orderCurrencyAtom
    },
    {
        field: "cusip",
        label: "CUSIP",
        type: "text",
        visibleFor: [PRICE, SPREAD],
        classNameFor: () => {
            return "";
        },
        atom: orderCusipAtom
    },
    {
        field: "isin",
        label: "ISIN",
        type: "text",
        visibleFor: [PRICE, SPREAD],
        classNameFor: () => {
            return "";
        },
        atom: orderIsinAtom
    },
    {
        field: "origSize",
        label: "Original Size",
        type: "size",
        visibleFor: [PRICE, SPREAD],
        classNameFor: () => {
            return "";
        },
        atom: orderOrigSizeAtom
    },
    {
        field: "unbookedAmt",
        label: "Unbooked Amt",
        type: "size",
        visibleFor: [PRICE, SPREAD],
        classNameFor: () => {
            return "";
        },
        atom: orderUnbookedAmtAtom
    },
    {
        field: "orderLeaves",
        label: "Order Leaves",
        type: "size",
        visibleFor: [PRICE, SPREAD],
        classNameFor: () => {
            return "";
        },
        atom: orderLeavesAtom
    },
    {
        field: "limit",
        label: "Limit",
        type: "price",
        visibleFor: [PRICE, SPREAD],
        classNameFor: (side: Side, value?: number) => {
            if (value !== NUM_PLACE_HOLDER) {
                return side === "BUY" ? "detail-limit-row-buy" : "detail-limit-row-sell";
            } else {
                return "";
            }
        },
        atom: orderLimitAtom
    },
    {
        field: "limitType",
        label: "Limit Type",
        type: "text",
        visibleFor: [PRICE, SPREAD],
        classNameFor: () => {
            return "";
        },
        atom: orderLimitTypeAtom
    },
    {
        field: "instructions",
        label: "Instructions",
        type: "text",
        visibleFor: [PRICE, SPREAD],
        classNameFor: () => {
            return "";
        },
        atom: orderInstructionsAtom
    },
    {
        field: "tradingBmk",
        label: "Trading Bmk",
        type: "text",
        visibleFor: [PRICE, SPREAD],
        classNameFor: () => {
            return "";
        },
        atom: orderTradingBmkAtom
    }
];

export const orderSchemaAtom = atom<OrderDetailSchema[]>(DEFAULT_ORDER_DETAIL_SCHEMA);

export const orderDetailsInfoAtom = atom<DetailsTableRowType[]>((get) => {
    const schema = get(orderSchemaAtom);
    const pricingType = get(pricingTypeAtom);
    const side = get(orderSideAtom);
    let orderBmkTableRowProps: Partial<DetailsTableRowType> = {
        editable: false,
        dropdownOffsetWidth: 200
    };
    return schema
        .filter((orderDetail: OrderDetailSchema) => orderDetail.visibleFor.includes(pricingType))
        .map((orderDetail: OrderDetailSchema): DetailsTableRowType => {
            const orderDetailAtom = orderDetail.atom;
            let value;
            if (!orderDetailAtom) {
                console.error(
                    `Order sub-atom corresponding to order detail field ${orderDetail.field} is undefined. Defaulting order detail value to '-' for that field.`
                );
                value = "-";
            } else {
                value = get(orderDetailAtom);
            }
            return {
                label: orderDetail.label,
                value: value === undefined ? "-" : orderDetail.field === "side" ? `You ${value}` : value,
                type: orderDetail.type,
                ...(orderDetail.field === "orderBmk" && {
                    ...orderBmkTableRowProps
                }),
                className: orderDetail.classNameFor(side, value)
            };
        });
});

export const startRfqSink = atom(null, async (get, set, orderNumber: number, benchmark: any) => {
    const currentOrderHasValidData = get(orderHasValidDataAtom);
    const settings = get(atoms.settings);
    const stepIdx = get(stepIndexAtom);

    if (currentOrderHasValidData) {
        return;
    }

    try {
        await latestTokens;

        const order = await getRFQOrderByOrderNumber(orderNumber);

        validateOrderAttributes(order.orderLeaves, order.id, stepIdx);

        // set order field atoms
        set(orderSideAtom, order.side);
        set(orderIdAtom, order.id);
        set(orderBondAtom, order.bond);
        set(orderCurrencyAtom, order.currency);
        set(orderCusipAtom, order.cusip);
        set(orderIsinAtom, order.isin);
        set(orderOrigSizeAtom, order.origSize);
        set(orderUnbookedAmtAtom, order.unbookedAmt);
        set(orderLimitAtom, order.limit);
        set(orderLimitTypeAtom, order.limitType);
        set(orderInstructionsAtom, order.instructions);
        set(orderSettleDateAtom, order.settleDate);
        set(orderTradingBmkAtom, order.tradingBmk);
        set(orderMinTrdSizeAtom, order.minTrdSize);
        set(orderPriceAtom, NUM_PLACE_HOLDER);
        set(brokerAtom, order.broker);
        set(orderLeavesAtom, order.orderLeaves);
        set(orderEligibleVenueNamesAtom, order.eligibleVenueNames);
        set(venueSpotTimesAtom, order.venueSpotTimes);
        set(rfqAtom, {
            ...get(rfqAtom),
            benchmarkDesc: benchmark?.benchmarkDescription ?? "-"
        });
        set(sizeAtom, order.orderLeaves);
        // this is the benchmark & benchmark id that corresponds to the order security, not the user-selected benchmark
        set(orderBmkAtom, benchmark?.benchmarkDescription ?? "-");
        set(orderBmkIdAtom, benchmark?.benchmarkId ?? "-");

        // set rfq pricing type to order quality
        set(pricingTypeAtom, order.pricingType);

        const venueEntities: VenueEntity[] = [];
        const broker: Broker = order.broker;
        order.eligibleVenueNames.forEach((venueName) => {
            const matchingVenueBroker = broker.entity.find((e) => e.name === venueName);
            if (matchingVenueBroker && matchingVenueBroker.desk.length > 0) {
                const { name, code, isDelayedSpot, isCounteringEnabled, isSpreadFlowEnabled, isMifidTagEnabled } =
                    matchingVenueBroker;
                venueEntities.push({
                    name: name as VenueName,
                    code,
                    isDelayedSpot,
                    isCounteringEnabled,
                    isSpreadFlowEnabled,
                    isMifidTagEnabled,
                    displayName: VENUE_DISPLAY_NAME[matchingVenueBroker.name],
                    subBrokerID: matchingVenueBroker.desk[0].subBrokerID
                });
            }
        });

        if (venueEntities.length > 0) {
            // Auto-select the first venue
            set(selectedVenueAtom, venueEntities[0]);
            set(venuesAtom, venueEntities);
        }

        const multiDeskBrokers = rfqUtils.getBrokersWithMultipleDesks(broker.entity);
        const persistedDesks: KeyValueNumber = settingsUtils.getDeskSettings(settings);

        // iterate through each multi desk broker - and see if that broker is persisted ...if so verify that that desk still exists ...
        let needToUpdate = false;
        multiDeskBrokers.forEach((broker) => {
            if (persistedDesks[broker.name]) {
                const defaultDesk = persistedDesks[broker.name];
                const found = broker.desk.find((desk) => desk.subBrokerID === defaultDesk);
                if (found === undefined) {
                    // oops - this desk no longer exists ...remove from persistence
                    delete persistedDesks[broker.name];
                    needToUpdate = true;
                }
            }
        });

        if (needToUpdate) {
            const deskJSON = JSON.stringify(persistedDesks);
            set(atoms.settings, { ...settings, desks: deskJSON });
        }

        // set order valid data atom to true
        set(orderHasValidDataAtom, true);
    } catch (e) {
        set(apiErrorSinkAtom, e);
    }
});
