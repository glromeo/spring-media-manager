import { logError } from "@atw/toolkit/telemetry";
import { latestTokens } from "@atx/commons/atoms";
import { jotaiStore } from "@atx/toolkit/atoms";
import {
    GraphQLBrokerAllocation,
    GraphQLOrderDetails,
    GraphQLOrderSummary,
    GraphQLOrderSummaryResponse,
    GraphQLOrderSummaryVariables,
    GraphQLPorfolioAllocation,
    GraphQLSpotTimes,
    orderLeavesQuery,
    orderRFQQuery
} from "../../api/types";
import { TEXT } from "../../common/constants";
import { apiUtils, genericUtils, orderUtils } from "../../common/utils";
import { urlUserAtom } from "../../models/atoms";
import { NUM_PLACE_HOLDER, PRICE, SPREAD, Side } from "../../models/common";
import { Broker, BrokerEntity, BrokerRestriction, BrokerRestrictionAllocation } from "../brokers/brokers";
import { WORKFLOWS } from "../stepper/stepper";
import { PricingType, VenueName, VenueSpotTimes } from "./order";

const getPorfolioName = (orderDetails: GraphQLOrderDetails[], code: number) => {
    const porfolioInfo = orderDetails.find((details) => {
        return details.portfolio.portfolioCode === code;
    });
    if (porfolioInfo === undefined) {
        console.log("method: getPorfolioName, unable to return porfolioInfo against broker code: " + code);
        return "";
    }
    return porfolioInfo.portfolio.portfolioName;
};

const getPortfolioAllocations = (
    orderDetails: GraphQLOrderDetails[],
    brokerAllocation: GraphQLBrokerAllocation
): BrokerRestrictionAllocation[] => {
    const getPercent = (portfolioAllocation: GraphQLPorfolioAllocation) => {
        if (brokerAllocation.availablePlacementQuantity === 0) return 0;
        return (Math.abs(portfolioAllocation.quantityAvailable) / brokerAllocation.availablePlacementQuantity) * 100;
    };
    const allocations = brokerAllocation.portfolioAllocations.map((portfolioAllocation: GraphQLPorfolioAllocation) => {
        return {
            name: getPorfolioName(orderDetails, portfolioAllocation.portfolioCode),
            code: portfolioAllocation.portfolioCode,
            quantity: Math.abs(portfolioAllocation.quantityAvailable),
            percent: getPercent(portfolioAllocation),
            isRestricted: false
        } as BrokerRestrictionAllocation;
    });
    // this is a little tricky - we don't get what is restricted in allocations, we have to look at the order details ... and that will tell us
    // we then see - what is in order details that is not in allocations ... what's is the retrictions
    const restrictedAllocations: BrokerRestrictionAllocation[] = [];
    if (brokerAllocation.availablePlacementQuantity !== brokerAllocation.eligiblePlacementQuantity) {
        orderDetails.forEach((detail: GraphQLOrderDetails) => {
            const code = detail.portfolio.portfolioCode;
            if (!orderUtils.isAllocated(allocations, code)) {
                restrictedAllocations.push({
                    name: detail.portfolio.portfolioName,
                    code: detail.portfolio.portfolioCode,
                    quantity: Math.abs(detail.quantity),
                    percent: Math.abs((detail.quantity / brokerAllocation.availablePlacementQuantity) * 100),
                    isRestricted: true
                });
            }
        });
    }
    // this allows us to put the 'fully' restricted portfolios at start...
    allocations.unshift(...restrictedAllocations);
    return allocations;
};

const getBrokerRestrictions = (
    orderDetails: GraphQLOrderDetails[],
    brokerAllocation: GraphQLBrokerAllocation
): BrokerRestriction => {
    return {
        quantity: brokerAllocation.eligiblePlacementQuantity,
        percent: brokerAllocation.eligiblePlacementQuantityAsPct,
        allocation: getPortfolioAllocations(orderDetails, brokerAllocation)
    };
};
const isDelayedBroker = (delayedSpotEnabled: number[] | undefined, code: number): boolean =>
    Boolean(delayedSpotEnabled?.includes(code));

const isSpreadFlowEnabled = (spreadFlowEnabled: number[] | undefined, code: number): boolean =>
    Boolean(spreadFlowEnabled?.includes(code));

const isMifidTagEnabled = (fiOrderSummary: GraphQLOrderSummary, code: number): boolean =>
    Boolean(fiOrderSummary.mifidTagEnabled?.includes(code));

const isDirect = (directBrokers: number[], code: number) => (directBrokers ? directBrokers.includes(code) : false);

const getDefaultDesk = (brokerAllocation: GraphQLBrokerAllocation) => {
    if (brokerAllocation.broker.defaultDesk === undefined) return undefined;
    const found = brokerAllocation.broker.desks.findIndex(
        (desk) => desk.subBrokerID.toString() === brokerAllocation.broker.defaultDesk
    );
    return found === -1 ? undefined : found;
};

export const isDirectOnlyBrokerWithNoDesks = (
    directBrokers: number[],
    brokerAllocation: GraphQLBrokerAllocation,
    entity: BrokerEntity
) => {
    // check that the broker allocation has no desks, is a direct broker, and is not associated with any venues
    return (
        brokerAllocation.broker.desks.length === 0 && isDirect(directBrokers, entity.code) && entity.venues.length === 0
    );
};

const reconcileBrokerAllocations = async (fiOrderSummary: GraphQLOrderSummary): Promise<Broker> => {
    const inEligibleEntityList: number[] = [];
    const isWorkflowMifidEligible =
        (await latestTokens).AladdinTraderMIFIDEligible === "true" &&
        fiOrderSummary.userMifidEligibility === "true" &&
        fiOrderSummary.fiAsset?.isMiFID2Eligible;
    let brokerInfo: Broker = {
        rollup: "-",
        entity: []
    };
    let hasAtleastOneAllocation = false;
    let hasAtLeastOneRestrictedEntity = false;

    // map allocations in fiOrderSummary of type GraphQLBrokerAllocation to type BrokerEntity
    brokerInfo.entity = fiOrderSummary.brokerAllocations!.map((brokerAllocation): BrokerEntity => {
        let entity: BrokerEntity = {
            name: "-",
            code: NUM_PLACE_HOLDER,
            isDelayedSpot: false,
            desk: [],
            isCounteringEnabled: false,
            isSpreadFlowEnabled: false,
            isDirect: false,
            venues: []
        };
        // grab relevant broker allocation by entity code
        // set fields in broker entity based on entity code
        entity.code = brokerAllocation.broker.code;
        entity.isDelayedSpot = isDelayedBroker(fiOrderSummary.delayedSpotEnabled, entity.code);
        entity.isCounteringEnabled = orderUtils.isCounteringEnabled(entity.code, fiOrderSummary);
        entity.isSpreadFlowEnabled = isSpreadFlowEnabled(fiOrderSummary.spreadFlowEnabled, entity.code);
        entity.isDirect = isDirect(fiOrderSummary.directBrokers, entity.code);
        if (isWorkflowMifidEligible) entity.isMifidTagEnabled = isMifidTagEnabled(fiOrderSummary, entity.code);
        entity.venues = fiOrderSummary.venueBrokers
            .filter((venue: any) => venue.executingBrokerCodes.includes(entity.code))
            .map((venue) => venue.brokerCode);
        if (brokerAllocation !== undefined) {
            // check that the broker allocation is for either a direct broker or venue itself (ie. not a venue executing broker), and no desks
            if (isDirectOnlyBrokerWithNoDesks(fiOrderSummary.directBrokers, brokerAllocation, entity)) {
                // in this case we have to exclude this broker entity
                console.log(
                    `Broker ${brokerAllocation.broker.shortName} has no associated desks and is not a venue executing broker - will be excluded from eligible list`
                );
                inEligibleEntityList.push(entity.code);
            } else {
                entity.desk = brokerAllocation.broker.desks;
                entity.defaultDesk = getDefaultDesk(brokerAllocation);
                entity.restriction = getBrokerRestrictions(fiOrderSummary.orderDetails!, brokerAllocation);
                if (orderUtils.isRestrictedBrokerEntity(entity)) hasAtLeastOneRestrictedEntity = true;
            }
            entity.name = brokerAllocation.broker.shortName;
            hasAtleastOneAllocation = true;
        }
        return entity;
    });

    // if we haven't gotten any allocations - this is bad (i.e. could happen) - whereby for regional brokers ... let's say JPM/JPMSL - whereby only JPM has allocations
    // and JPMSL does not - this is ok - we do not display other broker then ...however if NONE have allocations (likely an error) - then we STOP
    if (!hasAtleastOneAllocation || brokerInfo.entity.length === 0) {
        throw {
            title: "Error Fetching Broker Info",
            customMessage: TEXT.NO_BROKERS_CERTIFIED
        };
    }

    // now check if we need to remove any brokers from list - (inEligible) - because no desks have been defined
    if (inEligibleEntityList.length > 0) {
        brokerInfo.entity = brokerInfo.entity.filter((entity) => {
            return !inEligibleEntityList.includes(entity.code);
        });
        console.log(
            `The following (${
                inEligibleEntityList.length
            }) brokers were excluded from eligible list: (${inEligibleEntityList.join(",")})`
        );
    }

    if (hasAtLeastOneRestrictedEntity) {
        // Sort by percent available, fully available first
        brokerInfo.entity.sort((a, b) => (a.restriction!.percent < b.restriction!.percent ? 1 : -1));
        console.log(
            "The following brokers have at least one restriction: " +
                brokerInfo.entity.map((b) => b.name + "-" + b.restriction?.percent)
        );
    }

    // do one last check - have we filtered everything out?
    if (brokerInfo.entity.length === 0) {
        throw new Error(TEXT.NO_BROKERS_CERTIFIED);
    }

    return brokerInfo;
};

export const normalizeSpotTimes = (spotTimes: GraphQLSpotTimes[], eligibleVenueNames: VenueName[]): VenueSpotTimes => {
    const normalizedSpotTimes: VenueSpotTimes = {};

    eligibleVenueNames.push("DIRECT");

    if (!spotTimes) {
        eligibleVenueNames.forEach((venueName) => {
            normalizedSpotTimes[venueName] = [{ code: "A", displayName: "Spot Now" }];
        });
        return normalizedSpotTimes;
    }

    spotTimes.forEach((spotTimeObj) => {
        const spotTimeKey = spotTimeObj.venue;

        if (eligibleVenueNames.includes(spotTimeKey)) {
            normalizedSpotTimes[spotTimeKey] =
                spotTimeObj.spotTime?.length > 0 ? spotTimeObj.spotTime : [{ code: "A", displayName: "Spot Now" }];
        }
    });

    return normalizedSpotTimes;
};

type OrderSummaryQueryVariant = {
    query: string;
    variables: GraphQLOrderSummaryVariables;
};

export function getRFQOrderSummaryQuery(ordNum: number): OrderSummaryQueryVariant {
    const user = jotaiStore.get(urlUserAtom);
    const orderSummaryVariables: GraphQLOrderSummaryVariables = {
        ordNum,
        user,
        rfqExecution: true
    };

    return {
        query: orderRFQQuery,
        variables: orderSummaryVariables
    };
}

export async function getRFQOrderByOrderNumber(orderNumber: number): Promise<{
    side: Side;
    id: number;
    bond: string;
    currency: string;
    cusip: string;
    isin: string;
    origSize: number;
    unbookedAmt: number;
    limit: number;
    limitType: string;
    instructions: string;
    settleDate: string;
    tradingBmk: string;
    minTrdSize: number;
    pricingType: PricingType;
    venueSpotTimes: VenueSpotTimes;
    broker: Broker;
    orderLeaves: number;
    eligibleVenueNames: VenueName[];
}> {
    try {
        const { query, variables } = getRFQOrderSummaryQuery(orderNumber);
        const { fiOrderSummary }: GraphQLOrderSummaryResponse = await apiUtils.apiQuery<
            GraphQLOrderSummaryVariables,
            GraphQLOrderSummaryResponse
        >(query, variables, {
            fixture: `orders/${orderNumber}`,
            telemetry: ["getOrderByOrderNumber", "get order by order number"]
        });
        if (!fiOrderSummary) throw new Error();

        const totalBooked = fiOrderSummary.orderDetails!.reduce(
            (total: number, { quantityBooked }: any) => total + Math.abs(quantityBooked),
            0
        );

        const eligibleVenueNames = fiOrderSummary.venueBrokers.map((broker) => broker.brokerName);

        return {
            side: fiOrderSummary.order!.effectiveTranType,
            id: orderNumber,
            bond: `${fiOrderSummary.fiAsset!.bAsset.ticker} ${
                fiOrderSummary.fiAsset!.couponValue === null ? "" : fiOrderSummary.fiAsset!.couponValue + "%"
            } ${
                fiOrderSummary.fiAsset!.bAsset.maturity === null
                    ? ""
                    : genericUtils.formatDate(fiOrderSummary.fiAsset!.bAsset.maturity, {
                          fullYear: false
                      })
            }`,
            currency: fiOrderSummary.order!.priceCurrency,
            cusip: fiOrderSummary.fiAsset!.bAsset.cusip,
            isin: fiOrderSummary.fiAsset!.isin,
            origSize: Math.abs(fiOrderSummary.order!.face),
            unbookedAmt: Math.abs(fiOrderSummary.order!.face) - totalBooked,
            limit: fiOrderSummary.order!.limitValue === null ? NUM_PLACE_HOLDER : fiOrderSummary.order!.limitValue,
            limitType: fiOrderSummary.order!.limitType === null ? "-" : fiOrderSummary.order!.limitType,
            instructions: fiOrderSummary.order!.updateInstr === null ? "-" : fiOrderSummary.order!.updateInstr,
            settleDate: `${
                fiOrderSummary.fiAsset!.defaultSettleDate === null
                    ? "-"
                    : genericUtils.formatDate(fiOrderSummary.fiAsset!.defaultSettleDate, {
                          fullYear: true
                      })
            }`,
            tradingBmk: fiOrderSummary.order!.tradingBenchmark === null ? "-" : fiOrderSummary.order!.tradingBenchmark,
            minTrdSize: fiOrderSummary.fiAsset!.bAsset.minTrdSize,
            pricingType: (fiOrderSummary.fiAsset!.bondQuality === "IG" ? SPREAD : PRICE) as PricingType,
            venueSpotTimes: normalizeSpotTimes(fiOrderSummary.spotTimes, eligibleVenueNames),
            broker: await reconcileBrokerAllocations(fiOrderSummary),
            orderLeaves: Math.abs(fiOrderSummary.order!.orderLeaves),
            eligibleVenueNames
        };
    } catch (e: any) {
        if (typeof e === "string") {
            throw e;
        } else {
            if (e.errors?.length > 0) {
                throw apiUtils.handleGQLErrorRes(e.errors, `Unable to fetch order: ${orderNumber}`);
            } else {
                const title = e.title || `Error fetching order: ${orderNumber}`;
                const message = e.customMessage || e.message || `Unable to fetch order: ${orderNumber}`;
                logError(title || "Error fetching Order", { message });
                throw apiUtils.apiError(title, message);
            }
        }
    }
}

export async function getOrderLeaves(orderNumber: number) {
    try {
        const { variables } = getRFQOrderSummaryQuery(orderNumber);
        const { fiOrderSummary }: GraphQLOrderSummaryResponse = await apiUtils.apiQuery<
            GraphQLOrderSummaryVariables,
            GraphQLOrderSummaryResponse
        >(orderLeavesQuery, variables, {
            fixture: `orderLeaves/${orderNumber}`,
            telemetry: [getOrderLeaves.name, "get order leaves"]
        });
        if (!fiOrderSummary?.order) {
            throw new Error(`getOrderLeaves fiOrderSummary result was undefined. fiOrderSummary: ${fiOrderSummary}.`);
        }
        return fiOrderSummary.order.orderLeaves;
    } catch (e: any) {
        if (e.message) {
            console.error(e.message);
        }
        if (e.errors) {
            e.errors.map((error: any) => console.log(error.message));
        }
        throw apiUtils.apiErrors([
            {
                name: `Error fetching Order to retrieve order leaves for order number: ${orderNumber}`,
                message: "An error occurred when querying for updated order leaves from latest order data.",
                type: "ERROR"
            }
        ]);
    }
}

export function validateOrderAttributes(orderLeaves: number, orderId: number, stepIdx: number) {
    // validate that certain fields exist - expand this list as needed
    try {
        const isRequestScreen = WORKFLOWS[stepIdx] === "Request";
        if (orderLeaves === 0 && isRequestScreen) {
            console.error("tried to open RFQ against an order without order leaves remaining");
            throw Error(TEXT.NO_ORDER_LEAVES);
        }
    } catch (e: any) {
        const title = `Invalid Order ${orderId}`;
        const message = e.message || e || `Unable to validate order: ${orderId}`;
        logError(title, { message });
        throw apiUtils.apiError(title, message);
    }
}
