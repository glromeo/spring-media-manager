// #################### UPDATE TRACKING ####################
// Last updated: 8/1/2023
// https://tst.blackrock.com/apps/decodes/edit/MODIFY_REASON
// #########################################################

import { atom } from "jotai";

export const MODIFY_REASON: Record<ModifyReasonCodes, string> = {
    PQL: "Pending Quote Lift",
    PQPN: "Pending Negotiation",
    RPPR: "Pass Request",
    RQC: "Quote Cover",
    RQCR: "Quote Counter",
    RQCS: "Quote Color Sent",
    RQCT: "Quote Cover Tied",
    RQDA: "Quote Done Away",
    RQDT: "Quote Color Sent DNT",
    RQPC: "Pending Counter",
    RQPN: "Pending Negotiation",
    RFQC: "RFQ Color",
    RQT: "Quote Tied",
    PN: "Pending New",
    N: "New",
    PF: "Fill",
    DFD: "Done For Day",
    C: "Cancelation",
    REP: "Replacement",
    PC: "Pending Cancel",
    S: "Stopped",
    REJ: "Rejected",
    PR: "Pending Replace",
    TCRT: "Trade Correct",
    TCNL: "Trade Cancel",
    OS: "Status",
    OCR: "Cancel Reject",
    NOS: "New Order Single",
    CR: "Cancel Request",
    RR: "Cancel Replace Request",
    MF: "Manual Fill",
    MA: "Manual Activation",
    MC: "Manual Cancelation",
    MFC: "Manual Fill Cancelation",
    SF: "Sending Failure",
    MPC: "Manual Placement Change",
    F: "Fill",
    FMP: "Force Manual",
    TB: "Post Trade",
    PE: "Placement Expired",
    DFDC: "Done For Day",
    PT: "Pending Trade",
    TPF: "Trade Posting Failed",
    MCAF: "Manual Fill Cancelation",
    MERF: "Merged",
    MERT: "Merge Result",
    NOL: "New Order List",
    NOLK: "New Order Linked Order",
    LOCR: "Linked Order Cancel Request",
    LORR: "Linked Order Replace Request",
    Q: "Quote",
    QS: "Quote Requested",
    QSR: "Spread Received",
    QPR: "Price Received",
    QSS: "Spot Requested",
    QWC: "Win Confirmed",
    QL: "Quote Lost",
    QD: "Quote Declined",
    QYR: "Yield Received",
    RB: "Undo",
    QC: "Quote Committed",
    MRKC: "Marked Completed",
    MCAP: "Manual Fill and Placement Cancelation",
    MVC: "Manual Validation Complete",
    VC: "Validation Complete",
    VP: "Validation Pending",
    PTC: "Pending Trade Correct",
    TCB: "Trade Corrected",
    TCF: "Trade Correction Failed",
    RQQP: "Quote Passed",
    RQQA: "Quoted",
    RQQR: "Quote Rejected",
    RQQC: "Quote Cancelled",
    RQLP: "Lift Requested",
    RQLR: "Lift Rejected",
    RQLA: "Lift Accepted",
    RQQE: "Quote Expired",
    QCR: "Quote Confirmed",
    ARR: "Auto Replace Request",
    QSUB: "Quote Subjected",
    QRR: "Quote Replace Request"
};

type ModifyReasonCodes =
    | "PQL"
    | "PQPN"
    | "RPPR"
    | "RQC"
    | "RQCR"
    | "RQCS"
    | "RQCT"
    | "RQDA"
    | "RQDT"
    | "RQPC"
    | "RQPN"
    | "RFQC"
    | "RQT"
    | "PN"
    | "N"
    | "PF"
    | "DFD"
    | "C"
    | "REP"
    | "PC"
    | "S"
    | "REJ"
    | "PR"
    | "TCRT"
    | "TCNL"
    | "OS"
    | "OCR"
    | "NOS"
    | "CR"
    | "RR"
    | "MF"
    | "MA"
    | "MC"
    | "MFC"
    | "SF"
    | "MPC"
    | "F"
    | "FMP"
    | "TB"
    | "PE"
    | "DFDC"
    | "PT"
    | "TPF"
    | "MCAF"
    | "MERF"
    | "MERT"
    | "NOL"
    | "NOLK"
    | "LOCR"
    | "LORR"
    | "Q"
    | "QS"
    | "QSR"
    | "QPR"
    | "QSS"
    | "QWC"
    | "QL"
    | "QD"
    | "QYR"
    | "RB"
    | "QC"
    | "MRKC"
    | "MCAP"
    | "MVC"
    | "VC"
    | "VP"
    | "PTC"
    | "TCB"
    | "TCF"
    | "RQQP"
    | "RQQA"
    | "RQQR"
    | "RQQC"
    | "RQLP"
    | "RQLR"
    | "RQLA"
    | "RQQE"
    | "QCR"
    | "ARR"
    | "QSUB"
    | "QRR";

export const modifyReasonAtom = atom(MODIFY_REASON);
