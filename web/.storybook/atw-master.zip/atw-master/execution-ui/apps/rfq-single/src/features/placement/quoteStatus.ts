// #################### UPDATE TRACKING ####################
// Last updated: 8/1/2023
// https://tst.blackrock.com/apps/decodes/edit/QUOTE_STATUS
// #########################################################

export const QUOTE_STATUS: Record<QuoteStatusCodes, string> = {
    A: "A",
    B: "B",
    C: "C",
    D: "D",
    E: "E",
    J: "J",
    N: "N",
    O: "O",
    P: "P",
    S: "S",
    T: "T",
    U: "U",
    W: "W",
    X: "X",
    Y: "Y",
    Z: "Z"
};

export type QuoteStatusCodes =
    | "A"
    | "B"
    | "C"
    | "D"
    | "E"
    | "J"
    | "N"
    | "O"
    | "P"
    | "S"
    | "T"
    | "U"
    | "W"
    | "X"
    | "Y"
    | "Z";
