import { queryBenchmarkDescriptor } from "@atx/commons/benchmark/useBenchmark";
import { atom } from "jotai";
import { basketIDAtom, pricingTypeAtom } from "../../models/atoms";
import { quoteUtils, rfqUtils } from "../../common/utils";
import { NUM_PLACE_HOLDER, Side } from "../../models/common";
import { alertStatusAtom, apiErrorSinkAtom } from "../alerts/alert";
import { brokerAtom, BrokerEntity } from "../brokers/brokers";
import { orderIdAtom, orderLeavesAtom, orderSideAtom, venueSpotTimesAtom, PricingType } from "../order/order";
import { PLACEMENT_TYPE } from "../placement/placement";
import { getRFQQuotesForBasket } from "./rfqApi";
import { DateTime } from "luxon";
import { StepperStatus, StepperSubStatus, statusAtom } from "../stepper/stepper";
import { rfqTradeFormAtom, selectedVenueAtom } from "../rfqTradeForm/rfqTradeForm";
import { tradeFormAtom } from "../tradeForm";
import { isRFQRequest } from "../../common/utils/rfqUtils";

export type DeskSelectionType = "open" | "close" | "cancel";

export type RFQ = {
    orderNumber: number;
    selectedQuoteID?: string;
    initialRequestSize: number;
    basketID: string;
    negotiationBrokerNames: string[];
    dueIn: number | null;
    dueInProtocol: "ASAP" | "BIN" | "NOT_SET";
    spreadIndex?: string;
    benchmarkDesc?: string;
    pricingType: "PRICE" | "SPREAD" | "NOT_SET";
    side: Side;
    hasValidData: boolean;
    triggerDeskSelection: DeskSelectionType;
    triggeredDeskBrokerSelection?: BrokerEntity[];
};

export const DEFAULT_RFQ: RFQ = {
    orderNumber: NUM_PLACE_HOLDER,
    initialRequestSize: NUM_PLACE_HOLDER,
    basketID: "-",
    negotiationBrokerNames: [],
    dueIn: null,
    dueInProtocol: "NOT_SET",
    spreadIndex: "-",
    benchmarkDesc: "-",
    pricingType: "NOT_SET",
    hasValidData: false,
    triggerDeskSelection: "close",
    side: "NOTSET"
};

export type RFQInfo = {
    rfq: RFQ;
};

export type UpdateRFQActionPayload = { error: { workflow: "HITLIFT" | "COUNTER"; placementNum: number } };

export const REQUEST_SENT = "Request Sent";
export const BROKER_RESPONDED = "Broker Responded";
export const TRADE_PENDING = "Trade Pending";
export const TRADE_CONFIRMED = "Trade Confirmed";
export const TRADED = "Traded";
export const DECLINED = "Declined";
export const EXPIRED = "Expired";
export const QUOTE_SUBJECT = "Quote Subject";
export const PENDING_CANCEL = "Pending Cancel";
export const CANCELED = "Canceled";
export const UNKNOWN = "Unknown";
export const ERROR = "Error";

export type RFQStatus =
    | typeof REQUEST_SENT
    | typeof BROKER_RESPONDED
    | typeof TRADE_PENDING
    | typeof TRADE_CONFIRMED
    | typeof TRADED
    | typeof DECLINED
    | typeof EXPIRED
    | typeof QUOTE_SUBJECT
    | typeof PENDING_CANCEL
    | typeof CANCELED
    | typeof ERROR
    | typeof UNKNOWN;

export const COMMITTED_PLACEMENT_TYPES = [PLACEMENT_TYPE.RFQW, PLACEMENT_TYPE.LPC];
export const VENUE_PLACEMENT_TYPES = [PLACEMENT_TYPE.LP, PLACEMENT_TYPE.LPC];
export const DIRECT_PLACEMENT_TYPES = [PLACEMENT_TYPE.RFQ, PLACEMENT_TYPE.RFQW];

export type RFQQuote = {
    broker: string;
    deskKey: string;
    size: number;
    source: string;
    goodFor: number | "-";
    expired: boolean;
    id: string;
    pricingType: PricingType;
    pricingValue: number | "-";
    counterValue?: number;
    modifiedTime: number;
    rfqStatus: RFQStatus;
    spotTime: string;
    placementNum: number;
    modifyReason: string;
};

export const rfqAtom = atom(DEFAULT_RFQ);
export const rfqQuotesAtom = atom<RFQQuote[]>([]);
export const rfqDueInEnabledAtom = atom<boolean>((get) => {
    const rfqQuotes = get(rfqQuotesAtom);
    const dueInTimedOut = get(rfqDueInTimedOutAtom);
    return rfqUtils.dueInEnabled(rfqQuotes) && !dueInTimedOut;
});
export const rfqDueInAtom = atom((get) => {
    const { dueIn } = get(rfqAtom);
    return dueIn ? DateTime.fromMillis(dueIn, { zone: "America/New_York" }) : null;
});
export const rfqCancelEnabledAtom = atom<boolean>((get) => {
    const rfqQuotes = get(rfqQuotesAtom);
    return rfqUtils.cancelButtonEnabled(rfqQuotes);
});
export const rfqDueInTimedOutAtom = atom<boolean>(false);

export const setRFQSelectedQuoteIDSink = atom(null, (get, set, selectedQuoteID: string) => {
    console.log(`setRFQSelectedQuoteIDSink updating selected quote ID: ${selectedQuoteID}`);
    set(rfqAtom, { ...get(rfqAtom), selectedQuoteID: selectedQuoteID });
});

export const triggerDeskSelectionSink = atom(
    null,
    (get, set, selection: DeskSelectionType, brokers?: BrokerEntity[]) => {
        console.log(
            `triggerDeskSelectionSink updating triggerDeskSelection: ${selection}. Updating triggeredDeskBrokerSelection: ${JSON.stringify(
                brokers
            )}`
        );
        set(rfqAtom, {
            ...get(rfqAtom),
            triggerDeskSelection: selection,
            triggeredDeskBrokerSelection: brokers
        });
    }
);

const setRFQSink = atom(null, (get, set, value: RFQ) => {
    console.log(`setRFQSink updating RFQ: ${JSON.stringify(value)}`);
    return set(rfqAtom, { ...get(rfqAtom), ...value });
});

export const fetchBasketAtom = atom(null, async (get, set, payload?: UpdateRFQActionPayload) => {
    try {
        const basketID = get(basketIDAtom);
        const hasValidData = get(rfqAtom).hasValidData;
        const side = get(orderSideAtom);
        const orderId = get(orderIdAtom);
        const broker = get(brokerAtom);
        const venueSpotTimes = get(venueSpotTimesAtom);
        const selectedVenue = get(selectedVenueAtom);
        console.log("Fetching basket with basket ID: " + basketID);
        if (basketID !== "-") {
            const { rfqQuotes, rfq } = await getRFQQuotesForBasket(
                basketID,
                side,
                orderId,
                broker,
                venueSpotTimes,
                selectedVenue,
            );

            // if UPDATE_RFQ has a error payload telling UI of a specific quote cancelation
            if (payload?.error?.placementNum && payload?.error?.workflow) {
                const traderActionedToCancelledQuote = rfqQuotes.find(
                    (quote) => quote.placementNum === payload.error.placementNum
                );
                if (traderActionedToCancelledQuote) {
                    // set selected quote and pop up rejected
                    set(setRFQSelectedQuoteIDSink, traderActionedToCancelledQuote.id);
                    set(statusAtom, {
                        status: StepperStatus.STEPS,
                        subStatus: StepperSubStatus[`${payload.error.workflow}_REJECTED`]
                    });
                }
            }

            set(rfqQuotesAtom, rfqQuotes);
            if (!hasValidData) {
                // Initialize the RFQ data with the static variables
                rfq.hasValidData = true;
                set(setRFQSink, rfq);
                set(pricingTypeAtom, rfq.pricingType === "SPREAD" ? "SPREAD" : "PRICE"); // rfq.pricingType can also be NOT_SET
                set(benchmarkDescOrSpreadIdxSink, rfq.spreadIndex);
                set(basketIDAtom, rfq.basketID);
            }

            if (quoteUtils.isExpired(rfq.dueIn)) {
                set(rfqDueInTimedOutAtom, true);
            }
        }
        return [];
    } catch (e) {
        set(apiErrorSinkAtom, e);
    }
});

export const benchmarkDescOrSpreadIdxSink = atom(null, async (get, set, spreadIndex?: string) => {
    let benchmarkDesc = "-";
    if (spreadIndex && spreadIndex !== "-") {
        benchmarkDesc = (await queryBenchmarkDescriptor(spreadIndex)) ?? "";
    }
    set(rfqAtom, { ...get(rfqAtom), benchmarkDesc });
});

export const selectedRfqQuoteAtom = atom<RFQQuote | undefined>((get) => {
    const rfqQuotes = get(rfqQuotesAtom);
    const selectedQuoteID = get(selectedRfqQuoteIDAtom);
    return rfqQuotes.find((quote) => quote.id === selectedQuoteID);
});

export const selectedRfqQuoteIDAtom = atom<string | undefined>((get) => {
    return get(rfqAtom).selectedQuoteID;
});

/// Returns true if the selected RFQ quote can no longer be actioned on
export const selectedRfqQuoteDisabledAtom = atom<boolean>((get) => {
    const selectedRfqQuote = get(selectedRfqQuoteAtom);
    const hasHardWarning = get(alertStatusAtom) === "ERROR";
    const orderLeaves = get(orderLeavesAtom);
    const basketID = get(basketIDAtom);
    const rfqTradeFormSize = get(rfqTradeFormAtom).size;
    const tradeFormSize = get(tradeFormAtom).size;
    const outOfRangeSize = () => {
        const isRequestScreen = isRFQRequest(basketID);
        let maxSize = orderLeaves;
        let minSize = 1;
        let size = isRequestScreen ? Math.abs(rfqTradeFormSize) : Math.abs(tradeFormSize!);
        return size > maxSize || size < minSize;
    };

    return hasHardWarning || selectedRfqQuote?.expired || outOfRangeSize();
});

// Update a given quote and force an update of rfqQuotes
// todo-refactor - consider whether each quote should be its own atom instead?
export const updateQuoteAtom = atom(null, async (get, set, updatedQuote: RFQQuote) => {
    const rfqQuotes = get(rfqQuotesAtom);
    const index = rfqQuotes.findIndex((q) => q.id === updatedQuote.id);
    if (index > -1) {
        rfqQuotes[index] = updatedQuote;
        set(rfqQuotesAtom, [...rfqQuotes]);
    }
});
