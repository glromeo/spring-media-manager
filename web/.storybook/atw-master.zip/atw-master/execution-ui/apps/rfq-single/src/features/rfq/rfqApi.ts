import { logClick, logError } from "@atw/toolkit/telemetry";
import { benchmarkApi } from "@atx/commons/benchmark/useBenchmark";
import _ from "lodash";
import {
    basketQuery,
    cancelRFQPlacementsMutation,
    GraphQLBasketSummaryResponse,
    GraphQLBasketSummaryVariables,
    GraphQLBrokerEntityDesks,
    GraphQlCancelRFQPlacementsResponse,
    GraphQlCancelRFQPlacementsVariables,
    GraphQLPlacement,
    GraphQLPlacementCreationResponse,
    GraphQLPlacementCreationVariables,
    GraphQLQuote,
    requestPlacementQuoteMutation
} from "../../api/types";
import { urlUserAtom } from "../../models/atoms";
import { apiUtils, genericUtils, quoteUtils, tradeFormUtils, windowUtils } from "../../common/utils";
import { Side } from "../../models/common";
import { Broker, BrokerEntity, DIRECT, VenueEntity } from "../brokers/brokers";
import { VenueSpotTimes } from "../order/order";
import { RfqTradeForm } from "../rfqTradeForm/rfqTradeForm";
import { COMMITTED_PLACEMENT_TYPES, DIRECT_PLACEMENT_TYPES, RFQ, RFQQuote, VENUE_PLACEMENT_TYPES } from "./rfq";
import { latestTokens } from "@atx/commons/atoms";
import { jotaiStore } from "@atx/toolkit/atoms";
import { PLACEMENT_STATUS, PLACEMENT_TYPE } from "../placement/placement";
import { QUOTE_STATUS } from "../placement/quoteStatus";
import { MODIFY_REASON } from "../placement/modifyReason";
import { VENUE_DISPLAY_NAME } from "@atx/commons/decodes/venue";

//refactor-todo: write more tests for this function including the rfqStatus data normalization
export async function getRFQQuotesForBasket(
    basketId: string,
    orderSide: Side,
    orderId: number,
    broker: Broker,
    venueSpotTimes: VenueSpotTimes,
    selectedVenue: VenueEntity | undefined
): Promise<{ rfqQuotes: RFQQuote[]; rfq: RFQ }> {
    const action = "request for basket summary";
    try {
        const user = jotaiStore.get(urlUserAtom);
        const basketSummaryVariables = { basketId, user };
        console.log(`Sending ${action}: ${JSON.stringify(basketSummaryVariables)}`);
        const {
            fiBasketSummary: { placements }
        }: GraphQLBasketSummaryResponse = await apiUtils.apiQuery<
            GraphQLBasketSummaryVariables,
            GraphQLBasketSummaryResponse
        >(basketQuery, basketSummaryVariables, {
            fixture: `basket-summary/${basketId}`,
            telemetry: [getRFQQuotesForBasket.name, action]
        });
        if (!placements?.length) {
            throw new Error(`Unable to ${action} : ` + basketId);
        }

        generateLogging(placements[0].ordNum, basketSummaryVariables.basketId, "RFQ", `User sent ${action}`);
        // We don't get full desk information from fiBasketSummary so (for now) we construct it manually
        // We can remove this once the backend enhances the fiBasketSummary endpoint
        const desks = broker.entity.map((b: BrokerEntity) => {
            return {
                code: b.code,
                desks: b.desk
            } as GraphQLBrokerEntityDesks;
        });

        const tokens = await latestTokens;

        const rfqQuotes: RFQQuote[] = [];
        const filteredPlacements = getFilteredPlacements(placements);
        const actionedBrokerName = filteredPlacements.find((p) => COMMITTED_PLACEMENT_TYPES.includes(p.type))?.broker
            .shortName;
        const directBrokerNames = filteredPlacements
            .filter((p) => DIRECT_PLACEMENT_TYPES.includes(p.type))
            ?.map((p) => p.broker.shortName);

        filteredPlacements.forEach((placement: GraphQLPlacement) => {
            // Extract valid quotes for the given order side
            let quotes = quoteUtils.getValidRFQPlacementQuotes(placement, orderSide);
            const isUncommittedVenuePlacement =
                VENUE_PLACEMENT_TYPES.includes(placement.type) && !COMMITTED_PLACEMENT_TYPES.includes(placement.type);
            if (isUncommittedVenuePlacement) {
                // Uncommitted venue placement - take all uncommitted or active venue quotes (not direct, not actioned)
                quotes = quotes.filter(
                    (q) =>
                        !directBrokerNames.includes(q.counterparty.shortName) &&
                        (q.counterparty.shortName !== actionedBrokerName || q.quoteStatus !== QUOTE_STATUS.T)
                );
            } else {
                // Committed direct, commited venue, or uncommitted direct placement - take the quote that matches the placement
                quotes = quotes.filter((q) => q.counterparty.shortName === placement.broker.shortName);
            }

            // Assume backend returned 3 placements:
            // (1) LP placement with quotes: [committed, direct1, venue1, venue2]
            // (2) LPC or RFQW placement with quotes: [committed, direct1, venue1, venue2]
            // (3) RFQ placement with quotes: [direct1]
            // The above code will return four quotes: [committed (from LPC or RFQW), direct1 (from RFQ), venue1 (from LP), venue2 (from LP)]
            const spotTimeCode = placement.placementGenFields?.find((key) => key.key === "spotType")?.value;
            const source = VENUE_PLACEMENT_TYPES.includes(placement.type) ? selectedVenue?.name : DIRECT;
            quotes.forEach((quote: GraphQLQuote) => {
                // Enrich RFQQuote with relevant placement data
                const rfqStatus = quoteUtils.getRfqStatus(placement, quote, tokens);
                const priceOrSpread: number | null = placement.limitType === "Price" ? quote.price : quote.spread;
                rfqQuotes.push({
                    broker: quote.counterparty.shortName,
                    deskKey: generateDeskKey(placement, desks),
                    size: quote.quantity,
                    source: source && VENUE_DISPLAY_NAME[source],
                    goodFor: quote.expTime,
                    expired: quoteUtils.isExpired(quote.expTime, rfqStatus),
                    id: quote.quoteID,
                    pricingType: placement.limitType === "Price" ? "PRICE" : "SPREAD",
                    pricingValue: priceOrSpread || "-",
                    counterValue: placement.limitValue || undefined,
                    modifiedTime: placement.modifiedTime,
                    rfqStatus,
                    spotTime:
                        (placement.limitType === "Spread" &&
                            source &&
                            venueSpotTimes[source]?.find((spotTime) => spotTime.code == spotTimeCode)?.displayName) ||
                        "-",
                    placementNum: placement.placementNum,
                    modifyReason: placement.modifyReason
                });
            });
        });

        const rfq: RFQ = {
            orderNumber: orderId,
            initialRequestSize: placements[0].quantity,
            basketID: basketId,
            negotiationBrokerNames: rfqQuotes.map((q) => q.broker),
            dueIn: placements[0].dueInTime,
            dueInProtocol: placements[0].inquiryType === 1 ? "ASAP" : "BIN",
            spreadIndex: placements[0].spreadIndex,
            pricingType: placements[0].limitType === "Price" ? "PRICE" : "SPREAD",
            hasValidData: true,
            triggerDeskSelection: "close",
            side: orderSide
        };

        return { rfqQuotes, rfq };
    } catch (e: any) {
        const message = `Error in ${action}`;
        throw generateError(e, message, basketId);
    }
}

// We filter out any placements that are no longer relevant to that transaction - essentially, any LPC placements in C/C
// if we are in a venue recounter scenario
function getFilteredPlacements(placements: GraphQLPlacement[]): GraphQLPlacement[] {
    let numLPC = 0; // number of LPC placements
    let numLP_AN = 0; // number of LP placements in A/N
    let numLPC_CC = 0; // number of LPC placements in C/C

    placements.forEach((p) => {
        if (p.type === PLACEMENT_TYPE.LPC) {
            numLPC++;
            if (p.status === PLACEMENT_STATUS.C && p.modifyReason === MODIFY_REASON.C) {
                numLPC_CC++;
            }
        } else if (
            p.type === PLACEMENT_TYPE.LP &&
            p.status === PLACEMENT_STATUS.A &&
            p.modifyReason === MODIFY_REASON.N
        ) {
            numLP_AN++;
        }
    });

    // have at least 1 LP in A/N and at least 1 LPC in C/C (initial recounter) or multiple LPC placements (broker responds to recounter)
    const inRecounterScenario = (numLP_AN > 0 && numLPC_CC > 0) || numLPC > 1;

    // If we have placements, we filter the commmitted placement (LPC) in Cancelled, Cancelled.
    return inRecounterScenario
        ? placements.filter(
              (p) =>
                  !(
                      p.type === PLACEMENT_TYPE.LPC &&
                      p.modifyReason === MODIFY_REASON.C &&
                      p.status === PLACEMENT_STATUS.C
                  )
          )
        : placements;
}

export async function sendRfqRequest(
    ordNum: number,
    rfqTradeForm: RfqTradeForm,
    side: Side,
    user: string,
    spotType?: string
): Promise<string> {
    const action = "request rfq placement";
    try {
        const placementCreationVariables = apiUtils.constructRfqRequest(ordNum, rfqTradeForm, user, spotType);
        if (
            rfqTradeForm.pricingProtocolChecked === "Spread" &&
            placementCreationVariables.request.spreadIndex &&
            rfqTradeForm.spotTimeSelected.value === "A"
        ) {
            const twebPrice = await benchmarkApi.getTWEBPrice(placementCreationVariables.request.spreadIndex, side);
            if (genericUtils.isValidNumber(twebPrice)) {
                placementCreationVariables.request.benchPrice = twebPrice!;
            }
        }
        console.log(`Sending ${action}: ${JSON.stringify(placementCreationVariables)}`);
        const { requestPlacementQuote }: GraphQLPlacementCreationResponse = await apiUtils.apiQuery<
            GraphQLPlacementCreationVariables,
            GraphQLPlacementCreationResponse
        >(requestPlacementQuoteMutation, placementCreationVariables, {
            fixture: `placement-creation/${ordNum}`,
            telemetry: [sendRfqRequest.name, action]
        });
        if (!requestPlacementQuote?.length) {
            throw new Error(`Unable to ${action} on order#: ${ordNum}`);
        }

        if (!requestPlacementQuote[0].placements?.length) {
            throw new Error(`Unable to ${action} on order#: ${ordNum}, no placements returned`);
        }

        const { placementNum, basketID } = apiUtils.getMostRecentPlacementNumber(requestPlacementQuote[0].placements);
        if (!basketID) {
            logError(`Error in ${action}: invalid or null basket ID`, {
                "order#": ordNum
            });
            throw new Error(`New ${action} returned invalid or null basket ID for order#: ` + ordNum);
        }

        windowUtils.registerRFQForUrl(ordNum, basketID);

        generateLogging(ordNum, basketID, "RFQ", `User sent ${action}`);
        console.log(`placed ${action} on order#: ${ordNum}, basket ID: ${basketID}, placement num: ${placementNum}`);
        return basketID;
    } catch (e: any) {
        const message = `Error in ${action}`;
        throw generateError(e, message, ordNum);
    }
}

export async function cancelRFQPlacements(rfq: RFQ, rfqQuotes: RFQQuote[]): Promise<boolean> {
    const placementNumList = _.uniq(rfqQuotes.map((q) => q.placementNum));
    const basketID = rfq.basketID;
    const orderNum = rfq.orderNumber;
    const user = jotaiStore.get(urlUserAtom);
    const cancelRFQPlacementsVariables = { placementNumList, user };
    const action = "cancel RFQ placements";
    try {
        console.log(`Sending ${action}`);

        const { cancelRFQPlacements: cancelRfqPlacementsRes }: GraphQlCancelRFQPlacementsResponse =
            await apiUtils.apiQuery<GraphQlCancelRFQPlacementsVariables, GraphQlCancelRFQPlacementsResponse>(
                cancelRFQPlacementsMutation,
                cancelRFQPlacementsVariables,
                {
                    fixture: `cancelRFQPlacements/${rfq.basketID}`,
                    telemetry: [cancelRFQPlacements.name, action]
                }
            );

        if (!cancelRfqPlacementsRes?.length) {
            throw new Error(`Unable to ${action} for order# : ` + orderNum);
        }

        generateLogging(orderNum, basketID, "RFQ", `User sent ${action}`);
        console.log(`placed ${action} with order# : ${orderNum}`);
        return true;
    } catch (e: any) {
        const message = `Error in ${action}`;
        throw generateError(e, message, basketID);
    }
}

// Match the placement desk subBrokerID against the list of desks returned from fiOrderSummary
function generateDeskKey(placement: GraphQLPlacement, desks: GraphQLBrokerEntityDesks[]): string {
    // Search for a desk from fiOrderSummary with the same broker code as the placement broker
    const matchingDesk = (placement.desk = desks
        .find((d) => d.code === placement.broker.code)
        ?.desks?.find((d) => d.subBrokerID === placement.desk?.subBrokerID)); // For venue and direct, just take the placement desk
    return matchingDesk ? tradeFormUtils.getDeskKey(matchingDesk) : "-";
}

export function generateError(e: any, message: string, id: number | string) {
    logError(message, { message: e });
    if (e.errors?.length > 0) {
        return apiUtils.handleGQLErrorRes(e.errors, `${message} on id : ${id}`);
    } else {
        return apiUtils.apiError(message, e.message);
    }
}

function generateLogging(ordNum: number, basketID: string, workflowType: string, message: string) {
    logClick(message, {
        "basket#": basketID,
        "order#": ordNum,
        workflow: workflowType
    });
}
