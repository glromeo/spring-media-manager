import { atom, PrimitiveAtom } from "jotai";
import _ from "lodash";
import { genericUtils } from "../../common/utils";
import { FieldType, KeyValueNumber, NUM_PLACE_HOLDER } from "../../models/common";
import { BrokerEntity, DIRECT, VenueEntity } from "../brokers/brokers";
import { SpotTime, venueSpotTimesAtom } from "../order/order";

export type RfqTradeFormSchema = {
    field: keyof RfqTradeForm;
    label: string;
    minValue?: string;
    type: FieldType;
    visibleFor: (tradeForm?: RfqTradeFormInfo) => boolean;
    disabledFor: (tradeForm: RfqTradeFormInfo) => boolean;
};

export type PricingProtocol = "Price" | "Spread" | "-";
export type DueProtocol = "Due In" | "Due At" | "-";
export type SelectData = { displayValue: string; value: string };

export type RfqTradeFormTimerData = "Bin" | "ASAP";

export type RfqTradeFormInfo = {
    tradeForm: RfqTradeForm;
    schema: RfqTradeFormSchema[];
};

export const DEFAULT_RFQ_TRADEFORM_SCHEMA: RfqTradeFormSchema[] = [
    {
        field: "size",
        label: "Size",
        type: "size",
        visibleFor: () => true,
        disabledFor: () => false
    },
    {
        field: "pricingProtocol",
        label: "Pricing Protocol",
        type: "radio",
        visibleFor: () => true,
        disabledFor: () => false
    },
    {
        field: "benchmark",
        label: "Benchmark",
        type: "securityLookup",
        visibleFor: (rfqTradeFormInfo?: RfqTradeFormInfo) => {
            return rfqTradeFormInfo?.tradeForm.pricingProtocolChecked === "Spread";
        },
        disabledFor: () => false
    },
    {
        field: "spotTime",
        label: "Spot Time",
        type: "select",
        visibleFor: (rfqTradeFormInfo?: RfqTradeFormInfo) => {
            return rfqTradeFormInfo?.tradeForm.pricingProtocolChecked === "Spread";
        },
        disabledFor: (rfqTradeFormInfo: RfqTradeFormInfo) => {
            return false;
        }
    },
    {
        field: "timer",
        label: "Timer",
        type: "radio",
        visibleFor: () => true,
        disabledFor: () => false
    },
    {
        field: "dueProtocol",
        label: "",
        type: "radio",
        visibleFor: () => true,
        disabledFor: () => false
    },
    {
        field: "dueIn",
        label: "",
        type: "select",
        visibleFor: (rfqTradeFormInfo?: RfqTradeFormInfo) => {
            return rfqTradeFormInfo?.tradeForm.dueProtocolChecked === "Due In";
        },
        disabledFor: () => false
    },
    {
        field: "dueAt",
        label: "",
        type: "time",
        visibleFor: (rfqTradeFormInfo?: RfqTradeFormInfo) => {
            return rfqTradeFormInfo?.tradeForm.dueProtocolChecked === "Due At";
        },
        disabledFor: () => false
    },
    {
        field: "settleDate",
        label: "Settle Date",
        type: "date",
        visibleFor: () => true,
        disabledFor: () => false,
        minValue: genericUtils?.getTodaysDate(true)
    }
];

export type RfqTradeForm = {
    size: number;
    pricingProtocol: string[];
    dueProtocol: string[];
    benchmark: string[];
    spotTime: SelectData[];
    timer: string[];
    dueIn: SelectData[];
    dueAt: string;
    settleDate: string;
    pricingProtocolChecked: PricingProtocol;
    dueProtocolChecked: DueProtocol;
    benchmarkSelected: SelectData;
    spotTimeSelected: SelectData;
    timerChecked: RfqTradeFormTimerData;
    dueInSelected: SelectData;
    selectedDirectBrokers: BrokerEntity[];
    selectedVenueBrokers: BrokerEntity[];
    selectedDeskMap: KeyValueNumber;
    selectedVenue: VenueEntity | undefined;
    venues: VenueEntity[]; // other options for venue selection, e.g. MKTX
};

export const RFQ_DUEIN_DATA = {
    SPREAD: {
        BIN: { values: ["3 minutes", "5 minutes", "10 minutes"], selected: "5 minutes" }
    },
    PRICE: {
        BIN: { values: ["2 minutes", "5 minutes", "10 minutes", "30 minutes"], selected: "5 minutes" }
    }
};

export const sizeAtom = atom<number>(NUM_PLACE_HOLDER);
export const pricingProtocolAtom = atom<string[]>(["Price", "Spread"]);
export const dueProtocolAtom = atom<string[]>(["Due In", "Due At"]);
export const benchmarkAtom = atom<string[]>([]);
export const timerAtom = atom<string[]>(["ASAP", "Bin"]);
export const dueInAtom = atom<SelectData[]>([]);
export const dueAtAtom = atom<string>("-");
export const settleDateAtom = atom<string>("-");
export const pricingProtocolCheckedAtom = atom<PricingProtocol>("-");
export const dueProtocolCheckedAtom = atom<DueProtocol>("Due In");
export const benchmarkSelectedAtom = atom<SelectData>({ displayValue: "-", value: "-" });
export const spotTimeSelectedAtom = atom<SelectData>({ displayValue: "Spot Now", value: "A" });
export const timerCheckedAtom = atom<RfqTradeFormTimerData>("Bin");
export const dueInSelectedAtom = atom<SelectData>({ displayValue: "-", value: "-" });
export const selectedDirectBrokersAtom = atom<BrokerEntity[]>([]);
export const selectedVenueBrokersAtom = atom<BrokerEntity[]>([]);
export const selectedDeskMapAtom = atom<KeyValueNumber>({});
export const venuesAtom = atom<VenueEntity[]>([]);
export const selectedVenueAtom = atom<VenueEntity | undefined>(undefined);

export const spotTimesAtom = atom((get): SelectData[] => {
    const selectedVenueName = get(selectedVenueAtom)?.name;
    const venueSpotTimes = get(venueSpotTimesAtom);
    const selectedDirectBrokers = get(selectedDirectBrokersAtom);
    const selectedVenueBrokers = get(selectedVenueBrokersAtom);
    const dropDownOptionsMapper = (spotTime: SpotTime) => ({
        displayValue: spotTime.displayName,
        value: spotTime.code
    });
    let sortedSpotTimes: SpotTime[] = [];

    if (selectedVenueBrokers.length > 0 && selectedDirectBrokers.length === 0) {
        // If only venue brokers are selected, there is a selected venue, and spotType has a mapping for that venue, then the dropdown should have spotTimes displayNames for only venue.
        sortedSpotTimes = genericUtils.sortSpotTimes((selectedVenueName && venueSpotTimes[selectedVenueName]) || []);
    } else if (selectedDirectBrokers.length > 0 && selectedVenueBrokers.length === 0) {
        // If only direct brokers are selected then the dropdown should have spotTimes displayNames for only direct.
        sortedSpotTimes = genericUtils.sortSpotTimes(venueSpotTimes.DIRECT || []);
    } else if (selectedDirectBrokers.length > 0 && selectedVenueBrokers.length > 0) {
        const interSectedSpotTimes = _.intersectionWith(
            venueSpotTimes.DIRECT,
            (selectedVenueName && venueSpotTimes[selectedVenueName]) || [],
            _.isEqual
        );
        sortedSpotTimes = genericUtils.sortSpotTimes(interSectedSpotTimes);
    } else if (selectedDirectBrokers.length === 0 && selectedVenueBrokers.length === 0) {
        const mergedSpotTimes = _.uniqBy(
            [...(venueSpotTimes.DIRECT || []), ...((selectedVenueName && venueSpotTimes[selectedVenueName]) || [])],
            "code"
        );
        sortedSpotTimes = genericUtils.sortSpotTimes(mergedSpotTimes);
    }
    return sortedSpotTimes.map(dropDownOptionsMapper);
});

export const rfqTradeFormAtom = atom<RfqTradeForm>((get) => ({
    size: get(sizeAtom),
    pricingProtocol: get(pricingProtocolAtom),
    dueProtocol: get(dueProtocolAtom),
    benchmark: get(benchmarkAtom),
    spotTime: get(spotTimesAtom),
    timer: get(timerAtom),
    dueIn: get(dueInAtom),
    dueAt: get(dueAtAtom), // "-ET"
    settleDate: get(settleDateAtom),
    pricingProtocolChecked: get(pricingProtocolCheckedAtom),
    dueProtocolChecked: get(dueProtocolCheckedAtom),
    benchmarkSelected: get(benchmarkSelectedAtom),
    spotTimeSelected: get(spotTimeSelectedAtom),
    timerChecked: get(timerCheckedAtom),
    dueInSelected: get(dueInSelectedAtom),
    selectedDirectBrokers: get(selectedDirectBrokersAtom),
    selectedVenueBrokers: get(selectedVenueBrokersAtom),
    selectedDeskMap: get(selectedDeskMapAtom),
    selectedVenue: get(selectedVenueAtom),
    venues: get(venuesAtom)
}));

export const rfqTradeFormSchemaAtom = atom<RfqTradeFormSchema[]>(DEFAULT_RFQ_TRADEFORM_SCHEMA);
export const rfqTradeFormHasValidDataAtom = atom<boolean>(false);
export const rfqTradeFormInfoAtom = atom<RfqTradeFormInfo>((get) => ({
    tradeForm: get(rfqTradeFormAtom),
    schema: get(rfqTradeFormSchemaAtom)
}));

export const rfqTradeFormSink = atom(null, (get, set, rfqTradeForm: Partial<RfqTradeForm>) => {
    Object.entries(rfqTradeForm).forEach(([atomName, value]) => {
        const atomToSet = getAtomByName(atomName as keyof RfqTradeForm);
        set(atomToSet, value);
    });
});

export const getAtomByName = (atomName: keyof RfqTradeForm): PrimitiveAtom<any> => {
    switch (atomName) {
        case "size":
            return sizeAtom;
        case "pricingProtocol":
            return pricingProtocolAtom;
        case "dueProtocol":
            return dueProtocolAtom;
        case "benchmark":
            return benchmarkAtom;
        case "timer":
            return timerAtom;
        case "dueIn":
            return dueInAtom;
        case "dueAt":
            return dueAtAtom;
        case "settleDate":
            return settleDateAtom;
        case "pricingProtocolChecked":
            return pricingProtocolCheckedAtom;
        case "dueProtocolChecked":
            return dueProtocolCheckedAtom;
        case "benchmarkSelected":
            return benchmarkSelectedAtom;
        case "spotTimeSelected":
            return spotTimeSelectedAtom;
        case "timerChecked":
            return timerCheckedAtom;
        case "dueInSelected":
            return dueInSelectedAtom;
        case "selectedDirectBrokers":
            return selectedDirectBrokersAtom;
        case "selectedVenueBrokers":
            return selectedVenueBrokersAtom;
        case "selectedDeskMap":
            return selectedDeskMapAtom;
        case "selectedVenue":
            return selectedVenueAtom;
        case "venues":
            return venuesAtom;

        default:
            throw new Error(`Unknown atom name: ${atomName}`);
    }
};

export const rfqSelectedBrokerSink = atom(
    null,
    (get, set, action: "ADD" | "REMOVE", broker: BrokerEntity, brokerSource: string) => {
        let selectedBrokersAtom = brokerSource === DIRECT ? selectedDirectBrokersAtom : selectedVenueBrokersAtom;
        let brokers = get(selectedBrokersAtom) ?? [];

        if (action === "ADD") {
            if (!brokers.some(({ code }: BrokerEntity) => code === broker.code)) {
                brokers = [...brokers, broker];
            }
        } else {
            brokers = brokers.filter(({ code }: BrokerEntity) => code !== broker.code);
        }
        set(selectedBrokersAtom, brokers);
        genericUtils.logTelemetryClick("Selected Brokers", "selectedBroker" + action, broker.name);
    }
);
