// Mode - means the overall TYPE of application (type seemed too generic?)
// Working - means a specific usercase (within) that mode
// STEPS and DEFAULT_ACTION is normal reset mode
// HITLIFT and SEND creates popup
// combination of both status and subStatus determines certain states
import { searchParam } from "@atw/toolkit/utility";
import { atom } from "jotai";
import { isRFQRequest } from "../../common/utils/rfqUtils";

export enum StepperStatus {
    STEPS = "STEPS",
    VALIDATING = "VALIDATING",
    ACK_VALIDATION = "ACK_VALIDATION",
    SEND = "SEND",
    SENDING = "SENDING",
    SENT = "SENT"
}
export enum StepperSubStatus {
    DEFAULT_ACTION = "DEFAULT_ACTION",
    HITLIFT = "HITLIFT",
    HITLIFT_REJECTED = "HITLIFT_REJECTED",
    COUNTER = "COUNTER",
    COUNTER_REVIEW = "COUNTER_REVIEW",
    COUNTER_REJECTED = "COUNTER_REJECTED",
    CANCELING = "CANCELING",
    CANCELED = "CANCELED"
}

export type Stepper = {
    stepIdx: number;
    previousStatus: StepperStatus;
    status: StepperStatus;
    subStatus: StepperSubStatus;
    fatal: boolean;
};

export enum StepperState {
    Request = "Request",
    Response = "Response"
}

export const WORKFLOWS: StepperState[] = [StepperState.Request, StepperState.Response];
export const ALERT_SUBSTATUSES: StepperSubStatus[] = [
    StepperSubStatus.COUNTER_REJECTED,
    StepperSubStatus.HITLIFT_REJECTED
];

export const DEFAULT_STEPPER: Stepper = {
    stepIdx: isRFQRequest(searchParam("basketID") ?? "-") ? 0 : 1,
    previousStatus: StepperStatus.STEPS,
    status: StepperStatus.STEPS,
    subStatus: StepperSubStatus.DEFAULT_ACTION,
    fatal: false
};

export const stepperAtom = atom(DEFAULT_STEPPER);
stepperAtom.debugLabel = "stepperAtom";

export const stepIndexAtom = atom(
    (get) => {
        return get(stepperAtom).stepIdx;
    },
    (get, set, stepIdx: number) => {
        set(stepperAtom, {
            ...get(stepperAtom),
            stepIdx: stepIdx > 0 ? stepIdx : 0
        });
    }
);

export const statusAtom = atom(
    (get) => {
        const { status, subStatus } = get(stepperAtom);
        return { status, subStatus };
    },
    (get, set, config: { status?: StepperStatus; subStatus?: StepperSubStatus }) => {
        let current = get(stepperAtom);
        set(stepperAtom, {
            ...current,
            previousStatus: current.status,
            status: config.status ?? current.status,
            subStatus: config.subStatus ?? current.subStatus
        });
    }
);

statusAtom.debugLabel = "statusAtom";
