import { useAtom, useAtomValue, useSetAtom } from "jotai";
import _ from "lodash";
import { useMemo } from "react";
import { genericUtils } from "../../common/utils";
import { isRFQRequest } from "../../common/utils/rfqUtils";
import { basketIDAtom, urlUserAtom } from "../../models/atoms";
import { apiErrorSinkAtom } from "../alerts/alert";
import { performRFQValidation, validateBeforeUpdatingPlacementQuote } from "../alerts/validate/validateApi";
import { acceptPlacementQuoteFromRFQ, counterPlacementQuoteFromRFQ } from "../countering/counteringApi";
import {
    orderIdAtom,
    orderLeavesAtom,
    orderSideAtom,
    venueSpotTimesAtom
} from "../order/order";
import { getOrderLeaves } from "../order/orderApi";
import { rfqAtom, rfqQuotesAtom } from "../rfq/rfq";
import { cancelRFQPlacements, sendRfqRequest } from "../rfq/rfqApi";
import { RfqTradeFormInfo, rfqTradeFormHasValidDataAtom, rfqTradeFormInfoAtom } from "../rfqTradeForm/rfqTradeForm";
import { TradeFormInfo, tradeFormInfoAtom } from "../tradeForm";
import { StepperSubStatus, stepperAtom } from "./stepper";

export function useRFQActions() {
    const user = useAtomValue(urlUserAtom);
    const [basketId, setBasketID] = useAtom(basketIDAtom);
    const orderId = useAtomValue(orderIdAtom);
    const side = useAtomValue(orderSideAtom);
    const venueSpotTimes = useAtomValue(venueSpotTimesAtom);
    const [orderLeaves, setOrderLeaves] = useAtom(orderLeavesAtom);
    const tradeFormInfo = useAtomValue(tradeFormInfoAtom);
    const rfqTradeFormInfo = useAtomValue(rfqTradeFormInfoAtom);
    const setRfqTradeFormHasValidData = useSetAtom(rfqTradeFormHasValidDataAtom);
    const setApiError = useSetAtom(apiErrorSinkAtom);
    const { subStatus } = useAtomValue(stepperAtom);
    const rfqQuotes = useAtomValue(rfqQuotesAtom);
    const rfq = useAtomValue(rfqAtom);

    async function getOrderLeavesAndRequestSize(
        isRequestScreen: boolean,
        rfqTradeFormInfo: RfqTradeFormInfo,
        tradeFormInfo: TradeFormInfo,
        orderId: number
    ) {
        let oldOrderLeaves, newOrderLeaves, requestSize;
        if (isRequestScreen) {
            oldOrderLeaves = orderLeaves;
            requestSize = rfqTradeFormInfo.tradeForm.size!;
        } else {
            oldOrderLeaves = rfq.initialRequestSize;
            requestSize = tradeFormInfo.tradeForm.size!;
        }
        // query for any updates to order leaves
        newOrderLeaves = await getOrderLeaves(orderId);
        newOrderLeaves = Math.abs(newOrderLeaves!);
        requestSize = Math.abs(requestSize);
        return [oldOrderLeaves, newOrderLeaves, requestSize];
    }
    const errorOnInvalidRequestSize = (requestSize: number, newOrderLeaves: number) => {
        const errorMessage = `Request size of ${genericUtils.formatSize(
            requestSize
        )} exceeds the new order leaves of ${genericUtils.formatSize(newOrderLeaves)}.`;
        setApiError({
            title: `Error in validating RFQ Order, order leaves has changed`,
            message: errorMessage,
            type: "ERROR"
        });
    };

    return useMemo(
        () => [
            async function validateRFQOrder() {
                const isRequestScreen = isRFQRequest(basketId);
                const venueSpotTimeCode = rfqTradeFormInfo.tradeForm.spotTimeSelected.value

                let [oldOrderLeaves, newOrderLeaves, requestSize] = await getOrderLeavesAndRequestSize(
                    isRequestScreen,
                    rfqTradeFormInfo,
                    tradeFormInfo,
                    orderId
                );
                // if order leaves has changed update the order leaves data in state
                if (oldOrderLeaves !== newOrderLeaves) {
                    setOrderLeaves(newOrderLeaves);
                }
                if (requestSize > newOrderLeaves) {
                    // request size is no longer valid (order leaves has changed and is smaller than size)
                    if (isRequestScreen) {
                        // request screen -> update rfq trade form to block progressing to response screen because of invalid data
                        setRfqTradeFormHasValidData(false);
                    }
                    return errorOnInvalidRequestSize(requestSize, newOrderLeaves);
                } else {
                    // if  on rfq hit/lit or counter confirmational modal
                    if (subStatus === StepperSubStatus.COUNTER_REVIEW || subStatus === StepperSubStatus.HITLIFT) {
                        return validateBeforeUpdatingPlacementQuote(rfq, rfqQuotes, tradeFormInfo.tradeForm, user);
                    }
                    return performRFQValidation(orderId, rfqTradeFormInfo.tradeForm, user, venueSpotTimeCode);
                }
            },
            async function sendRFQOrder() {
                const tradeForm = tradeFormInfo.tradeForm;
                if (subStatus === StepperSubStatus.COUNTER_REVIEW) {
                    // in this case - even though we are in RFQ - we are trying to send a counter
                    return counterPlacementQuoteFromRFQ(rfq, rfqQuotes, tradeForm, user);
                } else if (subStatus === StepperSubStatus.HITLIFT) {
                    return acceptPlacementQuoteFromRFQ(rfq, rfqQuotes, tradeForm, user);
                } else if (subStatus === StepperSubStatus.CANCELING) {
                    return cancelRFQPlacements(rfq, rfqQuotes);
                } else {
                    const venueSpotTimeCode = rfqTradeFormInfo.tradeForm.spotTimeSelected.value

                    setBasketID(
                        await sendRfqRequest(orderId, rfqTradeFormInfo.tradeForm, side, user, venueSpotTimeCode)
                    );
                    return true;
                }
            }
        ],
        [orderId, side, venueSpotTimes, orderLeaves, subStatus, tradeFormInfo, rfqTradeFormInfo]
    );
}
