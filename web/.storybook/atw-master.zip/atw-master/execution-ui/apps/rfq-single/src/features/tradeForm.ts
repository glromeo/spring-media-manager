import { atom } from "jotai";
import { FieldType, NUM_PLACE_HOLDER } from "../models/common";
import { BrokerEntity } from "./brokers/brokers";
import { PricingType } from "./order/order";
import { StepperSubStatus } from "./stepper/stepper";

export type TradeFormSchema = {
    field: keyof TradeForm;
    label: string;
    minValue?: string;
    type: FieldType;
    visibleFor: (pricingType: PricingType, stepperSubStatus?: StepperSubStatus) => boolean;
    disabledFor: () => boolean;
    summarize?: boolean;
};

// refactor-todo: can we remove some of the remaining dependent functions using TradeForm types that aren't relevant?
export type TradeForm = {
    spread?: number | string;
    price?: number | string;
    size?: number;
    broker?: string[];
    desk?: string[];
    spotTime?: string[];
    dueIn?: string[];
    settleDate?: string;
    brokerSelected?: string;
    deskSelected?: string;
    spotTimeSelected?: string;
    dueInSelected?: string;
    hasValidData: boolean;
    selectedDeskMap: Record<string, number>;
    selectedBrokers: BrokerEntity[];
};

export type TradeFormInfo = {
    tradeForm: TradeForm;
    schema: TradeFormSchema[];
};

// refactor-todo: can delete more things out of this for sure
export const DEFAULT_TRADEFORM_SCHEMA: TradeFormSchema[] = [
    {
        field: "price",
        label: "Price $",
        type: "price",
        visibleFor: (pricingType: PricingType) => {
            return pricingType === "PRICE";
        },
        disabledFor: () => {
            return false;
        },
        summarize: true
    },
    {
        field: "spread",
        label: "Spread",
        type: "spread",
        visibleFor: (pricingType: PricingType) => {
            return pricingType === "SPREAD";
        },
        disabledFor: () => {
            return false;
        },
        summarize: true
    },
    {
        field: "dueIn",
        label: "Due in",
        type: "select",
        visibleFor: (pricingType: PricingType, stepperSubStatus?: StepperSubStatus) => {
            if (stepperSubStatus === undefined) return false;
            if (stepperSubStatus === StepperSubStatus.COUNTER || stepperSubStatus === StepperSubStatus.COUNTER_REVIEW) return true;
            return false;
        },
        disabledFor: () => {
            return false;
        },
        summarize: true
    },
    {
        field: "size",
        label: "Size",
        type: "size",
        visibleFor: () => {
            return true;
        },
        disabledFor: () => {
            return true;
        },
        summarize: true
    },
    {
        field: "broker",
        label: "Broker",
        type: "select",
        visibleFor: () => {
            return true;
        },
        disabledFor: () => {
            return true;
        },
        summarize: true
    },
    {
        field: "desk",
        label: "Desk",
        type: "select",
        visibleFor: () => {
            return true;
        },
        disabledFor: () => {
            return true;
        },
        summarize: true
    },
    {
        field: "spotTime",
        label: "Spot Time",
        type: "select",
        visibleFor: (pricingType: PricingType) => {
            return pricingType === "SPREAD";
        },
        disabledFor: () => {
            return true;
        },
        summarize: true
    }
];

export const DEFAULT_TRADEFORM: TradeForm = {
    price: NUM_PLACE_HOLDER,
    spread: NUM_PLACE_HOLDER,
    size: NUM_PLACE_HOLDER,
    broker: [],
    desk: [],
    dueIn: ["1 minute", "2 minutes", "5 minutes", "10 minutes"],
    spotTime: ["Spot Now", "11am ET", "1pm ET", "3pm ET", "4pm ET", "4:30pm ET"],
    settleDate: "-",
    brokerSelected: "-",
    deskSelected: "-",
    dueInSelected: "5 minutes",
    hasValidData: false,
    selectedBrokers: [],
    selectedDeskMap: {}
};

export const tradeFormAtom = atom<TradeForm>(DEFAULT_TRADEFORM);
export const tradeFormSchemaAtom = atom<TradeFormSchema[]>(DEFAULT_TRADEFORM_SCHEMA);
export const tradeFormInfoAtom = atom<TradeFormInfo>((get) => ({
    tradeForm: get(tradeFormAtom),
    schema: get(tradeFormSchemaAtom)
}));

export const tradeFormSink = atom(null, (get, set, value: Partial<TradeForm>) => {
    set(tradeFormAtom, { ...get(tradeFormAtom), ...value });
});
