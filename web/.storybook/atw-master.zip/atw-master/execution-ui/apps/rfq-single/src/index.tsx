import React from "react";
import { genericUtils } from "./common/utils";

import { AtxApp, AtxErrorBoundary, jotaiStore, renderApp } from "@atx/toolkit";
import { atoms, updateRfqActionAtom } from "./models/atoms";
import { UpdateRFQActionPayload } from "./features/rfq/rfq";
import { Alert, alertsAtom } from "./features/alerts/alert";
import { atom } from "jotai";

import "./index.scss";
import "./execution.scss";
import "./rfq.scss";

import { ContextMenu } from "./components/common/context-menu";
import { SingleRFQ } from "./components/singleRFQ";

const atwRequestStateAtom = atom<any>({});

renderApp(
    <AtxApp
        atoms={atoms}
        dispatch={(action) => {
            switch (action.type) {
                case "UPDATE_RFQ":
                    // create a new object reference here forces atom update
                    jotaiStore.set(updateRfqActionAtom, {
                        ...(action.payload as UpdateRFQActionPayload)
                    });
                    return;
                case "SET_ALERT":
                    const alerts = action.payload as Alert[];
                    alerts.forEach((a: Alert) => {
                        a.id = genericUtils.nextNumber();
                        a.timeout = a.timeout ?? 3600000;
                        console.log(`alerts -- ${a.name}: ${a.message}`);
                    });
                    jotaiStore.set(alertsAtom, [...jotaiStore.get(alertsAtom), ...alerts]);
                    return;
                case "ATW/SET_REQUEST_STATE":
                    jotaiStore.set(atwRequestStateAtom, action.payload);
                    return;
                default:
                    console.error("no case found for dispatched action:", action);
            }
        }}
    >
        <AtxErrorBoundary>
            <div className="execution">
                <ContextMenu />
                <SingleRFQ />
            </div>
        </AtxErrorBoundary>
    </AtxApp>,
    { strictMode: true, telemetry: true, logPrefix: true }
);
