import { searchParam } from "@atw/toolkit/utility";
import { atomWithEffects } from "@atx/toolkit/atoms";
import { settingsAtom } from "@atx/toolkit/utils/settings";
import { atom } from "jotai";
import { alertsAtom, alertStatusAtom } from "../features/alerts/alert";
import {
    brokerAtom,
    delayedSpotTimeEligibleBrokersAtom,
    directBrokersAtom,
    eligibleDirectBrokersAtom,
    eligibleVenueBrokersAtom,
    isVenueSelectAllCheckedAtom,
    pricingTypeEligibleBrokersAtom,
    pricingTypeEligibleDirectBrokersAtom,
    selectedBrokerNamesAtom,
    selectedBrokersCountAtom,
    currentVenueBrokersAtom
} from "../features/brokers/brokers";
import { decodesAtom } from "../features/decodes";
import {
    orderBmkAtom,
    orderBmkIdAtom,
    orderBondAtom,
    orderCurrencyAtom,
    orderCusipAtom,
    orderDetailsInfoAtom,
    orderEligibleVenueNamesAtom,
    orderHasValidDataAtom,
    orderIdAtom,
    orderInstructionsAtom,
    orderIsinAtom,
    orderLeavesAtom,
    orderLimitAtom,
    orderLimitTypeAtom,
    orderMinTrdSizeAtom,
    orderOrigSizeAtom,
    orderPriceAtom,
    orderSchemaAtom,
    orderSettleDateAtom,
    orderSideAtom,
    venueSpotTimesAtom,
    orderTradingBmkAtom,
    orderUnbookedAmtAtom,
    PricingType
} from "../features/order/order";
import { modifyReasonAtom } from "../features/placement/modifyReason";
import {
    fetchBasketAtom,
    rfqAtom,
    rfqCancelEnabledAtom,
    rfqDueInAtom,
    rfqDueInEnabledAtom,
    rfqDueInTimedOutAtom,
    rfqQuotesAtom,
    selectedRfqQuoteAtom,
    UpdateRFQActionPayload
} from "../features/rfq/rfq";
import {
    benchmarkAtom,
    benchmarkSelectedAtom,
    dueAtAtom,
    dueInAtom,
    dueInSelectedAtom,
    dueProtocolAtom,
    dueProtocolCheckedAtom,
    pricingProtocolAtom,
    pricingProtocolCheckedAtom,
    rfqTradeFormAtom,
    rfqTradeFormHasValidDataAtom,
    rfqTradeFormInfoAtom,
    rfqTradeFormSchemaAtom,
    selectedDeskMapAtom,
    selectedDirectBrokersAtom,
    selectedVenueAtom,
    selectedVenueBrokersAtom,
    settleDateAtom,
    sizeAtom,
    spotTimesAtom,
    spotTimeSelectedAtom,
    timerAtom,
    timerCheckedAtom,
    venuesAtom
} from "../features/rfqTradeForm/rfqTradeForm";
import { statusAtom, stepIndexAtom, stepperAtom, StepperStatus } from "../features/stepper/stepper";
import { tradeFormAtom, tradeFormInfoAtom, tradeFormSchemaAtom } from "../features/tradeForm";
import { NUM_PLACE_HOLDER } from "./common";

// url atoms
export const urlUserAtom = atom<string>(searchParam("user") ?? "testUser");
export const basketIDAtom = atomWithEffects<string>(searchParam("basketID") || "-", (get, set, basketID) => {
    if (basketID !== "-") {
        set(stepIndexAtom, 1);
        set(statusAtom, { status: StepperStatus.SENT });
    } else {
        set(stepIndexAtom, 0);
    }
});

// misc atoms
export const fetchAtom = atom<number>(NUM_PLACE_HOLDER);
export const inResumeRFQAtom = atom<boolean>(searchParam("basketID") ? true : false);
export const pricingTypeAtom = atom<PricingType>("PRICE");
pricingTypeAtom.debugLabel = "pricingTypeAtom";
export const debugInfoAtom = atom<boolean>(false);
export const updateRfqActionAtom = atomWithEffects<UpdateRFQActionPayload | null>(null, (get, set, updateRfqAction) => {
    const fetchOrderSuccess = get(orderHasValidDataAtom);
    if (fetchOrderSuccess && updateRfqAction) {
        console.log(`fetchBasket with UPDATE_RFQ payload: ${JSON.stringify(updateRfqAction)}`);
        set(fetchBasketAtom, updateRfqAction);
    }
});

// **NOTE** When importing atoms, use the reference to the actual atom (ie. userAtom) and not "atoms.user".
// This atoms object is used to:
//     1) Provide name mapping to atoms in Jotai DevTools
//     2) Provide a resource in the codebase for looking up atoms
export const atoms = {
    // url atoms
    urlUser: urlUserAtom,
    basketID: basketIDAtom,
    // misc atoms
    fetch: fetchAtom,
    debugInfo: debugInfoAtom,
    pricingType: pricingTypeAtom,
    updateRfqAction: updateRfqActionAtom,
    // alerts atoms
    alerts: alertsAtom,
    alertStatus: alertStatusAtom,
    // order atoms
    orderId: orderIdAtom,
    orderCusip: orderCusipAtom,
    orderSide: orderSideAtom,
    orderBond: orderBondAtom,
    orderCurrency: orderCurrencyAtom,
    orderIsin: orderIsinAtom,
    orderOrigSize: orderOrigSizeAtom,
    orderUnbookedAmt: orderUnbookedAmtAtom,
    orderLimit: orderLimitAtom,
    orderLimitType: orderLimitTypeAtom,
    orderInstructions: orderInstructionsAtom,
    orderSettleDate: orderSettleDateAtom,
    orderTradingBmk: orderTradingBmkAtom,
    orderMinTrdSize: orderMinTrdSizeAtom,
    orderPrice: orderPriceAtom,
    orderBmk: orderBmkAtom,
    orderBmkId: orderBmkIdAtom,
    orderLeaves: orderLeavesAtom,
    orderHasValidData: orderHasValidDataAtom,
    orderEligibleVenueNames: orderEligibleVenueNamesAtom,
    venueSpotTimes: venueSpotTimesAtom,
    orderSchema: orderSchemaAtom,
    orderDetailsInfo: orderDetailsInfoAtom,
    // trade form atoms
    tradeForm: tradeFormAtom,
    tradeFormSchema: tradeFormSchemaAtom,
    tradeFormInfo: tradeFormInfoAtom,
    // broker atoms
    broker: brokerAtom,
    directBrokers: directBrokersAtom,
    pricingTypeEligibleDirectBrokers: pricingTypeEligibleDirectBrokersAtom,
    eligibleDirectBrokers: eligibleDirectBrokersAtom,
    currentVenueBrokers: currentVenueBrokersAtom,
    eligibleVenueBrokers: eligibleVenueBrokersAtom,
    pricingTypeEligibleBrokers: pricingTypeEligibleBrokersAtom,
    delayedSpotTimeEligibleBrokers: delayedSpotTimeEligibleBrokersAtom,
    selectedBrokerNames: selectedBrokerNamesAtom,
    selectedBrokersCount: selectedBrokersCountAtom,
    // rfq atoms
    rfq: rfqAtom,
    rfqTradeForm: rfqTradeFormAtom,
    rfqTradeFormSchema: rfqTradeFormSchemaAtom,
    rfqTradeFormHasValidData: rfqTradeFormHasValidDataAtom,
    rfqTradeFormInfo: rfqTradeFormInfoAtom,
    rfqQuotes: rfqQuotesAtom,
    rfqDueIn: rfqDueInAtom,
    rfqDueInEnabled: rfqDueInEnabledAtom,
    rfqCancelEnabled: rfqCancelEnabledAtom,
    rfqDueInTimedOut: rfqDueInTimedOutAtom,
    selectedRfqQuote: selectedRfqQuoteAtom,
    // rfq trade form atoms
    size: sizeAtom,
    pricingProtocol: pricingProtocolAtom,
    dueProtocol: dueProtocolAtom,
    benchmark: benchmarkAtom,
    spotTimes: spotTimesAtom,
    timer: timerAtom,
    dueIn: dueInAtom,
    dueAt: dueAtAtom,
    settleDate: settleDateAtom,
    pricingProtocolChecked: pricingProtocolCheckedAtom,
    dueProtocolChecked: dueProtocolCheckedAtom,
    benchmarkSelected: benchmarkSelectedAtom,
    spotTimeSelected: spotTimeSelectedAtom,
    timerChecked: timerCheckedAtom,
    dueInSelected: dueInSelectedAtom,
    selectedDirectBrokers: selectedDirectBrokersAtom,
    selectedVenueBrokers: selectedVenueBrokersAtom,
    selectedDeskMap: selectedDeskMapAtom,
    selectedVenue: selectedVenueAtom,
    venues: venuesAtom,
    isVenueSelectAllCheckedAtom: isVenueSelectAllCheckedAtom,
    // stepper atoms
    stepper: stepperAtom,
    stepIndex: stepIndexAtom,
    stepperStatus: statusAtom,
    // decode atoms
    modifyReason: modifyReasonAtom,
    decodes: decodesAtom,
    // settings atom
    settings: settingsAtom(
        // refactor-todo: can we move declaration outside of atoms object?
        {
            version: "0.0.0",
            isOpen: false,
            desks: ""
        },
        {}
    )
};
