export type FieldType =
    | "spread"
    | "price"
    | "size"
    | "select"
    | "date"
    | "time"
    | "text"
    | "security"
    | "boolean"
    | "side"
    | "progress"
    | "radio"
    | "rating"
    | "securityLookup"
    | "allInLevel";

export type Side = "BUY" | "SELL" | "NOTSET";

export type SideColor = string;
export const BUY_COLOR: SideColor = "var(--buy-primary__background-color_hover)";
export const SELL_COLOR: SideColor = "var(--sell-primary__background-color_hover)";

export const EMPTY_PLACE_HOLDER = "";
export const NUM_PLACE_HOLDER = -999;
export const PRICE = "PRICE";
export const SPREAD = "SPREAD";

export interface Dimension {
    width: number;
    height: number;
}

export interface KeyValueNumber {
    [index: string]: number;
}

export interface KeyValueBoolean {
    [index: string]: boolean;
}
