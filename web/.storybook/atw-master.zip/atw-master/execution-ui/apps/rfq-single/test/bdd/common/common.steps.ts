/// <reference types="cypress" />
import { createDate } from "@atx/commons/utils";
import { TableDefinition } from "cypress-cucumber-preprocessor";
import { Given, Then } from "cypress-cucumber-preprocessor/steps";
import { DateTime } from "luxon";
import {
    GraphQLBasketSummaryResponse,
    GraphQLOrderSummaryResponse,
    GraphQLPlacementCreationResponse,
    GraphQLResult
} from "../../../src/api/types";
import { genericUtils } from "../../../src/common/utils";
import { brokerSource } from "../../../src/features/brokers/brokers";
import {
    assertAuxCard,
    assertAuxNotification,
    assertAuxSelectDropdownOptions,
    assertAuxSelectText,
    assertAuxStepper,
    assertDialog,
    assertElementContainsText,
    assertElementExists,
    assertElementHasLabel,
    assertElementHasText,
    assertElementNotExists,
    assertForm,
    assertFormError,
    assertFormFieldsMode,
    assertNumElements,
    assertPopup,
    assertSelectOptionState,
    assertTable,
    assertTableNumColumns,
    calledNumTimes,
    closeAuxNotification,
    dispatchAction,
    performCommand,
    performCtrlShift,
    populateForm,
    selectOption,
    setAuxStepper,
    setupBasketIntercepts,
    setupCommonIntercepts,
    setupDecodesIntercept,
    setupExecutionIntercepts,
    setupGraphQLIntercepts,
    setupSecuritySearchIntercept,
    toggleExpandOnAuxCard,
    verifyAtom,
    verifyElementState,
    verifyLocalStorage,
    verifyStyle,
    visit,
    waitFor
} from "../../common";
import { convertNumberStringToNumber, convertToWorkflowEnum, getTestSelector, WorkflowError } from "../../common.utils";
import { storeObject } from "@atx/toolkit/utils";

const { removeSpace } = genericUtils;

Cypress.on("uncaught:exception", (err, runnable) => {
    // aux related error that happens intermittently
    if (err.message.includes("Cannot read properties of undefined (reading 'openDropdown')")) {
        return false;
    }
    throw err;
});

Cypress.on("fail", (error, runnable) => {
    // we now have access to the err instance
    // and the mocha runnable this failed on
    throw error; // throw error to have test still fail
});

// set files dat tokens into local storage
function cacheRequiredTokens(entries: any) {
    storeObject("tokens", {
        entries,
        lastModified: -1
    });
}

beforeEach(() => {
    cacheRequiredTokens({
        AladdinTraderFeatures: "",
        AT_benchmark_date: "11/21/2021",
        MarketDepthAxeExpiryToken: "10:30PM",
        NiteJobsTimeZone: "America/New_York",
        AladdinTraderMIFIDEligible: "true",
        AladdinTraderRFQTimers: "600,120,36000",
        COMPOSITE_PRICE_ENABLED: "False",
        "DB.USER.TRADING.RO": "svc_trading_ro",
        "DB.USER.TRADING.RW": "svc_trading_rw"
    });
});

afterEach(() => {
    window.localStorage.clear();
    Cypress.env().updateRfqCount = 0;
    Cypress.env().api.count.requestplacementquote = 0;
    cy.clock(0).invoke("restore");
});

/**************************
 **** API INTERCEPTORS ****
 **************************/

Given("I have loaded an RFQ order scenario - {}", (scenario: string) => {
    let url = "/index.html?orderNumber=573390912&side=BUY&cusip=00033AAA6&user=testuser&scale=1",
        fixtureFile = "orders/573390912",
        basketFixtureFile = "baskets/219724585~1667240663713";
    switch (scenario) {
        // add cases as needed
        case "restrictions":
        case "restrictions_venue":
            url = "/index.html?user=testuser&orderNumber=660567884&side=Buy&cusip=02005NBM1";
            fixtureFile = "orders/660567884";
            basketFixtureFile = "baskets/213818284~1662665765719";
            break;
        case "HY_request_mode_bin":
            url = "/index.html?user=testuser&orderNumber=655156085&side=Sell&cusip=00033AAA6";
            fixtureFile = "orders/655156085";
            basketFixtureFile = "baskets/219721785~1667235267588";
            break;
        case "HY_request_mode_bin_multiple_desks":
            url = "/index.html?user=testuser&orderNumber=655156088&side=Sell&cusip=00033AAA6";
            fixtureFile = "orders/655156088";
            basketFixtureFile = "baskets/219721785~1667235267588";
            break;
        case "HY_counter":
            url =
                "/index.html?orderNumber=644938185&side=SELL&cusip=00033AAA6&user=testuser&basketID=216976685~1664479919974";
            fixtureFile = "orders/644938185";
            basketFixtureFile = "baskets/216976685~1664479919974";
            break;
        case "HY_response_table_BUY":
            url =
                "/index.html?user=testuser&orderNumber=716509185&side=BUY&cusip=00033AAA6&basketID=233224085~1677609541725";
            fixtureFile = "orders/716509185";
            basketFixtureFile = "baskets/233224085~1677609541725";
            break;
        case "HY_response_table_SELL":
            url =
                "/index.html?user=testuser&orderNumber=654995585&side=Sell&cusip=00033AAA6&basketID=219122685~1666812672252";
            fixtureFile = "orders/654995585";
            basketFixtureFile = "baskets/219122685~1666812672252";
            break;
        case "HY_response_table_qsub":
            url =
                "/index.html?user=testuser&orderNumber=697009385&side=Buy&cusip=00033AAA6&basketID=589448712~1689194602166";
            fixtureFile = "orders/697009385";
            basketFixtureFile = "baskets/589448712~1689194602166";
            break;
        case "HY_response_table_large_order_leaves_SELL":
            url =
                "/index.html?user=testuser&orderNumber=654995587&side=Sell&cusip=00033AAA6&basketID=219122685~1666812672252";
            fixtureFile = "orders/654995587";
            basketFixtureFile = "baskets/219122685~1666812672252";
            break;
        case "HY_response_table_perpetual_counter":
            url =
                "/index.html?user=testuser&orderNumber=570855412&side=BUY&cusip=00033AAA6&basketID=570855412~1682116220660";
            fixtureFile = "orders/570855412";
            basketFixtureFile = "baskets/570855412~1682116220660";
            break;
        case "HY_response_filled":
            url =
                "/index.html?user=testuser&orderNumber=706136685&cusip=00033AAA6&side=BUY&basketID=232171285~1676587740214";
            fixtureFile = "orders/706136685";
            basketFixtureFile = "baskets/232171285~1676587740214";
            break;
        case "HY_multiple_blank_responses":
            url =
                "/index.html?user=testuser&orderNumber=654995586&side=Sell&cusip=00033AAA6&basketID=220122685~1666812670000";
            fixtureFile = "orders/654995586";
            basketFixtureFile = "baskets/220122685~1666812670000";
            break;
        case "HY_order_times_out":
            url = "/index.html?user=testuser&orderNumber=606435412&cusip=00033AAA6&basketID=606435412~1692908555505";
            fixtureFile = "orders/606435412";
            basketFixtureFile = "baskets/606435412~1692908555505";
            break;
        case "HY_broker_doesnot_respond":
            url = "/index.html?user=testuser&orderNumber=590020311&cusip=00033AAA6&basketID=590020311~1693348119838";
            fixtureFile = "orders/590020311";
            basketFixtureFile = "baskets/590020311~1693348119838";
            break;
        case "HY_counter_and_cancel":
            url = "/index.html?user=testuser&orderNumber=590020211&cusip=00033AAA6&basketID=590020211~1693416272592";
            fixtureFile = "orders/590020211";
            basketFixtureFile = "baskets/590020211~1693416272592";
            break;
        case "HY_request_mode_asap":
            url = "/index.html?user=testuser&orderNumber=655156085&side=Sell&cusip=02005NBM1";
            fixtureFile = "orders/655156085";
            basketFixtureFile = "baskets/219724585~1667240663713";
            break;
        case "HY_spread":
            url =
                "/index.html?user=testuser&orderNumber=697009385&side=Sell&cusip=00033AAA6&basketID=230274985~1674675035654";
            fixtureFile = "orders/697009385";
            basketFixtureFile = "baskets/230274985~1674675035654";
            break;
        case "IG_price":
            url =
                "/index.html?user=testuser&orderNumber=655217285&side=Buy&cusip=92343VGJ7&basketID=219122685~1666812672252";
            fixtureFile = "orders/655217285";
            basketFixtureFile = "baskets/219122685~1666812672252";
            break;
        case "HY_order_with_benchmark_request_mode":
            url = "/index.html?orderNumber=716268385&side=Buy&cusip=92343VGJ7&user=testuser";
            fixtureFile = "orders/716268385";
            break;
        case "IG_request_mode":
        case "IG_venue_request_mode":
            url = "/index.html?orderNumber=484134985&side=Buy&cusip=92343VGJ7&user=testuser";
            fixtureFile = "orders/484134985";
            break;
        case "IG_response_grid_BUY":
        case "IG_response_filled":
            url =
                "/index.html?user=testuser&orderNumber=655217285&side=Buy&cusip=92343VGJ7&basketID=220223585~1667329354612";
            fixtureFile = "orders/655217285";
            basketFixtureFile = "baskets/220223585~1667329354612";
            break;
        case "IG_response_grid_SELL":
            url =
                "/index.html?user=testuser&orderNumber=716687485&side=SELL&cusip=92343VGJ7&basketID=233226085~1677612568381";
            fixtureFile = "orders/716687485";
            basketFixtureFile = "baskets/233226085~1677612568381";
            break;
        case "request_with_multiple_desks":
            url = "/index.html?orderNumber=610935487&side=Buy&cusip=00033AAA6&user=testuser";
            fixtureFile = "orders/610935487";
            break;
        case "request_with_0_order_leaves":
            url = "/index.html?orderNumber=610935488&side=Buy&cusip=00033AAA6&user=testuser";
            fixtureFile = "orders/610935488";
            break;
        case "IG_response_mode":
            url =
                "/index.html?orderNumber=655156385&side=BUY&cusip=92343VGJ7&user=testuser&basketID=219727385~1667245090825";
            fixtureFile = "orders/655156385";
            basketFixtureFile = "baskets/219727385~1667245090825";
            break;
        case "HY_venue_request_mode_asap":
        case "HY_venue_request_mode_asap_empty_desks_direct":
        case "HY_venue_request_mode_asap_empty_desks_venue":
        case "HY_venue_request_mode_asap_empty_desks_both":
            url = "/index.html?orderNumber=612194212&side=BUY&cusip=00033AAA6&user=testuser";
            fixtureFile = "orders/612194212";
            basketFixtureFile = "baskets/612194212~1694031969558";
            break;
        case "IG_venue_request_mode_asap":
            url = "/index.html?orderNumber=605979810&side=BUY&cusip=92343VGJ7&user=testuser";
            fixtureFile = "orders/605979810";
            basketFixtureFile = "baskets/605979810~1694110315875";
            break;
        case "HY_venue_hybrid_request_mode_asap":
            url = "/index.html?orderNumber=612194212&side=BUY&cusip=00033AAA6&user=testuser";
            fixtureFile = "orders/612194212";
            basketFixtureFile = "baskets/612194212~1694127038382";
            break;
        case "HY_venue_request_empty_direct_spot_times":
            (url = "/index.html?orderNumber=573390914&side=BUY&cusip=00033AAA6&user=testuser&scale=1"),
                (fixtureFile = "orders/573390914"),
                (basketFixtureFile = "baskets/219724585~1667240663713");
            break;
        case "HY_venue_request_empty_tradeweb_spot_times":
            (url = "/index.html?orderNumber=573390913&side=BUY&cusip=00033AAA6&user=testuser&scale=1"),
                (fixtureFile = "orders/573390913"),
                (basketFixtureFile = "baskets/219724585~1667240663713");
            break;
        case "HY_venue_request_empty_spot_times":
            (url = "/index.html?orderNumber=573390915&side=BUY&cusip=00033AAA6&user=testuser&scale=1"),
                (fixtureFile = "orders/573390915"),
                (basketFixtureFile = "baskets/219724585~1667240663713");
            break;
        case "HY_venue_scenario_1":
            url =
                "/index.html?orderNumber=595911812&side=BUY&cusip=00033AAA6&user=testuser&basketID=595911812~1691529028334";
            fixtureFile = "orders/595911812";
            basketFixtureFile = "baskets/595911812~1691529028334";
            break;
        case "HY_venue_scenario_3":
            url =
                "/index.html?orderNumber=605080212&side=BUY&cusip=00033AAA6&user=testuser&basketID=605080212~1691775951321";
            fixtureFile = "orders/605080212";
            basketFixtureFile = "baskets/605080212~1691775951321";
            break;
        case "HY_venue_scenario_4":
            url =
                "/index.html?orderNumber=418960816&side=BUY&cusip=90184LAP7&user=testuser&basketID=418960816~1689805972632";
            fixtureFile = "orders/418960816";
            basketFixtureFile = "baskets/418960816~1689805972632";
            break;
        case "HY_venue_scenario_5":
            url =
                "/index.html?orderNumber=728777509&side=BUY&cusip=90932LAH0&user=testuser&basketID=728777509~1691532773080";
            fixtureFile = "orders/728777509";
            basketFixtureFile = "baskets/728777509~1691532773080";
            break;
        case "HY_venue_scenario_9":
            url =
                "/index.html?orderNumber=581960312&side=BUY&cusip=00033AAA6&user=testuser&basketID=581960312~1687465158709";
            fixtureFile = "orders/581960312";
            basketFixtureFile = "baskets/581960312~1687465158709";
            break;
        case "HY_venue_scenario_10_timer_expires":
            url =
                "/index.html?orderNumber=573305011&side=BUY&cusip=BRW8DZC86&user=testuser&mode=rfq&workflow=single&basketID=573305011~1689894100861";
            fixtureFile = "orders/573305011";
            basketFixtureFile = "baskets/573305011~1689894100861";
            break;
        case "HY_venue_scenario_10_hit_broker":
            url =
                "/index.html?orderNumber=573305011&side=BUY&cusip=BRW8DZC86&user=testuser&mode=rfq&workflow=single&basketID=573305011~1689894100859";
            fixtureFile = "orders/573305011";
            basketFixtureFile = "baskets/573305011~1689894100859";
            break;
        case "HY_venue_scenario_10_counter_broker":
            url =
                "/index.html?orderNumber=573305011&side=BUY&cusip=BRW8DZC86&user=testuser&mode=rfq&workflow=single&basketID=573305011~1689894100863";
            fixtureFile = "orders/573305011";
            basketFixtureFile = "baskets/573305011~1689894100863";
            break;
        case "HY_venue_scenario_10_trader_cancels":
            url =
                "/index.html?orderNumber=573305011&side=BUY&cusip=BRW8DZC86&user=testuser&mode=rfq&workflow=single&basketID=573305011~1689894100862";
            fixtureFile = "orders/573305011";
            basketFixtureFile = "baskets/573305011~1689894100862";
            break;
        case "HY_venue_scenario_11":
            url =
                "/index.html?orderNumber=583148610&side=BUY&cusip=02005NBM1&user=testuser&basketID=583148610~1689367191464";
            fixtureFile = "orders/583148610";
            basketFixtureFile = "baskets/583148610~1689367191464";
            break;
        case "HY_venue_scenario_13":
            url =
                "/index.html?orderNumber=583148610&side=BUY&cusip=02005NBM1&user=testuser&basketID=583148710~1689367258778";
            fixtureFile = "orders/583148610";
            basketFixtureFile = "baskets/583148710~1689367258778";
            break;
        case "HY_venue_scenario_14":
            url =
                "/index.html?orderNumber=620611512&side=BUY&cusip=40010PAA6&user=testuser&basketID=620611512~1695336634210";
            fixtureFile = "orders/620611512";
            basketFixtureFile = "baskets/620611512~1695336634210";
            break;
        case "HY_venue_scenario_15":
            url =
                "/index.html?orderNumber=573305011&side=BUY&cusip=BRW8DZC86&user=testuser&basketID=573305011~1689894100860";
            fixtureFile = "orders/573305011";
            basketFixtureFile = "baskets/573305011~1689894100860";
            break;
        case "HY_venue_scenario_16":
            url =
                "/index.html?orderNumber=605080213&side=BUY&cusip=00033AAA6&user=testuser&basketID=605080213~1691775951323";
            fixtureFile = "orders/605080213";
            basketFixtureFile = "baskets/605080213~1691775951323";
            break;
        case "IG_venue_scenario_1":
            url =
                "/index.html?orderNumber=588364410&side=BUY&cusip=00033AAA6&user=testuser&basketID=588364410~1691536082112";
            fixtureFile = "orders/588364410";
            basketFixtureFile = "baskets/588364410~1691536082112";
            break;
        case "IG_venue_scenario_2":
            url =
                "/index.html?orderNumber=581373610&side=BUY&cusip=92343VGJ7&user=testuser&basketID=581373610~1688163693867";
            fixtureFile = "orders/581373610";
            basketFixtureFile = "baskets/581373610~1688163693867";
            break;
        case "IG_venue_scenario_3":
            url =
                "/index.html?orderNumber=605104012&side=BUY&cusip=00033AAA6&user=testuser&basketID=605104012~1691780719767";
            fixtureFile = "orders/605104012";
            basketFixtureFile = "baskets/605104012~1691780719767";
            break;
        case "IG_venue_scenario_6":
            url =
                "/index.html?orderNumber=588259910&side=BUY&cusip=037833EA4&user=testuser&basketID=588259910~1689808924015";
            fixtureFile = "orders/588259910";
            basketFixtureFile = "baskets/588259910~1689808924015";
            break;
        case "IG_venue_scenario_7":
            url =
                "/index.html?orderNumber=412727516&side=BUY&cusip=92343VGJ7&user=testuser&basketID=412727516~1689181763509";
            fixtureFile = "orders/412727516";
            basketFixtureFile = "baskets/412727516~1689181763509";
            break;
        case "IG_venue_scenario_8":
            url =
                "/index.html?orderNumber=412934016&side=BUY&cusip=92343VGJ7&user=testuser&basketID=412934016~1689283728980";
            fixtureFile = "orders/412934016";
            basketFixtureFile = "baskets/412934016~1689283728980";
            break;
        case "IG_venue_scenario_12":
            url =
                "/index.html?orderNumber=573729111&side=BUY&cusip=00206RDC3&user=testuser&mode=rfq&workflow=single&basketID=573729111~1691619144326";
            fixtureFile = "orders/573729111";
            basketFixtureFile = "baskets/573729111~1691619144326";
            break;
        case "IG_venue_scenario_1_diff_exp_times":
            url =
                "/index.html?orderNumber=588364410&side=BUY&cusip=00033AAA6&user=testuser&basketID=588364410~1691536082113";
            fixtureFile = "orders/588364410";
            basketFixtureFile = "baskets/588364410~1691536082113";
            break;
        case "trader_actioned_counter_then_rejected_quote":
            url =
                "/index.html?orderNumber=573305011&side=BUY&cusip=BRW8DZC86&user=testuser&basketID=588259910~1689808924016";
            fixtureFile = "orders/573305011";
            basketFixtureFile = "baskets/588259910~1689808924016";
            break;
        case "trader_actioned_hit_then_rejected_quote":
            url =
                "/index.html?orderNumber=573305011&side=BUY&cusip=BRW8DZC86&user=testuser&basketID=588259910~1689808924017";
            fixtureFile = "orders/573305011";
            basketFixtureFile = "baskets/588259910~1689808924017";
            break;
        case "HY_hybrid_scenario_1":
            url =
                "/index.html?orderNumber=604986412&side=BUY&cusip=00033AAA6&user=testuser&mode=rfq&workflow=single&basketID=604986412~1691711360757";
            fixtureFile = "orders/604986412";
            basketFixtureFile = "baskets/604986412~1691711360757";
            break;
        case "HY_hybrid_scenario_2":
            url =
                "/index.html?orderNumber=581960312&side=BUY&cusip=00033AAA6&user=testuser&mode=rfq&workflow=single&basketID=581960312~1687465158781";
            fixtureFile = "orders/581960312";
            basketFixtureFile = "baskets/581960312~1687465158781";
            break;
        case "HY_hybrid_scenario_3":
            url =
                "/index.html?orderNumber=620331212&side=BUY&cusip=00033AAA6&user=testuser&mode=rfq&workflow=single&basketID=620331212~1694466386541";
            fixtureFile = "orders/620331212";
            basketFixtureFile = "baskets/620331212~1694466386541";
            break;
        default:
            break;
    }

    cy.fixture(fixtureFile).then((order: GraphQLResult<GraphQLOrderSummaryResponse>) => {
        switch (scenario) {
            default:
                break;
        }
        cy.fixture(basketFixtureFile).then(
            (basket: {
                responses: GraphQLResult<GraphQLBasketSummaryResponse>[];
            }) => {
                cy.fixture("requestPlacementQuote/success.json").then(
                    (requestPlacementQuoteRes: GraphQLResult<GraphQLPlacementCreationResponse>) => {
                        let dueInTime = DateTime.fromISO("2021-08-10", {
                            zone: "America/New_York"
                        }).plus({ minutes: 1 });
                        let tenMinsDueInTime = DateTime.fromISO("2021-08-10", {
                            zone: "America/New_York"
                        }).plus({ minutes: 10 });
                        switch (scenario) {
                            case "HY_request_mode_bin":
                                const fiveMinsDueInTime = DateTime.fromISO("2021-08-10", {
                                    zone: "America/New_York"
                                }).plus({ minutes: 5 });
                                requestPlacementQuoteRes.data.requestPlacementQuote[0].placements[0].basketID =
                                    "219721785~1667235267588";
                                basket.responses[
                                    Cypress.env().updateRfqCount
                                ].data.fiBasketSummary.placements[0].dueInTime = fiveMinsDueInTime.toMillis();
                                break;
                            case "HY_request_mode_asap":
                                const hourDueInTime = DateTime.fromISO("2021-08-10", {
                                    zone: "America/New_York"
                                }).plus({ hours: 1, seconds: 20 });
                                requestPlacementQuoteRes.data.requestPlacementQuote[0].placements[0].basketID =
                                    "219724585~1667240663713";
                                basket.responses[
                                    Cypress.env().updateRfqCount
                                ].data.fiBasketSummary.placements[0].dueInTime = hourDueInTime.toMillis();
                                break;
                            case "HY_response_table_SELL":
                            case "HY_response_table_large_order_leaves_SELL":
                            case "HY_response_table_BUY":
                            case "HY_response_table_perpetual_counter":
                            case "IG_response_grid_BUY":
                            case "IG_response_grid_SELL":
                            case "HY_venue_scenario_1":
                            case "HY_venue_scenario_3":
                            case "HY_venue_scenario_4":
                            case "HY_venue_scenario_5":
                            case "HY_venue_scenario_9":
                            case "HY_venue_scenario_10_timer_expires":
                            case "HY_venue_scenario_10_hit_broker":
                            case "HY_venue_scenario_10_counter_broker":
                            case "HY_venue_scenario_10_trader_cancels":
                            case "HY_venue_scenario_13":
                            case "HY_venue_scenario_14":
                            case "HY_venue_scenario_15":
                            case "HY_venue_scenario_16":
                            case "IG_venue_scenario_1":
                            case "IG_venue_scenario_2":
                            case "IG_venue_scenario_3":
                            case "IG_venue_scenario_6":
                            case "IG_venue_scenario_7":
                            case "IG_venue_scenario_8":
                            case "IG_venue_scenario_12":
                            case "HY_hybrid_scenario_1":
                            case "HY_hybrid_scenario_2":
                            case "HY_hybrid_scenario_3":
                                const expTime = DateTime.fromISO("2021-08-10", {
                                    zone: "America/New_York"
                                }).plus({ seconds: 30 });
                                basket.responses[Cypress.env().updateRfqCount].data.fiBasketSummary.placements.forEach(
                                    (p) => {
                                        p.quotes[0].expTime = expTime.toMillis();
                                        p.dueInTime = dueInTime.toMillis();
                                    }
                                );
                                break;
                            case "HY_counter":
                                requestPlacementQuoteRes.data.requestPlacementQuote[0].placements[0].basketID =
                                    "216976685~1664479919974";
                                break;
                            case "IG_counter":
                                requestPlacementQuoteRes.data.requestPlacementQuote[0].placements[0].basketID =
                                    "219723785~1667239823880";
                                break;
                            case "IG_response_filled":
                                const placements =
                                    basket.responses[Cypress.env().updateRfqCount].data.fiBasketSummary.placements;
                                placements.forEach((placement) => {
                                    placement.modifyReason = "Cancelation";
                                    placement.status = "Cancelled";
                                });
                                placements[0].modifyReason = "Trade Correct";
                                placements[0].status = "FILLED";
                                break;
                            case "HY_venue_request_mode_asap":
                                requestPlacementQuoteRes.data.requestPlacementQuote[0].placements[0].basketID =
                                    "612194212~1694031969558";
                                basket.responses[
                                    Cypress.env().updateRfqCount
                                ].data.fiBasketSummary.placements[0].dueInTime = tenMinsDueInTime.toMillis();
                                break;
                            case "IG_venue_request_mode_asap":
                                requestPlacementQuoteRes.data.requestPlacementQuote[0].placements[0].basketID =
                                    "605979810~1694110315875";
                                basket.responses[
                                    Cypress.env().updateRfqCount
                                ].data.fiBasketSummary.placements[0].dueInTime = tenMinsDueInTime.toMillis();
                                break;
                            case "HY_venue_hybrid_request_mode_asap":
                                requestPlacementQuoteRes.data.requestPlacementQuote[0].placements[0].basketID =
                                    "612194212~1694127038382";
                                basket.responses[
                                    Cypress.env().updateRfqCount
                                ].data.fiBasketSummary.placements[0].dueInTime = tenMinsDueInTime.toMillis();
                                break;
                            case "HY_venue_request_mode":
                                order.data.fiOrderSummary.venueBrokers = [
                                    {
                                        "brokerCode": 134400,
                                        "brokerName": "SIMTWEB",
                                        "executingBrokerCodes": [
                                            1033, 1045, 1643, 8211, 14419, 33882, 51056, 61860, 65910, 65911, 73030,
                                            129555, 129556, 129557, 129558
                                        ]
                                    }
                                ];
                                break;
                            case "IG_venue_request_mode":
                                order.data.fiOrderSummary.venueBrokers = [
                                    {
                                        "brokerCode": 134400,
                                        "brokerName": "SIMTWEB",
                                        "executingBrokerCodes": [129558, 129556, 1626]
                                    }
                                ];
                                break;
                            case "restrictions_venue":
                                order.data.fiOrderSummary.venueBrokers = [
                                    {
                                        "brokerCode": 134400,
                                        "brokerName": "SIMTWEB",
                                        "executingBrokerCodes": [
                                            5, 15, 25, 149, 165, 231, 1098, 1948, 4036, 61860, 62322, 135280, 135289,
                                            135294, 135295, 135300, 201639, 4164805, 61861, 73030, 1643
                                        ]
                                    }
                                ];
                                break;
                            case "HY_venue_request_mode_asap_empty_desks_direct":
                                order.data.fiOrderSummary.brokerAllocations!.find(
                                    (ba) => ba.broker.code === 129554
                                )!.broker.desks = [];
                                break;
                            case "HY_venue_request_mode_asap_empty_desks_venue":
                                order.data.fiOrderSummary.brokerAllocations!.find(
                                    (ba) => ba.broker.code === 154607
                                )!.broker.desks = [];
                                break;
                            case "HY_venue_request_mode_asap_empty_desks_both":
                                order.data.fiOrderSummary.brokerAllocations!.find(
                                    (ba) => ba.broker.code === 129554
                                )!.broker.desks = [];
                                order.data.fiOrderSummary.brokerAllocations!.find(
                                    (ba) => ba.broker.code === 154607
                                )!.broker.desks = [];
                                break;
                            default:
                                const defaultExpTime = DateTime.fromISO("2021-08-10", {
                                    zone: "America/New_York"
                                }).plus({ minutes: 2 });
                                basket.responses[Cypress.env().updateRfqCount].data.fiBasketSummary.placements.forEach(
                                    (p) => {
                                        p.quotes[0].expTime = defaultExpTime.toMillis();
                                        p.dueInTime = dueInTime.toMillis();
                                    }
                                );
                                break;
                        }
                        setupGraphQLIntercepts(undefined, {
                            order,
                            basket: basket.responses[Cypress.env().updateRfqCount],
                            requestPlacementQuote: requestPlacementQuoteRes
                        });
                        setupCommonIntercepts();
                        setupSecuritySearchIntercept();
                        setupDecodesIntercept("MODIFY_REASON");
                        visit(url);
                        waitFor("getPrefs");
                        waitFor("prices").then((interception) => {
                            // only wait for benchmark call if prices returns a valid response
                            if (interception.response.body) waitFor("benchmark");
                        });
                        waitFor("rfq");
                        cy.wait(2000);
                    }
                );
            }
        );
    });
});

Given("the date is {}", (date: string) => {
    cy.clock(createDate(date, "America/New_York").getTime(), ["Date"]);
    cy.get("body").realHover({ position: "topLeft" });
});

Given("I restore the clock", (date: string) => {
    cy.clock(0).invoke("restore");
});

Given("the time is frozen and the date is {}", (date: string) => {
    cy.clock(createDate(date, "America/New_York").getTime(), [
        "Date",
        "setInterval",
        "setTimeout",
        "clearInterval",
        "clearTimeout"
    ]);
    cy.get("body").realHover({ position: "topLeft" });
});

Given("the API calls will have status", (table: TableDefinition) => {
    let errorList: WorkflowError[] = [];
    table.hashes().forEach((elem) => {
        if (elem["status"] === "failure") {
            errorList.push(convertToWorkflowEnum(elem["API"], elem["reason"]));
        }
    });
    setupExecutionIntercepts(errorList);
});

/*************************
 **** ASSERT UI ELEMS ****
 *************************/
// And header should have attributes
//  |num|value|state}
Then("header should have attributes", (table: TableDefinition) => {
    assertAuxStepper(table.hashes().length, table);
});

// And Lift Table should have attributes
//  |key|value|
Then("{} table should have attributes", (tableName: string, table: TableDefinition) => {
    assertTable(tableName.toLowerCase(), table);
});

// And Lift[Lift] form should have attributes
//  |key|value|type
Then("{} form should have attributes", (formName: string, table: TableDefinition) => {
    assertForm(formName, table);
});

// And Confirmation form should have attributes
//  |key|value
Then("{} popup should have attributes", (formName: string, table: TableDefinition) => {
    assertPopup(formName, table);
});

// And table inside of Confirmation form should have 6 columns
Then("table inside of {} should have {} columns", (formName: string, numColumns: string) => {
    assertTableNumColumns(formName, parseInt(numColumns));
});

// And Alert dialog should have attributes
//  |key|value
Then("{} dialog should have attributes", (formName: string, table: TableDefinition) => {
    assertDialog(formName, true, table);
});

// And Alert dialog should not exist
Then("{} dialog should not exist", (formName: string) => {
    assertDialog(formName, false);
});

Then("rfq-response-table should have attributes", (table: TableDefinition) => {
    table.hashes().forEach((row, i) => {
        Object.keys(row).forEach((key) => {
            if (key === "Action Btns") {
                if (row[key] !== "-") {
                    const btns = row[key].split(",").map((btn) => ({
                        name: btn.split(":")[0],
                        states: btn.split(":").slice(1, btn.length)
                    }));
                    btns.forEach((btn) => {
                        btn.states.forEach((state) =>
                            verifyElementState(`${btn.name}-placement-${row["Broker"].toLowerCase()}`, state)
                        );
                    });
                }
            } else if (key === "Broker" && row[key].includes("-check-icon-")) {
                const brokerName = row[key].split("-check-icon-")[0].trim();
                const nameSelector = cy.get(`[data-test-id="${brokerName.toLowerCase()}-filled-name"]`);
                nameSelector.should("have.text", brokerName);

                const iconSelector = cy.get(`[data-test-id="${brokerName.toLowerCase()}-filled-icon"]`);
                iconSelector.should("have.class", "success-bold");
                iconSelector.should("have.class", "success");
            } else if (key === "Price" || key === "Spread") {
                const selector = cy.get(
                    `[data-test-id="rfq-response-table"] [data-index="${i}"] [data-test-id="rfq-response-table-pricingvalue"]`
                );
                selector.should("have.text", row[key], { timeout: 5000 });
            } else {
                const selector = cy.get(
                    `[data-test-id="rfq-response-table"] [data-index="${i}"] [data-test-id="rfq-response-table-${removeSpace(
                        key.toLowerCase()
                    )}"]`
                );
                selector.should("have.text", row[key], { timeout: 5000 });
            }
        });
    });
});

// And Broker Chips
//  | num | value | state   | checked |
Then("{} {} Broker Chips should have attributes", (num: number, brokerSource: brokerSource, table: TableDefinition) => {
    const containerKey = `${brokerSource}-broker-chips-container`;
    const list: any = [];
    cy.get(`[data-test-id="${removeSpace(containerKey)}"]`)
        .children()
        .should("have.length", num);
    table.hashes().forEach((elem) => {
        const key = `${brokerSource}-broker-chip-${removeSpace(elem["value"])}`;
        const value = elem.value;
        const enabled = elem["enabled"];
        const selected = elem["selected"];
        list.push({ key, value, enabled, selected });
    });
    cy.wrap(list).each((item: any) => {
        const enabledLabel = item.enabled === "true" ? "enabled" : "disabled";
        const selected = item.selected === "true" ? true : false;
        const control = item.key;
        const truncatedValue = item.value.length > 6 ? item.value.substring(0, 6) + "..." : item.value;
        assertElementHasLabel(control, truncatedValue);
        verifyElementState(control, enabledLabel);
        verifyElementState(control, "isondualstate", !selected);
    });
});

// And Next button should be enabled
Then("[{}] should be {}", (control: string, command: string) => {
    if (control.includes("splitbutton")) {
        // for selecting more complicated elements without direct data-test-id access IE Aladdin Web Components
        performCommand(control, command);
    } else {
        verifyElementState(control, command, false);
    }
});

// And Next should not be enabled
Then("[{}] should not be {}", (control: string, command: string) => {
    verifyElementState(control, command, true);
});

// I should see a warning alert notification
Then("I should see a {} {} notification", (style: string, type: "restrictions" | "alert" | "message bar") => {
    assertAuxNotification({ type, style });
});

// I should see a warning alert notification for [minTrdSize]
Then(
    "I should see a {} {} notification for [{}]",
    (style: string, type: "restrictions" | "alert" | "message bar", message: string) => {
        assertAuxNotification({ type, style }, message);
    }
);

// I should not see a warning alert notification for [minTrdSize]
Then(
    "I should not see a {} {} notification for [{}]",
    (style: string, type: "restrictions" | "alert" | "message bar", message: string) => {
        assertAuxNotification({ type, style }, message, true);
    }
);

// I close error alert notification
Then("I close {} {} notification", (style: string, type: "restrictions" | "alert" | "message bar") => {
    closeAuxNotification({ type, style });
});

// I should see a yellow message bar with message [Confirm Cancel]
Then("I should see a {} message bar with message [{}]", (color: string, message: string) => {
    let style = "error";
    if (color === "green") style = "success";
    if (color === "yellow") style = "warning";
    assertAuxNotification({ type: "message bar", style }, message);
});

// And Lift[Lift] form should show error
// | key  | error | type |
Then("{} form should {} error", (formName: string, type: "show" | "not show", table: TableDefinition) => {
    assertFormError(formName, table, type);
});

// And Lift[Lift] form have disabled fields
// | key  | error | type |
Then("{} form should have disabled fields", (formName: string, table: TableDefinition) => {
    assertFormFieldsMode(formName, table, false);
});

// And Lift[Lift] form have enabled fields
// | key  | error | type |
Then("{} form should have enabled fields", (formName: string, table: TableDefinition) => {
    assertFormFieldsMode(formName, table, true);
});

//  And I should see 2 options for restrictions
// | num | key | value
Then("I should see {} options for {}", (numOptions: number, control: string, table?: TableDefinition) => {
    let parentSelector;
    let selector;
    switch (control) {
        case "direct-brokers-restrictions-list":
        case "simtweb-brokers-restrictions-list":
            for (let i = 0; i < numOptions; i++) {
                parentSelector = `[data-test-id="${control}"]`;
                selector = `${parentSelector} [data-test-id="restrictioncard${i + 1}"]`;
                assertAuxCard(selector, table!, i);
            }
            break;
        default:
            selector = control;
    }
});

Then("element {} contains text {}", (element: string, text: string) => {
    // this is a substring test
    assertElementContainsText(element, text);
});

//I have hovered over row 2 column Size
Then("I have hovered over row {} column {}", (row: number, column: string) => {
    cy.get(
        `[data-test-id="rfq-response-table"] [data-index="${row - 1}"] [data-test-id="rfq-response-table-${removeSpace(
            column.toLowerCase()
        )}"]`
    ).realHover();
});

Then("element {} should have text {}", (element: string, text: string) => {
    // this is an exact test for text content
    assertElementHasText(element, text);
});

Then("button [{}] should have label {}", (element: string, text: string) => {
    // this is an exact test for text content
    assertElementHasLabel(element, text);
});

Then("element {} exists", (element: string) => {
    assertElementExists(element);
});

Then("element {} does not exist", (element: string) => {
    assertElementNotExists(element);
});

// for asserting AUX Select Option State
Then("select option {} should be {}", (value: string, state: string) => {
    assertSelectOptionState(value, state);
});

Then(`{}-pricingprotocol should be disabled`, (element: string) => {
    const selector = `[data-test-id="${element}-pricingprotocol"]`;
    cy.get(selector).find('[data-test="aux-radio--input"]').should("be.disabled");
});

Then(`{}-pricingprotocol should be enabled`, (element: string) => {
    const selector = `[data-test-id="${element}-pricingprotocol"]`;
    cy.get(selector).find('[data-test="aux-radio--input"]').should("be.enabled");
});

Then(`{}-dueprotocol should be disabled`, (element: string) => {
    const selector = `[data-test-id="${element}-dueprotocol"]`;
    cy.get(selector).find('[data-test="aux-radio--input"]').should("be.disabled");
});

Then("icon {} has type {}", (selector: string, type: string) => {
    cy.get(`[data-test-id="${selector}"]`).should("have.class", type);
});

Then("icon {} does not exist", (selector: string, type: string) => {
    cy.get(`[data-test-id="${selector}"]`).should("not.exist");
});

Then("I verify select {} has option set to {}", (element: string, value: string) => {
    assertAuxSelectText(element, value);
});

Then("I see {} elements for this selector {} under {}", (num: string, selector: string, element: string) => {
    const n = parseInt(num);
    assertNumElements(n, selector, element === "none" ? undefined : element);
});

Then("the {} {} benchmark is not editable", (table: string, type: string) => {
    let selector = `${removeSpace(table)}-${type}bmk`;

    cy.get(`[data-test-id="${selector}"]`).find("aux-icon[type='edit']").should("not.exist");
});

/*************************
 ******** UTILITY ********
 *************************/

Then("I dispatch {}", (action: { type: string; payload: any }) => {
    dispatchAction(action);
});

Then("placement data has updated", () => {
    Cypress.env().updateRfqCount++;
    setupBasketIntercepts(Cypress.env().updateRfqCount);
});

Then("I verify that atom {} has {} {}", (atom: string, property: string, state: any) => {
    verifyAtom(atom, property, state);
});

Then("I verify localStorage {} is {}", (item: string, state: any) => {
    verifyLocalStorage(item, state);
});

Then("I pop a {} dialog with text {}", (type: string, message: string) => {
    dispatchAction({
        type: "SET_ALERT",
        payload: [
            {
                id: 1,
                message: message,
                type: type
            }
        ]
    });
});

// And I have style [{offsetWidth: 60px}] for [Counter-Placement]
Then("I have style {} for [{}]", (style: string, control: string) => {
    verifyStyle(control, style);
});

// And I have classname filled-broker for [simjs-filled-row]
Then("I have classname {} for [{}]", (classname: string, control: string) => {
    control = removeSpace(control);
    const selector = getTestSelector(control);
    cy.get(selector).should("have.attr", "class", classname);
});

/*******************************
 **** PERFORM USER ACTIONS  ****
 *******************************/

// for selecting an AUX Select option from dropdown
Then("I select option {}", (value: string) => {
    selectOption(value);
});

// And I have clicked [Next]
Then("I have {} [{}]", (command: string, control: string) => {
    performCommand(control, command);
});

// When I populate the Lift[Lift] form with
//  | key  | value | type  |
Then("I populate the {} form with", (formName: string, table: TableDefinition) => {
    populateForm(formName, table);
});

// And I press/release Ctrl Shift X or C
Then("I {} Ctrl Shift {}", (command: string, key: string) => {
    performCtrlShift(key, removeSpace(command) === "release");
});

Then("I select the {} header option", (n: string) => {
    const num = convertNumberStringToNumber(n);
    setAuxStepper(num);
});

Then("I {} the {} restriction", (action: string, n: string) => {
    const num = convertNumberStringToNumber(n);
    const selector = `[data-test-id="restrictioncard${num + 1}"]`;
    toggleExpandOnAuxCard(selector, num);
});

Then(`I set the {} radio group to {}`, (name: string, category: string) => {
    const selector = `[data-test-id=${name}]`;
    cy.get(selector).find(`aux-radio[label="${category}"]`).find("input").click({ force: true });
});

Then("I see select options for [{}]", (control: string, table: TableDefinition) => {
    let options: string[] = [];
    table.hashes().forEach((elem) => {
        options.push(elem["option"]);
    });
    performCommand(control, "opened select");
    assertAuxSelectDropdownOptions(control, options);
    // click on select dropdown to close again
    performCommand(control, "opened select");
});

Then("I click to edit the {} {} benchmark", (table: string, type: string) => {
    let selector = `${removeSpace(table)}-${type}bmk`;

    cy.get(`[data-test-id="${selector}"]`).find("aux-icon").click({ multiple: true, force: true });
    cy.get(`[data-test-id="${selector}"]`).find("aux-text-input").should("be.visible");
});

Then("I set the {} {} benchmark to {}", (table: string, type: string, value: string) => {
    let selector = `${removeSpace(table)}-${type}bmk`;
    cy.get(`[data-test-id="${selector}"]`).find("aux-text-input").find("input").type(value, { delay: 50 });

    cy.wait(1000);
    cy.get(`.aux-type-ahead__table-cell div[title="${value}"]`).click();
});

Then("I right click to open context menu and click on {}", (menuItem: string) => {
    const selector = "context-menu";

    cy.get("body").rightclick();
    cy.get(`[data-test-id="${selector}"]`).contains(menuItem).click();
});

Then("I click on {} key", (key: string) => {
    cy.get("body").type(`{${key}}`);
});

Then("I dismiss the benchmark typeahead dropdown if present", (key: string) => {
    cy.get('[data-test-id="rfq-trade-form-control-benchmark"]').blur();
});

/**************************
 **** WAIT FOR THINGS  ****
 **************************/

Then("Broker entities has completed", () => {
    waitFor("brokerEntity");
});

Then("HY CARE order has loaded", () => {
    waitFor("brokerEntity");
    waitFor("care");
});

Then("IG CARE order has loaded", () => {
    waitFor("brokerEntity");
    waitFor("care");
    waitFor("prices");
    waitFor("benchmark");
});

Then("HY order has loaded", () => {
    // wait that we have data
    waitFor("brokerEntity");
    waitFor("orders");
});

Then("IG order has loaded", () => {
    // wait that we have data
    waitFor("brokerEntity");
    waitFor("orders");
    waitFor("prices");
    waitFor("benchmark");
});

// And Validate Quick Place has finished
Then("{} has finished", (control: string) => {
    waitFor(control);
});

// And Request Placement Quote was called 1 times
Then("{} was called {} times", (control: string, numTimes: number) => {
    calledNumTimes(control, numTimes);
});

// And Validate Quick Place has not finished
Then("{} has not finished", (control: string) => {
    calledNumTimes(control, 0);
});

// And Validate Quick Place has finished with req variables
Then("{} has finished with", (control: string, table: TableDefinition) => {
    waitFor(control, table);
});

Then("I wait for the page to change", () => {
    cy.wait(1000);
});

Then("I wait {} secs", (secs: string) => {
    cy.wait(parseInt(secs) * 1000);
});

// NOTE: Be careful using this with API calls, ATW will return "REJECTED" if it passes 5-10 seconds by default.
// Waiting for a GQL to be finished won't work here since the ATW wrapper is what dispatches the "REJECTED" action
Then("{} {} pass", (amount: string, timeUnit: "secs" | "mins" | "hours") => {
    let miliseconds;
    switch (timeUnit) {
        case "secs":
            miliseconds = parseInt(amount) * 1000;
            break;
        case "mins":
            miliseconds = parseInt(amount) * 60000;
            break;
        case "hours":
            miliseconds = parseInt(amount) * 3600000;
            break;
    }
    cy.tick(miliseconds);
    // re-focus on cypress body in case tick unfocuses it
    cy.get("body").click(0, 0);
});
