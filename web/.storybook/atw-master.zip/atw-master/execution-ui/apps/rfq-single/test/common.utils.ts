import { TableDefinition } from "cypress-cucumber-preprocessor";
import { genericUtils } from "../src/common/utils";

// API / INTERCEPT UTILS
export enum ApiQuery {
    ORDER_RFQ_QUERY = "queryfiOrderSummary($ordNum:Int!,$user:String!,$rfqExecution:Boolean!){fiOrderSummary(ordNum:$ordNum,user:$user,rfqExecution:$rfqExecution){",
    ORDERLEAVES_QUERY = "queryfiOrderSummary($ordNum:Int!){fiOrderSummary(ordNum:$ordNum){",
    VALIDATE_PLACEMENTS_COUNTERING_MUTATION = "mutationvalidatePlacementsCountering($request:PlacementQuoteRequest!,$warnings:String,$user:String){validatePlacementsCountering(request:$request,warnings:$warnings,user:$user){",
    VALIDATE_PLACEMENTS_EXECUTION_MUTATION = "mutationvalidatePlacementsExecution($request:PlacementQuoteExecute!,$user:String){validatePlacementsExecution(request:$request,user:$user){",
    REQUEST_PLACEMENT_QUOTE_QUERY = "mutationrequestPlacementQuote($request:PlacementQuoteRequest!,$user:String){requestPlacementQuote(request:$request,user:$user){",
    COUNTER_RFQ_ACCEPT_QUERY = "mutationexecutePlacementQuote($request:PlacementQuoteExecute!,$quotes:[PlacementQuotes],$user:String){executePlacementQuote(request:$request,quotes:$quotes,user:$user){",
    COUNTER_RFQ_PLACEMENT_QUOTE_MUTATION = "mutationcounterPlacementQuote($request:PlacementQuoteExecute!,$quotes:[PlacementQuotes],$user:String){counterPlacementQuote(request:$request,quotes:$quotes,user:$user){",
    PRICES_QUERY = "queryprices($cusips:[String!],$startInclusive:BFMTimestamp){prices(cusips:$cusips,startInclusive:$startInclusive){",
    BENCHMARK_QUERY = "queryfiAsset($secId:String){fiAsset(secId:$secId){",
    BASKET_QUERY = "queryfiBasketSummary($basketId:String!,$user:String!){fiBasketSummary(basketId:$basketId,user:$user){",
    CANCEL_RFQ_QUERY = "mutationcancelRFQPlacements($placementNumList:[Int!],$user:String!){",
    GET_FILES_DAT = "/std/files.dat",
    GET_DECODES = "/api/reference-data/decodes/v1/decode?sets=",
    CANCEL_ERROR_PLACEMENTS_MUTATION = "mutationcancelErrorPlacements($placementNumList:[Int!],$user:String!){",
    GET_PREFS = "/weblications/etc/getPrefs.epl?appID=at-rfq-single",
    SET_PREFS = "/weblications/etc/setPrefs.epl"
}
export const ApiAliases = {
    [ApiQuery.ORDER_RFQ_QUERY]: "gqlOrderRFQ",
    [ApiQuery.ORDERLEAVES_QUERY]: "gqlOrderLeaves",
    [ApiQuery.VALIDATE_PLACEMENTS_COUNTERING_MUTATION]: "gqlValidatePlacementsCountering",
    [ApiQuery.REQUEST_PLACEMENT_QUOTE_QUERY]: "gqlRequestPlacementQuote",
    [ApiQuery.PRICES_QUERY]: "gqlPrices",
    [ApiQuery.BENCHMARK_QUERY]: "gqlBenchmark",
    [ApiQuery.COUNTER_RFQ_ACCEPT_QUERY]: "gqlCounterRfqAccept",
    [ApiQuery.COUNTER_RFQ_PLACEMENT_QUOTE_MUTATION]: "gqlCounterRfqPlacementQuote",
    [ApiQuery.VALIDATE_PLACEMENTS_EXECUTION_MUTATION]: "gqlValidatePlacementsExecution",
    [ApiQuery.BASKET_QUERY]: "gqlBasket",
    [ApiQuery.CANCEL_RFQ_QUERY]: "gqlCancelRFQ",
    [ApiQuery.GET_FILES_DAT]: "getFilesDat",
    [ApiQuery.GET_DECODES]: "getDecodes",
    [ApiQuery.CANCEL_ERROR_PLACEMENTS_MUTATION]: "gqlCancelErrorPlacements",
    [ApiQuery.GET_PREFS]: "getPrefs",
    [ApiQuery.SET_PREFS]: "setPrefs"
};

export const getTestSelector = (key: string) => `[data-test-id="${key}"]`;

export function getWaitString(query: ApiQuery): string {
    return "@" + [ApiAliases[query]];
}

// FORM UTILS
export interface AuxFormDefinition {
    type?: string;
    key?: string;
    label?: string;
    mode?: string;
    value?: any;
    error?: any;
    num?: number;
    visible?: boolean;
}

export function convertTableDefinitionToList(table: TableDefinition): AuxFormDefinition[] {
    const list: AuxFormDefinition[] = [];
    table.hashes().forEach((elem) => {
        const type = elem["type"];
        const key = genericUtils.removeSpace(elem["key"]);
        const label = elem["label"];
        const value = elem["value"];
        const error = elem["error"];
        const num = parseInt(elem["num"]);
        const mode = elem["mode"];
        const visible = elem["visible"] ? elem["visible"] === "true" : undefined;
        list.push({ key, label, value, type, error, num, mode, visible });
    });
    return list;
}

// ERROR UTILS
export enum WorkflowError {
    CANCEL_RFQ_QUERY_RESPONSE_NULL = "CANCEL_RFQ_QUERY_RESPONSE_NULL",
    CANCEL_RFQ_QUERY_RESPONSE_DATA_NULL = "CANCEL_RFQ_QUERY_RESPONSE_DATA_NULL",
    CANCEL_RFQ_QUERY_RESPONSE_DATA_FIORDERSUMMARY_NULL = "CANCEL_RFQ_QUERY_RESPONSE_DATA_FIORDERSUMMARY_NULL",

    ORDER_RFQ_QUERY_RESPONSE_NULL = "ORDER_RFQ_QUERY_RESPONSE_NULL",
    ORDER_RFQ_QUERY_RESPONSE_DATA_NULL = "ORDER_RFQ_QUERY_RESPONSE_DATA_NULL",
    ORDER_RFQ_QUERY_RESPONSE_DATA_FIORDERSUMMARY_NULL = "ORDER_RFQ_QUERY_RESPONSE_DATA_FIORDERSUMMARY_NULL",

    PRICES_RESPONSE_NULL = "PRICES_RESPONSE_NULL",
    PRICES_RESPONSE_DATA_NULL = "PRICES_RESPONSE_DATA_NULL",
    PRICES_RESPONSE_DATA_PRICES_NULL = "PRICES_RESPONSE_DATA_PRICES_NULL",
    PRICES_RESPONSE_DATA_PRICES_EMPTY = "PRICES_RESPONSE_DATA_PRICES_EMPTY",
    PRICES_RESPONSE_DATA_INDEX_NAME_NULL = "PRICES_RESPONSE_DATA_INDEX_NAME_NULL",

    BENCHMARK_RESPONSE_NULL = "BENCHMARK_RESPONSE_NULL",
    BENCHMARK_RESPONSE_DATA_NULL = "BENCHMARK_RESPONSE_DATA_NULL",
    BENCHMARK_RESPONSE_DATA_FIASSET_NULL = "BENCHMARK_RESPONSE_DATA_FIASSET_NULL",
    BENCHMARK_RESPONSE_DATA_BASSET_NULL = "BENCHMARK_RESPONSE_DATA_BASSET_NULL",

    VALIDATE_PLACEMENTS_COUNTERING_MUTATION_RESPONSE_NULL = "VALIDATE_PLACEMENTS_COUNTERING_MUTATION_RESPONSE_NULL",
    VALIDATE_PLACEMENTS_COUNTERING_MUTATION_MIN_AMOUNT = "VALIDATE_PLACEMENTS_COUNTERING_MUTATIOL_MIN_AMOUNT",
    VALIDATE_PLACEMENTS_COUNTERING_MUTATION_GENERIC_ERROR = "VALIDATE_PLACEMENTS_COUNTERING_MUTATION_GENERIC_ERROR",
    VALIDATE_PLACEMENTS_COUNTERING_MUTATION_UNSPECIFIED_RESPONSE_TYPE = "VALIDATE_PLACEMENTS_COUNTERING_MUTATION_UNSPECIFIED_RESPONSE_TYPE",

    VALIDATE_PLACEMENTS_EXECUTION_MUTATION_RESPONSE_NULL = "VALIDATE_PLACEMENTS_EXECUTION_MUTATION_RESPONSE_NULL",
    VALIDATE_PLACEMENTS_EXECUTION_MUTATION_RESPONSE_WARNING = "VALIDATE_PLACEMENTS_EXECUTION_MUTATION_RESPONSE_WARNING",
    VALIDATE_PLACEMENTS_EXECUTION_MUTATION_RESPONSE_ERROR = "VALIDATE_PLACEMENTS_EXECUTION_MUTATION_RESPONSE_ERROR",

    VALIDATE_COUNTER_RFQ_PLACEMENT_QUOTE_RESPONSE_NULL = VALIDATE_PLACEMENTS_EXECUTION_MUTATION_RESPONSE_NULL,
    VALIDATE_COUNTER_RFQ_PLACEMENT_QUOTE_RESPONSE_WARNING = VALIDATE_PLACEMENTS_EXECUTION_MUTATION_RESPONSE_WARNING,
    VALIDATE_COUNTER_RFQ_PLACEMENT_QUOTE_RESPONSE_ERROR = VALIDATE_PLACEMENTS_EXECUTION_MUTATION_RESPONSE_ERROR,

    VALIDATE_REQUEST_PLACEMENT_QUOTE_RESPONSE_NULL = VALIDATE_PLACEMENTS_COUNTERING_MUTATION_RESPONSE_NULL,
    VALIDATE_REQUEST_PLACEMENT_QUOTE_MIN_AMOUNT = VALIDATE_PLACEMENTS_COUNTERING_MUTATION_MIN_AMOUNT,
    VALIDATE_REQUEST_PLACEMENT_QUOTE_GENERIC_ERROR = VALIDATE_PLACEMENTS_COUNTERING_MUTATION_GENERIC_ERROR,
    VALIDATE_REQUEST_PLACEMENT_QUOTEN_UNSPECIFIED_RESPONSE_TYPE = VALIDATE_PLACEMENTS_COUNTERING_MUTATION_UNSPECIFIED_RESPONSE_TYPE,

    VALIDATE_COUNTER_ACCEPT_RESPONSE_NULL = "VALIDATE_PLACEMENTS_EXECUTION_MUTATION_RESPONSE_NULL",
    VALIDATE_COUNTER_ACCEPT_RESPONSE_WARNING = "VALIDATE_PLACEMENTS_EXECUTION_MUTATION_RESPONSE_WARNING",
    VALIDATE_COUNTER_ACCEPT_RESPONSE_ERROR = "VALIDATE_PLACEMENTS_EXECUTION_MUTATION_RESPONSE_ERROR",

    REQUEST_PLACEMENT_QUOTE_ERROR = "REQUEST_PLACEMENT_QUOTE_ERROR",
    REQUEST_PLACEMENT_QUOTE_RESPONSE_NULL = "REQUEST_PLACEMENT_QUOTE_RESPONSE_NULL",
    REQUEST_PLACEMENT_QUOTE_RESPONSE_HAS_GQL_ERRORS = "REQUEST_PLACEMENT_QUOTE_RESPONSE_HAS_GQL_ERRORS",

    COUNTER_ACCEPT_ERROR = "COUNTER_ACCEPT_ERROR",
    COUNTER_ACCEPT_RESPONSE_NULL = "COUNTER_ACCEPT_RESPONSE_NULL",

    COUNTER_COUNTER_ERROR = "COUNTER_COUNTER_ERROR",
    COUNTER_COUNTER_RESPONSE_NULL = "COUNTER_COUNTER_RESPONSE_NULL",

    COUNTER_PASS_ERROR = "COUNTER_PASS_ERROR",
    COUNTER_PASS_RESPONSE_NULL = "COUNTER_PASS_RESPONSE_NULL",

    BASKET_QUERY_RESPONSE_NULL = "ORDER_QUERY_RESPONSE_NULL",
    BASKET_QUERY_RESPONSE_DATA_NULL = "ORDER_QUERY_RESPONSE_DATA_NULL",
    BASKET_QUERY_RESPONSE_DATA_FIBASKETSUMMARY_NULL = "ORDER_QUERY_RESPONSE_DATA_FIORDERSUMMARY_NULL",

    ORDERLEAVES_QUERY_RESPONSE_NULL = "ORDERLEAVES_QUERY_RESPONSE_NULL",
    ORDERLEAVES_QUERY_RESPONSE_DATA_NULL = "ORDERLEAVES_QUERY_RESPONSE_DATA_NULL",
    ORDERLEAVES_QUERY_RESPONSE_CHANGED_ORDERLEAVES = "ORDERLEAVES_QUERY_RESPONSE_CHANGED_ORDERLEAVES",

    CANCEL_ERROR_PLACEMENTS_MUTATION_RESPONSE_ERROR = "CANCEL_PLACEMENTS_MUTATION_RESPONSE_ERROR"
}

export function convertToWorkflowEnum(...words: string[]): WorkflowError {
    let result = "";
    words.forEach((word) => {
        result += "_" + word.replace(/ /g, "_").toUpperCase();
    });
    result = result.substring(1);
    return result as WorkflowError;
}

// Removes all whitespace, i.e. new line, carriage return, spaces
export function stripAllWhitespace(input: string): string {
    return input.replace(/\n|\r|\ /g, "");
}

// Converts first = 0, second = 1, third = 2
export function convertNumberStringToNumber(n: string): number {
    let num = 0;
    if (n === "second") {
        num = 1;
    } else if (n === "third") {
        num = 2;
    }
    return num;
}

export function cleanJSON(someJson: string) {
    return someJson;
}
