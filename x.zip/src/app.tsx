import {Provider} from "react-redux";
import {store} from "./redux/store";
import DebugInfo from "./components/debugInfo";
import React from "react";

import "./app.css";

type Props = {
    children: JSX.Element;
};

const App = ({children}: Props) => {
    return (
        <div className="App">
            <Provider store={store}>
                <DebugInfo/>
                {children}
            </Provider>
        </div>
    );
};

export default App;
