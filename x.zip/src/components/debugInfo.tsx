import { useCallback, useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { AppState } from "../redux/store";
import JSZip from "jszip";
import FileSaver from "file-saver";

/**
 * The purpose of this component is to add a hidden row to the summary section that expands to debug information
 * when a secret key sequence is pressed. This is fundamental to troubleshoot in production and allows us to
 * avoid depending on console.log.
 *
 * @constructor
 */
export default function DebugInfo() {
    const params = useSelector<AppState, any>(state => state.params);
    const [display, setDisplay] = useState<boolean>(false);

    const keydownCallback = useCallback(event => {
        if (event.key === "X" && event.ctrlKey) {
            event.preventDefault();
            event.stopPropagation();
            setDisplay(true);
        } else {
            setDisplay(false);
        }
    }, []);

    useEffect(() => {
        window.addEventListener("keydown", keydownCallback);
        return () => {
            window.removeEventListener("keydown", keydownCallback);
        };
    }, [keydownCallback]);

    const downloadState = useCallback(() => {
        const zip = new JSZip();
        zip.file("state.json", JSON.stringify((window as any).store.getState(), null, 4));
        zip.generateAsync({ type: "blob" })
            .then(blob => {
                FileSaver.saveAs(blob, "store-snapshot.zip");
            })
            .catch(console.error);
    }, []);

    return display ? (
        <div className="debug-info">
            <div className="item">
                <label>Location:</label>
                <span>{`${window.location}`}</span>
            </div>
            <div className="item">
                <label style={{ marginRight: 25 }}>Redux</label>
                <div>
                    <button onClick={downloadState}>snapshot</button>
                </div>
            </div>
        </div>
    ) : null;
}
