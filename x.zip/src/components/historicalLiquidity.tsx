import "./historical-liquidity.scss";
import {useCallback, useEffect, useMemo, useState} from "react";
import {AtwCellRenderer, AtwColumnDef, AtwGrid, AtwGroupBy, AtwGroupTotals} from "@atw/components";
import {useDispatch, useSelector} from "react-redux";
import {AppState} from "../redux/store";
import {Axe, AXE_COLUMNS} from "../model/axe";
import {fetchHistoricalLiquidity} from "../redux/actions";
import {formatDateTime} from "../util/format";
import {AtwChart} from "@atw/components";

const columnRenderers: Partial<Record<keyof Axe, AtwCellRenderer<Axe>>> = {
    effectiveTime: axe => <div
        className="atw-grid-cell-content effectiveTime">{formatDateTime(axe.effectiveTime)}</div>,
    modifiedTime: axe => <div className="atw-grid-cell-content modifiedTime">{formatDateTime(axe.modifiedTime)}</div>,
    expiryTime: axe => <div className="atw-grid-cell-content expiryTime">{formatDateTime(axe.expiryTime)}</div>,
    createdTime: axe => <div className="atw-grid-cell-content createdTime">{formatDateTime(axe.createdTime)}</div>
};

const visible = new Set([
    "brokerTicker",
    "axeType",
    "axeId",
    "status",
    "secId",
    "tranType",
    "actualSize",
    "source",
    "brokerCode",
    "priceCurrency",
    "priceType",
    "price",
    "benchId",
    "benchIdType",
    "benchAladdinId",
    "submittedBy",
    "effectiveTime",
    "modifiedBy",
    "modifiedTime",
    "naturalFlag",
    "expiryType",
    "expiryTime",
    "createdTime"
]);

function isVisible(column: AtwColumnDef<Axe>): boolean {
    return visible.has(column.field);
}

export function HistoricalLiquidity() {
    const dispatch = useDispatch();
    const axes = useSelector<AppState, Axe[]>(state => state.data);

    useEffect(() => {
        dispatch(fetchHistoricalLiquidity({}));
    }, []);

    const [groupBy, setGroupBy] = useState<AtwGroupBy<Axe>>(() => {
        const params = new URLSearchParams(window.location.search);
        const groupBy = params.get("groupBy");
        const groups = groupBy ? [...new Set(groupBy.split(","))] : [];
        return new Map(groups.map(field => [field, new Map()])) as AtwGroupBy<Axe>;
    })

    const [columnDefs, setColumnDefs] = useState<AtwColumnDef<any>[]>(() => AXE_COLUMNS
        .filter(isVisible)
        .map(column => ({
            ...column,
            render: columnRenderers[column.field],
            pinned: column.pinned || groupBy.has(column.field)
        }))
    );

    const onDnD = useCallback((startIndex, endIndex) => {
        const result = [...columnDefs];
        const [removed] = result.splice(startIndex, 1);
        result.splice(endIndex, 0, removed);
        setColumnDefs(result);
    }, [columnDefs]);

    return (
        <div className="historical-liquidity">
            {/*<AtwGrid data={axes} columnDefs={columnDefs} groupBy={groupBy} onDnD={onDnD} onGroupBy={(gb)=>{*/}
            {/*    console.log("gb", gb)*/}
            {/*    setGroupBy(gb);*/}
            {/*}}/>*/}
            <AtwChart data={axes}/>
        </div>
    );
}
