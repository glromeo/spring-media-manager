import React from "react";
import ReactDOM from "react-dom";
import App from "./app";

import {HistoricalLiquidity} from "./components/historicalLiquidity";

import "./index.scss";

// import {bootstrapComponents} from "@atw/components";
// import {bootstrapTelemetry} from "@atw/telemetry";
//
// bootstrapComponents();
// bootstrapTelemetry("market-depth-ui", "testUser");

ReactDOM.render(
    <App>
        <HistoricalLiquidity/>
    </App>,
    document.getElementById("root")
);

if (process.env.NODE_ENV === "development") {
    Object.defineProperty(window, "$", {value: require("jquery")});
}
