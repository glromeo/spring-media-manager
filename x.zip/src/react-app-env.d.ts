/// <reference types="react-scripts" />
declare namespace JSX {
}
