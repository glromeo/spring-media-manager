import {createAction, createAsyncThunk} from "@reduxjs/toolkit";
import {Axe} from "../model/axe";

export const gridMode = createAction("GRID_MODE");
export const chartsMode = createAction("CHARTS_MODE");

import mock from "../__mock__/axes.json";

export const fetchHistoricalLiquidity = createAsyncThunk<Axe[], any>(
    "FETCH_HISTORICAL_LIQUIDITY", async args => {
        return mock.map(row => {
            return {
                id: row.axeId,
                ...row,
                effectiveTime: row.effectiveTime ? new Date(row.effectiveTime) : null,
                modifiedTime: row.modifiedTime ? new Date(row.modifiedTime) : null,
                expiryTime: row.expiryTime ? new Date(row.expiryTime) : null,
                createdTime: row.createdTime ? new Date(row.createdTime) : null,
            }
        }) as unknown as Axe[];
    }
);
