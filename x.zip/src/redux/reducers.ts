import {combineReducers, createReducer} from "@reduxjs/toolkit";
import {Axe} from "../model/axe";
import {chartsMode, fetchHistoricalLiquidity, gridMode} from "./actions";

const data = createReducer<Axe[]>([] as Axe[], builder => builder
    .addCase(fetchHistoricalLiquidity.fulfilled, (current, {payload: data}) => {
        return data;
    })
);

const mode = createReducer<string>("grid", builder => builder
    .addCase(gridMode, () => "grid")
    .addCase(chartsMode, () => "charts")
);

export const rootReducer = combineReducers({
    mode,
    data
});
