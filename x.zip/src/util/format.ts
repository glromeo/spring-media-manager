import { OrderMetrics } from "../models/order";
import { PricingType } from "../models/security";
import { AppState } from "../redux/store";

export type Quantity = `${number}` | `${number}M` | `${number}MM` | "0" | "";

export function formatTime(value: Date | string | number | null): string {
    try {
        if (!(value instanceof Date)) {
            value = new Date(Number(value));
        }
        return value.toTimeString().substring(0, 8);
    } catch (ignored) {
        // invalid time value, we don't show anything in the cell
    }
    return "";
}

export function formatDateTime(value: Date | string | number | null): string {
    try {
        if (!(value instanceof Date)) {
            value = new Date(Number(value));
        }
        return value.toISOString().slice(0, -5).replace("T", " ");
    } catch (ignored) {
        // invalid time value, we don't show anything in the cell
    }
    return "";
}

export function formatTimer(value: number | null): string {
    try {
        if (value) {
            return new Date(value).toISOString().substr(11, 8);
        }
    } catch (ignored) {
        // invalid time value, we don't show anything in the cell
    }
    return "";
}

export function parseDate(maturity: string): string {
    const splitDate = maturity.split("-");
    const mm = splitDate[1];
    const yy = splitDate[0].slice(2);
    const dd = splitDate[2];
    return `${mm}/${dd}/${yy}`;
}

const priceFormat = Intl.NumberFormat(navigator.language, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 4,
});

const spreadFormat = Intl.NumberFormat(navigator.language, {
    signDisplay: "always",
    minimumFractionDigits: 2,
    maximumFractionDigits: 4,
});

const quantityFormat = Intl.NumberFormat(navigator.language, {
    minimumFractionDigits: 0,
});

export function formatPrice(price: number | null, na = "-"): string {
    if (price) {
        return priceFormat.format(price);
    } else {
        return price === 0 ? "0.00" : na;
    }
}

export function formatSpread(spread: number | null, na = "-"): string {
    if (spread) {
        return spreadFormat.format(spread);
    } else {
        return spread === 0 ? "+0.00" : na;
    }
}

export function formatQuantity(quantity: number | null, na = "-"): string {
    if (quantity) {
        // if (quantity >= 1_000_000_000) {
        //     return `${Math.floor(quantity / 10_000_000) / 100}B` as Quantity;
        // }
        // if (quantity >= 1_000_000) {
        //     return `${Math.floor(quantity / 10_000) / 100}M` as Quantity;
        // }
        // if (quantity >= 1_000) {
        //     return `${Math.floor(quantity / 10) / 100}K` as Quantity;
        // }
        // return String(quantity) as Quantity;
        return quantityFormat.format(quantity);
    } else {
        return quantity === 0 ? "0" : na;
    }
}

export function parseQuantity(quantity: Quantity): number {
    return quantity ? parseInt(quantity) * parseFactor(quantity) : 0;
}

function parseFactor(quantity: `${number}` | `${number}M` | `${number}MM`): number {
    return quantity.endsWith("M") ? (quantity.endsWith("MM") ? 1_000_000 : 1_000) : 1;
}

export function getYesterdaysDateAsEpoch() {
    const date = new Date();
    date.setDate(date.getDate() - 1);
    date.setHours(0, 0, 0, 0);

    return date.getTime();
}

export const expectedCostFormatter = ([orderMetrics]: [OrderMetrics], state: AppState) => {
    const pricingType: PricingType = state.pricingType;
    if (!orderMetrics) {
        return undefined;
    } else {
        if (pricingType === "spread") {
            return formatSpread(orderMetrics?.expectedCostBps ?? null);
        } else {
            return formatPrice(orderMetrics.expectedCost ?? null);
        }
    }
};

export const liquidityScoreFormatter = (liquidityScore: number | null) => {
    if (liquidityScore !== null && isNaN(liquidityScore)) {
        return undefined;
    } else {
        return liquidityScore ? liquidityScore.toString() : null;
    }
};

export const maturityFormatter = (maturity: string) => {
    return new Date(maturity).toLocaleDateString();
};

export const orderSideFormatter = (transactionType: string) => {
    return transactionType === "BUY" ? "Buy" : "Sell";
};

export const percentAdvFormatter = (orderMetrics: OrderMetrics) => {
    if (!orderMetrics) {
        return undefined;
    } else {
        const percentAdv = orderMetrics?.advForecastPct ?? null;
        return percentAdv !== null ? percentAdv.toPrecision(3) : null;
    }
};

export const unbookedAmountFormatter = (values: any) => {
    const [face, orderDetails] = values;

    const totalBooked = orderDetails.reduce(
        (totalBooked: number, quantityBooked: number) => totalBooked + quantityBooked,
        0
    );

    return formatQuantity(face - totalBooked);
};
