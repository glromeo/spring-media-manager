function parseQueryNumber(text: string | null): number | null {
    return text !== null ? parseInt(text) : null;
}

export interface QueryParams {
    orderNumber: number | null;
    assetId: string | null;
    embedded: boolean;
    theme: "light" | "dark";
    user: string | null;
    simulate: boolean;
    isEligibleRequestStatus: boolean;
}

let cachedSearch: String;
let cachedQuery: QueryParams;

export function getQuery(search: string = window.location.search): QueryParams {
    if (cachedSearch === window.location.search) {
        return cachedQuery;
    }
    cachedSearch = window.location.search;
    const query = new URLSearchParams(search);

    const isERS = query.get("isEligibleRequestStatus");

    return (cachedQuery = {
        orderNumber: parseQueryNumber(query.get("orderNumber")),
        assetId: query.get("assetId"),
        embedded: !!query.get("embedded"),
        theme: query.get("theme") === "dark" ? "dark" : "light",
        user: query.get("user"),
        simulate: query.get("simulate") === "true",
        isEligibleRequestStatus: isERS === null || isERS === "true",
    });
}
